#!/usr/bin/env bash
set -euo pipefail
mkdir -p proof
adb install -r -t build/app.apk
adb install -r -t build/test.apk
for fixture in user-iqoo-3.bds iqoo.bds; do
  adb shell am instrument -w -e fixture "$fixture" com.mina.baidu.previewtest/com.mina.baidu.DevicePreviewTest | tee "proof/$fixture.txt"
done
adb root
adb wait-for-device
adb pull /data/data/com.mina.baidu/files/device-proof proof/
adb logcat -d -t 1500 > proof/logcat.txt
python3 - <<'PY'
from pathlib import Path
for p in Path('proof').glob('*.bds.txt'):
    assert 'Completed installed APK preview exercise.' in p.read_text(),p
PY
