package com.mina.baidu;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import java.io.*;
import java.util.*;

/** Runs the installed release DEX in ART and captures the displayed window. */
public final class DevicePreviewTest extends Instrumentation {
 private MainActivity activity;
 private String fixture;
 @Override public void onCreate(Bundle arguments) {
  fixture=arguments.getString("fixture","user-iqoo-3.bds");
  super.onCreate(arguments);start();
 }
 @Override public void callActivityOnCreate(Activity a,Bundle state) {
  super.callActivityOnCreate(a,state);
  if(a instanceof MainActivity) {
   activity=(MainActivity)a;activity.loginPending=true;
   try {
    File root=new File(activity.getFilesDir(),"projects/device-preview-"+System.currentTimeMillis());
    SkinCore.unzip(getContext().getAssets().open(fixture),root);
    activity.project=root;
    activity.getPreferences(0).edit().putString("archive:"+root.getName(),fixture).commit();
    activity.studio();
   } catch(Exception e) { throw new RuntimeException(e); }
  }
 }
 @Override public void onStart() {
  Bundle result=new Bundle();
  try {
   Intent intent=new Intent(Intent.ACTION_MAIN).setClassName(getTargetContext(),"com.mina.baidu.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
   startActivitySync(intent);waitForIdleSync();
   snapshot("initial");
   for(String name:new String[]{"en_26_num_h.ini","def_9.ini","hw_grid.ini","num_9.ini","py_26.ini"}) {
    runOnMainSync(()->activity.choosePanel());waitForIdleSync();
    tap("port/"+name);
    waitForIdleSync();snapshot(name);
   }
   result.putString("stream","\nCompleted installed APK preview exercise.\n");
   finish(Activity.RESULT_OK,result);
  } catch(Throwable error) {
   StringWriter trace=new StringWriter();error.printStackTrace(new PrintWriter(trace));
   result.putString("stream","\n"+trace);finish(Activity.RESULT_CANCELED,result);
  }
 }
 private void tap(String text)throws Exception {
  for(int attempt=0;attempt<25;attempt++) {
   AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow();
   if(root!=null) {
    List<AccessibilityNodeInfo> found=root.findAccessibilityNodeInfosByText(text);
    for(AccessibilityNodeInfo node:found) {
     if(node.getText()!=null&&node.getText().toString().contains(text)) {
      for(AccessibilityNodeInfo target=node;target!=null;target=target.getParent())
       if(target.isClickable()&&target.performAction(AccessibilityNodeInfo.ACTION_CLICK)){waitForIdleSync();SystemClock.sleep(350);return;}
     }
    }
    scroll(root);
   }
   SystemClock.sleep(250);
  }
  throw new AssertionError("Missing visible entry: "+text);
 }
 private boolean scroll(AccessibilityNodeInfo node) {
  if(node.isScrollable())return node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
  for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo child=node.getChild(i);if(child!=null&&scroll(child))return true;}
  return false;
 }
 private void snapshot(String name)throws Exception {
  waitForIdleSync();SystemClock.sleep(700);
  final String[] state={""};
  runOnMainSync(()->{
   MainActivity.SkinCanvas canvas=activity.canvas;
   StringBuilder s=new StringBuilder("selected=").append(activity.relative(activity.current));
   s.append(" preview=").append(canvas==null?"BDA":activity.relative(canvas.previewFile));
   if(canvas!=null) {
    s.append(" elements=").append(canvas.elements.size()).append(" hardware=").append(canvas.isHardwareAccelerated());
    s.append(" layer=").append(canvas.getLayerType()).append(" drawn=").append(canvas.drawnPanel);
    if(!activity.relative(activity.current).equals(canvas.drawnPanel)||canvas.drawCount<1||canvas.candidate==null||canvas.bitmaps.isEmpty())throw new AssertionError("Selected scene was not drawn with top bar/images: "+s);
    s.append(" text=").append(activity.text.hashCode()).append(" draft=").append(canvas.previewDraft.hashCode());
    s.append(" keys=");for(PreviewGeometry.Element e:canvas.elements)if(e.section.name.matches("KEY[0-9]+"))s.append(e.section.get("CENTER",e.section.get("KEY",""))).append(',');
   }
   state[0]=s.toString()+"\n"+activity.previewDiagnostics();
  });
  File out=new File(getTargetContext().getFilesDir(),"device-proof");out.mkdirs();
  Bitmap screen=getUiAutomation().takeScreenshot();
  if(screen==null)throw new IOException("Window capture unavailable");
  try(FileOutputStream stream=new FileOutputStream(new File(out,fixture+"-"+name+".png"))){screen.compress(Bitmap.CompressFormat.PNG,100,stream);}
  try(FileOutputStream stream=new FileOutputStream(new File(out,"state.txt"),true)){stream.write((fixture+" "+name+" "+state[0]+"\n").getBytes("UTF-8"));}
  Bundle progress=new Bundle();progress.putString("stream",fixture+" "+name+" "+state[0]+"\n");sendStatus(0,progress);
 }
}
