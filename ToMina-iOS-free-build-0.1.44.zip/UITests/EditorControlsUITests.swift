import XCTest
import UIKit

final class EditorControlsUITests: XCTestCase {
    func testSaveOpensSystemExportPanelAndToolsKeepLatestProject() {
        let app = openApp()
        app.buttons["保存"].tap()
        // Use the English system control; the Chinese app button remains in
        // the accessibility tree behind the sheet and is not proof of saving.
        let save = app.buttons["Save"]
        XCTAssertTrue(save.waitForExistence(timeout: 45))
        // Choose the provider location through Files itself. The directoryURL
        // hint on a fresh simulator can display an unresolved, read-only route.
        let local = app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "On My iPad")).firstMatch
        XCTAssertTrue(local.waitForExistence(timeout: 15)); local.tap()
        let documents = app.cells.containing(.staticText, identifier: "To.Mina").firstMatch
        XCTAssertTrue(documents.waitForExistence(timeout: 15)); documents.tap()
        let cancel = app.buttons.matching(NSPredicate(format: "label IN %@", ["Cancel", "取消"])).firstMatch
        XCTAssertTrue(cancel.waitForExistence(timeout: 10))
        proof(app, name: "System-save-panel-with-save-button")
        save.tap()
        if app.buttons["Replace"].waitForExistence(timeout: 3) { app.buttons["Replace"].tap() }
        XCTAssertTrue(app.staticTexts["已保存：controls.bds"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.buttons["⋮"].waitForExistence(timeout: 5)); app.buttons["⋮"].tap()
        app.buttons["工具箱"].tap()
        let clear = app.buttons["清除缓存"]
        XCTAssertTrue(clear.waitForExistence(timeout: 5)); clear.tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "已保留最新项目")).firstMatch.waitForExistence(timeout: 10))
        proof(app, name: "Clear-history-cache-keep-latest")
        app.buttons["关闭"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["editor.preview"].exists)
        app.buttons["保存"].tap()
        XCTAssertTrue(save.waitForExistence(timeout: 30)); save.tap()
        let replace = app.buttons["Replace"]
        XCTAssertTrue(replace.waitForExistence(timeout: 10))
        proof(app, name: "System-same-name-replace-confirmation")
        replace.tap()
        XCTAssertTrue(app.staticTexts["已保存：controls.bds"].waitForExistence(timeout: 15))
        proof(app, name: "Saved-again-after-cache-cleanup")
    }
    func testGlobalViewFitToolReportAndBorderToggle() {
        let app = openApp()
        app.buttons["⋮"].tap(); app.buttons["工具箱"].tap()
        let fit = app.buttons["VIEW 全局贴合"]
        XCTAssertTrue(fit.waitForExistence(timeout: 5)); fit.tap()
        let result = app.buttons["最近处理结果"]
        XCTAssertTrue(result.waitForExistence(timeout: 30)); result.tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "已处理")).firstMatch.waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["POS_TYPE 归零"].exists)
        app.buttons["POS_TYPE 归零"].tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "POS_TYPE 归零")).firstMatch.waitForExistence(timeout: 30))
        let borders = app.switches["显示 VIEW / LIST 边框"]
        XCTAssertTrue(borders.exists); borders.tap()
        proof(app, name: "Global-VIEW-tool-report-and-toggle")
        app.buttons["关闭"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["editor.preview"].waitForExistence(timeout: 5))
        proof(app, name: "Global-VIEW-borders-in-real-editor")
    }
    func testGlobalViewFitReplacesVisibleSourceAndOtherPanels() {
        let app=openApp(viewFit:true)
        app.buttons["editor.open"].tap()
        let before=app.textViews.firstMatch
        XCTAssertTrue(before.waitForExistence(timeout:5))
        XCTAssertTrue((before.value as? String ?? "").contains("VIEW_RECT=12,8,96,44"))
        proof(app,name:"VIEW-source-before-fitting")
        app.buttons["⋮"].tap();app.buttons["工具箱"].tap()
        app.buttons["VIEW 全局贴合"].tap()
        let show=app.buttons["查看修改源码"]
        XCTAssertTrue(show.waitForExistence(timeout:30));show.tap()
        let source=app.textViews.firstMatch
        XCTAssertTrue(source.waitForExistence(timeout:5))
        let refreshed=XCTNSPredicateExpectation(predicate:NSPredicate{_,_ in
            let value=source.value as? String ?? ""
            return value.contains("VIEW_RECT=0,0,120,60") && !value.contains("VIEW_RECT=12,8,96,44")
        },object:nil)
        XCTAssertEqual(XCTWaiter.wait(for:[refreshed],timeout:10),.completed)
        XCTAssertTrue((source.value as? String ?? "").contains("TOUCH_RECT=12,8,96,44"))
        proof(app,name:"VIEW-source-after-fitting-verified-in-real-editor")
        edit("other.ini",in:app)
        let other=app.textViews.firstMatch.value as? String ?? ""
        XCTAssertTrue(other.contains("CENTER=other"));XCTAssertTrue(other.contains("VIEW_RECT=0,0,120,60"))
        XCTAssertFalse(other.contains("VIEW_RECT=12,8,96,44"))
        proof(app,name:"VIEW-other-panel-source-after-fitting")
    }
    func testLandscapeSearchAndMenuVersion() {
        let app = openApp()
        XCUIDevice.shared.orientation = .landscapeLeft
        let settled = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            let frame = app.windows.firstMatch.frame
            return frame.width > frame.height && app.buttons["editor.operations"].frame.minX > frame.width * 0.5
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [settled], timeout: 12), .completed)
        app.buttons["editor.operations"].tap()
        let search = app.buttons["editor.search"]
        XCTAssertTrue(search.waitForExistence(timeout: 5)); search.tap()
        let input = app.textFields["editor.searchQuery"]
        XCTAssertTrue(input.waitForExistence(timeout: 5)); input.tap(); input.typeText("KEY1")
        XCTAssertTrue(app.staticTexts["editor.searchResult"].waitForExistence(timeout: 5))
        XCTAssertNotEqual(app.staticTexts["editor.searchResult"].label, "未找到关键词")
        XCTAssertTrue(app.textViews.firstMatch.exists)
        XCTAssertGreaterThan(app.textViews.firstMatch.frame.minX, app.windows.firstMatch.frame.width * 0.5)
        XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "app.version").firstMatch.exists)
        proof(app, name: "Landscape-search-left-preview-right-editor")
        let source = app.textViews.firstMatch
        let original = source.value as? String ?? ""
        jumpToEnd(app)
        source.typeText("\n; SEARCH-EDIT")
        XCTAssertEqual(source.value as? String, original + "\n; SEARCH-EDIT")
        proof(app, name: "Search-keeps-caret-while-editing")
        if app.buttons["收起键盘"].exists { app.buttons["收起键盘"].tap() }
        app.buttons["⋮"].tap()
        XCTAssertTrue(app.descendants(matching: .any).matching(NSPredicate(format: "label BEGINSWITH %@", "版本 0.1.44")).firstMatch.waitForExistence(timeout: 5))
        proof(app, name: "Version-only-in-menu")
    }
    func testListSourceAndRegionGuidesAfterGlobalFit() {
        let app=openApp(listFit:true)
        app.buttons["editor.open"].tap()
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("CELL_SIZE=40,26"))
        proof(app,name:"LIST-before-fitting-source-and-preview")
        app.buttons["⋮"].tap();app.buttons["工具箱"].tap();app.buttons["VIEW 全局贴合"].tap()
        let show=app.buttons["查看修改源码"]
        XCTAssertTrue(show.waitForExistence(timeout:30));show.tap()
        let source=app.textViews.firstMatch
        XCTAssertTrue(source.waitForExistence(timeout:5))
        let updated=XCTNSPredicateExpectation(predicate:NSPredicate{_,_ in
            let value=source.value as? String ?? ""
            return value.contains("POS=0,0") && value.contains("CELL_SIZE=52,30") && value.contains("VIEW_RECT=52,0,188,60")
        },object:nil)
        XCTAssertEqual(XCTWaiter.wait(for:[updated],timeout:10),.completed)
        XCTAssertTrue((source.value as? String ?? "").contains("VALUES=a b c d"))
        proof(app,name:"LIST-after-fitting-source-and-cell-borders")
    }
    private func jumpToEnd(_ app: XCUIApplication) {
        app.buttons["editor.operations"].tap()
        let jump = app.buttons["editor.jumpToEnd"]
        XCTAssertTrue(jump.waitForExistence(timeout: 5)); jump.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
    }
    func testJumpToLastLineOpensSourceAndPreservesLongDraft() {
        let app = openApp()
        jumpToEnd(app)
        XCTAssertTrue(app.buttons["editor.exit"].exists)
        let source = app.textViews.firstMatch
        let initial = source.value as? String ?? ""
        source.typeText("; tail")
        XCTAssertEqual(source.value as? String, initial + "; tail")
        app.buttons["editor.exit"].tap()
        edit("long.txt", in: app)
        jumpToEnd(app)
        let longText = source.value as? String ?? ""
        XCTAssertTrue(longText.hasSuffix("; END"))
        source.typeText("-FIRST")
        XCTAssertEqual(source.value as? String, longText + "-FIRST")
        XCUIDevice.shared.orientation = .landscapeLeft
        // XCUI can synthesize a tap using an intermediate rotation frame.
        // Wait for the actual action row to settle before opening its menu.
        var previous = CGRect.null, stableFrames = 0
        let settled = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            let window = app.windows.firstMatch.frame
            let frame = app.buttons["editor.operations"].frame
            guard window.width > window.height, frame == previous else {
                previous = frame; stableFrames = 0; return false
            }
            stableFrames += 1
            return stableFrames >= 3
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [settled], timeout: 10), .completed)
        jumpToEnd(app)
        source.typeText("-SECOND")
        XCTAssertEqual(source.value as? String, longText + "-FIRST-SECOND")
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = "Jump-to-last-line-keyboard-landscape"; attachment.lifetime = .keepAlways; add(attachment)
        app.buttons["editor.exit"].tap()
        app.buttons["editor.open"].tap()
        XCTAssertEqual(source.value as? String, longText + "-FIRST-SECOND")
    }
    func testJumpToLastLineKeepsAnimationEditorAndDraft() {
        // XCUI waits up to 60 seconds for each continuous preview/menu
        // animation to become idle even while the app remains interactive.
        executionTimeAllowance = 180
        let app = openApp()
        app.buttons["漂浮预览"].tap()
        app.buttons["animation.selector"].tap(); app.buttons["ANIM1"].tap()
        let source = app.textViews.firstMatch
        let initial = source.value as? String ?? ""
        XCTAssertTrue(initial.contains("[ANIM1]"))
        jumpToEnd(app)
        source.typeText("\n; animation tail")
        XCTAssertEqual(source.value as? String, initial + "\n; animation tail")
        jumpToEnd(app)
        source.typeText("-SECOND")
        XCTAssertEqual(source.value as? String, initial + "\n; animation tail-SECOND")
        XCTAssertTrue(app.buttons["退出漂浮"].exists)
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = "Jump-to-last-line-animation"; attachment.lifetime = .keepAlways; add(attachment)
    }
    override func setUpWithError() throws { continueAfterFailure = false }

    private func openApp(viewFit:Bool=false,listFit:Bool=false) -> XCUIApplication {
        XCUIDevice.shared.orientation = .portrait
        let app = XCUIApplication()
        app.launchArguments = ["--editor-controls-fixture"]
        if viewFit {app.launchArguments.append("--view-fit-fixture")}
        if listFit {app.launchArguments.append("--list-fit-fixture")}
        app.launch()
        XCTAssertTrue(app.buttons["包内文件夹：controls.bds"].waitForExistence(timeout: 15))
        XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "app.version").firstMatch.exists)
        return app
    }
    private func edit(_ file: String, in app: XCUIApplication, folder: String? = nil) {
        app.buttons["包内文件夹：controls.bds"].tap()
        if let folder { app.buttons[folder].tap() }
        let row = app.buttons[file]
        XCTAssertTrue(row.waitForExistence(timeout: 5))
        row.tap()
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout: 5))
    }
    private func assertNextToPanel(_ app: XCUIApplication, action: String) {
        let panel = app.buttons["editor.panel"], source = app.buttons[action]
        XCTAssertTrue(panel.isHittable); XCTAssertTrue(source.isHittable)
        XCTAssertEqual(source.frame.midY, panel.frame.midY, accuracy: 1)
        XCTAssertGreaterThanOrEqual(source.frame.minX, panel.frame.maxX)
        XCTAssertLessThanOrEqual(source.frame.minX - panel.frame.maxX, 8)
    }
    private func cleanup(_ app: XCUIApplication) {
        XCTAssertFalse(app.buttons["editor.cssCleanup"].isHittable)
        app.buttons["editor.operations"].tap()
        let button = app.buttons["editor.cssCleanup"]
        XCTAssertTrue(button.waitForExistence(timeout: 5)); XCTAssertTrue(button.isHittable)
        XCTAssertEqual(app.buttons.matching(identifier: "editor.cssCleanup").count, 1)
        proof(app, name: "CSS-cleanup-in-edit-menu")
        button.tap()
    }
    private func proof(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways
        add(attachment)
    }
    func testINIEditorHasOneVisibleExitAndCanReturn() {
        let app = openApp(); edit("py_26.ini", in: app, folder: "port")
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertEqual(app.buttons.matching(identifier: "editor.exit").count, 1)
        XCTAssertFalse(app.buttons["editor.cssCleanup"].isHittable)
        proof(app, name: "INI-editor-exit-next-to-panel")
        app.buttons["editor.exit"].tap()
        XCTAssertTrue(app.buttons["editor.open"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.textViews.firstMatch.exists)
        assertNextToPanel(app, action: "editor.open")
        app.buttons["editor.open"].tap()
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout: 5))
    }
    func testCSSCleanupMenuClearsUnusedBodyKeepsHeaderAndUndoRestoresIt() {
        let app = openApp(); edit("styles.css", in: app)
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]"))
        proof(app, name: "CSS-editor-adjacent-actions")
        cleanup(app)
        XCTAssertTrue(app.staticTexts["已清空 1 个未调用样式的内容，标题保留，可撤销"].waitForExistence(timeout: 5))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]\n[STYLE3]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("STYLE_NUM=3\n"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE1]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE3]"))
        proof(app, name: "CSS-cleanup-keeps-STYLE-headers")
        app.buttons["editor.operations"].tap(); app.buttons["撤销"].tap()
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]\nNM_COLOR=FF000000"))
    }
    func testCSSCleanupCanBeOpenedFromINIMenu() {
        let app = openApp(); edit("py_26.ini", in: app, folder: "port")
        cleanup(app)
        XCTAssertTrue(app.staticTexts["已清空 1 个未调用样式的内容，标题保留，可撤销"].waitForExistence(timeout: 5))
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE1]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE3]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]\n[STYLE3]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("STYLE_NUM=3\n"))
    }
    func testEditorActionsRemainHittableWithKeyboardAndLandscape() {
        let app = openApp(); edit("styles.css", in: app)
        app.textViews.firstMatch.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertTrue(app.buttons["editor.operations"].isHittable)
        XCUIDevice.shared.orientation = .landscapeLeft
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout: 5))
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertTrue(app.buttons["editor.operations"].isHittable)
        proof(app, name: "Editor-actions-keyboard-landscape")
        app.buttons["editor.exit"].tap()
        XCTAssertTrue(app.buttons["editor.open"].waitForExistence(timeout: 5))
    }
    func testFloatingButtonsHaveEqualFramesIncludingMenuAndPauseState() {
        let app = openApp()
        XCTAssertTrue(app.buttons["漂浮预览"].isHittable)
        app.buttons["漂浮预览"].tap()
        let ids = ["animation.replay", "animation.pause", "animation.selector", "animation.images", "animation.log"]
        for id in ids {
            let button = app.buttons[id]
            XCTAssertTrue(button.waitForExistence(timeout: 5)); XCTAssertTrue(button.isHittable)
            XCTAssertEqual(button.frame.width, 88, accuracy: 1)
            XCTAssertEqual(button.frame.height, 32, accuracy: 1)
        }
        proof(app, name: "Floating-controls-equal-size")
        app.buttons["animation.pause"].tap()
        XCTAssertEqual(app.buttons["animation.pause"].label, "继续")
        XCTAssertEqual(app.buttons["animation.pause"].frame.width, 88, accuracy: 1)
        XCTAssertEqual(app.buttons["animation.pause"].frame.height, 32, accuracy: 1)
        app.buttons["animation.pause"].tap()
        app.buttons["animation.selector"].tap()
        let panelBinding = app.buttons["animation.panelBinding"]
        XCTAssertTrue(panelBinding.waitForExistence(timeout: 5))
        XCTAssertTrue(panelBinding.isHittable)
        panelBinding.tap()
        XCTAssertEqual(app.buttons["animation.selector"].frame.width, 88, accuracy: 1)
        XCTAssertEqual(app.buttons["animation.selector"].frame.height, 32, accuracy: 1)
    }
    func testAnimationEditorAppendsNewBlockAndPersistsItInAnimINI() {
        let app = openApp()
        app.buttons["漂浮预览"].tap()
        app.buttons["animation.selector"].tap()
        app.buttons["ANIM1"].tap()
        let editor = app.textViews.firstMatch
        XCTAssertTrue(editor.waitForExistence(timeout:5))
        XCTAssertTrue((editor.value as? String ?? "").contains("[ANIM1]"))
        // The fixture has a short document. Tapping below its text puts the
        // caret at the end, just as a user appending an animation would do.
        editor.coordinate(withNormalizedOffset:CGVector(dx:0.8,dy:0.85)).tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout:5))
        editor.typeText("\n\n[ANIM18]\nTYPE=4\nDURATION=250\n")
        XCTAssertTrue((editor.value as? String ?? "").contains("[ANIM18]"))
        app.buttons["退出漂浮"].tap()
        XCTAssertFalse(app.alerts.firstMatch.exists)
        edit("anim.ini",in:app)
        let source = app.textViews.firstMatch.value as? String ?? ""
        XCTAssertTrue(source.contains("[ANIM1]"))
        XCTAssertTrue(source.contains("[ANIM18]"))
        XCTAssertTrue(source.contains("ANIM_NUM=2"))
        XCTAssertTrue(source.contains("DURATION=250"))
        proof(app,name:"Added-ANIM18-saved-in-anim-ini")
    }
    private func combinedApp(narrow:Bool=false)->XCUIApplication {
        XCUIDevice.shared.orientation = .portrait
        let app=XCUIApplication()
        app.launchArguments=["--combined-preview-fixture"] + (narrow ? ["--narrow-preview-fixture"] : [])
        app.launch()
        XCTAssertTrue(app.buttons["包内文件夹：combined.bds"].waitForExistence(timeout:15))
        return app
    }
    func testArchiveFileCopyAndConfirmedBatchDeletion() {
        let app = openApp()
        app.buttons["包内文件夹：controls.bds"].tap()
        let original = app.buttons["styles.css"]
        XCTAssertTrue(original.waitForExistence(timeout: 5))
        original.press(forDuration: 1)
        app.buttons["复制文件"].tap()
        let first = app.buttons["styles 副本.css"]
        XCTAssertTrue(first.waitForExistence(timeout: 5))
        original.press(forDuration: 1)
        app.buttons["复制文件"].tap()
        let second = app.buttons["styles 副本 2.css"]
        XCTAssertTrue(second.waitForExistence(timeout: 5))
        proof(app, name: "Archive-copies-preserve-original")
        app.buttons["多选"].tap(); first.tap(); second.tap()
        XCTAssertTrue(app.staticTexts["已选 2 个文件"].exists)
        app.buttons["archive.deleteSelected"].tap()
        XCTAssertTrue(app.alerts.firstMatch.waitForExistence(timeout: 5))
        app.alerts.firstMatch.buttons["取消"].tap()
        XCTAssertTrue(first.exists); XCTAssertTrue(second.exists); XCTAssertTrue(original.exists)
        app.buttons["archive.deleteSelected"].tap()
        proof(app, name: "Archive-batch-delete-confirmation")
        app.alerts.firstMatch.buttons["删除"].tap()
        XCTAssertTrue(app.staticTexts["已删除 2 个文件"].waitForExistence(timeout: 5))
        XCTAssertFalse(first.exists); XCTAssertFalse(second.exists)
        XCTAssertTrue(original.exists); XCTAssertTrue(app.buttons["port"].exists)
        proof(app, name: "Archive-batch-delete-keeps-unselected-files")
    }
    private func preview(_ app:XCUIApplication)->XCUIElement {
        app.descendants(matching:.any).matching(identifier:"editor.preview").firstMatch
    }
    private func screenPoint(_ app:XCUIApplication,_ x:CGFloat,_ y:CGFloat)->CGPoint {
        let r=preview(app).frame,scale=min((r.width-16)/1080,(r.height-16)/760)
        return CGPoint(x:r.midX-1080*scale/2+x*scale,y:r.midY-760*scale/2+(y+120)*scale)
    }
    private func tapScene(_ app:XCUIApplication,_ x:CGFloat,_ y:CGFloat) {
        let point=screenPoint(app,x,y)
        app.coordinate(withNormalizedOffset:.zero).withOffset(CGVector(dx:point.x,dy:point.y)).tap()
    }
    private func assertCompletePreview(_ app:XCUIApplication,name:String) {
        let canvas=preview(app)
        XCTAssertTrue(canvas.waitForExistence(timeout:5))
        XCTAssertEqual(canvas.label,"顶栏与键盘预览")
        XCTAssertEqual(canvas.value as? String,"py_26 · cand1.cnd")
        // Capture the physical screen. Application screenshots can retain a
        // portrait crop immediately after rotation on the iPad simulator.
        let screenshot=XCUIScreen.main.screenshot(),raw=screenshot.image
        let attachment=XCTAttachment(screenshot:screenshot);attachment.name=name;attachment.lifetime = .keepAlways;add(attachment)
        // XCUIScreenshot may carry landscape orientation in UIImage metadata.
        // Draw through UIImage before comparing against screen coordinates.
        let format=UIGraphicsImageRendererFormat();format.scale=raw.scale
        let image=UIGraphicsImageRenderer(size:raw.size,format:format).image { _ in raw.draw(in:CGRect(origin:.zero,size:raw.size)) }
        print("PREVIEW_SCREEN: \(name), app=\(app.frame), canvas=\(canvas.frame), raw=\(raw.size), orientation=\(raw.imageOrientation.rawValue), normalized=\(image.size)")
        guard let cg=image.cgImage else { XCTFail("No preview screenshot");return }
        var bytes=[UInt8](repeating:0,count:cg.width*cg.height*4)
        guard let ctx=CGContext(data:&bytes,width:cg.width,height:cg.height,bitsPerComponent:8,bytesPerRow:cg.width*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else { XCTFail("Cannot read screenshot");return }
        ctx.draw(cg,in:CGRect(x:0,y:0,width:cg.width,height:cg.height))
        let pixelScale=CGFloat(cg.width)/image.size.width
        for (point,expected) in [(screenPoint(app,540,-105),[160,96,64]),(screenPoint(app,20,620),[64,128,192])] {
            XCTAssertTrue(canvas.frame.contains(point))
            let x=Int(point.x*pixelScale),y=Int(point.y*pixelScale)
            guard x>=0,y>=0,x<cg.width,y<cg.height else { XCTFail("Preview cropped");continue }
            let offset=(y*cg.width+x)*4
            for channel in 0..<3 { XCTAssertEqual(Double(bytes[offset+channel]),Double(expected[channel]),accuracy:8,"Missing top bar or bottom keyboard pixels") }
        }
    }
    func testTopBarAndKeyboardRemainVisibleThroughAnimationAndBarEditing() {
        let app=combinedApp()
        assertCompletePreview(app,name:"Combined-top-bar-and-keyboard")
        app.buttons["动效预览"].tap();tapScene(app,54,80)
        XCTAssertTrue(app.buttons["退出动效"].waitForExistence(timeout:5))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[ANIM1]"))
        assertCompletePreview(app,name:"Combined-preview-during-animation-editing")
        tapScene(app,540,-60)
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout:5))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[CAND]"))
        XCTAssertFalse((app.textViews.firstMatch.value as? String ?? "").contains("[KEY1]"))
        assertCompletePreview(app,name:"Combined-preview-while-editing-CND")
        tapScene(app,54,80)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[KEY1]"))
        XCUIDevice.shared.orientation = .landscapeLeft
        assertCompletePreview(app,name:"Combined-preview-landscape")
    }
    func testNarrowPreviewAndSoftwareKeyboardKeepTopBarAndBottomRowVisible() {
        let app=combinedApp(narrow:true)
        XCTAssertEqual(preview(app).frame.width,375,accuracy:1)
        assertCompletePreview(app,name:"Combined-preview-375-point-width")
        // A drag at fit size must not displace/crop the top of the skin.
        let canvas=preview(app)
        canvas.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:0.5)).press(forDuration:0.1,thenDragTo:canvas.coordinate(withNormalizedOffset:CGVector(dx:0.7,dy:0.2)))
        assertCompletePreview(app,name:"Combined-preview-after-drag-at-fit")
        app.buttons["editor.open"].tap();app.textViews.firstMatch.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout:5))
        assertCompletePreview(app,name:"Combined-preview-with-software-keyboard")
    }
}
