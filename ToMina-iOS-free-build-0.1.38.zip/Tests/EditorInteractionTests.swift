import XCTest
import SwiftUI
import UIKit
@testable import ToMina

final class EditorInteractionTests: XCTestCase {
    @MainActor func testJumpToEndPreservesUnicodeDraftAndRevealsCaretAfterResize() async throws {
        let draft = EditorDraft(), focus = Focus()
        let original = (0..<600).map { "; 第\($0)行 👩🏽‍🎨" }.joined(separator: "\n") + "\n"
        draft.replace(original)
        func editor() -> DraftTextEditor {
            DraftTextEditor(draft: draft, focused: Binding(get: { focus.active }, set: { focus.active = $0 }),
                edit: { value, _ in draft.acceptTyping(value); return true }, finish: {})
        }
        let host = UIHostingController(rootView: editor()), window = UIWindow(frame: CGRect(x: 0, y: 0, width: 375, height: 600))
        window.rootViewController = host; window.makeKeyAndVisible(); defer { window.isHidden = true }
        host.view.layoutIfNeeded()
        let view = try XCTUnwrap(input(host.view))
        view.selectedRange = NSRange(location: 0, length: 0)
        view.insertText("; unsaved\n")
        let latest = draft.text, revision = draft.revision
        draft.requestEnd(); host.rootView = editor(); host.view.layoutIfNeeded()
        try await Task.sleep(for: .milliseconds(100))
        view.layoutIfNeeded()
        XCTAssertEqual(view.text, latest); XCTAssertEqual(draft.revision, revision)
        XCTAssertEqual(view.selectedRange, NSRange(location: (latest as NSString).length, length: 0))
        XCTAssertTrue(view.isFirstResponder)
        // Resize the editor itself, as split view does. Shrinking the whole
        // test window below the software keyboard leaves no visible editor.
        view.frame.size = CGSize(width: 320, height: 120)
        view.setNeedsLayout(); view.layoutIfNeeded()
        let caret = view.caretRect(for: view.endOfDocument)
        XCTAssertTrue(view.bounds.insetBy(dx: 0, dy: -1).contains(caret), "Final caret \(caret), visible bounds \(view.bounds)")
        view.insertText("; appended")
        XCTAssertEqual(draft.text, latest + "; appended")
        // A completed request must not jump again on a preview redraw.
        view.selectedRange = NSRange(location: 0, length: 0)
        host.rootView = editor(); host.view.layoutIfNeeded()
        XCTAssertEqual(view.selectedRange.location, 0)
        draft.requestEnd(); host.rootView = editor(); host.view.layoutIfNeeded()
        try await Task.sleep(for: .milliseconds(100))
        XCTAssertEqual(view.selectedRange.location, (draft.text as NSString).length)
    }
    @MainActor func testJumpToEndHandlesEmptyDocumentAndPendingRequestBeforeOpening() async throws {
        let draft = EditorDraft(); draft.requestEnd()
        let host = UIHostingController(rootView: DraftTextEditor(draft: draft, focused: .constant(false),
            edit: { value, _ in draft.acceptTyping(value); return true }, finish: {}))
        let window = UIWindow(frame: CGRect(x: 0, y: 0, width: 375, height: 400))
        window.rootViewController = host; window.makeKeyAndVisible(); defer { window.isHidden = true }
        host.view.layoutIfNeeded()
        let view = try XCTUnwrap(input(host.view))
        try await Task.sleep(for: .milliseconds(100))
        XCTAssertEqual(view.selectedRange, NSRange(location: 0, length: 0))
        XCTAssertTrue(view.isFirstResponder)
        view.insertText("First line")
        XCTAssertEqual(draft.text, "First line")
        XCTAssertFalse(draft.consumeEndRequest())
    }
    @MainActor private final class Focus: ObservableObject { @Published var active = false }
    @MainActor private func input(_ view: UIView) -> UITextView? {
        if let value = view as? UITextView { return value }
        return view.subviews.lazy.compactMap { self.input($0) }.first
    }
    @MainActor func testNativeTapOpensKeyboardAndTypingSurvivesPreviewUpdates() async throws {
        let draft = EditorDraft(), focus = Focus(); draft.replace("[PANEL]\nSIZE=240,120\n")
        var finishes = 0
        func editor() -> DraftTextEditor {
            DraftTextEditor(draft: draft, focused: Binding(get: { focus.active }, set: { focus.active = $0 }),
                edit: { value, _ in draft.acceptTyping(value); return true }, finish: { finishes += 1 })
        }
        let host = UIHostingController(rootView: editor()), window = UIWindow(frame: CGRect(x: 0,y: 0,width: 400,height: 600))
        window.rootViewController = host; window.makeKeyAndVisible(); defer { window.isHidden = true }
        host.view.layoutIfNeeded()
        let view = try XCTUnwrap(input(host.view))
        XCTAssertTrue(view.isEditable); XCTAssertTrue(view.becomeFirstResponder())
        XCTAssertTrue(focus.active)
        for _ in 0..<4 { host.rootView = editor(); host.view.layoutIfNeeded(); await Task.yield() }
        XCTAssertTrue(view.isFirstResponder, "Preview updates closed the native keyboard")
        view.selectedRange = NSRange(location: (view.text as NSString).length, length: 0)
        view.insertText("; typing works")
        XCTAssertTrue(draft.text.hasSuffix("; typing works"))
        focus.active = false; host.rootView = editor(); host.view.layoutIfNeeded()
        try await Task.sleep(for: .milliseconds(100))
        XCTAssertFalse(view.isFirstResponder); XCTAssertGreaterThan(finishes, 0)
        XCTAssertTrue(view.becomeFirstResponder(), "The editor cannot reopen the keyboard")
    }
    @MainActor func testAnimationEditorFocusAndDisableFinishLatestDraft() async throws {
        let draft = EditorDraft(), focus = Focus(); draft.replace("[ANIM1]\nDURATION=180\n")
        var latest = ""
        func editor(_ enabled: Bool) -> some View {
            DraftTextEditor(draft: draft, focused: Binding(get: { focus.active }, set: { focus.active = $0 }),
                edit: { value, _ in draft.acceptTyping(value); return true }, finish: { latest = draft.text }).disabled(!enabled)
        }
        let host = UIHostingController(rootView: AnyView(editor(true))), window = UIWindow(frame: CGRect(x: 0,y: 0,width: 380,height: 500))
        window.rootViewController = host; window.makeKeyAndVisible(); defer { window.isHidden = true }
        host.view.layoutIfNeeded()
        let view = try XCTUnwrap(input(host.view)); XCTAssertTrue(view.becomeFirstResponder())
        view.selectedRange = NSRange(location: (view.text as NSString).length, length: 0); view.insertText("; 中文")
        host.rootView = AnyView(editor(false)); host.view.layoutIfNeeded()
        try await Task.sleep(for: .milliseconds(100))
        XCTAssertFalse(view.isFirstResponder); XCTAssertFalse(view.isEditable); XCTAssertTrue(latest.hasSuffix("; 中文"))
        host.rootView = AnyView(editor(true)); host.view.layoutIfNeeded()
        try await Task.sleep(for: .milliseconds(100))
        XCTAssertTrue(view.isEditable); XCTAssertTrue(view.becomeFirstResponder())
    }
}
