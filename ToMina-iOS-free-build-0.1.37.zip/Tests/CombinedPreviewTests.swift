import XCTest
import SwiftUI
import UIKit
import ZIPFoundation
@testable import ToMina

final class CombinedPreviewTests: XCTestCase {
    @MainActor private func fixture() async throws -> (SkinStore,URL) {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString), skin = folder.appendingPathComponent("skin")
        let res = skin.appendingPathComponent("port/res");try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        try "[PANEL]\nSIZE=240,120\n[CAND]\nLAYOUT_NAME=bar.cnd\nVIEW_RECT=0,0,240,40\n".write(to:skin.appendingPathComponent("port/gen.ini"),atomically:true,encoding:.utf8)
        try "[PANEL]\n[KEY1]\nVIEW_RECT=10,10,60,60\nBACK_STYLE=2\nCENTER=q\n".write(to:skin.appendingPathComponent("port/py_26.ini"),atomically:true,encoding:.utf8)
        try "[CAND]\nBACK_STYLE=1\nFORE_STYLE=4\n[ICON1]\nVIEW_RECT=10,5,20,20\nBACK_STYLE=3\nPERSIST=3\n".write(to:skin.appendingPathComponent("port/bar.cnd"),atomically:true,encoding:.utf8)
        try "[STYLE1]\nNM_COLOR=FFFF0000\n[STYLE2]\nNM_COLOR=FF0000FF\n[STYLE3]\nNM_COLOR=FF00FF00\n[STYLE4]\nNM_IMG=decor,1\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try "[IMG1]\nSOURCE_RECT=0,0,8,8\n".write(to:res.appendingPathComponent("decor.til"),atomically:true,encoding:.utf8)
        try "[ANIM1]\nTYPE=1\nFROM=0\nTO=20\nDURATION=250\n".write(to:res.appendingPathComponent("anim.ini"),atomically:true,encoding:.utf8)
        let format = UIGraphicsImageRendererFormat();format.scale=1
        let image = UIGraphicsImageRenderer(size:CGSize(width:8,height:8),format:format).image { ctx in UIColor.yellow.setFill();ctx.fill(CGRect(x:0,y:0,width:8,height:8)) }
        try XCTUnwrap(image.pngData()).write(to:res.appendingPathComponent("decor.png"))
        let original=folder.appendingPathComponent("keyboard.bds");try FileManager.default.zipItem(at:skin,to:original,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(original);XCTAssertNil(store.error)
        return (store,folder)
    }
    @MainActor private func cleanup(_ store:SkinStore,_ folder:URL) {
        store.finishSourceEditing();if let root=store.root{try? FileManager.default.removeItem(at:root)}
        try? FileManager.default.removeItem(at:folder)
    }
    private func rgb(_ image:CGImage,_ x:Int,_ y:Int)throws->[UInt8] {
        var bytes=[UInt8](repeating:0,count:image.width*image.height*4)
        let bitmap=try XCTUnwrap(CGContext(data:&bytes,width:image.width,height:image.height,bitsPerComponent:8,bytesPerRow:image.width*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue))
        bitmap.draw(image,in:CGRect(x:0,y:0,width:image.width,height:image.height))
        let offset=(y*image.width+x)*4;return Array(bytes[offset..<offset+3])
    }
    @MainActor func testKeyboardTopBarIconsAndBarForegroundRenderTogether() async throws {
        let (store,folder)=try await fixture();defer{cleanup(store,folder)}
        XCTAssertEqual(store.renderer.candidateFile?.lastPathComponent,"bar.cnd")
        let bounds=store.renderer.previewBounds(panel:store.panel,keys:store.keys)
        XCTAssertEqual(bounds,CGRect(x:0,y:-40,width:240,height:160))
        let scene=Canvas { context,_ in
            context.translateBy(x:0,y:40)
            store.renderer.drawPreview(panel:store.panel,keys:store.keys,pressed:false,scale:1,rasterScale:1,context:&context)
        }.frame(width:240,height:160)
        let painter=ImageRenderer(content:scene);painter.scale=1;let pixels=try XCTUnwrap(painter.cgImage)
        XCTAssertEqual(try rgb(pixels,2,2),[255,0,0])
        XCTAssertEqual(try rgb(pixels,15,12),[0,255,0])
        XCTAssertEqual(try rgb(pixels,120,20),[255,255,0])
        XCTAssertEqual(try rgb(pixels,20,90),[0,0,255])
    }
    @MainActor func testCandidateAndGenLongPressEditingKeepFullKeyboardPreview() async throws {
        let (store,folder)=try await fixture();defer{cleanup(store,folder)}
        let preview=store.previewPanelName,cnd=try XCTUnwrap(store.files.first{$0.lastPathComponent=="bar.cnd"})
        try store.openForEditing(cnd)
        XCTAssertEqual(store.current,cnd);XCTAssertEqual(store.previewPanelName,preview);XCTAssertTrue(store.keys.contains{$0.name=="KEY1"})
        _=store.editSource(store.text.replacingOccurrences(of:"BACK_STYLE=1",with:"BACK_STYLE=3"));store.finishSourceEditing()
        XCTAssertEqual(store.renderer.candidateSections.first?.values["BACK_STYLE"],"3")
        let gen=try XCTUnwrap(store.files.first{$0.lastPathComponent=="gen.ini"});try store.openForEditing(gen)
        _=store.editSource(store.text.replacingOccurrences(of:"240,40",with:"240,64"));store.finishSourceEditing()
        XCTAssertEqual(store.previewPanelName,preview);XCTAssertEqual(store.renderer.candidateSize.height,64)
        XCTAssertTrue(store.keys.contains{$0.name=="KEY1"})
    }
    @MainActor func testEmptyIniRemainsBlankWithAvailableTopBar() async throws {
        let (store,folder)=try await fixture();defer{cleanup(store,folder)}
        store.change("[PANEL]\nSIZE=240,120\n[CAND]\n")
        XCTAssertTrue(store.blankPreview);XCTAssertTrue(store.keys.isEmpty)
    }
    @MainActor func testTapTopBarThenKeyboardKeepsCompositionAndEditsCorrectFile() async throws {
        let (store,folder)=try await fixture();defer{cleanup(store,folder)}
        let panel = store.current
        try store.editCandidateBar()
        XCTAssertEqual(store.current?.lastPathComponent,"bar.cnd")
        XCTAssertEqual(store.previewPanelName,"py_26")
        XCTAssertEqual(store.renderer.previewBounds(panel:store.panel,keys:store.keys),CGRect(x:0,y:-40,width:240,height:160))
        XCTAssertTrue(store.keys.contains{$0.name == "KEY1"})
        try store.editPreviewKeyboard()
        XCTAssertEqual(store.current,panel)
        XCTAssertEqual(store.renderer.candidateFile?.lastPathComponent,"bar.cnd")
        XCTAssertTrue(store.parsedText.contains{$0.name == "KEY1"})
    }
    @MainActor func testAnimationSourceEditingRetainsKeyboardAndBar() async throws {
        let (store,folder)=try await fixture();defer{cleanup(store,folder)}
        try store.openForEditing(XCTUnwrap(store.files.first{$0.lastPathComponent == "anim.ini"}))
        XCTAssertFalse(store.blankPreview)
        XCTAssertEqual(store.previewPanelName,"py_26")
        XCTAssertEqual(store.renderer.candidateFile?.lastPathComponent,"bar.cnd")
        _ = store.editSource(store.text.replacingOccurrences(of:"DURATION=250",with:"DURATION=500"))
        store.finishSourceEditing()
        XCTAssertEqual(store.renderer.timeline.definitions["1"]?["DURATION"],"500")
        XCTAssertEqual(store.renderer.candidateSize,CGSize(width:240,height:40))
        XCTAssertTrue(store.keys.contains{$0.name == "KEY1"})
    }
    @MainActor func testRestoreOldStandaloneCandidateSessionRecoversCombinedPreview() async throws {
        let (store,folder)=try await fixture();defer{cleanup(store,folder)}
        try store.open(XCTUnwrap(store.renderer.candidateFile))
        XCTAssertEqual(store.previewPanelName,"bar")
        let record = folder.appendingPathComponent("session.json")
        var view=EditorViewState();view.zoom=2;view.panX=150;view.panY = -100
        try await store.saveSession(view,recordFile:record)
        let restored = SkinStore()
        let restoredState = try await restored.restoreSession(recordFile:record)
        defer{if let root=restored.root{try? FileManager.default.removeItem(at:root)}}
        XCTAssertEqual(restored.current?.lastPathComponent,"bar.cnd")
        XCTAssertEqual(restored.previewPanelName,"py_26")
        XCTAssertEqual(restored.renderer.candidateFile?.lastPathComponent,"bar.cnd")
        XCTAssertTrue(restored.keys.contains{$0.name == "KEY1"})
        XCTAssertEqual(restoredState?.zoom,1);XCTAssertEqual(restoredState?.panX,0);XCTAssertEqual(restoredState?.panY,0)
    }
    func testCompleteTopBarAndKeyboardFitPhoneSplitViewAndLandscape() {
        let bounds = CGRect(x:0,y:-120,width:1080,height:760)
        for area in [CGSize(width:375,height:264),CGSize(width:320,height:232),CGSize(width:507,height:232),CGSize(width:1024,height:320),CGSize(width:507,height:96)] {
            let view = PreviewViewport(bounds:bounds,available:area,pan:CGSize(width:250,height:-180))
            let top = view.point(CGPoint(x:0,y:-120)),bottom=view.point(CGPoint(x:1080,y:640))
            XCTAssertGreaterThanOrEqual(top.x,7.99);XCTAssertGreaterThanOrEqual(top.y,7.99)
            XCTAssertLessThanOrEqual(bottom.x,area.width-7.99);XCTAssertLessThanOrEqual(bottom.y,area.height-7.99)
            let bar = CGPoint(x:540,y:-60),key = CGPoint(x:540,y:500)
            XCTAssertEqual(view.scenePoint(view.point(bar)).y,bar.y,accuracy:0.001)
            XCTAssertEqual(view.scenePoint(view.point(key)).y,key.y,accuracy:0.001)
        }
        let zoomed=PreviewViewport(bounds:bounds,available:CGSize(width:507,height:232),zoom:2,pan:CGSize(width:60,height:40))
        let centered=PreviewViewport(bounds:bounds,available:CGSize(width:507,height:232),zoom:2)
        XCTAssertEqual(zoomed.origin.x-centered.origin.x,60,accuracy:0.001)
        XCTAssertEqual(zoomed.origin.y-centered.origin.y,40,accuracy:0.001)
    }
}
