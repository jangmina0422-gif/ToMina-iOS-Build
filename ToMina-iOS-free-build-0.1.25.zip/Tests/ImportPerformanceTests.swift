import XCTest
import SwiftUI
import UIKit
import ZIPFoundation
import ImageIO
import UniformTypeIdentifiers
@testable import ToMina

final class ImportPerformanceTests:XCTestCase {
    private func directory()throws->URL {
        let url=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:url,withIntermediateDirectories:true);return url
    }
    private func fixture(_ directory:URL,extras:Int=0)throws->URL {
        let root=directory.appendingPathComponent("skin"),port=root.appendingPathComponent("port"),res=root.appendingPathComponent("res")
        try FileManager.default.createDirectory(at:port,withIntermediateDirectories:true)
        try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        var layout="[PANEL]\nSIZE=720,400\nKEY_NUM=60\n"
        for i in 0..<60{layout += "[KEY\(i+1)]\nVIEW_RECT=\((i%10)*72),\((i/10)*60),64,52\nBACK_STYLE=1\nFORE_STYLE=2\nCENTER=q\n"}
        try layout.write(to:port.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
        var css="[STYLE1]\nNM_COLOR=FFFF0000\n[STYLE2]\nFONT_SIZE=24\nNM_COLOR=FF000000\n"
        for i in 3..<703{css += "[STYLE\(i)]\nFONT_SIZE=18\nNM_COLOR=FF000000\n"}
        try css.write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        for i in 0..<extras{try "[META]\nVALUE=\(i)\n".write(to:res.appendingPathComponent("extra\(i).ini"),atomically:true,encoding:.utf8)}
        let archive=directory.appendingPathComponent("input.bds")
        try FileManager.default.zipItem(at:root,to:archive,shouldKeepParent:false);return archive
    }
    @MainActor private func raster(_ size:CGSize,_ draw:@escaping (inout GraphicsContext)->Void)throws->CGImage {
        let output=ImageRenderer(content:Canvas{context,_ in draw(&context)}.frame(width:size.width,height:size.height));output.scale=1
        return try XCTUnwrap(output.cgImage)
    }
    private func rgb(_ image:CGImage,x:Int,y:Int)throws->[UInt8] {
        let piece=try XCTUnwrap(image.cropping(to:CGRect(x:x,y:y,width:1,height:1)))
        var bytes=[UInt8](repeating:0,count:4)
        try bytes.withUnsafeMutableBytes{buffer in
            let c=try XCTUnwrap(CGContext(data:buffer.baseAddress,width:1,height:1,bitsPerComponent:8,bytesPerRow:4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue));c.draw(piece,in:CGRect(x:0,y:0,width:1,height:1))
        }
        return Array(bytes.prefix(3))
    }
    @MainActor func testLargeImportPreparesOffMainWhileInterfaceTicks()async throws {
        let dir=try directory();defer{try? FileManager.default.removeItem(at:dir)}
        let input=try fixture(dir,extras:1500),original=try Data(contentsOf:input),store=SkinStore()
        var ticks=0,last=Date(),longest:TimeInterval=0
        let heartbeat=Task{@MainActor in
            while !Task.isCancelled{
                let now=Date();longest=max(longest,now.timeIntervalSince(last));last=now;ticks += 1
                do{try await Task.sleep(for:.milliseconds(10))}catch{return}
            }
        }
        let start=Date();await store.openArchive(input);heartbeat.cancel()
        defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
        XCTAssertNil(store.error);XCTAssertFalse(store.busy);XCTAssertTrue(store.importPreparedOffMain)
        XCTAssertGreaterThan(ticks,1,"Import prevented the interface task from running")
        XCTAssertEqual(store.files.count,1502);XCTAssertEqual(store.keys.count,60)
        XCTAssertEqual(try Data(contentsOf:input),original,"Import changed the user's source archive")
        XCTAssertEqual(store.parsedText.first{$0.name=="PANEL"}?.values["SIZE"],"720,400")
        print("IMPORT_BACKGROUND: files=\(store.files.count), mainTicks=\(ticks), longestTickGap=\(longest), seconds=\(Date().timeIntervalSince(start))")
    }
    @MainActor func testImportedKeyboardReusesStaticLayersAndFontResolutionWithLiveEdits()async throws {
        let dir=try directory();defer{try? FileManager.default.removeItem(at:dir)}
        let store=SkinStore();await store.openArchive(try fixture(dir,extras:500));XCTAssertNil(store.error)
        defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
        let renderer=store.renderer,canvas=CGSize(width:360,height:200),bounds=CGRect(origin:.zero,size:store.panel)
        func render(_ cached:Bool)throws->CGImage {
            try raster(canvas){context in
                context.scaleBy(x:0.5,y:0.5)
                let commands=store.keys.map{key in PreviewDrawCommand(id:key.name){layer in renderer.key(key,pressed:false,context:&layer)}}
                if cached{renderer.rasterCache.draw(commands,bounds:bounds,scale:0.5,context:&context)}
                else{for command in commands{command.draw(&context)}}
            }
        }
        _=try render(true)
        let count=renderer.fontLookupCount
        let start=Date();for _ in 0..<90{_ = try render(true)}
        let cachedSeconds=Date().timeIntervalSince(start)
        XCTAssertEqual(renderer.rasterCache.rasterCount,1);XCTAssertEqual(renderer.rasterCache.staticCommandCount,60)
        XCTAssertEqual(renderer.fontLookupCount,count);XCTAssertEqual(count,1)
        let directStart=Date();for _ in 0..<30{_ = try render(false)}
        let directSeconds=Date().timeIntervalSince(directStart)
        XCTAssertEqual(try rgb(render(true),x:5,y:5),try rgb(render(false),x:5,y:5))
        let css=try XCTUnwrap(store.files.first{$0.lastPathComponent=="default.css"});try store.open(css)
        store.setParameter(section:"STYLE1",key:"NM_COLOR",value:"FF0000FF")
        XCTAssertEqual(try rgb(render(true),x:5,y:5),[0,0,255],"The cached preview hid a live style edit")
        XCTAssertLessThanOrEqual(renderer.rasterCache.bytes,renderer.rasterCache.costLimit)
        print("IMPORT_RASTER: 60 keys, cached90Seconds=\(cachedSeconds), direct30Seconds=\(directSeconds), staticPaints=60, fontLookups=1")
    }
    @MainActor func testRasterLayersKeepOrderCandidateBoundsAndResizeBudget()throws {
        let cache=PreviewRasterCache(),bounds=CGRect(x:0,y:-20,width:160,height:100)
        var paints=0
        func render(_ frame:Int,_ scale:CGFloat=1)throws->CGImage {
            try raster(CGSize(width:160,height:100)){context in
                context.translateBy(x:0,y:20)
                let commands=[
                    PreviewDrawCommand(id:"bar"){c in paints += 1;c.fill(Path(CGRect(x:0,y:-20,width:160,height:20)),with:.color(.blue))},
                    PreviewDrawCommand(id:"moving",dynamic:true){c in c.fill(Path(CGRect(x:CGFloat(frame%2)*10,y:0,width:50,height:50)),with:.color(.green))},
                    PreviewDrawCommand(id:"foreground"){c in paints += 1;c.fill(Path(CGRect(x:20,y:10,width:10,height:10)),with:.color(.red))}
                ]
                cache.draw(commands,bounds:bounds,scale:scale,context:&context)
            }
        }
        for i in 0..<60{_ = try render(i)}
        XCTAssertEqual(paints,2);XCTAssertEqual(cache.rasterCount,2)
        let image=try render(0)
        XCTAssertEqual(try rgb(image,x:10,y:10),[0,0,255],"Candidate bar above y=0 disappeared")
        XCTAssertEqual(try rgb(image,x:25,y:35),[255,0,0],"Static foreground fell behind the animation")
        let a=try render(0),b=try render(1)
        XCTAssertNotEqual(try rgb(a,x:5,y:25),try rgb(b,x:5,y:25),"Dynamic layer was flattened")
        for i in 1...50{_ = try render(i,CGFloat(i)*0.1)}
        XCTAssertLessThanOrEqual(cache.bytes,cache.costLimit)
    }
    @MainActor func testBdaCachesStaticItemsAndOnlyRunsVisibleAnimatedState()throws {
        let dir=try directory();defer{try? FileManager.default.removeItem(at:dir)}
        let png=dir.appendingPathComponent("red.png"),gif=dir.appendingPathComponent("highlight.gif")
        func image(_ color:UIColor)->CGImage {
            let format=UIGraphicsImageRendererFormat();format.scale=1
            return UIGraphicsImageRenderer(size:CGSize(width:32,height:32),format:format).image{c in color.setFill();c.fill(CGRect(x:0,y:0,width:32,height:32))}.cgImage!
        }
        try UIImage(cgImage:image(.red)).pngData()!.write(to:png)
        let destination=try XCTUnwrap(CGImageDestinationCreateWithURL(gif as CFURL,UTType.gif.identifier as CFString,2,nil))
        for color in [UIColor.blue,.green]{CGImageDestinationAddImage(destination,image(color),[kCGImagePropertyGIFDictionary:[kCGImagePropertyGIFDelayTime:0.1]] as CFDictionary)}
        XCTAssertTrue(CGImageDestinationFinalize(destination))
        let engine=BdaPreviewEngine(root:dir,files:[png,gif]);engine.panelID="test"
        let items=(0..<40).map{i in BdaPreviewEngine.Item(id:"KEY\(i)",kind:"keys",data:["backStyle":["key":1]],rect:CGRect(x:(i%10)*36,y:(i/10)*36,width:32,height:32))}
        engine.panels["test"] = .init(id:"test",data:[:],size:CGSize(width:360,height:144),items:items)
        engine.images=["1":["normalImage":["resource":["resourceID":"red.png"]],"highlightImage":["resource":["resourceID":"highlight.gif"]]]]
        XCTAssertEqual(engine.refreshPlan(epoch:Date()),.idle,"Unused highlighted GIF kept the normal keyboard refreshing")
        XCTAssertTrue(engine.refreshPlan(epoch:Date(),pressed:true).continuous)
        func render(_ time:TimeInterval,_ pressed:Bool=false)throws->CGImage {
            try raster(CGSize(width:360,height:144)){c in engine.draw(context:&c,time:time,pressed:pressed,debug:false,scale:1,rasterScale:1)}
        }
        for i in 0..<60{_ = try render(Double(i)/30)}
        XCTAssertEqual(engine.rasterCache.rasterCount,1);XCTAssertEqual(engine.rasterCache.staticCommandCount,40)
        XCTAssertEqual(try rgb(render(0.05,true),x:10,y:10),[0,0,255])
        XCTAssertEqual(try rgb(render(0.15,true),x:10,y:10),[0,255,0],"Visible GIF stopped playing in the cached scene")
        engine.images=["1":["normalColor":UInt64(0xff0000ff)]]
        XCTAssertEqual(try rgb(render(0),x:10,y:10),[0,0,255],"Configuration change used stale BDA pixels")
    }
    @MainActor func testFailedImportKeepsPriorDocumentAndUnlocksInterface()async throws {
        let dir=try directory();defer{try? FileManager.default.removeItem(at:dir)}
        let store=SkinStore();await store.openArchive(try fixture(dir));XCTAssertNil(store.error)
        defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
        let root=store.root,current=store.current,text=store.text
        let bad=dir.appendingPathComponent("bad.bds");try Data("invalid".utf8).write(to:bad)
        await store.openArchive(bad)
        XCTAssertNotNil(store.error);XCTAssertFalse(store.busy)
        XCTAssertEqual(store.root,root);XCTAssertEqual(store.current,current);XCTAssertEqual(store.text,text)
        XCTAssertEqual(store.keys.count,60)
    }
}
