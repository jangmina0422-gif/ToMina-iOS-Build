import Foundation
import UIKit
import ZIPFoundation
import Combine
import CoreFoundation

struct SkinFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}
struct KeyShape: Identifiable {
    var id: Int
    var name: String
    var rect: CGRect
    var caption: String
}
@MainActor final class SkinStore: ObservableObject {
    let soundPreview=PreviewSound()
    @Published var soundEnabled=UserDefaults.standard.bool(forKey:"previewSound") {didSet{UserDefaults.standard.set(soundEnabled,forKey:"previewSound");soundPreview.enabled=soundEnabled}}
    func soundFile(_ key:String)->URL? {
        guard let root else{return nil}
        let section=renderer.effectiveSections.first{$0.name==key}
        let reference=PreviewSoundBinding.reference(key:section,panel:renderer.panelSection,styles:renderer.styles)
        return PreviewSoundBinding.resolve(reference,root:root,config:renderer.styleFile ?? layoutFile,files:files)
    }
    func pressSound(_ key:String){soundPreview.enabled=soundEnabled;soundPreview.press(soundFile(key))}
    let renderer = IniSkinRenderer()
    @Published var bda: BdaPreviewEngine?
    @Published var bdaColor="light"
    @Published var bdaOrientation="port"
    @Published var root: URL?
    @Published var filename = "导入"
    @Published var files: [URL] = []
    @Published var current: URL?
    private var layoutFile: URL?
    private var originalURL: URL?
    private var originalBookmark: Data?
    @Published var blankPreview = false
    var restoredView: EditorViewState?
    var resumeRevision: Int?
    private var restoringSession = false
    var panelFiles:[URL] {cachedPanelFiles}
    var previewPanelName:String {bda?.panelID ?? layoutFile?.deletingPathExtension().lastPathComponent ?? "panel"}
    @Published var text = "" {didSet{parsedText=Self.parse(text)}}
    private(set) var parsedText:[Section]=[]
    private(set) var importPreparedOffMain=false
    private var relativeNames:[URL:String]=[:]
    private var cachedPanelFiles:[URL]=[]
    @Published var error: String?
    @Published var busy = false
    @Published var documentRevision=0
    @Published var animationText="" {didSet{refreshAnimationDraft()}}
    func refreshAnimationDraft(){
        guard animationText != animationSaved else{return}
        let sections=Self.parse(animationText)
        guard Set(sections.map{$0.name})==Set(animationSourceFiles.keys) else{return}
        for section in sections{renderer.timeline.definitions[String(section.name.dropFirst(4))]=section.values}
        renderer.rasterCache.clear();renderer.configureFloating();objectWillChange.send()
    }
    private var animationSourceFiles:[String:URL]=[:]
    private var animationSaved=""
    func loadAnimationSource(_ key:String,floating:Bool=false) {
        guard saveAnimationSource() else{return}
        renderer.configureFloating()
        let ids=floating ? renderer.floatingAnimations:renderer.boundAnimations(key)
        animationSourceFiles=[:];var blocks:[String]=[]
        for id in ids {
            guard let file=renderer.animationFiles[id],let text=IniSkinRenderer.read(file),let range=Self.blockRange(text,"ANIM"+id) else{continue}
            animationSourceFiles["ANIM"+id]=file
            blocks.append(text.components(separatedBy:"\n")[range].joined(separator:"\n").trimmingCharacters(in:.whitespacesAndNewlines))
        }
        animationText=blocks.joined(separator:"\n\n");animationSaved=animationText
    }
    func editAnimationBinding(_ key:String,values:[String:String])throws {
        guard bda==nil,current?.pathExtension.lowercased()=="ini" else{throw SkinFailure(message:"请打开 INI 布局并选择按键")}
        guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
        var next=text
        for field in ["ANIM_STYLE","BACK_ANIM_STYLE","FORE_ANIM_STYLE"] {
            next=try AnimationEdits.set(next,section:key,field:field,value:AnimationEdits.ids(values[field] ?? ""))
        }
        guard let current else{throw SkinFailure(message:"请打开布局")};try writeAnimationChanges([current:next]);loadAnimationSource(key);renderer.trigger(key)
    }
    private func writeAnimationChanges(_ pending:[URL:String])throws {
        renderer.invalidatePrepared(Array(pending.keys))
        try SkinConfiguration.write(pending)
        if let current,let value=pending[current]{text=value;savedText=value}
        rescan()
    }
    func editAnimationEvents(_ style:String,press:String,show:String,key:String)throws {
        guard saveAnimationSource(),let file=renderer.styleFile,let original=IniSkinRenderer.read(file) else{throw SkinFailure(message:"没有可编辑的样式文件")}
        var next=try AnimationEdits.set(original,section:"STYLE"+style,field:"PRESS_ANIM",value:AnimationEdits.ids(press,allowMany:false))
        next=try AnimationEdits.set(next,section:"STYLE"+style,field:"SHOW_ANIM",value:AnimationEdits.ids(show,allowMany:false))
        try writeAnimationChanges([file:next]);loadAnimationSource(key);renderer.trigger(key)
    }
    func editAnimationImage(_ id:String,value:String,floating:Bool,key:String)throws {
        guard saveAnimationSource(),let file=renderer.animationFiles[id],let original=IniSkinRenderer.read(file) else{throw SkinFailure(message:"没有可编辑的动画文件")}
        let value = try (floating ? AnimationEdits.ids(value) : value)
        if floating {let count=value.split(separator:",").count;guard (1...10).contains(count) else{throw SkinFailure(message:"请选择 1–10 个底包图片样式")}}
        let next=try AnimationEdits.set(original,section:"ANIM"+id,field:floating ? "PARTICLE_IMAGE":"ANIM_PATH",value:value)
        try writeAnimationChanges([file:next]);loadAnimationSource(key,floating:floating);renderer.trigger(key);renderer.restartFloating()
    }
    func editStyleImage(_ style:String,field:String,reference:String,key:String)throws {
        guard ["NM_IMG","HL_IMG"].contains(field),saveAnimationSource(),let file=renderer.styleFile,let original=IniSkinRenderer.read(file) else{throw SkinFailure(message:"没有可编辑的样式")}
        let next=try AnimationEdits.set(original,section:"STYLE"+style,field:field,value:reference)
        try writeAnimationChanges([file:next]);loadAnimationSource(key);renderer.trigger(key)
    }
    func animationLog(_ key:String,floating:Bool)->String {
        let ids=floating ? renderer.timeline.definitions.keys.filter{renderer.timeline.definitions[$0]?["CATEGORY"]=="3"}.sorted():renderer.boundAnimations(key)
        var rows=["按键："+key,"样式文件："+(renderer.styleFile.map(relative) ?? "未找到"),"触发："+renderer.animationEvent]
        if ids.isEmpty{rows.append("未找到绑定动画")}
        for id in ids {rows.append("ANIM"+id+" · "+(renderer.animationFiles[id].map(relative) ?? "文件未找到"))}
        return rows.joined(separator:"\n")
    }
    var tileReferences:[String] {
        var result:[String]=[]
        for file in files where file.pathExtension.lowercased()=="til" {
            guard let text=IniSkinRenderer.read(file) else{continue}
            let atlas=(relative(file) as NSString).deletingPathExtension
            for section in Self.parse(text) where section.name.hasPrefix("IMG") && Int(section.name.dropFirst(3)) != nil {
                if Self.numbers(section.values["SOURCE_RECT"]).count==4{result.append(atlas+","+section.name.dropFirst(3))}
            }
        }
        return result.sorted()
    }
    func addKeyAnimation(_ key:String)throws {
        guard bda==nil,let current,current.pathExtension.lowercased()=="ini",Self.parse(text).contains(where:{$0.name==key && key.hasPrefix("KEY")}) else{throw SkinFailure(message:"请先选择按键")}
        guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")};try save()
        let anim=(renderer.timeline.definitions.keys.compactMap{Int($0)}.max() ?? 0)+1
        let style=(renderer.styles.keys.compactMap{Int($0.dropFirst(5))}.max() ?? 0)+1
        let css=renderer.styleFile ?? current.deletingLastPathComponent().appendingPathComponent("res/default.css")
        let file=css.deletingLastPathComponent().appendingPathComponent("anim.ini")
        var at=(IniSkinRenderer.read(file) ?? "[GLOBAL]\nANIM_NUM=0\n")+"\n[ANIM\(anim)]\nTYPE=4\nFROM=100,100\nTO=85,85\nDURATION=180\nREPEAT_CNT=1\nREPEAT_MODE=1\nREMOVE=1\n"
        var ct=(IniSkinRenderer.read(css) ?? "[GLOBAL]\nSTYLE_NUM=0\n")+"\n[STYLE\(style)]\nPRESS_ANIM=\(anim)\n"
        if Self.blockRange(at,"GLOBAL") != nil{at=try AnimationEdits.set(at,section:"GLOBAL",field:"ANIM_NUM",value:String(Self.parse(at).filter{$0.name.range(of:"^ANIM[0-9]+$",options:.regularExpression) != nil}.count))}
        if Self.blockRange(ct,"GLOBAL") != nil{ct=try AnimationEdits.set(ct,section:"GLOBAL",field:"STYLE_NUM",value:String(Self.parse(ct).filter{$0.name.range(of:"^STYLE[0-9]+$",options:.regularExpression) != nil}.count))}
        let next=try AnimationEdits.set(text,section:key,field:"ANIM_STYLE",value:String(style))
        try writeAnimationChanges([file:at,css:ct,current:next]);loadAnimationSource(key);renderer.trigger(key)
    }
    static func blockRange(_ text:String,_ name:String)->Range<Int>? {
        let lines=text.components(separatedBy:"\n");var start:Int?
        for (i,line) in lines.enumerated() {
            if let section=SkinConfiguration.header(line) {
                if let start{return start..<i}
                if section==name.uppercased(){start=i}
            }
        };return start.map{$0..<lines.count}
    }
    @discardableResult func saveAnimationSource()->Bool {
        guard animationText != animationSaved else{return true}
        do {
            let parsed=Self.parse(animationText),names=parsed.map{$0.name}
            guard Set(names)==Set(animationSourceFiles.keys),names.count==Set(names).count else{throw SkinFailure(message:"请保留全部 ANIM 段名，不要重复或删除编号")}
            var pending:[URL:String]=[:]
            for file in Set(animationSourceFiles.values) {
                let original=try Data(contentsOf:file)
                guard var text=SkinConfiguration.decode(original)?.text else{throw SkinFailure(message:"无法读取原配置")}
                for name in names where animationSourceFiles[name]==file {
                    guard let range=Self.blockRange(text,name),let replacement=Self.blockRange(animationText,name) else{throw SkinFailure(message:"ANIM 段已发生变化，请重新打开")}
                    var lines=text.components(separatedBy:"\n")
                    lines.replaceSubrange(range,with:animationText.components(separatedBy:"\n")[replacement]);text=lines.joined(separator:"\n")
                }
                pending[file]=text
            }
            try writeAnimationChanges(pending)
            animationSaved=animationText;return true
        }catch{self.error=error.localizedDescription;return false}
    }
    @Published var keys: [KeyShape] = []
    @Published var panel = CGSize(width: 1080, height: 642)
    @Published var previewNote = "导入皮肤"
    private var undoStack: [String] = []
    private var redoStack: [String] = []
    var canUndo: Bool { !undoStack.isEmpty }
    var canRedo: Bool { !redoStack.isEmpty }
    func change(_ next: String) {
        guard next != text else { return }
        guard saveAnimationSource() else{return}
        undoStack.append(text)
        if undoStack.count > 40 { undoStack.removeFirst() }
        redoStack.removeAll()
        text = next
        if !linkedBinaryText || (try? JSONSerialization.jsonObject(with:Data(text.utf8))) != nil {
            do { try save() } catch { self.error = error.localizedDescription }
        }
        refresh()
    }
    func history(redo: Bool) {
        guard saveAnimationSource() else{return}
        if redo { guard let next = redoStack.popLast() else { return }; undoStack.append(text); text = next }
        else { guard let next = undoStack.popLast() else { return }; redoStack.append(text); text = next }
        do { try save() } catch { self.error = error.localizedDescription }
        refresh()
    }
    func sectionRange(_ name: String) -> Range<Int>? {
        Self.blockRange(text,name)
    }
    func setParameter(section: String, key: String, value: String) {
        do{change(try AnimationEdits.set(text,section:section,field:key,value:value))}catch{self.error=error.localizedDescription}
    }
    func addKey(copy name: String? = nil) -> String? {
        guard current?.pathExtension.lowercased() == "ini" else { error = "请选择 INI 布局"; return nil }
        let index = (Self.parse(text).compactMap { s -> Int? in
            guard s.name.hasPrefix("KEY") else { return nil }
            return Int(s.name.dropFirst(3))
        }.max() ?? 0) + 1
        let nextName = "KEY\(index)"
        var content = "BACK_STYLE=2\nFORE_STYLE=3\nVIEW_RECT=10,10,100,100\nTOUCH_RECT=10,10,100,100\nCENTER=F38"
        if let name, let range = sectionRange(name) {
            content = text.components(separatedBy: "\n")[range].dropFirst().joined(separator: "\n")
        }
        change(Self.updateCounts(text + "\n[" + nextName + "]\n" + content + "\n"))
        return nextName
    }
    func deleteKey(_ name: String) {
        guard name.range(of:"^KEY[0-9]+$",options:.regularExpression) != nil, let range = sectionRange(name) else { return }
        let number=String(name.dropFirst(3))
        guard !Self.parse(text).contains(where:{$0.name != name && $0.values["BROTHER_ID"]==number}) else {
            error="此按键被 BROTHER_ID 引用，请先修改引用";return
        }
        var lines = text.components(separatedBy: "\n"); lines.removeSubrange(range)
        change(Self.updateCounts(SkinConfiguration.renumberKeys(lines.joined(separator: "\n"))))
    }
    static func updateCounts(_ text: String) -> String {
        let sections = parse(text)
        var counts: [String: Int] = [:]
        for prefix in ["KEY", "TIP", "ICON", "OFFSET", "STYLE", "IMG"] {
            counts[prefix + "_NUM"] = sections.filter {
                $0.name.hasPrefix(prefix) && Int($0.name.dropFirst(prefix.count)) != nil
            }.count
        }
        return text.components(separatedBy: "\n").map { line in
            guard let equal = line.firstIndex(of: "=") else { return line }
            let key = line[..<equal].trimmingCharacters(in: .whitespaces).uppercased()
            guard let count = counts[key] else { return line }
            let original=String(line[line.index(after:equal)...]),comment=original.range(of:" //")
            return String(line[...equal]) + String(count) + (comment.map{String(original[$0.lowerBound...])} ?? (line.hasSuffix("\r") ? "\r" : ""))
        }.joined(separator: "\n")
    }
    func checkLayout() -> String {
        let issues=SkinConfiguration.validate(text)
        return issues.isEmpty ? "当前文件配置检查通过；实际导入与效果仍需真机验证。":issues.joined(separator:"\n")
    }
    private var encoding = String.Encoding.utf8
    private var savedText = ""

    static func parse(_ text: String) -> [Section] {
        SkinConfiguration.parse(text)
    }
    static func numbers(_ value: String?) -> [CGFloat] {
        SkinConfiguration.numbers(value).map{CGFloat($0)}
    }
    func openArchive(_ url: URL) async {
        guard !busy else{return}
        busy=true;defer{busy=false}
        do {
            guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
            try save()
            let access=url.startAccessingSecurityScopedResource()
            defer{if access{url.stopAccessingSecurityScopedResource()}}
            let bookmark=try OriginalSkinDocument.bookmark(url)
            let prepared=try await Task.detached(priority:.userInitiated){try PreparedSkinArchive.open(url)}.value
            try adopt(prepared,filename:url.lastPathComponent)
            originalURL=url;originalBookmark=bookmark;restoredView=nil;resumeRevision=nil;error=nil
        }catch{self.error=error.localizedDescription}
    }
    private func adopt(_ archive:PreparedSkinArchive,filename name:String)throws {
        let folder=archive.folder
        root=folder;filename=name;current=nil;layoutFile=nil;text="";savedText="";bda=nil
        panel=CGSize(width:1080,height:642);keys=[];blankPreview=false
        renderer.resetSelection();renderer.prepare(archive);bdaColor="light";bdaOrientation="port"
        documentRevision += 1
        animationText="";animationSaved="";animationSourceFiles=[:]
        files=archive.files;cachedPanelFiles=SkinConfiguration.panelFiles(files)
        relativeNames=Dictionary(files.map{($0,String($0.path.dropFirst(folder.path.count+1)))},uniquingKeysWith:{_,new in new})
        importPreparedOffMain=archive.backgroundPrepared
        if SkinConfiguration.usesConfigPreview(filename,files:files) {
            let engine=BdaPreviewEngine(root:folder,files:files)
            engine.prepareConfigurations(archive.configurations,errors:archive.configurationErrors);bda=engine;reloadBda()
        }else if let first=SkinConfiguration.firstLayout(files){try open(first)}
        else{keys=[];blankPreview=true;previewNote="未找到可预览布局，请打开文件查看配置"}
    }
    func saveSession(_ view: EditorViewState, recordFile: URL = OriginalSkinDocument.sessionFile) async throws {
        guard !busy else { throw SkinFailure(message: "正在处理文件，请稍候") }
        guard saveAnimationSource() else { throw SkinFailure(message: "请先修正动效代码") }
        try save()
        guard let root, let originalURL, let originalBookmark else { throw SkinFailure(message: "请先导入原皮肤文件") }
        if filename.lowercased().hasSuffix(".bda") { _ = try BdaTextSync.synchronize(files: files) }
        let record = EditorResumeRecord(bookmark: originalBookmark, filename: filename, current: current.map(relative) ?? "", preview: layoutFile.map(relative) ?? "", view: view)
        busy = true; defer { busy = false }
        try await Task.detached {
            try OriginalSkinDocument.overwrite(root: root, original: originalURL)
            try OriginalSkinDocument.write(record, at: recordFile)
        }.value
    }
    @discardableResult func restoreSession(recordFile: URL = OriginalSkinDocument.sessionFile) async throws -> EditorViewState? {
        guard FileManager.default.fileExists(atPath: recordFile.path) else { return nil }
        guard !busy else { return nil }
        busy = true; restoringSession = true
        defer { busy = false; restoringSession = false }
        let data = try Data(contentsOf: recordFile)
        guard data.count <= 1024*1024 else { throw SkinFailure(message: "保存的编辑记录无效") }
        let record = try JSONDecoder().decode(EditorResumeRecord.self, from: data)
        guard record.version == 1 else { throw SkinFailure(message: "保存的编辑记录版本无效") }
        let original = try OriginalSkinDocument.resolve(record.bookmark)
        let archive = try await Task.detached(priority:.userInitiated) { try PreparedSkinArchive.open(original) }.value
        let folder=archive.folder
        let edited = try OriginalSkinDocument.path(record.current, root: folder)
        let preview = try OriginalSkinDocument.path(record.preview, root: folder)
        try adopt(archive, filename: original.lastPathComponent)
        if let edited { try open(edited) }
        layoutFile = preview; bdaColor = record.view.color; bdaOrientation = record.view.orientation
        if let bda { bda.panelID = record.view.panel; bda.animationChoice = record.view.animation }
        refresh()
        renderer.hasCandidates = record.view.hasCandidates; renderer.candidateChoice = record.view.candidate
        renderer.floatingChoice = record.view.floating; renderer.animationEvent = record.view.event
        refresh()
        renderer.animationEnabled = record.view.effect == "key"
        if !record.view.effect.isEmpty { loadAnimationSource(record.view.selected, floating: record.view.effect == "floating") }
        if record.view.floatingPaused { renderer.floatingPausedAt = Date() }
        originalURL = original
        let access = original.startAccessingSecurityScopedResource()
        defer { if access { original.stopAccessingSecurityScopedResource() } }
        originalBookmark = try OriginalSkinDocument.bookmark(original)
        restoredView = record.view; documentRevision += 1; resumeRevision = documentRevision
        return record.view
    }
    func relative(_ url: URL) -> String {
        if let cached=relativeNames[url]{return cached}
        guard let root else { return url.lastPathComponent }
        let base = root.resolvingSymlinksInPath().pathComponents
        let path = url.resolvingSymlinksInPath().pathComponents
        guard path.starts(with: base) else { return url.lastPathComponent }
        return path.dropFirst(base.count).joined(separator: "/")
    }
    func rescan(){
        guard let root,let iterator=FileManager.default.enumerator(at:root,includingPropertiesForKeys:[.isRegularFileKey]) else{return}
        files=iterator.compactMap{$0 as? URL}.filter{(try? $0.resourceValues(forKeys:[.isRegularFileKey]).isRegularFile)==true}.sorted{$0.path<$1.path};cachedPanelFiles=SkinConfiguration.panelFiles(files);renderer.invalidatePrepared(files);bda?.invalidatePreparedConfigurations();refresh()
    }
    func importResource(_ url:URL) throws {
        guard let root,bda==nil else{throw SkinFailure(message:"请先导入 BDS / BDI")}
        let access=url.startAccessingSecurityScopedResource();defer{if access{url.stopAccessingSecurityScopedResource()}}
        let name=url.lastPathComponent
        guard !name.isEmpty,!name.contains(".."),!name.contains(":"),!name.contains("/") else{throw SkinFailure(message:"文件名无效")}
        let dir=(layoutFile?.deletingLastPathComponent() ?? root).appendingPathComponent("res")
        let target=dir.appendingPathComponent(name)
        guard !FileManager.default.fileExists(atPath:target.path) else{throw SkinFailure(message:"已有同名文件，请在文件列表中打开后替换")}
        let data=try Data(contentsOf:url);guard data.count<=32*1024*1024 else{throw SkinFailure(message:"资源超过 32 MB")}
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true);try data.write(to:target,options:.atomic);rescan()
    }
    func open(_ url: URL) throws {
        if !restoringSession { restoredView = nil; resumeRevision = nil }
        guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
        try save()
        guard ["ini","css","txt","json","til","cnd","pop","anim","ani"].contains(url.pathExtension.lowercased()) else { throw SkinFailure(message: "该文件原样保留；当前编辑器只打开文本配置") }
        let data = try Data(contentsOf: url)
        guard data.count <= 2*1024*1024 else { throw SkinFailure(message: "文本超过 2 MB") }
        guard let decoded=SkinConfiguration.decode(data) else { throw SkinFailure(message: "无法识别文本编码，未修改文件") }
        encoding=decoded.encoding
        current = URL(fileURLWithPath: url.path, isDirectory: false); text = decoded.text; savedText = decoded.text
        if ["ini","cnd","pop"].contains(url.pathExtension.lowercased()){layoutFile=url;panel=CGSize(width:1080,height:642)}
        animationText="";animationSaved="";animationSourceFiles=[:];renderer.resetSelection();documentRevision+=1
        undoStack.removeAll(); redoStack.removeAll(); refresh()
    }
    private var linkedBinaryText:Bool {
        guard filename.lowercased().hasSuffix(".bda"),let current,["json","txt"].contains(current.pathExtension.lowercased()) else{return false}
        return ["appearanceconfig","layoutconfig","animationconfig","sceneconfig","soundconfig"].contains(current.deletingPathExtension().lastPathComponent.lowercased())
    }
    func save() throws {
        guard let current else { return }
        guard text != savedText else { return }
        guard FileManager.default.fileExists(atPath: current.deletingLastPathComponent().path) else {
            throw SkinFailure(message: "当前编辑目录已失效。请先复制未保存的代码，再重新导入皮肤。")
        }
        guard let data = text.data(using: encoding, allowLossyConversion: false) else { throw SkinFailure(message: "当前编码不能保存输入内容") }
        let original=try Data(contentsOf:current)
        do {
            try data.write(to: current, options: .atomic)
            if linkedBinaryText{_=try BdaTextSync.synchronize(files:files)}
        }catch{try? original.write(to:current,options:.atomic);throw error}
        renderer.invalidatePrepared([current]);if linkedBinaryText{bda?.invalidatePreparedConfigurations()}
        savedText = text
    }
    func refresh() {
        if bda != nil { blankPreview = false; reloadBda();return }
        keys = []; blankPreview = true
        guard let layoutFile else { previewNote = "选择 INI 布局预览"; return }
        let layoutText = current == layoutFile ? text : (IniSkinRenderer.read(layoutFile) ?? "")
        renderer.configure(root: root, config: layoutFile, files: files, text: layoutText, overrides:current.map{[$0:text]} ?? [:])
        let sections = renderer.effectiveSections
        panel=PanelMetrics.size(sections)
        if layoutFile.pathExtension.lowercased()=="cnd",renderer.candidateSize.width>0{panel=renderer.candidateSize}
        var nextKeys:[KeyShape]=[]
        for (index, s) in sections.enumerated() {
            if !renderer.visible(s){continue}
            if s.name=="CAND" && layoutFile.pathExtension.lowercased()=="ini" && !(s.values["LAYOUT_NAME"] ?? "").isEmpty{continue}
            guard let rect=IniGeometry.bounds(s,panel:panel) else{continue}
            let action=s.values["CENTER"] ?? s.values["KEY"] ?? s.name
            let label=PreviewLabels.caption(action)
            nextKeys.append(KeyShape(id:index,name:s.name,rect:rect,caption:label))
        }
        keys=nextKeys
        blankPreview = layoutFile.pathExtension.lowercased() == "ini" && !keys.contains { $0.name.range(of: "^KEY[0-9]+$", options: .regularExpression) != nil }
        if blankPreview { keys = []; previewNote = ""; return }
        refreshAnimationDraft()
        previewNote = renderer.hasStyles ? "INI 样式预览" : "布局线框 · 当前配置未找到 CSS 样式"
    }
    func export() throws -> URL {
        guard saveAnimationSource() else{throw SkinFailure(message:"请先修正动效代码")}
        try save()
        guard let root else { throw SkinFailure(message: "请先导入") }
        if filename.lowercased().hasSuffix(".bda"){_=try BdaTextSync.synchronize(files:files)}
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let url = folder.appendingPathComponent(filename)
        try FileManager.default.zipItem(at: root, to: url, shouldKeepParent: false)
        return url
    }
    func reloadBda() {
        var drafts:[URL:Data]=[:]
        if linkedBinaryText,text != savedText,let current {
            do{drafts=try BdaTextSync.preview(file:current,text:text,files:files)}
            catch{return}
        }
        bda?.load(color:bdaColor,orientation:bdaOrientation,overrides:drafts);syncBda()
    }
    func syncBda() {
        guard let bda else{return}
        panel=bda.size
        keys=(bda.panel?.items ?? []).enumerated().compactMap { i,item in
            guard item.kind=="keys",item.visible,let rect=item.rect else{return nil}
            return KeyShape(id:i,name:item.id,rect:rect,caption:"")
        }
        previewNote=keys.isEmpty ? "未恢复布局 · 查看解析日志":((bda.panel?.items.contains{$0.source=="semanticInference" || $0.source=="fallback"}) == true ? "推算布局 · 调试可查看坐标来源":"BDA 布局预览")
        objectWillChange.send()
    }
    func batch(_ names: [String], operation: String, factor: Double = 1) {
        let sections=Self.parse(text)
        var replacements:[String:[String:String]]=[:]
        func format(_ values:[CGFloat]) -> String { values.map{String(Int(floor($0+0.5)))}.joined(separator:",") }
        if operation=="scale" {
            guard factor.isFinite,(0.1...5).contains(factor) else { error="倍数须在 0.1 至 5 之间";return }
            for s in sections { for (key,value) in s.values where ["VIEW_RECT","TOUCH_RECT","SIZE","POS","PADDING","ICON_ON_SWITCH_SIZE","ICON_ON_SWITCH_POS"].contains(key) {
                let values=Self.numbers(value).map{$0*CGFloat(factor)}
                if !values.isEmpty,values.allSatisfy({abs($0)<1e12}) { replacements[s.name,default:[:]][key]=format(values) }
            }}
        } else {
            let chosen=names.compactMap{name in sections.first{$0.name==name}}
            guard chosen.count>=2 else { error="请多选至少两个按键";return }
            let base=Self.numbers(chosen[0].values["VIEW_RECT"])
            guard base.count==4 else { error="首个按键没有有效 VIEW_RECT";return }
            if operation=="swap" {
                guard chosen.count==2 else { error="交换需要恰好两个按键";return }
                for i in 0..<2 {
                    let other=chosen[1-i]
                    replacements[chosen[i].name] = ["VIEW_RECT":other.values["VIEW_RECT"] ?? "", "TOUCH_RECT":other.values["TOUCH_RECT"] ?? other.values["VIEW_RECT"] ?? ""]
                }
            } else {
                let axis=operation=="left" ? 0:1
                for s in chosen {
                    var r=Self.numbers(s.values["VIEW_RECT"])
                    guard r.count==4 else { continue }
                    let delta=base[axis]-r[axis];r[axis]=base[axis]
                    replacements[s.name,default:[:]]["VIEW_RECT"]=format(r)
                    var touch=Self.numbers(s.values["TOUCH_RECT"])
                    if touch.count==4 { touch[axis]+=delta;replacements[s.name,default:[:]]["TOUCH_RECT"]=format(touch) }
                }
            }
        }
        var section="", seen=Set<String>(), lines:[String]=[]
        func appendMissing() {
            for (key,value) in (replacements[section] ?? [:]).sorted(by:{$0.key<$1.key}) where !seen.contains(key) { lines.append(key+"="+value) }
        }
        for raw in text.components(separatedBy:"\n") {
            let line=raw.trimmingCharacters(in:.whitespacesAndNewlines)
            if line.hasPrefix("["),let end=line.firstIndex(of:"]") { appendMissing();seen=[];section=String(line[line.index(after:line.startIndex)..<end]).uppercased();lines.append(raw);continue }
            guard let equal=raw.firstIndex(of:"=") else { lines.append(raw);continue }
            let key=raw[..<equal].trimmingCharacters(in:.whitespaces).uppercased()
            seen.insert(key)
            guard let value=replacements[section]?[key] else { lines.append(raw);continue }
            lines.append(String(raw[...equal])+value+(raw.hasSuffix("\r") ? "\r":""))
        }
        appendMissing()
        change(lines.joined(separator:"\n"))
    }
    func generatePlaintext() {
        do {
            guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
            try save()
            var count = 0, logs: [String] = []
            for file in files where ["appearanceconfig", "layoutconfig", "animationconfig", "sceneconfig", "soundconfig"].contains(file.lastPathComponent.lowercased()) {
                do {
                    let data = try BinaryPlaintext.decode(file)
                    var output = file.appendingPathExtension("decoded.json"), index = 2
                    while FileManager.default.fileExists(atPath: output.path) {
                        output = file.appendingPathExtension("decoded-\(index).json"); index += 1
                    }
                    try data.write(to: output, options: .atomic); files.append(output)
                    count += 1; logs.append(relative(output))
                } catch { logs.append(relative(file) + "：" + error.localizedDescription) }
            }
            files.sort { $0.path < $1.path }
            error = "已生成 \(count) 份明文副本\n" + logs.joined(separator: "\n") + "\n点击顶部文件名查看。原二进制保持不变。"
        } catch { self.error = error.localizedDescription }
    }
    var canConvert: Bool { root != nil && ["bds","bdi"].contains((filename as NSString).pathExtension.lowercased()) }
    func convertSystem() throws -> URL {
        guard canConvert, let root else { throw SkinFailure(message:"仅支持 BDS / BDI") }
        try save()
        guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
        let target=try SystemMigration.convert(root:root,files:files)
        let ios=SystemMigration.allFiles(target).filter{$0.lastPathComponent.lowercased()=="info.txt"}.contains { (IniSkinRenderer.read($0) ?? "").contains("SupportPlatform=I") }
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        let output=directory.appendingPathComponent((filename as NSString).deletingPathExtension + (ios ? "_iOS.bdi":"_Android.bds"))
        try FileManager.default.zipItem(at:target,to:output,shouldKeepParent:false)
        return output
    }
    func convertLandscape(width: Int) {
        do {
            guard canConvert, let root else { throw SkinFailure(message:"仅支持 BDS / BDI") }
            try save()
            guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
            let previous = current.map(relative) ?? "port/py_26.ini"
            let target = try SkinTools.landscape(root:root,files:files,width:width)
            self.root = target; current = nil; layoutFile = nil; text = ""
            animationText="";animationSaved="";animationSourceFiles=[:];renderer.resetSelection();documentRevision+=1
            files = (FileManager.default.enumerator(at:target,includingPropertiesForKeys:[.isRegularFileKey])?.allObjects as? [URL] ?? []).filter { (try? $0.resourceValues(forKeys:[.isRegularFileKey]).isRegularFile) == true }.sorted{$0.path < $1.path}
            var parts = previous.components(separatedBy:"/")
            if let index = parts.firstIndex(where:{$0.lowercased()=="port"}) { parts[index] = "land" }
            let preferred = parts.joined(separator:"/")
            let first = files.first(where:{relative($0)==preferred}) ?? files.first(where:{$0.path.contains("/land/") && $0.pathExtension=="ini"})
            if let first { try open(first) }
        } catch { self.error = error.localizedDescription }
    }
}
