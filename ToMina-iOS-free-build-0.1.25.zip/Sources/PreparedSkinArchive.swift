import Foundation

// JSON values are immutable after decoding. No mutable Foundation container
// escapes the worker that creates this value.
struct PreparedConfiguration: @unchecked Sendable {
    let value: [String: Any]
    let binary: Bool
    let unknownFields: Int
    static func decode(_ file: URL, data: Data) throws -> Self {
        if let value = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            return Self(value: value, binary: false, unknownFields: 0)
        }
        let copy = try JSONSerialization.jsonObject(with: BinaryPlaintext.decode(file, data: data, includeInspection: false)) as? [String: Any] ?? [:]
        return Self(value: copy["decoded"] as? [String: Any] ?? [:], binary: true, unknownFields: (copy["unknownFields"] as? NSNumber)?.intValue ?? 0)
    }
}

struct PreparedSkinArchive: Sendable {
    let folder: URL
    let files: [URL]
    let texts: [URL: String]
    let sections: [URL: [Section]]
    let configurations: [URL: PreparedConfiguration]
    let configurationErrors: [URL: String]
    let backgroundPrepared: Bool

    static func open(_ original: URL) throws -> Self {
        let folder = try OriginalSkinDocument.unpack(original)
        do { return try index(folder) }
        catch { try? FileManager.default.removeItem(at: folder); throw error }
    }
    static func index(_ folder: URL) throws -> Self {
        let root = folder.resolvingSymlinksInPath()
        guard let iterator = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey]) else { throw SkinFailure(message: "无法读取皮肤目录") }
        let files = iterator.compactMap { $0 as? URL }.filter { (try? $0.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true }.sorted { $0.path < $1.path }
        var texts: [URL: String] = [:], sections: [URL: [Section]] = [:]
        var configurations: [URL: PreparedConfiguration] = [:], errors: [URL: String] = [:]
        var textBytes = 0
        let kinds = Set(["appearanceconfig", "layoutconfig", "animationconfig", "sceneconfig", "soundconfig"])
        for file in files {
            let kind = file.deletingPathExtension().lastPathComponent.lowercased()
            if kinds.contains(kind) {
                do {
                    let data = try Data(contentsOf: file, options: .mappedIfSafe)
                    guard data.count <= 32 * 1024 * 1024 else { throw SkinFailure(message: "配置过大") }
                    configurations[file] = try PreparedConfiguration.decode(file, data: data)
                } catch { errors[file] = error.localizedDescription }
            }
            guard ["ini", "css", "til", "cnd", "pop", "anim", "ani"].contains(file.pathExtension.lowercased()),
                  let raw = SkinConfiguration.read(file), textBytes + raw.utf8.count <= 24 * 1024 * 1024 else { continue }
            texts[file] = raw; sections[file] = SkinConfiguration.parse(raw); textBytes += raw.utf8.count
        }
        return Self(folder: root, files: files, texts: texts, sections: sections, configurations: configurations, configurationErrors: errors, backgroundPrepared: !Thread.isMainThread)
    }
}
