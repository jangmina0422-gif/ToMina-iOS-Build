import XCTest
import UIKit
import UniformTypeIdentifiers
import ZIPFoundation
@testable import ToMina

final class ArchiveFilesTests: XCTestCase {
    private func directory() throws -> URL {
        let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString,isDirectory:true)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true);return folder
    }
    func testFolderBrowsingAndEmptyDirectoriesSurviveZip() throws {
        let root=try directory(),output=root.deletingLastPathComponent().appendingPathComponent(UUID().uuidString+".zip")
        defer{try? FileManager.default.removeItem(at:root);try? FileManager.default.removeItem(at:output)}
        try ArchiveFiles.createFolder("port",in:root,root:root)
        try ArchiveFiles.createFolder("空素材",in:root,root:root)
        try Data([1,2,3]).write(to:root.appendingPathComponent("a.bin"))
        let entries=try ArchiveFiles.entries(in:root,root:root)
        XCTAssertEqual(entries.filter(\.directory).count,2);XCTAssertFalse(try XCTUnwrap(entries.last).directory)
        try FileManager.default.zipItem(at:root,to:output,shouldKeepParent:false)
        let unpacked=try OriginalSkinDocument.unpack(output);defer{try? FileManager.default.removeItem(at:unpacked)}
        XCTAssertTrue((try unpacked.appendingPathComponent("空素材").resourceValues(forKeys:[.isDirectoryKey])).isDirectory == true)
        XCTAssertEqual(try Data(contentsOf:unpacked.appendingPathComponent("a.bin")),Data([1,2,3]))
        XCTAssertThrowsError(try ArchiveFiles.createFolder("../escape",in:root,root:root))
        XCTAssertThrowsError(try ArchiveFiles.createFolder("a.bin",in:root,root:root))
        XCTAssertThrowsError(try ArchiveFiles.entries(in:root.deletingLastPathComponent(),root:root))
    }
    func testMixedExtensionsPreserveBytesAndOriginalSources() throws {
        let input=try directory(),root=try directory()
        defer{try? FileManager.default.removeItem(at:input);try? FileManager.default.removeItem(at:root)}
        let names=["drawing.procreate","drawing.psd","drawing.tiff","drawing.pdf","key.ogg","notes.ini","opaque.anything"]
        for (index,name) in names.enumerated(){try Data([UInt8(index),0,255,12]).write(to:input.appendingPathComponent(name))}
        let batch=ResourceImport.stageURLs(names.map{input.appendingPathComponent($0)});defer{batch.discard()}
        XCTAssertTrue(batch.failures.isEmpty);XCTAssertEqual(batch.files.count,names.count)
        let written=try ResourceImport.insert(batch.files,into:root,root:root,policy:.keepBoth)
        XCTAssertEqual(written.map(\.lastPathComponent),names)
        for name in names {XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent(name)),try Data(contentsOf:input.appendingPathComponent(name)))}
    }
    func testCollisionPoliciesAndDirectoryPreflightKeepExistingData() throws {
        let input=try directory(),root=try directory()
        defer{try? FileManager.default.removeItem(at:input);try? FileManager.default.removeItem(at:root)}
        try Data([2]).write(to:input.appendingPathComponent("Key.PNG"));try Data([1]).write(to:root.appendingPathComponent("key.png"))
        let batch=ResourceImport.stageURLs([input.appendingPathComponent("Key.PNG")]);defer{batch.discard()}
        let kept=try ResourceImport.insert(batch.files,into:root,root:root,policy:.keepBoth)
        XCTAssertEqual(kept.first?.lastPathComponent,"Key (2).PNG");XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("key.png")),Data([1]))
        let replaced=try ResourceImport.insert(batch.files,into:root,root:root,policy:.replace)
        XCTAssertEqual(replaced.first?.lastPathComponent,"key.png");XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("key.png")),Data([2]))
        try ArchiveFiles.createFolder("blocked",in:root,root:root);try Data([3]).write(to:input.appendingPathComponent("blocked"))
        let blocked=try ResourceImport.stage(input.appendingPathComponent("blocked"));defer{try? FileManager.default.removeItem(at:blocked.url.deletingLastPathComponent())}
        XCTAssertThrowsError(try ResourceImport.insert(batch.files+[blocked],into:root,root:root,policy:.replace))
        XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("key.png")),Data([2]))
    }
    func testProviderTemporaryFilesAreCopiedBeforeCompletion() async throws {
        let source=try directory();defer{try? FileManager.default.removeItem(at:source)}
        let file=source.appendingPathComponent("art.procreate"),bytes=Data([80,75,3,4,0,255])
        try bytes.write(to:file)
        let provider=NSItemProvider();provider.suggestedName="art.procreate"
        provider.registerFileRepresentation(forTypeIdentifier:"com.savageinteractive.procreate.document",fileOptions:[],visibility:.all){completion in
            completion(file,false,nil);return nil
        }
        let staged=try await ResourceImport.stageProvider(provider)
        defer{try? FileManager.default.removeItem(at:staged.url.deletingLastPathComponent())}
        try FileManager.default.removeItem(at:file)
        XCTAssertEqual(staged.name,"art.procreate");XCTAssertEqual(try Data(contentsOf:staged.url),bytes)
    }
    @MainActor func testMultiDropReceivesImagesAndUnknownFileTypes() async throws {
        let source=try directory();defer{try? FileManager.default.removeItem(at:source)}
        let file=source.appendingPathComponent("animation.weird"),bytes=Data([0,1,2,3])
        try bytes.write(to:file)
        let opaque=NSItemProvider();opaque.suggestedName=file.lastPathComponent
        opaque.registerFileRepresentation(forTypeIdentifier:UTType.data.identifier,fileOptions:[],visibility:.all){completion in completion(file,false,nil);return nil}
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let image=UIGraphicsImageRenderer(size:CGSize(width:8,height:8),format:format).image{context in UIColor.red.setFill();context.fill(CGRect(x:0,y:0,width:8,height:8))}
        let picture=NSItemProvider(object:image);picture.suggestedName="Procreate画图"
        let batch=await ResourceImport.stageProviders([opaque,picture]);defer{batch.discard()}
        XCTAssertTrue(batch.failures.isEmpty);XCTAssertEqual(batch.files.count,2)
        XCTAssertEqual(try Data(contentsOf:batch.files[0].url),bytes)
        let received=try XCTUnwrap(UIImage(data:Data(contentsOf:batch.files[1].url)))
        XCTAssertEqual(received.cgImage?.width,8);XCTAssertEqual(received.cgImage?.height,8)
    }
    @MainActor func testMultiplePickerAcceptsAllFilesAndCompletesOnce() throws {
        let controller=SkinResourcePicker.controller()
        XCTAssertTrue(controller.allowsMultipleSelection)
        var calls=0,count=0
        let coordinator=SkinResourcePicker.Coordinator{result in calls += 1;count=(try? result.get().count) ?? -1}
        coordinator.documentPicker(controller,didPickDocumentsAt:[URL(fileURLWithPath:"/a.png"),URL(fileURLWithPath:"/b.psd")])
        coordinator.documentPickerWasCancelled(controller)
        XCTAssertEqual(calls,1);XCTAssertEqual(count,2)
    }
    @MainActor func testResourceImportUpdatesPreviewWithoutOverwritingOriginal() async throws {
        let input=try directory();defer{try? FileManager.default.removeItem(at:input)}
        let skin=input.appendingPathComponent("skin"),res=skin.appendingPathComponent("res")
        try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        try "[PANEL]\nSIZE=120,80\n[KEY1]\nVIEW_RECT=0,0,80,60\nBACK_STYLE=1\n".write(to:skin.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
        try "[STYLE1]\nNM_IMG=art,1\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try "[IMG1]\nSOURCE_RECT=0,0,8,8\n".write(to:res.appendingPathComponent("art.til"),atomically:true,encoding:.utf8)
        let archive=input.appendingPathComponent("original.bds")
        try FileManager.default.zipItem(at:skin,to:archive,shouldKeepParent:false)
        let original=try Data(contentsOf:archive),store=SkinStore();await store.openArchive(archive)
        defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let png=UIGraphicsImageRenderer(size:CGSize(width:8,height:8),format:format).image{context in UIColor.green.setFill();context.fill(CGRect(x:0,y:0,width:8,height:8))}.pngData()!
        let art=input.appendingPathComponent("art.png");try png.write(to:art)
        let batch=ResourceImport.stageURLs([art]);defer{batch.discard()}
        let root=try XCTUnwrap(store.root),revision=store.fileRevision
        _=try await store.importResources(batch,into:root.appendingPathComponent("res"),policy:.keepBoth)
        XCTAssertGreaterThan(store.fileRevision,revision);XCTAssertTrue(store.files.contains{$0.lastPathComponent=="art.png"})
        XCTAssertFalse(store.blankPreview);XCTAssertEqual(try Data(contentsOf:archive),original)
        let export=try store.export();defer{try? FileManager.default.removeItem(at:export)}
        let unpacked=try OriginalSkinDocument.unpack(export);defer{try? FileManager.default.removeItem(at:unpacked)}
        XCTAssertEqual(try Data(contentsOf:unpacked.appendingPathComponent("res/art.png")),png)
    }
    @MainActor func testSharingBeforeOpeningSkinCreatesSaveableResourceZip() async throws {
        let input=try directory();defer{try? FileManager.default.removeItem(at:input)}
        let source=input.appendingPathComponent("art.psd");try Data([56,66,80,83]).write(to:source)
        let batch=ResourceImport.stageURLs([source]);defer{batch.discard()}
        let store=SkinStore();_=try await store.importResources(batch,into:nil,policy:.keepBoth)
        defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
        XCTAssertEqual(store.filename,"素材.zip");XCTAssertTrue(store.requiresSaveDestination);XCTAssertTrue(store.blankPreview)
        let output=try await store.prepareCopySave();defer{try? FileManager.default.removeItem(at:output.deletingLastPathComponent())}
        let root=try OriginalSkinDocument.unpack(output);defer{try? FileManager.default.removeItem(at:root)}
        XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("art.psd")),Data([56,66,80,83]))
    }
    func testRemovalRejectsFoldersOutsideFilesAndSymbolicLinks() throws {
        let root=try directory(),outside=try directory()
        defer{try? FileManager.default.removeItem(at:root);try? FileManager.default.removeItem(at:outside)}
        let owned=root.appendingPathComponent("key.png"),other=outside.appendingPathComponent("private.png")
        try Data([1,2]).write(to:owned);try Data([3,4]).write(to:other)
        try ArchiveFiles.createFolder("res",in:root,root:root)
        let link=root.appendingPathComponent("link.png")
        try FileManager.default.createSymbolicLink(at:link,withDestinationURL:other)
        for rejected in [root,root.appendingPathComponent("res"),other,link] {
            XCTAssertThrowsError(try ArchiveFiles.removeFile(rejected,root:root))
        }
        XCTAssertEqual(try Data(contentsOf:other),Data([3,4]))
        XCTAssertEqual(try Data(contentsOf:owned),Data([1,2]))
        try ArchiveFiles.removeFile(owned,root:root)
        XCTAssertFalse(FileManager.default.fileExists(atPath:owned.path))
    }
    @MainActor func testDeletingCurrentLayoutPersistsAndDoesNotRecreateDraft() async throws {
        let input=try directory();defer{try? FileManager.default.removeItem(at:input)}
        let skin=input.appendingPathComponent("skin"),port=skin.appendingPathComponent("port")
        try FileManager.default.createDirectory(at:port,withIntermediateDirectories:true)
        let layout="[PANEL]\nSIZE=120,80\n[KEY1]\nVIEW_RECT=0,0,80,60\nCENTER=q\n"
        for name in ["py_26.ini","py_9.ini"] {try layout.write(to:port.appendingPathComponent(name),atomically:true,encoding:.utf8)}
        let archive=input.appendingPathComponent("original.bds"),record=input.appendingPathComponent("resume.json")
        try FileManager.default.zipItem(at:skin,to:archive,shouldKeepParent:false)
        let original=try Data(contentsOf:archive),store=SkinStore();await store.openArchive(archive)
        defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
        let root=try XCTUnwrap(store.root),first=root.appendingPathComponent("port/py_26.ini")
        try store.open(first);store.change(store.text+"\n; edited before deleting\n")
        XCTAssertTrue(store.canUndo)
        try await store.deleteArchiveFile(first)
        XCTAssertEqual(store.current?.lastPathComponent,"py_9.ini")
        XCTAssertFalse(store.canUndo);XCTAssertFalse(store.canRedo)
        XCTAssertFalse(store.files.contains(first));XCTAssertFalse(store.blankPreview)
        XCTAssertEqual(try Data(contentsOf:archive),original)
        try await store.saveSession(EditorViewState(),recordFile:record)
        let exported=try OriginalSkinDocument.unpack(archive);defer{try? FileManager.default.removeItem(at:exported)}
        XCTAssertFalse(FileManager.default.fileExists(atPath:exported.appendingPathComponent("port/py_26.ini").path))
        XCTAssertEqual(try String(contentsOf:exported.appendingPathComponent("port/py_9.ini"),encoding:.utf8),layout)
        try await store.deleteArchiveFile(try XCTUnwrap(store.current))
        try await store.saveSession(EditorViewState(),recordFile:record)
        XCTAssertNil(store.current);XCTAssertNil(store.layoutFile);XCTAssertEqual(store.text,"")
        XCTAssertTrue(store.blankPreview);XCTAssertFalse(store.canUndo)
        let reopened=SkinStore();_=try await reopened.restoreSession(recordFile:record)
        defer{if let root=reopened.root{try? FileManager.default.removeItem(at:root)}}
        XCTAssertNil(reopened.current);XCTAssertTrue(reopened.blankPreview)
        XCTAssertFalse(reopened.files.contains{$0.pathExtension=="ini"})
    }
    @MainActor func testDeletingImageInvalidatesResolverAndKeepsEditor() async throws {
        let input=try directory();defer{try? FileManager.default.removeItem(at:input)}
        let skin=input.appendingPathComponent("skin"),res=skin.appendingPathComponent("res")
        try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        try "[PANEL]\nSIZE=120,80\n[KEY1]\nVIEW_RECT=0,0,80,60\nBACK_STYLE=1\n".write(to:skin.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
        try "[STYLE1]\nNM_IMG=art,1\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try Data([1,2,3]).write(to:res.appendingPathComponent("art.png"))
        let archive=input.appendingPathComponent("original.bds")
        try FileManager.default.zipItem(at:skin,to:archive,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(archive)
        defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
        let root=try XCTUnwrap(store.root),current=try XCTUnwrap(store.current),image=root.appendingPathComponent("res/art.png")
        XCTAssertNotNil(store.renderer.resolve("art.png"))
        let revision=store.fileRevision,text=store.text
        try await store.deleteArchiveFile(image)
        XCTAssertNil(store.renderer.resolve("art.png"));XCTAssertGreaterThan(store.fileRevision,revision)
        XCTAssertEqual(store.current,current);XCTAssertEqual(store.text,text)
        let output=try store.export();defer{try? FileManager.default.removeItem(at:output)}
        let unpacked=try OriginalSkinDocument.unpack(output);defer{try? FileManager.default.removeItem(at:unpacked)}
        XCTAssertFalse(FileManager.default.fileExists(atPath:unpacked.appendingPathComponent("res/art.png").path))
        XCTAssertTrue(FileManager.default.fileExists(atPath:unpacked.appendingPathComponent("py_26.ini").path))
    }
}
