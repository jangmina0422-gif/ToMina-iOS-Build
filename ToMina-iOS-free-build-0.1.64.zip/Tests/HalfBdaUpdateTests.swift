import XCTest
import ZIPFoundation
@testable import ToMina

final class HalfBdaUpdateTests: XCTestCase {
    let original=Data([48,184,8,152,6,42])
    let schemas:BdaTextSync.Schemas=["appearance":["6":["name":"designWidth","type":"number"]]]
    func folder() throws -> URL {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true);return root
    }
    @discardableResult func pair(_ root:URL,_ dir:String,_ ext:String="json",_ text:String="{\"designWidth\":1920}") throws -> URL {
        let parent=root.appendingPathComponent(dir)
        try FileManager.default.createDirectory(at:parent,withIntermediateDirectories:true)
        try original.write(to:parent.appendingPathComponent("appearanceConfig"))
        let file=parent.appendingPathComponent("appearanceConfig."+ext)
        try Data(text.utf8).write(to:file);return file
    }
    func update(_ root:URL,drafts:[URL:Data]=[:]) throws -> BdaTextSync.UpdateResult {
        try BdaTextSync.updateHalfBda(root:root,files:SingleGIFCompiler.files(root),drafts:drafts,schemas:schemas)
    }
    func testWholeProjectUpdatesRepeatAndExportRetainsUnknownFields() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"light/port");try pair(root,"dark/land","txt","{\"designWidth\":720}");try pair(root,"same","JSON","{\"designWidth\":1080}")
        let resource=root.appendingPathComponent("Token.txt"),resourceData=Data("unchanged-resource".utf8);try resourceData.write(to:resource)
        let result=try update(root);XCTAssertEqual(result.updated,2);XCTAssertEqual(result.unchanged,1)
        let binary=file.deletingPathExtension(),updated=try Data(contentsOf:binary)
        XCTAssertEqual(updated,Data([48,128,15,152,6,42]))
        let repeated=try update(root);XCTAssertEqual(repeated.updated,0);XCTAssertEqual(repeated.unchanged,3)
        let exportRoot=try folder();defer{try? FileManager.default.removeItem(at:exportRoot)}
        let archive=exportRoot.appendingPathComponent("edited.bda"),reopened=exportRoot.appendingPathComponent("reopened")
        try FileManager.default.zipItem(at:root,to:archive,shouldKeepParent:false)
        try FileManager.default.createDirectory(at:reopened,withIntermediateDirectories:true)
        try FileManager.default.unzipItem(at:archive,to:reopened)
        XCTAssertEqual(try Data(contentsOf:reopened.appendingPathComponent("light/port/appearanceConfig")),updated)
        XCTAssertEqual(try Data(contentsOf:reopened.appendingPathComponent("Token.txt")),resourceData)
    }
    func testInvalidLaterFileDoesNotCommitEarlierBinaryOrDraft() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"a-good","json","{\"designWidth\":1080}");try pair(root,"z-bad","txt","{bad")
        let before=try Data(contentsOf:file)
        XCTAssertThrowsError(try update(root,drafts:[file:Data("{\"designWidth\":1920}".utf8)])) { error in XCTAssertTrue(error.localizedDescription.contains("z-bad")) }
        XCTAssertEqual(try Data(contentsOf:file),before);XCTAssertEqual(try Data(contentsOf:file.deletingPathExtension()),original)
    }
    func testConflictMissingBinaryAndUnknownFieldsLeaveFilesIntact() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"port"),binary=file.deletingPathExtension(),conflict=file.deletingLastPathComponent().appendingPathComponent("APPEARANCECONFIG.TXT")
        try Data("{}".utf8).write(to:conflict)
        XCTAssertThrowsError(try update(root)) { XCTAssertTrue($0.localizedDescription.contains("冲突")) }
        XCTAssertEqual(try Data(contentsOf:binary),original);try FileManager.default.removeItem(at:conflict)
        try Data("{\"unknown\":1}".utf8).write(to:file)
        XCTAssertThrowsError(try update(root)) { XCTAssertTrue($0.localizedDescription.contains("未验证字段")) }
        XCTAssertEqual(try Data(contentsOf:binary),original);try FileManager.default.removeItem(at:binary)
        XCTAssertThrowsError(try update(root)) { XCTAssertTrue($0.localizedDescription.contains("缺少")) }
    }
    func testNoPairsReportsNothingToUpdate() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        XCTAssertThrowsError(try update(root)) { XCTAssertTrue($0.localizedDescription.contains("无需更新半 BDA")) }
    }
    @MainActor func testToolCommitsUnsavedEditorDraftAndCanRepeat() async throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"port","json","{\"designWidth\":1080}"),store=SkinStore()
        store.root=root;store.filename="half.bda";store.files=try SingleGIFCompiler.files(root)
        try store.open(file);store.text="{\"designWidth\":1920}"
        XCTAssertTrue(store.canUpdateHalfBda)
        try await store.updateHalfBda(schemas:schemas)
        XCTAssertEqual(try String(contentsOf:file,encoding:.utf8),store.text)
        XCTAssertEqual(try Data(contentsOf:file.deletingPathExtension()),Data([48,128,15,152,6,42]))
        XCTAssertTrue(store.halfBdaReport.contains("同步 JSON/TXT 1 个"),store.halfBdaReport);XCTAssertFalse(store.busy)
        try await store.updateHalfBda(schemas:schemas)
        XCTAssertTrue(store.halfBdaReport.contains("同步 JSON/TXT 0 个"),store.halfBdaReport)
        for suffix in ["bds","bdi","zip"] {
            store.filename="same-config."+suffix;XCTAssertTrue(store.canUpdateHalfBda)
            try await store.updateHalfBda(schemas:schemas)
            XCTAssertEqual(store.filename,"same-config."+suffix)
            XCTAssertEqual(try Data(contentsOf:file.deletingPathExtension()),Data([48,128,15,152,6,42]))
        }
        store.files=[];store.filename="no-config.bda";XCTAssertFalse(store.canUpdateHalfBda)
    }
    @MainActor func testFailedToolKeepsUnsavedDraftAndOldBinary() async throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"port","json","{\"designWidth\":1080}"),store=SkinStore()
        store.root=root;store.filename="half.bda";store.files=try SingleGIFCompiler.files(root)
        try store.open(file);store.text="{broken"
        do{try await store.updateHalfBda(schemas:schemas);XCTFail("Invalid JSON accepted")}catch{}
        XCTAssertEqual(store.text,"{broken");XCTAssertEqual(try Data(contentsOf:file.deletingPathExtension()),original)
        XCTAssertEqual(try String(contentsOf:file,encoding:.utf8),"{\"designWidth\":1080}")
        XCTAssertTrue(store.halfBdaReport.contains("更新未完成"));XCTAssertFalse(store.busy)
    }
    // MARK: Any base package: plaintext copies, suffixed names and engine regeneration

    func makeCopy(_ root:URL,_ dir:String) throws -> (binary:URL,copy:URL) {
        let parent=root.appendingPathComponent(dir);try FileManager.default.createDirectory(at:parent,withIntermediateDirectories:true)
        let binary=parent.appendingPathComponent("appearanceConfig");try original.write(to:binary)
        let copy=parent.appendingPathComponent("appearanceConfig.decoded.json")
        try BinaryPlaintext.decode(binary,schemas:schemas).write(to:copy,options:.atomic)
        return (binary,copy)
    }
    func editCopy(_ copy:URL,width:Int) throws {
        var json=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:copy)) as? [String:Any])
        var decoded=try XCTUnwrap(json["decoded"] as? [String:Any]);XCTAssertEqual((decoded["designWidth"] as? NSNumber)?.intValue,1080)
        decoded["designWidth"]=width;json["decoded"]=decoded
        try JSONSerialization.data(withJSONObject:json,options:[.prettyPrinted,.sortedKeys]).write(to:copy,options:.atomic)
    }
    func testPlaintextCopyEditsAreWrittenBackAndSurviveRegeneration() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let (binary,copy)=try makeCopy(root,"port");try editCopy(copy,width:1920)
        XCTAssertTrue(HalfBdaUpdate.available(root:root,files:try SingleGIFCompiler.files(root)))
        XCTAssertTrue(HalfBdaUpdate.availability(root:root,files:try SingleGIFCompiler.files(root)).contains("明文副本"))
        let result=try HalfBdaUpdate.commit(root:root,files:SingleGIFCompiler.files(root),regenerated:[:],schemas:schemas)
        XCTAssertEqual(result.patched,1,result.report);XCTAssertEqual(try Data(contentsOf:binary),Data([48,128,15,152,6,42]),"unknown field 99 kept")
        let refreshed=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:copy)) as? [String:Any])
        XCTAssertEqual(refreshed["sourceSha256"] as? String,HalfBdaUpdate.hash(try Data(contentsOf:binary)))
        XCTAssertTrue(try String(contentsOf:root.appendingPathComponent(HalfBdaUpdate.overridesName),encoding:.utf8).contains("1920"))
        // A later INI regeneration that restores 1080 keeps the saved plaintext edit.
        let again=try HalfBdaUpdate.commit(root:root,files:SingleGIFCompiler.files(root),regenerated:["port/appearanceConfig":original],schemas:schemas)
        XCTAssertEqual(try Data(contentsOf:binary),Data([48,128,15,152,6,42]),again.report);XCTAssertEqual(again.patched,0)
    }
    func testStaleCopyIsRejectedWithoutWritingAnything() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let (binary,copy)=try makeCopy(root,"land");try editCopy(copy,width:1920)
        let changed=Data([48,176,9]);try changed.write(to:binary)
        XCTAssertThrowsError(try HalfBdaUpdate.commit(root:root,files:SingleGIFCompiler.files(root),regenerated:[:],schemas:schemas)) {
            XCTAssertTrue($0.localizedDescription.contains("重新生成明文副本"),$0.localizedDescription)
        }
        XCTAssertEqual(try Data(contentsOf:binary),changed)
        XCTAssertFalse(FileManager.default.fileExists(atPath:root.appendingPathComponent(HalfBdaUpdate.overridesName).path))
    }
    func testSuffixedConfigNamesAndCopiesAreRecognised() {
        XCTAssertEqual(HalfBdaUpdate.configType("layoutConfig_py_26"),"layout");XCTAssertEqual(HalfBdaUpdate.configType("AppearanceConfig"),"appearance")
        XCTAssertNil(HalfBdaUpdate.configType("appearanceConfig.json"))
        XCTAssertTrue(HalfBdaUpdate.isCopy(URL(fileURLWithPath:"/x/port/appearanceConfig.decoded-2.json")))
        XCTAssertFalse(HalfBdaUpdate.isCopy(URL(fileURLWithPath:"/x/port/appearanceConfig.json")))
    }
    func testChooseKeepsTheModeThatReproducesTheBinaryAndRejectsOthers() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        _=try makeCopy(root,"port")
        let edited=Data([48,128,15,152,6,42]).base64EncodedString(),lossy=Data([48,184,8]).base64EncodedString()
        let result:[String:Any]=["android":["writes":["port/appearanceConfig":edited]],"ios":["writes":["port/appearanceConfig":lossy]]]
        let choice=try XCTUnwrap(HalfBdaUpdate.choose(base:root,result:result,schemas:schemas))
        XCTAssertEqual(choice.mode,"android");XCTAssertEqual(choice.changed,2);XCTAssertTrue(choice.trustworthy,choice.summary)
        let only=try XCTUnwrap(HalfBdaUpdate.choose(base:root,result:["ios":["writes":["port/appearanceConfig":lossy]]],schemas:schemas))
        XCTAssertTrue(only.losesUnknown);XCTAssertFalse(only.trustworthy)
        let unverified=try XCTUnwrap(HalfBdaUpdate.choose(base:root,result:["android":["writes":["port/appearanceConfig":edited]]],schemas:[:]))
        XCTAssertFalse(unverified.trustworthy,"no schema means no safe comparison")
    }
    func testEngineRegeneratesACompiledPackageFromItsOwnINI() throws {
        let fm=FileManager.default,root=try folder();defer{try? fm.removeItem(at:root)}
        let project=root.appendingPathComponent("project");try fm.createDirectory(at:project.appendingPathComponent("port/res"),withIntermediateDirectories:true)
        let texts=["port/py_26.ini":"[PANEL]\nSIZE=1080,640\nBACK_STYLE=1\n[KEY1]\nCENTER=q\nVIEW_RECT=0,0,108,160\nBACK_STYLE=1\nFORE_STYLE=2\n",
                   "port/res/default.css":"[STYLE1]\nNM_IMG=btn_fhl,1\n[STYLE2]\nSHOW=Q\nFONT_SIZE=20\nNM_COLOR=FF112233\n",
                   "port/res/btn_fhl.til":"[IMG1]\nSOURCE_RECT=0,0,1,1\n"]
        for (path,text) in texts {try Data(text.utf8).write(to:project.appendingPathComponent(path))}
        let fixture=try XCTUnwrap(Bundle(for:Self.self).url(forResource:"GIFBackgroundAnimated",withExtension:"gif",subdirectory:"Fixtures"))
        let gif=try SingleGIFCompiler.GIF(name:"py26bj.gif",bytes:Data(contentsOf:fixture))
        let output=try SingleGIFCompiler.compile(project:project,name:"keyboard.bds",backgrounds:["port/py_26.ini":gif.name],gifs:[gif])
        defer {try? fm.removeItem(at:output.folder.deletingLastPathComponent())}
        try SingleGIFCompiler.apply(output,to:project)
        XCTAssertTrue(HalfBdaUpdate.compiledFromIni(project))
        XCTAssertTrue(HalfBdaUpdate.availability(root:project,files:try SingleGIFCompiler.files(project)).contains("INI/CSS"))
        // The public build has no verified schema, so the engine runs but the result is not trusted.
        let choice=try XCTUnwrap(HalfBdaUpdate.regenerate(project:project,name:"keyboard.bds",schemas:[:]))
        XCTAssertNotNil(choice.writes["port/appearanceConfig"],choice.error);XCTAssertFalse(choice.trustworthy)
    }

    // MARK: 转横屏 / 转系统 for half-BDA packages

    /// Types are known but carry no fields, so every value counts as unknown and is compared as such.
    let opaque:BdaTextSync.Schemas=["appearance":[:],"animation":[:],"layout":[:]]
    func compiledProject(_ root:URL) throws -> URL {
        let fm=FileManager.default,project=root.appendingPathComponent("project")
        try fm.createDirectory(at:project.appendingPathComponent("port/res"),withIntermediateDirectories:true)
        let texts=["Info.txt":"Name=T\r\nSupportPlatform=A\r\n",
                   "port/gen.ini":"[PANEL]\nSIZE=1080,640\n",
                   "port/py_26.ini":"[PANEL]\nSIZE=1080,640\nBACK_STYLE=1\n[KEY1]\nCENTER=q\nVIEW_RECT=0,0,108,160\nBACK_STYLE=1\nFORE_STYLE=2\n",
                   "port/res/default.css":"[STYLE1]\nNM_IMG=btn_fhl,1\n[STYLE2]\nSHOW=Q\nFONT_SIZE=20\nNM_COLOR=FF112233\n",
                   "port/res/btn_fhl.til":"[IMG1]\nSOURCE_RECT=0,0,1,1\n"]
        for (path,text) in texts {try Data(text.utf8).write(to:project.appendingPathComponent(path))}
        let fixture=try XCTUnwrap(Bundle(for:Self.self).url(forResource:"GIFBackgroundAnimated",withExtension:"gif",subdirectory:"Fixtures"))
        let gif=try SingleGIFCompiler.GIF(name:"py26bj.gif",bytes:Data(contentsOf:fixture))
        let output=try SingleGIFCompiler.compile(project:project,name:"keyboard.bds",backgrounds:["port/py_26.ini":gif.name],gifs:[gif])
        try SingleGIFCompiler.apply(output,to:project);try? fm.removeItem(at:output.folder.deletingLastPathComponent())
        return project
    }
    func testSupportPlatformGainsOnlyTheMissingTarget() {
        XCTAssertEqual(HalfBdaUpdate.supportPlatform("Name=A\r\nSupportPlatform=SWIA\r\n",toIos:true),"Name=A\r\nSupportPlatform=SWIA\r\n")
        XCTAssertEqual(HalfBdaUpdate.supportPlatform("SupportPlatform=A\r\nX=1",toIos:true),"SupportPlatform=I\r\nX=1")
        XCTAssertEqual(HalfBdaUpdate.supportPlatform("SupportPlatform=I",toIos:false),"SupportPlatform=A")
        XCTAssertTrue(HalfBdaUpdate.supportPlatform("Name=A",toIos:true).hasSuffix("SupportPlatform=I\r\n"))
    }
    @MainActor func testLandscapeConversionRegeneratesLandscapeConfigsAndKeepsGIF() throws {
        let fm=FileManager.default,root=try folder();defer{try? fm.removeItem(at:root)}
        let project=try compiledProject(root),files=try SingleGIFCompiler.files(project)
        XCTAssertTrue(HalfBdaUpdate.compiledFromIni(project))
        let result=try HalfBdaUpdate.convert(root:project,files:files,name:"keyboard.bds",landscape:true,width:1920,schemas:opaque)
        defer{try? fm.removeItem(at:result.folder)}
        XCTAssertEqual(result.name,"keyboard转横屏.bds");XCTAssertTrue(result.report.contains("转横屏"),result.report)
        XCTAssertEqual(HalfBdaUpdate.backgrounds(result.folder)["land/py_26.ini"],"py26bj.gif")
        // This fixture's appearance holds styles only, so portrait and landscape may encode identically;
        // what must hold is that both landscape configs exist and the GIF background reaches landscape.
        for name in ["land/appearanceConfig","land/animationConfig"] { XCTAssertTrue(fm.fileExists(atPath:result.folder.appendingPathComponent(name).path),name) }
        // The converted package is consistent: rebuilding it again changes nothing.
        let again=try XCTUnwrap(HalfBdaUpdate.regenerate(project:result.folder,name:result.name,schemas:opaque))
        XCTAssertTrue(again.trustworthy,again.summary);XCTAssertEqual(again.changed,0)
    }
    @MainActor func testSystemConversionBuildsBDIFromTheSameINI() throws {
        let fm=FileManager.default,root=try folder();defer{try? fm.removeItem(at:root)}
        let project=try compiledProject(root),files=try SingleGIFCompiler.files(project)
        let result=try HalfBdaUpdate.convert(root:project,files:files,name:"keyboard.bds",landscape:false,width:0,schemas:opaque)
        defer{try? fm.removeItem(at:result.folder)}
        XCTAssertEqual(result.name,"keyboard_iOS.bdi")
        XCTAssertTrue(try String(contentsOf:result.folder.appendingPathComponent("Info.txt"),encoding:.utf8).contains("SupportPlatform=I"))
        let names=try SingleGIFCompiler.files(result.folder).map{HalfBdaUpdate.relative($0,result.folder)}
        XCTAssertTrue(names.contains("port/appearanceConfig"),names.joined(separator:" "))
        XCTAssertFalse(names.contains{$0.contains("layoutConfig_")},"BDI keeps INI layouts")
        XCTAssertEqual(try Data(contentsOf:result.folder.appendingPathComponent("res/py26bj.gif")),try Data(contentsOf:project.appendingPathComponent("res/py26bj.gif")))
    }
    @MainActor func testConversionRefusesWithoutVerifiedSchema() throws {
        let fm=FileManager.default,root=try folder();defer{try? fm.removeItem(at:root)}
        let project=try compiledProject(root),files=try SingleGIFCompiler.files(project)
        XCTAssertThrowsError(try HalfBdaUpdate.convert(root:project,files:files,name:"keyboard.bds",landscape:true,width:1920,schemas:[:])) {
            XCTAssertTrue($0.localizedDescription.contains("未生成转换包"),$0.localizedDescription)
        }
    }

}
