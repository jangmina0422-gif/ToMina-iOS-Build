import SwiftUI
import UIKit

struct PackageCheckView: View {
    @ObservedObject var store:SkinStore
    let openFile:(URL)->Void
    @State private var result:PackageCheck.Result?
    @State private var filter="all"
    @State private var working=false
    @State private var error=""
    @State private var copied=false
    private var issues:[PackageCheck.Issue] { result?.issues.filter{filter=="all" || $0.severity==filter} ?? [] }
    var body:some View {
        List {
            SwiftUI.Section {
                MinaNote("扫描整个底包的配置、资源引用和布局问题。只检查，不自动修复或导出；实际兼容性仍需在输入法中验证。")
                Button(result==nil ? "开始检查":"重新检查") { scan() }.buttonStyle(MinaPrimaryButtonStyle()).disabled(working || store.root==nil).accessibilityIdentifier("packageCheck.start")
                if working { ProgressView("正在检查整个底包…") }
                if !error.isEmpty { Text(error).foregroundStyle(.red) }
            }
            if let result {
                SwiftUI.Section {
                    Text("文件 \(result.summary.files) · 错误 \(result.summary.error) · 警告 \(result.summary.warning) · 未确认/提示 \(result.summary.info)").accessibilityIdentifier("packageCheck.summary")
                    Button(copied ? "报告已复制":"复制检查报告") { UIPasteboard.general.string=result.report;copied=true }.buttonStyle(MinaToolButtonStyle()).accessibilityIdentifier("packageCheck.copy")
                    Picker("问题类别",selection:$filter) { Text("全部").tag("all");Text("错误").tag("error");Text("警告").tag("warning");Text("未确认/提示").tag("info") }
                }
                SwiftUI.Section {
                    ForEach(issues) { issue in
                        DisclosureGroup {
                            Text(issue.message).textSelection(.enabled)
                            if !issue.section.isEmpty { Text("[\(issue.section)] \(issue.field)").font(.caption).textSelection(.enabled) }
                            MinaNote("建议："+issue.suggestion)
                            if let file=editable(issue) { Button("打开文件") { openFile(file) }.buttonStyle(MinaButtonStyle()) }
                        } label: {
                            VStack(alignment:.leading,spacing:4) {
                                Text((issue.severity=="error" ? "错误":issue.severity=="warning" ? "警告":"未确认/提示")+" · "+issue.message).font(.subheadline)
                                Text(issue.path+(issue.line>0 ? " · 第 \(issue.line) 行":"")).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if issues.isEmpty { MinaNote("本次检查范围内没有该类问题；未检查项仍需单独核对。") }
                    if result.summary.omitted>0 { MinaNote("另有 \(result.summary.omitted) 条未展示，报告保留前 1000 条，错误优先。") }
                }
            }
            SwiftUI.Section {
                MinaNote("当前源码草稿参与检查。图片检查格式读取与尺寸，未逐帧渲染；未知二进制字段和输入法版本行为不判为已通过。")
                if store.hasUnsavedAnimationDraft { MinaNote("独立动效草稿尚未保存，本次检查使用包内已保存的动效配置。") }
            }
        }.navigationTitle("底包检查").navigationBarBackButtonHidden(working).interactiveDismissDisabled(working)
    }
    private func editable(_ issue:PackageCheck.Issue)->URL? {
        guard store.bda==nil,let root=store.root,let file=try? GlobalViewFit.child(issue.path,root:root),["ini","css","til","cnd","pop","json","txt","anim","ani"].contains(file.pathExtension.lowercased()),FileManager.default.fileExists(atPath:file.path) else{return nil};return file
    }
    private func scan(){
        guard let root=store.root,!working else{return}
        let drafts=store.current.map{[$0:store.text]} ?? [:]
        working=true;store.busy=true;error="";copied=false
        Task {
            defer { working=false;store.busy=false }
            do { result=try await Task.detached(priority:.userInitiated){try PackageCheck.scan(root,drafts:drafts)}.value }
            catch { self.error="检查未完成："+error.localizedDescription }
        }
    }
}
