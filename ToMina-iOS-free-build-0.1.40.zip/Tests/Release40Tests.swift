import XCTest
import ZIPFoundation
@testable import ToMina

final class Release40Tests: XCTestCase {
    func testSearchUsesLiteralUTF16RangesAndFindsEveryOccurrence() {
        let text = "🍣 中文 KEY1\nkey1\n[A.*]"
        XCTAssertEqual(SourceSearch.ranges(in: text, query: "KEY1"), [NSRange(location: 6, length: 4), NSRange(location: 11, length: 4)])
        XCTAssertEqual(SourceSearch.ranges(in: text, query: ".*"), [NSRange(location: 18, length: 2)])
        XCTAssertTrue(SourceSearch.ranges(in: text, query: "").isEmpty)
        XCTAssertTrue(SourceSearch.ranges(in: text, query: "不存在").isEmpty)
    }
    @MainActor func testLegacyBrokenPathRepairsAndCopySaveBindsOriginal() async throws {
        let fm = FileManager.default
        let dir = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try fm.createDirectory(at: dir.appendingPathComponent("skin/port"), withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: dir) }
        let source = dir.appendingPathComponent("skin/port/py_26.ini")
        try "[PANEL]\nSIZE=720,400\n[KEY1]\nVIEW_RECT=0,0,40,40\nCENTER=q\n".write(to: source, atomically: true, encoding: .utf8)
        let original = dir.appendingPathComponent("test.bds"), record = dir.appendingPathComponent("resume.json")
        try fm.zipItem(at: dir.appendingPathComponent("skin"), to: original, shouldKeepParent: false)
        let store = SkinStore(); await store.openArchive(original, asCopy: true)
        defer { if let root = store.root { try? fm.removeItem(at: root) } }
        XCTAssertNil(store.error)
        XCTAssertEqual(store.relative(try XCTUnwrap(store.current)), "port/py_26.ini")
        store.setParameter(section: "PANEL", key: "SIZE", value: "900,500")
        try await store.overwriteSelectedOriginal(original, view: EditorViewState(), recordFile: record)
        XCTAssertFalse(store.requiresSaveDestination)
        store.setParameter(section: "PANEL", key: "SIZE", value: "910,510")
        try await store.saveSession(EditorViewState(), recordFile: record)
        let unpacked = try OriginalSkinDocument.unpack(original); defer { try? fm.removeItem(at: unpacked) }
        XCTAssertTrue(try String(contentsOf: unpacked.appendingPathComponent("port/py_26.ini"), encoding: .utf8).contains("SIZE=910,510"))
        var legacy = try JSONDecoder().decode(EditorResumeRecord.self, from: Data(contentsOf: record))
        legacy.current = "061FE50/port/py_26.ini"; legacy.preview = legacy.current
        try OriginalSkinDocument.write(legacy, at: record)
        let restored = SkinStore(); _ = try await restored.restoreSession(recordFile: record)
        defer { if let root = restored.root { try? fm.removeItem(at: root) } }
        XCTAssertEqual(restored.relative(try XCTUnwrap(restored.current)), "port/py_26.ini")
        XCTAssertEqual(restored.panel.width, 910)
        let repaired = try JSONDecoder().decode(EditorResumeRecord.self, from: Data(contentsOf: record))
        XCTAssertEqual(repaired.current, "port/py_26.ini")
        let archive = try PreparedSkinArchive.index(unpacked)
        XCTAssertThrowsError(try OriginalSkinDocument.restoredPath("061FE50/../port/py_26.ini", archive: archive))
        XCTAssertNil(try OriginalSkinDocument.restoredPath("DEADBEEF/port/missing.ini", archive: archive))
    }
}
