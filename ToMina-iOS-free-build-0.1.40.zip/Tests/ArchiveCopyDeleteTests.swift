import XCTest
import ZIPFoundation
@testable import ToMina

final class ArchiveCopyDeleteTests: XCTestCase {
    private func directory() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }
    func testCopyPreservesBinaryDataExtensionAndExistingCopies() throws {
        let root = try directory(); defer { try? FileManager.default.removeItem(at: root) }
        let folder = root.appendingPathComponent("素材")
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: false)
        let original = folder.appendingPathComponent("图案.PNG"), bytes = Data([0, 255, 128, 3, 10])
        try bytes.write(to: original)
        try Data([7]).write(to: folder.appendingPathComponent("图案 副本.png"))
        let copy = try ArchiveFiles.copyFile(original, root: root)
        XCTAssertEqual(copy.lastPathComponent, "图案 副本 2.PNG")
        XCTAssertEqual(try Data(contentsOf: copy), bytes)
        XCTAssertEqual(try Data(contentsOf: original), bytes)
        XCTAssertEqual(try Data(contentsOf: folder.appendingPathComponent("图案 副本.png")), Data([7]))
        let plain = folder.appendingPathComponent("无后缀"); try bytes.write(to: plain)
        XCTAssertEqual(try ArchiveFiles.copyFile(plain, root: root).lastPathComponent, "无后缀 副本")
    }
    func testCopyRejectsOutsideFilesDirectoriesAndLinks() throws {
        let root = try directory(), outside = try directory()
        defer { try? FileManager.default.removeItem(at: root); try? FileManager.default.removeItem(at: outside) }
        let original = root.appendingPathComponent("source.bin"), other = outside.appendingPathComponent("source.bin")
        try Data([1]).write(to: original); try Data([2]).write(to: other)
        let link = root.appendingPathComponent("link.bin"), parentLink = root.appendingPathComponent("linked")
        try FileManager.default.createSymbolicLink(at: link, withDestinationURL: original)
        try FileManager.default.createSymbolicLink(at: parentLink, withDestinationURL: outside)
        for rejected in [root, outside, other, link, parentLink.appendingPathComponent("source.bin")] {
            XCTAssertThrowsError(try ArchiveFiles.copyFile(rejected, root: root))
        }
        XCTAssertEqual(try Data(contentsOf: other), Data([2]))
        XCTAssertEqual(try ArchiveFiles.entries(in: root, root: root).count, 1)
    }
    func testBatchDeletionValidatesWholeSelectionAndDeduplicates() throws {
        let root = try directory(), outside = try directory()
        defer { try? FileManager.default.removeItem(at: root); try? FileManager.default.removeItem(at: outside) }
        let a = root.appendingPathComponent("a.ini"), b = root.appendingPathComponent("b.png"), other = outside.appendingPathComponent("c.ini")
        for file in [a,b,other] { try Data([1,2,3]).write(to: file) }
        XCTAssertThrowsError(try ArchiveFiles.removeFiles([a,b,other], root: root))
        XCTAssertThrowsError(try ArchiveFiles.removeFiles([a,root.appendingPathComponent("missing")], root: root))
        for file in [a,b,other] { XCTAssertEqual(try Data(contentsOf: file), Data([1,2,3])) }
        XCTAssertEqual(Set(try ArchiveFiles.removeFiles([a,a,b], root: root)), Set([a,b]))
        XCTAssertTrue(try ArchiveFiles.entries(in: root, root: root).isEmpty)
        XCTAssertEqual(try Data(contentsOf: other), Data([1,2,3]))
        XCTAssertTrue(try ArchiveFiles.removeFiles([], root: root).isEmpty)
    }
    private func archive(in input: URL) throws -> URL {
        let skin = input.appendingPathComponent("skin")
        try FileManager.default.createDirectory(at: skin, withIntermediateDirectories: false)
        try "[PANEL]\nSIZE=240,120\n[KEY1]\nVIEW_RECT=0,0,120,80\nCENTER=q\n".write(to: skin.appendingPathComponent("py_26.ini"), atomically: true, encoding: .utf8)
        try "[PANEL]\nSIZE=200,100\n[KEY1]\nVIEW_RECT=0,0,90,70\nCENTER=x\n".write(to: skin.appendingPathComponent("py_9.ini"), atomically: true, encoding: .utf8)
        try Data([0,255,7]).write(to: skin.appendingPathComponent("picture.png"))
        let file = input.appendingPathComponent("original.bds")
        try FileManager.default.zipItem(at: skin, to: file, shouldKeepParent: false)
        return file
    }
    @MainActor func testCopyUsesLatestEditorDraftAndPersistsOnOriginalSave() async throws {
        let input = try directory(); defer { try? FileManager.default.removeItem(at: input) }
        let original = try archive(in: input), before = try Data(contentsOf: original), store = SkinStore()
        await store.openArchive(original)
        let root = try XCTUnwrap(store.root); defer { try? FileManager.default.removeItem(at: root) }
        let current = root.appendingPathComponent("py_26.ini"); try store.open(current)
        let draft = store.text.replacingOccurrences(of: "240,120", with: "320,180")
        _ = store.editSource(draft)
        let copy = try await store.copyArchiveFile(current)
        XCTAssertEqual(try String(contentsOf: copy, encoding: .utf8), draft)
        XCTAssertEqual(store.current, current); XCTAssertEqual(store.text, draft)
        XCTAssertEqual(store.panel, CGSize(width: 320, height: 180))
        XCTAssertTrue(store.files.contains(copy)); XCTAssertTrue(store.canUndo)
        XCTAssertEqual(try Data(contentsOf: original), before)
        try await store.saveSession(EditorViewState(), recordFile: input.appendingPathComponent("resume.json"))
        let unpacked = try OriginalSkinDocument.unpack(original); defer { try? FileManager.default.removeItem(at: unpacked) }
        XCTAssertEqual(try String(contentsOf: unpacked.appendingPathComponent(copy.lastPathComponent), encoding: .utf8), draft)
    }
    @MainActor func testBatchDeletionRefreshesCurrentPreviewAndDoesNotResurrectDraft() async throws {
        let input = try directory(); defer { try? FileManager.default.removeItem(at: input) }
        let original = try archive(in: input), before = try Data(contentsOf: original), store = SkinStore()
        await store.openArchive(original)
        let root = try XCTUnwrap(store.root); defer { try? FileManager.default.removeItem(at: root) }
        let current = root.appendingPathComponent("py_26.ini"), picture = root.appendingPathComponent("picture.png")
        try store.open(current); _ = store.editSource(store.text + "\n; pending draft")
        try await store.deleteArchiveFiles([current, picture])
        try await Task.sleep(for: .milliseconds(550))
        XCTAssertEqual(store.current?.lastPathComponent, "py_9.ini")
        XCTAssertEqual(store.panel, CGSize(width: 200, height: 100))
        XCTAssertFalse(store.canUndo); XCTAssertEqual(store.files.count, 1)
        for file in [current,picture] { XCTAssertFalse(FileManager.default.fileExists(atPath: file.path)) }
        XCTAssertEqual(try Data(contentsOf: original), before)
        try await store.saveSession(EditorViewState(), recordFile: input.appendingPathComponent("resume.json"))
        let restored = SkinStore(); _ = try await restored.restoreSession(recordFile: input.appendingPathComponent("resume.json"))
        defer { if let folder = restored.root { try? FileManager.default.removeItem(at: folder) } }
        XCTAssertEqual(restored.files.map(\.lastPathComponent), ["py_9.ini"])
        XCTAssertEqual(restored.panel, CGSize(width: 200, height: 100))
    }
}
