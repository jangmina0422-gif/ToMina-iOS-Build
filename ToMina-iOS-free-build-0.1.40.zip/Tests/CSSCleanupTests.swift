import XCTest
import ZIPFoundation
@testable import ToMina

final class CSSCleanupTests: XCTestCase {
    private func values(_ id: Int, in text: String) throws -> [String: String] {
        try XCTUnwrap(SkinConfiguration.parse(text).first { $0.name == "STYLE\(id)" }).values
    }
    func testClearingPreservesExactHeadersCountAndEmptySlots() throws {
        let css = "; preamble\r\n[GLOBAL]\r\nSTYLE_NUM=99 // unchanged\r\n[style003] ; keep slot\r\nNM_COLOR=FF123456\r\n// unused body note\r\n\r\n[STYLE10]\r\n  \r\n[STYLE99]\r\n; comment-only body\r\n[OFFSET1]\r\nPOS=0,0\r\n"
        let expected = "; preamble\r\n[GLOBAL]\r\nSTYLE_NUM=99 // unchanged\r\n[style003] ; keep slot\r\n\r\n[STYLE10]\r\n  \r\n[STYLE99]\r\n[OFFSET1]\r\nPOS=0,0\r\n"
        let result = try CSSCleanup.clean(css, external: [])
        XCTAssertEqual(result.cleared, [3, 99])
        XCTAssertEqual(result.text, expected)
        let repeated = try CSSCleanup.clean(result.text, external: [])
        XCTAssertEqual(repeated.cleared, [])
        XCTAssertEqual(repeated.text, expected)
    }
    func testReachabilityIncludesPanelsCandidatePopupParticlesAndCycles() throws {
        let css = "; keep this comment\r\n[GLOBAL]\r\nSTYLE_NUM=20 // original ceiling\r\n\r\n[STYLE1]\r\nBACK_STYLE=2\r\n[STYLE2]\r\nNM_COLOR=FFFFFFFF\r\n[STYLE3]\r\nNM_IMG=atlas,1\r\n[STYLE4]\r\nNM_COLOR=FF00FF00\r\n[STYLE5]\r\nFORE_STYLE=1\r\n[STYLE7]\r\nFORE_STYLE=8\r\n; preserve notes\r\n[STYLE8]\r\nFORE_STYLE=7\r\n[STYLE20]\r\nSHOW=unused\r\n"
        let references = ["[KEY1]\nFORE_STYLE=1\n", "[ICON1]\nBACK_STYLE=3\n", "[POP]\nBACK_STYLE=4\n", "[ANIM2]\nPARTICLE_IMAGE=5\n"]
        let result = try CSSCleanup.clean(css, external: references)
        XCTAssertEqual(result.cleared,[7,8,20]); XCTAssertTrue(result.text.contains("STYLE_NUM=20 // original ceiling\r\n"))
        for id in 1...5 { XCTAssertTrue(result.text.contains("[STYLE\(id)]")) }
        XCTAssertTrue(result.text.contains("; keep this comment")); XCTAssertFalse(result.text.contains("; preserve notes"))
        for id in [7,8,20] { XCTAssertTrue(try values(id, in: result.text).isEmpty) }
        XCTAssertFalse(result.text.contains("SHOW=unused")); XCTAssertTrue(result.text.contains("NM_IMG=atlas,1"))
        XCTAssertEqual(try CSSCleanup.clean(result.text,external:references).cleared,[])
    }
    func testUncalledExternalStylesDoNotKeepStylesButCalledChainsDo() throws {
        let css = "[GLOBAL]\nSTYLE_NUM=9\n[STYLE1]\nNM_COLOR=FFFFFFFF\n[STYLE2]\nNM_COLOR=FF000000\n[STYLE9]\nSHOW=unused\n[OFFSET1]\nPOS=0,0\n"
        let extra = "[STYLE100]\nFORE_STYLE=1\n[STYLE101]\nFORE_STYLE=2\n"
        let root = "[KEY1]\nANIM_STYLE=100\n"
        let result = try CSSCleanup.clean(css, external: [extra, root])
        XCTAssertEqual(result.cleared, [2, 9])
        for id in [2, 9] { XCTAssertTrue(try values(id, in: result.text).isEmpty) }
        XCTAssertTrue(result.text.contains("[STYLE1]"))
        XCTAssertTrue(result.text.contains("[OFFSET1]\nPOS=0,0"))
        XCTAssertTrue(result.text.contains("STYLE_NUM=9\n"))
        XCTAssertEqual(try CSSCleanup.clean(css, external: [extra, root + "[PANEL]\nFORE_STYLE=101\n"]).cleared, [9])
    }
    func testUnknownReferencesAndDuplicateStylesStopDeletion() throws {
        for css in ["[STYLE1]\nFORE_STYLE=dynamicValue\n[STYLE2]\n", "[STYLE1]\nSHOW=a\n[STYLE1]\nSHOW=b\n"] {
            XCTAssertThrowsError(try CSSCleanup.clean(css,external:[]))
        }
        XCTAssertEqual(try CSSCleanup.clean("[STYLE1]\nNM_COLOR=FFFFFFFF\n",external:["[KEY1]\nBACK_STYLE=1\n"]).cleared,[])
    }
    func testStatePatchReferencesKeepTIPStylesWithoutUsingStateOrPatchNumbersAsCSSIDs() throws {
        let ids = Array(1...12) + [34, 36, 37]
        let css = "[GLOBAL]\nSTYLE_NUM=37\n" + ids.map { "[STYLE\($0)]\nNM_COLOR=FFFFFFFF\n" }.joined() + "FORE_STYLE=12\n"
        let panel = "[KEY30]\nSTAT_STYLE=S34_8 | S36_10|S37_11 // state to TIP mapping\n[TIP8]\nFORE_STYLE=3\n[TIP10]\nBACK_STYLE=6\n[TIP11]\nFORE_STYLE=7,STYLE9\n"
        let result = try CSSCleanup.clean(css, external: [panel])
        // STYLE37's link is unused; state S37 does not call it.
        XCTAssertEqual(result.cleared, [1, 2, 4, 5, 8, 10, 11, 12, 34, 36, 37])
        for id in result.cleared { XCTAssertTrue(try values(id, in: result.text).isEmpty) }
        for id in [3, 6, 7, 9] { XCTAssertTrue(result.text.contains("[STYLE\(id)]")) }
        XCTAssertTrue(result.text.contains("STYLE_NUM=37\n"))
        XCTAssertEqual(try CSSCleanup.clean(result.text, external: [panel]).cleared, [])
    }
    func testCandidateStatePatchesAndEmptyMappingAreAcceptedButMalformedMappingsStopDeletion() throws {
        let css = "[GLOBAL]\nSTYLE_NUM=3\n[STYLE1]\nNM_COLOR=FFFFFFFF\n[STYLE2]\nNM_IMG=atlas,1\n[STYLE3]\nNM_COLOR=FF000000\n"
        let candidate = "[ICON4]\nSTAT_STYLE=s9_1\n[TIP1]\nBACK_STYLE=1\nFORE_STYLE=2\n[ICON5]\nSTAT_STYLE=\n"
        XCTAssertEqual(try CSSCleanup.clean(css, external: [candidate]).cleared, [3])
        for mapping in ["S9_1|", "S9", "S9_STYLE3", "STYLE3", "S9_1,S4_2", "S-9_1", "dynamicValue"] {
            XCTAssertThrowsError(try CSSCleanup.clean(css, external: ["[KEY30]\nSTAT_STYLE=\(mapping)\n"]))
        }
    }
    @MainActor func testStatePatchArchiveCleanupKeepsPatchStylesSupportsUndoAndOriginalSave() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let skin = folder.appendingPathComponent("skin"), res = skin.appendingPathComponent("port/res")
        try FileManager.default.createDirectory(at: res, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let css = "[GLOBAL]\nSTYLE_NUM=4\n" + (1...4).map { "[STYLE\($0)]\nNM_COLOR=FFFFFFFF\n" }.joined()
        try css.write(to: res.appendingPathComponent("default.css"), atomically: true, encoding: .utf8)
        try "[PANEL]\nSIZE=240,120\nKEY_NUM=1\nTIP_NUM=1\n[KEY1]\nVIEW_RECT=0,0,60,50\nBACK_STYLE=1\nSTAT_STYLE=S34_1|S36_1\n[TIP1]\nFORE_STYLE=2\n".write(to: skin.appendingPathComponent("port/py_26.ini"), atomically: true, encoding: .utf8)
        try "[ICON4]\nSTAT_STYLE=S9_1\n[TIP1]\nFORE_STYLE=3\n".write(to: skin.appendingPathComponent("port/cand1.cnd"), atomically: true, encoding: .utf8)
        let original = folder.appendingPathComponent("keyboard.bds")
        try FileManager.default.zipItem(at: skin, to: original, shouldKeepParent: false)
        let originalBytes = try Data(contentsOf: original), store = SkinStore()
        await store.openArchive(original)
        defer { if let root = store.root { try? FileManager.default.removeItem(at: root) } }
        try store.openForEditing(try XCTUnwrap(store.files.first { $0.lastPathComponent == "default.css" }))
        let removed = try await store.removeUnusedCSS()
        XCTAssertEqual(removed, 1)
        XCTAssertTrue(try values(4, in: store.text).isEmpty)
        XCTAssertTrue(store.text.contains("STYLE_NUM=4\n"))
        for id in 1...3 { XCTAssertTrue(store.text.contains("[STYLE\(id)]")) }
        XCTAssertEqual(try Data(contentsOf: original), originalBytes)
        store.history(redo: false); XCTAssertEqual(store.text, css)
        _ = try await store.removeUnusedCSS()
        try await store.saveSession(EditorViewState(), recordFile: folder.appendingPathComponent("resume.json"))
        let reopened = SkinStore(); await reopened.openArchive(original)
        defer { if let root = reopened.root { try? FileManager.default.removeItem(at: root) } }
        try reopened.openForEditing(try XCTUnwrap(reopened.files.first { $0.lastPathComponent == "default.css" }))
        XCTAssertTrue(try values(4, in: reopened.text).isEmpty)
        XCTAssertTrue(reopened.text.contains("STYLE_NUM=4\n"))
        for id in 1...3 { XCTAssertTrue(reopened.text.contains("[STYLE\(id)]")) }
    }
    @MainActor func testAllLanguageDirectoriesAreScannedAndCleanupUndoRestoresCSS() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let skin = folder.appendingPathComponent("skin"), res = skin.appendingPathComponent("port/res")
        try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:folder) }
        let css = "[GLOBAL]\nSTYLE_NUM=6\n" + (1...6).map { "[STYLE\($0)]\nNM_COLOR=FFFFFFFF\n" }.joined()
        try css.write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try "[PANEL]\nSIZE=240,120\n[KEY1]\nVIEW_RECT=0,0,60,50\nBACK_STYLE=1\n".write(to:skin.appendingPathComponent("port/py_26.ini"),atomically:true,encoding:.utf8)
        for (index,name) in ["cj.ini","zhuyin.ini","jp.ini","kor.ini"].enumerated() {
            let directory = skin.appendingPathComponent("land"); try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
            try "[KEY1]\nFORE_STYLE=\(index+2)\n".write(to:directory.appendingPathComponent(name),atomically:true,encoding:.utf8)
        }
        let original = folder.appendingPathComponent("keyboard.bds")
        try FileManager.default.zipItem(at:skin,to:original,shouldKeepParent:false)
        let originalBytes = try Data(contentsOf:original), store = SkinStore(); await store.openArchive(original)
        defer { if let root = store.root { try? FileManager.default.removeItem(at:root) } }
        try store.openForEditing(try XCTUnwrap(store.files.first { $0.lastPathComponent == "default.css" }))
        let count = try await store.removeUnusedCSS()
        XCTAssertEqual(count,1); XCTAssertTrue(try values(6, in: store.text).isEmpty)
        XCTAssertTrue(store.text.contains("STYLE_NUM=6\n"))
        XCTAssertTrue(store.canUndo); store.history(redo:false); XCTAssertEqual(store.text,css)
        XCTAssertEqual(try Data(contentsOf:original),originalBytes)
        let blocked = try XCTUnwrap(store.root).appendingPathComponent("broken.ini")
        try Data(repeating:65,count:2*1024*1024+1).write(to:blocked); store.rescan()
        do { _ = try await store.removeUnusedCSS(); XCTFail("Unreadable references must stop cleanup") } catch {}
        XCTAssertEqual(store.text,css)
    }
}
