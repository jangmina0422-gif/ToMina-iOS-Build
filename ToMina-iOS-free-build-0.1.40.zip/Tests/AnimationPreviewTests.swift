import XCTest
import SwiftUI
import UIKit
@testable import ToMina

final class AnimationPreviewTests:XCTestCase {
    func testTranslationUnitsDelayAndPressCompletion() throws {
        let t=IniTimeline(definitions:[
            "1":["TYPE":"2","FROM":"50,20","TO":"0,0","DURATION":"500","DELAY":"100"],
            "2":["TYPE":"2","FROM_PX":"0,0","TO_PX":"150,0","DURATION":"500"],
            "3":["TYPE":"3","FROM":"0,0","TO":"500,500","DURATION":"500"],
            "4":["TYPE":"3","FROM":"0,0","TO":"500,500","DURATION":"500","REMOVE":"0"],
            "5":["CATEGORY":"1","BUILD_LIST":"1,2","BUILD_METHOD":"0"],
            "6":["CATEGORY":"2","ANIM_PATH":"bubble.gif","DURATION":"700"]])
        let waiting=try XCTUnwrap(t.sample("1",50).operations.first)
        XCTAssertEqual(waiting.translation(width:108,height:160),[54,32])
        XCTAssertEqual(t.sample("1",350).operations[0].translation(width:108,height:160),[27,16])
        XCTAssertEqual(t.sample("2",250).operations[0].translation(width:108,height:160),[75,0])
        XCTAssertEqual(t.sample("3",400).imageScale(),[4,4])
        XCTAssertTrue(t.sample("3",500,removeWhenFinished:true).operations.isEmpty)
        XCTAssertEqual(t.sample("4",500,removeWhenFinished:true).imageScale(),[5,5])
        XCTAssertEqual(t.sample("5",200).operations.count,2)
        XCTAssertEqual(t.sample("6",300).operations.first?.path,"bubble.gif")
        XCTAssertTrue(t.sample("6",700,removeWhenFinished:true).operations.isEmpty)
    }

    @MainActor private func pixels(type:Int,ninePatch:Bool)throws->[UInt8] {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:root.appendingPathComponent("res"),withIntermediateDirectories:true)
        defer{try? FileManager.default.removeItem(at:root)}
        let config=root.appendingPathComponent("py_26.ini")
        let text="[PANEL]\nSIZE=220,220\n[KEY1]\nVIEW_RECT=90,90,40,40\nFORE_STYLE=1\nFORE_ANIM_STYLE=2\n"
        try text.write(to:config,atomically:true,encoding:.utf8)
        try "[STYLE1]\nNM_IMG=tile,1\n[STYLE2]\nPRESS_ANIM=1\n".write(to:root.appendingPathComponent("res/default.css"),atomically:true,encoding:.utf8)
        try ("[IMG1]\nSOURCE_RECT=0,0,20,20\n"+(ninePatch ? "INNER_RECT=2,2,16,16\n":"")).write(to:root.appendingPathComponent("res/tile.til"),atomically:true,encoding:.utf8)
        try "[ANIM1]\nTYPE=\(type)\nFROM=500,500\nTO=500,500\nDURATION=10000\nREMOVE=0\n".write(to:root.appendingPathComponent("res/anim.ini"),atomically:true,encoding:.utf8)
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let tile=UIGraphicsImageRenderer(size:CGSize(width:20,height:20),format:format).image{ctx in
            UIColor.blue.setFill();ctx.fill(CGRect(x:0,y:0,width:20,height:20))
            UIColor.red.setFill();ctx.fill(CGRect(x:2,y:2,width:16,height:16))
        }
        try XCTUnwrap(tile.pngData()).write(to:root.appendingPathComponent("res/tile.png"))
        let files=(FileManager.default.enumerator(at:root,includingPropertiesForKeys:[.isRegularFileKey])?.allObjects as? [URL] ?? []).filter{(try? $0.resourceValues(forKeys:[.isRegularFileKey]).isRegularFile)==true}
        let renderer=IniSkinRenderer();renderer.configure(root:root,config:config,files:files,text:text)
        renderer.animationEnabled=true;renderer.trigger("KEY1")
        let key=KeyShape(id:1,name:"KEY1",rect:CGRect(x:90,y:90,width:40,height:40),caption:"")
        let canvas=Canvas{ctx,_ in
            ctx.fill(Path(CGRect(x:0,y:0,width:220,height:220)),with:.color(.white))
            renderer.key(key,pressed:false,context:&ctx)
        }.frame(width:220,height:220)
        let painter=ImageRenderer(content:canvas);painter.scale=1
        let image=try XCTUnwrap(painter.cgImage)
        var bytes=[UInt8](repeating:0,count:220*220*4)
        let bitmap=try XCTUnwrap(CGContext(data:&bytes,width:220,height:220,bitsPerComponent:8,bytesPerRow:880,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue))
        bitmap.draw(image,in:CGRect(x:0,y:0,width:220,height:220))
        return bytes
    }
    @MainActor func testType3ScalesNonNinePatchBeyondItsNaturalSize() throws {
        let resize=try pixels(type:3,ninePatch:false),canvasScale=try pixels(type:4,ninePatch:false)
        func rgb(_ bytes:[UInt8],_ x:Int)->[UInt8]{let p=(110*220+x)*4;return Array(bytes[p..<p+3])}
        XCTAssertEqual(rgb(resize,75),[255,0,0]) // Outside the unscaled 20 px image.
        XCTAssertEqual(rgb(resize,65),[0,0,255])
        for x in [55,65,75,110,145,155,165]{XCTAssertEqual(rgb(resize,x),rgb(canvasScale,x))}
    }
    @MainActor func testType3KeepsNinePatchCornersWhileType4ScalesThem() throws {
        let resize=try pixels(type:3,ninePatch:true),canvasScale=try pixels(type:4,ninePatch:true)
        let p=(110*220+15)*4
        XCTAssertEqual(Array(resize[p..<p+3]),[255,0,0])
        XCTAssertEqual(Array(canvasScale[p..<p+3]),[0,0,255])
    }
}
