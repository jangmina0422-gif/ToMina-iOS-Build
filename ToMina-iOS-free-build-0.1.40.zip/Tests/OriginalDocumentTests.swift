import XCTest
import Foundation
import ZIPFoundation
@testable import ToMina

final class OriginalDocumentTests: XCTestCase {
    private func fixture(_ directory: URL) throws -> URL {
        let root = directory.appendingPathComponent("source", isDirectory: true)
        try FileManager.default.createDirectory(at: root.appendingPathComponent("port"), withIntermediateDirectories: true)
        try "[PANEL]\nSIZE=1080,642\nKEY_NUM=1\n[KEY1]\nVIEW_RECT=35,18,92,127\nTOUCH_RECT=20,0,112,168\nCENTER=q\nPRESS_ANIM=1\n[ANIM1]\nTYPE=2\nFROM=0,0\nTO=0,-40\nDURATION=250\nREPEAT_CNT=1\nREPEAT_MODE=1\n".write(to: root.appendingPathComponent("port/py_26.ini"), atomically: true, encoding: .utf8)
        try "[INPUT]\n[GLOBAL]\n".write(to: root.appendingPathComponent("Info.txt"), atomically: true, encoding: .utf8)
        let result = directory.appendingPathComponent("original.bds")
        try FileManager.default.zipItem(at: root, to: result, shouldKeepParent: false)
        return result
    }
    @MainActor func testOriginalOverwriteAndFreshResume() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let original = try fixture(directory), record = directory.appendingPathComponent("state/editor-resume.json")
        let before = try Data(contentsOf: original), store = SkinStore()
        await store.openArchive(original); XCTAssertNil(store.error)
        defer { if let root = store.root { try? FileManager.default.removeItem(at: root) } }
        let relative = store.relative(try XCTUnwrap(store.current))
        store.setParameter(section: "PANEL", key: "SIZE", value: "900.5,590.25")
        store.setParameter(section: "KEY1", key: "VIEW_RECT", value: "41,22,93,128")
        var view = EditorViewState(); view.selected = "KEY1"; view.editing = true; view.zoom = 2.25; view.panX = 23; view.panY = 17; view.view = true
        try await store.saveSession(view, recordFile: record)
        XCTAssertNotEqual(try Data(contentsOf: original), before)
        let unpacked = try OriginalSkinDocument.unpack(original)
        defer { try? FileManager.default.removeItem(at: unpacked) }
        for file in store.files { XCTAssertEqual(try Data(contentsOf: file), try Data(contentsOf: unpacked.appendingPathComponent(store.relative(file)))) }
        XCTAssertEqual(try FileManager.default.contentsOfDirectory(at: record.deletingLastPathComponent(), includingPropertiesForKeys: nil).map { $0.lastPathComponent }, ["editor-resume.json"])
        let restored = SkinStore(), state = try await restored.restoreSession(recordFile: record)
        defer { if let root = restored.root { try? FileManager.default.removeItem(at: root) } }
        XCTAssertEqual(state, view); XCTAssertEqual(restored.panel, CGSize(width: 900.5, height: 590.25))
        XCTAssertEqual(restored.relative(try XCTUnwrap(restored.current)), relative)
        let layout = unpacked.appendingPathComponent(relative), text = try String(contentsOf: layout, encoding: .utf8)
        try AnimationEdits.set(text, section: "PANEL", field: "SIZE", value: "900.5,675.75").write(to: layout, atomically: true, encoding: .utf8)
        try OriginalSkinDocument.overwrite(root: unpacked, original: original)
        let fresh = SkinStore(); _ = try await fresh.restoreSession(recordFile: record)
        defer { if let root = fresh.root { try? FileManager.default.removeItem(at: root) } }
        XCTAssertEqual(fresh.panel.height, 675.75)
    }
    @MainActor func testBlankIniAndLiveKeyChanges() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = SkinStore(); await store.openArchive(try fixture(directory)); XCTAssertNil(store.error)
        let root = try XCTUnwrap(store.root), layout = try XCTUnwrap(store.current)
        defer { try? FileManager.default.removeItem(at: root) }
        let empty = layout.deletingLastPathComponent().appendingPathComponent("empty.ini")
        try "[PANEL]\nSIZE=500,300\n[KEY1]\nVIEW_RECT=0,0,0,20\n".write(to: empty, atomically: true, encoding: .utf8)
        try store.open(empty); XCTAssertTrue(store.blankPreview); XCTAssertTrue(store.keys.isEmpty)
        store.change("[PANEL]\nSIZE=500,300\n[KEY1]\nVIEW_RECT=10,20,100,80\nCENTER=q\n")
        XCTAssertFalse(store.blankPreview); XCTAssertEqual(store.keys.first { $0.name == "KEY1" }?.rect, CGRect(x: 10, y: 20, width: 100, height: 80))
        store.change("[PANEL]\nSIZE=500,300\n"); XCTAssertTrue(store.blankPreview); XCTAssertTrue(store.keys.isEmpty)
        try store.open(layout); XCTAssertFalse(store.blankPreview)
    }
    @MainActor func testMissingOriginalKeepsPriorRecord() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let original = try fixture(directory), record = directory.appendingPathComponent("editor-resume.json"), store = SkinStore()
        await store.openArchive(original); XCTAssertNil(store.error)
        defer { if let root = store.root { try? FileManager.default.removeItem(at: root) } }
        try await store.saveSession(EditorViewState(), recordFile: record)
        let previous = try Data(contentsOf: record)
        try FileManager.default.removeItem(at: original)
        do { try await store.saveSession(EditorViewState(), recordFile: record); XCTFail("Missing original recreated") } catch {}
        XCTAssertFalse(store.busy); XCTAssertEqual(try Data(contentsOf: record), previous)
        XCTAssertFalse(FileManager.default.fileExists(atPath: original.path))
        for unsafe in ["../outside.ini", "/outside.ini", "x/../../outside.ini", "./test.ini"] {
            XCTAssertThrowsError(try OriginalSkinDocument.path(unsafe, root: try XCTUnwrap(store.root)))
        }
    }
    func testMissingOrMalformedCredentialsDenyLogin() throws {
        XCTAssertTrue(Credentials.hashes.isEmpty)
        XCTAssertFalse(Credentials.matches("test", "test"))
        XCTAssertTrue(Credentials.readHashes(nil).isEmpty)
        XCTAssertTrue(Credentials.readHashes(Data("{}".utf8)).isEmpty)
        XCTAssertTrue(Credentials.readHashes(Data("{\"version\":1,\"hashes\":[\"invalid\"]}".utf8)).isEmpty)
        let hash = String(repeating: "a", count: 64)
        let valid = try JSONSerialization.data(withJSONObject: ["version": 1, "hashes": [hash]])
        XCTAssertEqual(Credentials.readHashes(valid), Set([hash]))
    }
}
