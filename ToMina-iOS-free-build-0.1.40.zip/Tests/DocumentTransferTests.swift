import XCTest
import Foundation
import UIKit
import UniformTypeIdentifiers
import ZIPFoundation
@testable import ToMina

final class DocumentTransferTests: XCTestCase {
    private func directory() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true); return url
    }
    private func fixture(_ directory: URL, ext: String = "bds") throws -> URL {
        let root = directory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: root.appendingPathComponent("port"), withIntermediateDirectories: true)
        try "[PANEL]\nSIZE=720,400\nKEY_NUM=1\n[KEY1]\nVIEW_RECT=10,20,80,60\nCENTER=q\n".write(to: root.appendingPathComponent("port/py_26.ini"), atomically: true, encoding: .utf8)
        let file = directory.appendingPathComponent(UUID().uuidString + "." + ext)
        try FileManager.default.zipItem(at: root, to: file, shouldKeepParent: false); return file
    }
    func testProfileIdentitySelectsCopyWithoutChangingBundle() throws {
        func profile(_ id: String) throws -> Data {
            let plist = try PropertyListSerialization.data(fromPropertyList: ["Entitlements": ["application-identifier": id]], format: .xml, options: 0)
            return Data([0x30, 0x82, 0x00, 0x10]) + plist + Data([0xff, 0x00])
        }
        XCTAssertFalse(SigningCompatibility.prefersCopy(profile: try profile("EXAMPLETEAM.com.mina.tomina"), bundleIdentifier: "com.mina.tomina"))
        XCTAssertFalse(SigningCompatibility.prefersCopy(profile: try profile("EXAMPLETEAM.*"), bundleIdentifier: "com.mina.tomina"))
        XCTAssertFalse(SigningCompatibility.prefersCopy(profile: try profile("EXAMPLETEAM.com.mina.*"), bundleIdentifier: "com.mina.tomina"))
        XCTAssertTrue(SigningCompatibility.prefersCopy(profile: try profile("EXAMPLETEAM.com.example.other"), bundleIdentifier: "com.mina.tomina"))
        XCTAssertTrue(SigningCompatibility.prefersCopy(profile: try profile("EXAMPLETEAM.com.example.*"), bundleIdentifier: "com.mina.tomina"))
        XCTAssertFalse(SigningCompatibility.prefersCopy(profile: Data("<plist>broken</plist>".utf8), bundleIdentifier: "com.mina.tomina"))
        XCTAssertFalse(SigningCompatibility.prefersCopy(profile: Data(repeating: 0, count: 4*1024*1024+1), bundleIdentifier: "com.mina.tomina"))
        XCTAssertEqual(Bundle.main.bundleIdentifier, "com.mina.tomina")
    }
    @MainActor func testPickerModesKeepOriginalAndCopyPathsSeparate() throws {
        let dir = try directory(); defer { try? FileManager.default.removeItem(at: dir) }
        let file = dir.appendingPathComponent("test.bds"); try Data("test".utf8).write(to: file)
        let original = SkinDocumentPicker.controller(contentTypes: [.item], asCopy: false)
        let copied = SkinDocumentPicker.controller(contentTypes: [.item], asCopy: true)
        let export = SkinDocumentPicker.controller(contentTypes: [.item], asCopy: true, exporting: file)
        XCTAssertEqual(original.documentPickerMode, .open)
        XCTAssertEqual(copied.documentPickerMode, .import)
        XCTAssertEqual(export.documentPickerMode, .exportToService)
    }
    @MainActor func testCancelledPickerCompletesOnceAndEmptySelectionFails() throws {
        let picker = SkinDocumentPicker.controller(contentTypes: [.item], asCopy: true)
        var results: [Result<URL?, Error>] = []
        let cancelled = SkinDocumentPicker.Coordinator { results.append($0) }
        cancelled.documentPickerWasCancelled(picker)
        cancelled.documentPicker(picker, didPickDocumentsAt: [URL(fileURLWithPath: "/late.bds")])
        XCTAssertEqual(results.count, 1); XCTAssertNil(try results[0].get())
        let missing = SkinDocumentPicker.Coordinator { results.append($0) }
        missing.documentPicker(picker, didPickDocumentsAt: [])
        XCTAssertEqual(results.count, 2); XCTAssertThrowsError(try results[1].get())
    }
    @MainActor func testCopyImportEditsAndExportsAllSkinExtensions() async throws {
        let dir = try directory(); defer { try? FileManager.default.removeItem(at: dir) }
        for ext in ["bds", "bdi", "bda"] {
            let original = try fixture(dir, ext: ext), before = try Data(contentsOf: original), store = SkinStore()
            await store.openArchive(original, asCopy: true)
            XCTAssertNil(store.error); XCTAssertTrue(store.requiresSaveDestination)
            let root = try XCTUnwrap(store.root)
            let layout = try XCTUnwrap(store.files.first { $0.lastPathComponent == "py_26.ini" })
            try store.open(layout); store.setParameter(section: "PANEL", key: "SIZE", value: "600,300")
            let ready = try await store.prepareCopySave(), unpacked = try OriginalSkinDocument.unpack(ready)
            defer { try? FileManager.default.removeItem(at: root); try? FileManager.default.removeItem(at: unpacked); try? FileManager.default.removeItem(at: ready.deletingLastPathComponent()) }
            XCTAssertEqual(try Data(contentsOf: original), before, "An imported copy was incorrectly treated as the external original")
            XCTAssertTrue(try String(contentsOf: unpacked.appendingPathComponent("port/py_26.ini"), encoding: .utf8).contains("SIZE=600,300"))
            XCTAssertFalse(store.busy)
            let record = dir.appendingPathComponent("not-saved-" + ext + ".json")
            do { try await store.saveSession(EditorViewState(), recordFile: record); XCTFail("Copy save claimed to overwrite the original") } catch {}
            XCTAssertFalse(FileManager.default.fileExists(atPath: record.path))
        }
    }
    @MainActor func testCopySaveRestoresStateWithoutOverwritingTemporaryInput() async throws {
        let dir = try directory(); defer { try? FileManager.default.removeItem(at: dir) }
        let input = try fixture(dir), before = try Data(contentsOf: input), record = dir.appendingPathComponent("resume.json"), store = SkinStore()
        await store.openArchive(input, asCopy: true); XCTAssertNil(store.error)
        let root = try XCTUnwrap(store.root); defer { try? FileManager.default.removeItem(at: root) }
        store.setParameter(section: "PANEL", key: "SIZE", value: "900.5,590.25")
        var view = EditorViewState(); view.selected = "KEY1"; view.editing = true; view.zoom = 1.5; view.view = true
        let ready = try await store.prepareCopySave(); defer { try? FileManager.default.removeItem(at: ready.deletingLastPathComponent()) }
        // Simulate the document provider's completed export to an external destination.
        let destination = dir.appendingPathComponent("external.bds"); try FileManager.default.copyItem(at: ready, to: destination)
        try store.finishCopySave(view, recordFile: record)
        XCTAssertEqual(try Data(contentsOf: input), before)
        try FileManager.default.removeItem(at: input)
        let saved = try JSONDecoder().decode(EditorResumeRecord.self, from: Data(contentsOf: record))
        XCTAssertEqual(saved.version, 2); XCTAssertTrue(saved.bookmark.isEmpty); XCTAssertEqual(saved.workingDirectory, root.lastPathComponent)
        let restored = SkinStore(), state = try await restored.restoreSession(recordFile: record)
        XCTAssertEqual(state, view); XCTAssertTrue(restored.requiresSaveDestination)
        XCTAssertEqual(restored.panel, CGSize(width: 900.5, height: 590.25)); XCTAssertEqual(restored.root, root)
        let exported = try OriginalSkinDocument.unpack(destination); defer { try? FileManager.default.removeItem(at: exported) }
        XCTAssertTrue(try String(contentsOf: exported.appendingPathComponent("port/py_26.ini"), encoding: .utf8).contains("SIZE=900.5,590.25"))
    }
    @MainActor func testFailedCopyImportKeepsOriginalDocumentAndRecord() async throws {
        let dir = try directory(); defer { try? FileManager.default.removeItem(at: dir) }
        let input = try fixture(dir), record = dir.appendingPathComponent("resume.json"), store = SkinStore()
        await store.openArchive(input); XCTAssertNil(store.error)
        let root = try XCTUnwrap(store.root); defer { try? FileManager.default.removeItem(at: root) }
        try await store.saveSession(EditorViewState(), recordFile: record)
        let before = try Data(contentsOf: record), bad = dir.appendingPathComponent("bad.bds")
        try Data("not a zip".utf8).write(to: bad)
        await store.openArchive(bad, asCopy: true)
        XCTAssertNotNil(store.error); XCTAssertEqual(store.root, root); XCTAssertFalse(store.requiresSaveDestination); XCTAssertFalse(store.busy)
        XCTAssertEqual(try Data(contentsOf: record), before)
        store.error = nil; try await store.saveSession(EditorViewState(), recordFile: record)
    }
    func testCachedResumeRejectsOutsideAndMissingDirectories() throws {
        for path in ["../outside", "/tmp/outside", "name/other", UUID().uuidString, "not-a-uuid"] {
            XCTAssertThrowsError(try OriginalSkinDocument.cachedRoot(path))
        }
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let link = docs.appendingPathComponent(UUID().uuidString), target = try directory()
        defer { try? FileManager.default.removeItem(at: link); try? FileManager.default.removeItem(at: target) }
        try FileManager.default.createDirectory(at: docs, withIntermediateDirectories: true)
        try FileManager.default.createSymbolicLink(at: link, withDestinationURL: target)
        XCTAssertThrowsError(try OriginalSkinDocument.cachedRoot(link.lastPathComponent))
    }
    func testInstalledDocumentMetadataSupportsSkinSharing() throws {
        XCTAssertEqual(Bundle.main.object(forInfoDictionaryKey: "UIFileSharingEnabled") as? Bool, true)
        XCTAssertEqual(Bundle.main.object(forInfoDictionaryKey: "LSSupportsOpeningDocumentsInPlace") as? Bool, true)
        XCTAssertEqual(Bundle.main.object(forInfoDictionaryKey: "UIRequiresFullScreen") as? Bool, false)
        let types = try XCTUnwrap(Bundle.main.object(forInfoDictionaryKey: "UTImportedTypeDeclarations") as? [[String: Any]])
        let extensions = types.flatMap { (($0["UTTypeTagSpecification"] as? [String: Any])?["public.filename-extension"] as? [String]) ?? [] }
        XCTAssertTrue(Set(extensions).isSuperset(of: ["bds", "bdi", "bda", "procreate"]))
        let docs = try XCTUnwrap(Bundle.main.object(forInfoDictionaryKey: "CFBundleDocumentTypes") as? [[String: Any]])
        XCTAssertEqual(docs.count, 4); XCTAssertTrue(docs.allSatisfy { $0["CFBundleTypeRole"] as? String == "Editor" })
        let supported=docs.flatMap{$0["LSItemContentTypes"] as? [String] ?? []}
        XCTAssertTrue(supported.contains("public.data"));XCTAssertTrue(supported.contains("public.image"))
    }
}
