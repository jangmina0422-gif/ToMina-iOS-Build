import XCTest
import ZIPFoundation
@testable import ToMina

final class ArchiveRenameTests: XCTestCase {
    private func directory() throws -> URL {
        let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString,isDirectory:true)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true);return folder
    }
    func testRenameValidatesNamesConflictsRootAndSymlinks() throws {
        let root=try directory(),outside=try directory()
        defer{try? FileManager.default.removeItem(at:root);try? FileManager.default.removeItem(at:outside)}
        let folder=root.appendingPathComponent("目录"),file=folder.appendingPathComponent("Art.png")
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:false)
        try Data([1,2,3]).write(to:file);try Data([4]).write(to:folder.appendingPathComponent("existing.PNG"))
        for name in [""," ",".","..","../escape","a/b","a\\b","a:b","a\n","a\0",String(repeating:"x",count:256),"EXISTING.png"] {
            XCTAssertThrowsError(try ArchiveFiles.rename(file,to:name,root:root))
        }
        XCTAssertEqual(try Data(contentsOf:file),Data([1,2,3]))
        XCTAssertThrowsError(try ArchiveFiles.rename(root,to:"moved",root:root))
        let external=outside.appendingPathComponent("source.bin");try Data([8]).write(to:external)
        XCTAssertThrowsError(try ArchiveFiles.rename(external,to:"moved.bin",root:root))
        let link=root.appendingPathComponent("alias")
        try FileManager.default.createSymbolicLink(at:link,withDestinationURL:outside)
        XCTAssertThrowsError(try ArchiveFiles.rename(link,to:"moved",root:root))
        XCTAssertThrowsError(try ArchiveFiles.rename(link.appendingPathComponent("source.bin"),to:"moved.bin",root:root))
        let change=try ArchiveFiles.rename(file,to:"art.PNG",root:root)
        XCTAssertEqual(change.destination.lastPathComponent,"art.PNG")
        XCTAssertEqual(try Data(contentsOf:change.destination),Data([1,2,3]))
        let same=try ArchiveFiles.rename(change.destination,to:"art.PNG",root:root)
        XCTAssertEqual(same.original,same.destination)
        XCTAssertEqual(try ArchiveFiles.entries(in:folder,root:root).count,2)
    }
    @MainActor func testRenamingParentKeepsCurrentDraftPreviewAndOriginalSave() async throws {
        let input=try directory();defer{try? FileManager.default.removeItem(at:input)}
        let skin=input.appendingPathComponent("skin"),res=skin.appendingPathComponent("port/res")
        try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        let text="[PANEL]\nSIZE=240,120\n[KEY1]\nVIEW_RECT=0,0,120,80\nCENTER=q\nBACK_STYLE=1\nANIM_STYLE=2\n"
        try text.write(to:skin.appendingPathComponent("port/py_26.ini"),atomically:true,encoding:.utf8)
        try "[STYLE1]\nNM_IMG=art,1\n[STYLE2]\nPRESS_ANIM=1\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try Data([1,2,3]).write(to:res.appendingPathComponent("art.png"))
        try "[ANIM1]\nTYPE=4\nDURATION=180\n".write(to:res.appendingPathComponent("anim.ini"),atomically:true,encoding:.utf8)
        let original=input.appendingPathComponent("original.bds"),record=input.appendingPathComponent("resume.json")
        try FileManager.default.zipItem(at:skin,to:original,shouldKeepParent:false)
        let before=try Data(contentsOf:original),store=SkinStore();await store.openArchive(original)
        let root=try XCTUnwrap(store.root);defer{try? FileManager.default.removeItem(at:root)}
        store.loadAnimationSource("KEY1")
        _=store.editAnimationSource(store.animationText.replacingOccurrences(of:"180",with:"250"))
        let draft=text.replacingOccurrences(of:"240,120",with:"300,160")+"\n; keep this draft"
        _=store.editSource(draft)
        let rename=try await store.renameArchiveEntry(root.appendingPathComponent("port"),to:"新布局")
        XCTAssertEqual(store.relative(try XCTUnwrap(store.current)),"新布局/py_26.ini")
        XCTAssertEqual(store.text,draft);XCTAssertEqual(store.panel,CGSize(width:300,height:160))
        XCTAssertTrue(store.canUndo);XCTAssertEqual(store.keys.first?.caption,"q")
        XCTAssertEqual(store.renderer.resolve("art.png")?.path,root.appendingPathComponent("新布局/res/art.png").path)
        XCTAssertEqual(store.renderer.timeline.definitions["1"]?["DURATION"],"250")
        XCTAssertFalse(FileManager.default.fileExists(atPath:root.appendingPathComponent("port").path))
        XCTAssertEqual(rename.relocated(root.appendingPathComponent("port-extra/file.ini")),root.appendingPathComponent("port-extra/file.ini"))
        XCTAssertEqual(try Data(contentsOf:original),before)
        try await store.saveSession(EditorViewState(),recordFile:record)
        let unpacked=try OriginalSkinDocument.unpack(original);defer{try? FileManager.default.removeItem(at:unpacked)}
        XCTAssertEqual(try String(contentsOf:unpacked.appendingPathComponent("新布局/py_26.ini"),encoding:.utf8),draft)
        let restored=SkinStore();_=try await restored.restoreSession(recordFile:record)
        defer{if let folder=restored.root{try? FileManager.default.removeItem(at:folder)}}
        XCTAssertEqual(restored.relative(try XCTUnwrap(restored.current)),"新布局/py_26.ini")
        XCTAssertEqual(restored.panel,CGSize(width:300,height:160))
        XCTAssertEqual(restored.renderer.timeline.definitions["1"]?["DURATION"],"250")
    }
    @MainActor func testRenamingCurrentFileCancelsOldWorkAndKeepsUndoAndExport() async throws {
        let input=try directory();defer{try? FileManager.default.removeItem(at:input)}
        let skin=input.appendingPathComponent("skin")
        try FileManager.default.createDirectory(at:skin,withIntermediateDirectories:false)
        let initial="[PANEL]\nSIZE=200,100\n[KEY1]\nVIEW_RECT=0,0,100,50\nCENTER=q\n"
        try initial.write(to:skin.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
        let archive=input.appendingPathComponent("original.bds")
        try FileManager.default.zipItem(at:skin,to:archive,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(archive)
        let root=try XCTUnwrap(store.root),old=try XCTUnwrap(store.current)
        defer{try? FileManager.default.removeItem(at:root)}
        let edited=initial.replacingOccurrences(of:"200,100",with:"320,160")
        _=store.editSource(edited)
        let rename=try await store.renameArchiveEntry(old,to:"自定.ini")
        XCTAssertEqual(store.current?.path,rename.destination.path)
        XCTAssertTrue(store.panelFiles.contains{$0.lastPathComponent=="自定.ini"})
        try await Task.sleep(for:.milliseconds(550))
        XCTAssertEqual(store.text,edited);XCTAssertEqual(store.panel,CGSize(width:320,height:160))
        store.history(redo:false);XCTAssertEqual(store.text,initial)
        XCTAssertFalse(FileManager.default.fileExists(atPath:old.path))
        XCTAssertEqual(try String(contentsOf:rename.destination,encoding:.utf8),initial)
        let output=try store.export();defer{try? FileManager.default.removeItem(at:output.deletingLastPathComponent())}
        let unpacked=try OriginalSkinDocument.unpack(output);defer{try? FileManager.default.removeItem(at:unpacked)}
        XCTAssertFalse(FileManager.default.fileExists(atPath:unpacked.appendingPathComponent("py_26.ini").path))
        XCTAssertEqual(try String(contentsOf:unpacked.appendingPathComponent("自定.ini"),encoding:.utf8),initial)
    }
}
