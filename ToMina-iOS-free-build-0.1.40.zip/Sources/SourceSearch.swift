import SwiftUI
import Foundation

enum SourceSearch {
    static func ranges(in text: String, query: String) -> [NSRange] {
        guard !query.isEmpty else { return [] }
        let source = text as NSString
        var start = 0, found: [NSRange] = []
        while start < source.length {
            let range = source.range(of: query, options: [.caseInsensitive],
                range: NSRange(location: start, length: source.length - start))
            guard range.location != NSNotFound, range.length > 0 else { break }
            found.append(range); start = NSMaxRange(range)
        }
        return found
    }
}

struct SourceSearchBar: View {
    @ObservedObject var draft: EditorDraft
    let close: () -> Void
    @State private var query = ""
    @State private var position = -1
    @State private var matches: [NSRange] = []
    var body: some View {
        VStack(spacing: 6) {
            TextField("输入关键词", text: $query)
                .textInputAutocapitalization(.never).autocorrectionDisabled()
                .textFieldStyle(.roundedBorder).accessibilityIdentifier("editor.searchQuery")
                .onChange(of: query) { _, _ in search(reset: true) }
                .onSubmit { search() }
            HStack(spacing: 8) {
                Text(query.isEmpty ? "搜索当前文本" : matches.isEmpty ? "未找到关键词" : "\(position + 1) / \(matches.count)")
                    .font(.caption).foregroundStyle(MinaTheme.muted)
                    .accessibilityIdentifier("editor.searchResult")
                Spacer(minLength: 0)
                Button("上一个") { search(backwards: true) }.disabled(matches.isEmpty)
                Button("下一个") { search() }.disabled(matches.isEmpty)
                Button("关闭") { draft.requestSelection(nil); close() }
            }.buttonStyle(MinaButtonStyle())
        }
        .onChange(of: draft.revision) { _, _ in search(reset: true) }
        .onChange(of: draft.searchRevision) { _, _ in search(reset: true) }
        .onAppear { draft.searchActive = true }
        .onDisappear { draft.searchActive = false; draft.requestSelection(nil) }
    }
    private func search(backwards: Bool = false, reset: Bool = false) {
        matches = SourceSearch.ranges(in: draft.text, query: query)
        guard !matches.isEmpty else { position = -1; draft.requestSelection(nil); return }
        if reset || position < 0 { position = backwards ? matches.count - 1 : 0 }
        else { position = (position + (backwards ? -1 : 1) + matches.count) % matches.count }
        draft.requestSelection(matches[position])
    }
}
