import Foundation
import SwiftUI

// Flatten only consecutive static layers. Moving layers remain between the
// same neighbours, so candidate bars, foregrounds and particles keep their order.
@MainActor struct PreviewDrawCommand {
    var id: String
    var dynamic = false
    var draw: (inout GraphicsContext) -> Void
}

@MainActor final class PreviewRasterCache {
    private struct Entry { var image: CGImage; var cost: Int; var used: Int }
    private var entries: [String: Entry] = [:]
    private var clock = 0
    private(set) var bytes = 0
    private(set) var rasterCount = 0
    private(set) var staticCommandCount = 0
    let costLimit = 24 * 1024 * 1024
    func clear() { entries.removeAll(); bytes = 0; rasterCount = 0; staticCommandCount = 0 }

    func draw(_ commands: [PreviewDrawCommand], bounds: CGRect, scale: CGFloat, context: inout GraphicsContext) {
        var pending: [PreviewDrawCommand] = []
        func flush(_ context: inout GraphicsContext) {
            guard !pending.isEmpty else { return }
            let run = pending; pending.removeAll(keepingCapacity: true)
            guard drawStatic(run, bounds: bounds, scale: scale, context: &context) else {
                for command in run { command.draw(&context) }; return
            }
        }
        for command in commands {
            if command.dynamic { flush(&context); command.draw(&context) }
            else { pending.append(command) }
        }
        flush(&context)
    }

    private func drawStatic(_ commands: [PreviewDrawCommand], bounds: CGRect, scale: CGFloat, context: inout GraphicsContext) -> Bool {
        guard bounds.width > 0, bounds.height > 0, scale.isFinite, scale > 0,
              bounds.width.isFinite, bounds.height.isFinite else { return false }
        // Cache at the visible resolution. Split-screen resizing is bucketed,
        // rather than producing a different bitmap for every drag position.
        let longest = max(bounds.width, bounds.height)
        let edge = min(2048, max(64, ceil(longest * scale / 64) * 64))
        let resolution = edge / longest
        let width = max(1, Int(ceil(bounds.width * resolution)))
        let height = max(1, Int(ceil(bounds.height * resolution)))
        let key = "\(bounds)|\(width)x\(height)|" + commands.map(\.id).joined(separator: "|")
        clock &+= 1
        if var entry = entries[key] {
            entry.used = clock; entries[key] = entry
            context.draw(Image(decorative: entry.image, scale: 1), in: bounds)
            return true
        }
        let canvas = Canvas { drawing, _ in
            drawing.scaleBy(x: resolution, y: resolution)
            drawing.translateBy(x: -bounds.minX, y: -bounds.minY)
            for command in commands { command.draw(&drawing) }
        }.frame(width: CGFloat(width), height: CGFloat(height))
        let renderer = ImageRenderer(content: canvas); renderer.scale = 1
        guard let image = renderer.cgImage else { return false }
        rasterCount += 1; staticCommandCount += commands.count
        let cost = image.bytesPerRow * image.height
        while bytes + cost > costLimit, let oldest = entries.min(by: { $0.value.used < $1.value.used }) {
            bytes -= oldest.value.cost; entries.removeValue(forKey: oldest.key)
        }
        if cost <= costLimit { entries[key] = Entry(image: image, cost: cost, used: clock); bytes += cost }
        context.draw(Image(decorative: image, scale: 1), in: bounds)
        return true
    }
}
