import Foundation

struct ParticleTimeline {
    struct Particle {var x:Double;var y:Double;var scale:Double;var rotation:Double;var alpha:Double;var style:String}
    // java.util.Random sequence keeps APK and iOS previews repeatable.
    struct Random {
        var state:UInt64
        init(_ seed:Int64){state=(UInt64(bitPattern:seed)^0x5deece66d)&((1<<48)-1)}
        mutating func next(_ bits:Int)->UInt64{state=(state &* 0x5deece66d &+ 11)&((1<<48)-1);return state>>UInt64(48-bits)}
        mutating func unit()->Double{Double(next(24))/16777216}
        mutating func index(_ bound:Int)->Int {
            if bound & (bound-1)==0{return Int((UInt64(bound)*next(31))>>31)}
            while true{let bits=Int64(next(31)),value=bits%Int64(bound);if bits-value+Int64(bound-1)<=Int64(Int32.max){return Int(value)}}
        }
    }
    var config:[String:String];var ios:Bool;var seed:Int64
    func range(_ name:String,_ fallback:Double)->(Double,Double){let parts=(config[name] ?? "").components(separatedBy:",");let a=IniTimeline.number(parts.first,fallback),b=parts.count>1 ? IniTimeline.number(parts[1],a):a;return(min(a,b),max(a,b))}
    // Uses the same lifetime and emission bounds as sample(), including the
    // delay before the first particle and the last particle's whole lifetime.
    var playbackDuration: Double? {
        func n(_ key:String,_ fallback:Double=0)->Double{IniTimeline.number(config[key],fallback)}
        let total=Int(max(0,min(256,n("TOTAL_NUMBER",10))))
        guard total>0,!(config["PARTICLE_IMAGE"] ?? "").components(separatedBy:",").filter({!$0.isEmpty}).isEmpty else{return 0}
        let burst=ios || n("EMIT_TYPE")==1,rate=max(0,n("BIRTH_RATE",5))
        guard burst || rate>0 else{return 0}
        if n("DURATION",-1)==0,(config["REMOVE_INCLUDE_PRACTICES"]=="1" || (config["FINISH_AFTER_PRACTICES"] ?? "1")=="1"){return 0}
        let repeats=["inf","infinite","infinity","-1","0"].contains((config["REPEAT_CNT"] ?? "").lowercased().trimmingCharacters(in:.whitespaces)) ? 0:n("REPEAT_CNT",1)
        guard repeats>0 else{return nil}
        let interval=burst ? 0:1000/rate,life=max(1,min(600000,range("LIFE",5000).1))
        return max(0,n("DELAY"))+max(1,Double(total-1)*interval+life)*repeats
    }
    func sample(_ elapsed:Double,width:Double,height:Double)->[Particle] {
        func n(_ key:String,_ fallback:Double=0)->Double{IniTimeline.number(config[key],fallback)}
        let t=elapsed-max(0,n("DELAY"));guard t>=0 else{return []}
        let total=Int(max(0,min(256,n("TOTAL_NUMBER",10)))),images=(config["PARTICLE_IMAGE"] ?? "").components(separatedBy:",").filter{!$0.isEmpty}
        guard total>0,!images.isEmpty else{return []}
        let burst=ios || n("EMIT_TYPE")==1,rate=max(0,n("BIRTH_RATE",5));guard burst || rate>0 else{return []}
        let interval=burst ? 0:1000/rate,lifeMax=max(1,min(600000,range("LIFE",5000).1)),cycle=max(1,Double(total-1)*interval+lifeMax)
        let batch=floor(t/cycle),local=t-batch*cycle,repeats=["inf","infinite","infinity","-1","0"].contains((config["REPEAT_CNT"] ?? "").lowercased().trimmingCharacters(in:.whitespaces)) ? 0:n("REPEAT_CNT",1)
        guard repeats<=0 || batch<repeats else{return []}
        let end=n("DURATION",-1),finish=(config["FINISH_AFTER_PRACTICES"] ?? "1")=="1"
        if end>=0,local>=end,(config["REMOVE_INCLUDE_PRACTICES"]=="1" || finish){return []}
        let parts=(config["EMIT_REGION"] ?? "0,0,1,1").components(separatedBy:",")
        let bounds=(0..<4).map{IniTimeline.number($0<parts.count ? parts[$0]:nil,$0<2 ? 0:1)}
        let complex = !ios || n("TYPE")==1
        var result:[Particle]=[]
        for i in 0..<total {
            var birth=Double(i)*interval
            if end>=0,birth>end {if finish{continue};birth=end}
            let ageMs=local-birth;guard ageMs>=0 else{continue}
            var rng=Random(seed &+ Int64(min(batch,1e9))*1000003 &+ Int64(i)*7919)
            func pick(_ name:String,_ fallback:Double)->Double{let r=range(name,fallback);return r.0+rng.unit()*(r.1-r.0)}
            let life=max(1,min(600000,pick("LIFE",5000)));guard ageMs<life else{continue}
            let age=ageMs/1000
            var x=(bounds[0]+rng.unit()*(bounds[2]-bounds[0]))*width,y=(bounds[1]+rng.unit()*(bounds[3]-bounds[1]))*height
            let speed=pick("VELOCITY",0),dir=pick("VELOCITY_DIRECTION",90) * .pi/180,accel=pick("ACCELERATION",0),ad=pick("ACCELERATION_DIRECTION",90) * .pi/180
            x+=speed*cos(dir)*age+(complex ? 0.5*accel*cos(ad)*age*age:0);y+=speed*sin(dir)*age+(complex ? 0.5*accel*sin(ad)*age*age:0)
            let scale=max(0,pick("INIT_SCALE",1)+(complex ? pick("SCALE_SPEED",0)*age:0)),rotation=complex ? pick("INIT_ROTATE",0)+pick("ROTATE_SPEED",0)*age:0,alpha=max(0,min(255,pick("INIT_ALPHA",255)+(complex ? pick("ALPHA_SPEED",0)*age:0)))
            let index=rng.index(min(10,images.count))
            result.append(Particle(x:x,y:y,scale:scale,rotation:rotation,alpha:alpha,style:images[index].trimmingCharacters(in:.whitespaces)))
        }
        return result
    }
}
