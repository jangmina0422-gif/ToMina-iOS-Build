import SwiftUI
import UIKit
import Combine

struct PreparedEditorPreview: Sendable {
    let sections: [Section]
    let overrides: [URL: Data]?
    let configurations: [URL: PreparedConfiguration]
    let failure: String?
    let background: Bool
    static func prepare(_ text: String, file: URL?, files: [URL], linkedBinary: Bool) -> Self {
        let sections = SkinConfiguration.parse(text, cancelled: { Task.isCancelled })
        guard linkedBinary, let file, !Task.isCancelled else {
            return Self(sections: sections, overrides: nil, configurations: [:], failure: nil, background: !Thread.isMainThread)
        }
        do {
            let overrides = try BdaTextSync.preview(file: file, text: text, files: files)
            let configurations = try Dictionary(uniqueKeysWithValues: overrides.map { ($0.key, try PreparedConfiguration.decode($0.key, data: $0.value)) })
            return Self(sections: sections, overrides: overrides, configurations: configurations, failure: nil, background: !Thread.isMainThread)
        } catch {
            return Self(sections: sections, overrides: nil, configurations: [:], failure: error.localizedDescription, background: !Thread.isMainThread)
        }
    }
}

// Typing changes only this buffer. Preview observers are notified after a
// completed edit burst, rather than once for every character in a large file.
@MainActor final class EditorDraft: ObservableObject {
    private(set) var text = ""
    @Published private(set) var revision = 0
    @Published private(set) var endRequest = 0
    @Published private(set) var selectionRequest = 0
    @Published private(set) var searchRevision = 0
    private(set) var requestedSelection: NSRange?
    var searchActive = false
    private var consumedEndRequest = 0
    func replace(_ value: String) {
        text = value; revision &+= 1
    }
    func acceptTyping(_ value: String) { text = value; if searchActive { searchRevision &+= 1 } }
    func requestSelection(_ range: NSRange?) { requestedSelection = range; selectionRequest &+= 1 }
    func requestEnd() { endRequest &+= 1 }
    func consumeEndRequest() -> Bool {
        guard consumedEndRequest != endRequest else { return false }
        consumedEndRequest = endRequest
        return true
    }
}

// Keep the requested caret visible when the keyboard or split view changes
// the editor's size. Ordinary scrolling and taps still own the viewport.
final class SourceTextView: UITextView {
    private var endCaret: Int?
    private var revealSize = CGSize.zero
    private var revealContentSize = CGSize.zero
    private var revealScheduled = false
    func jumpToEnd() {
        let end = (text as NSString).length
        selectedRange = NSRange(location: end, length: 0)
        endCaret = end; revealSize = .zero; revealContentSize = .zero
        setNeedsLayout()
        scheduleEndReveal()
    }
    func cancelEndReveal() { endCaret = nil }
    override func layoutSubviews() {
        super.layoutSubviews()
        guard let end = endCaret, selectedRange == NSRange(location: end, length: 0),
              bounds.width > 0, bounds.height > 0,
              revealSize != bounds.size || revealContentSize != contentSize else { return }
        revealSize = bounds.size; revealContentSize = contentSize
        scheduleEndReveal()
    }
    private func scheduleEndReveal() {
        guard !revealScheduled else { return }
        revealScheduled = true
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.revealScheduled = false
            guard let end = self.endCaret,
                  self.selectedRange == NSRange(location: end, length: 0),
                  self.bounds.height > 0, self.window != nil else { return }
            self.revealEndCaret()
        }
    }
    private func revealEndCaret() {
        // A far-away caret can still have estimated geometry with
        // noncontiguous layout. Resolve it once for this explicit jump/resize.
        layoutManager.ensureLayout(for: textContainer)
        layoutIfNeeded()
        let caret = caretRect(for: endOfDocument)
        scrollRectToVisible(caret.insetBy(dx: 0, dy: -8), animated: false)
    }
}

struct DraftTextEditor: UIViewRepresentable {
    @Environment(\.isEnabled) private var enabled
    @ObservedObject var draft: EditorDraft
    @Binding var focused: Bool
    let edit: (String, Bool) -> Bool
    let finish: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> UITextView {
        let view = SourceTextView(frame: .zero)
        view.delegate = context.coordinator
        view.font = .systemFont(ofSize: 14)
        view.textColor = .black; view.backgroundColor = .clear
        view.autocorrectionType = .no; view.spellCheckingType = .no
        view.smartQuotesType = .no; view.smartDashesType = .no
        view.smartInsertDeleteType = .no; view.keyboardDismissMode = .interactive
        view.alwaysBounceVertical = true
        view.textContainerInset = UIEdgeInsets(top: 8, left: 4, bottom: 16, right: 4)
        view.layoutManager.allowsNonContiguousLayout = true
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        view.accessibilityLabel = "配置源码"
        return view
    }
    func updateUIView(_ view: UITextView, context: Context) {
        context.coordinator.parent = self
        view.isEditable = enabled; view.isSelectable = enabled
        // Never assign the entire document back during ordinary typing,
        // scrolling, preview redraws or Chinese input composition.
        if context.coordinator.revision != draft.revision {
            let selection = view.selectedRange, offset = view.contentOffset
            view.text = draft.text
            let count = (draft.text as NSString).length
            view.selectedRange = NSRange(location: min(selection.location, count), length: min(selection.length, max(0, count - selection.location)))
            view.setContentOffset(offset, animated: false)
            context.coordinator.revision = draft.revision
        }
        context.coordinator.synchronizeFocus(view, enabled: enabled, requested: focused)
        if context.coordinator.selectionRequest != draft.selectionRequest {
            context.coordinator.selectionRequest = draft.selectionRequest
            (view as? SourceTextView)?.cancelEndReveal()
            let full = NSRange(location: 0, length: (view.text as NSString).length)
            view.textStorage.beginEditing()
            view.textStorage.removeAttribute(.backgroundColor, range: full)
            if let range = draft.requestedSelection, NSMaxRange(range) <= full.length {
                view.selectedRange = range
                view.textStorage.addAttribute(.backgroundColor, value: UIColor(white: 0.78, alpha: 1), range: range)
                DispatchQueue.main.async { [weak view] in view?.scrollRangeToVisible(range) }
            }
            view.textStorage.endEditing()
            view.typingAttributes.removeValue(forKey: .backgroundColor)
        }
        if enabled && draft.consumeEndRequest() {
            (view as? SourceTextView)?.jumpToEnd()
            // A newly opened editor must enter the window before it can
            // become first responder. Do not replace its draft to navigate.
            DispatchQueue.main.async { [weak view] in
                guard let view, view.window != nil, view.isEditable else { return }
                view.becomeFirstResponder()
                view.setNeedsLayout()
            }
        }
    }
    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: DraftTextEditor
        var revision = -1
        var selectionRequest = -1
        private var lastRequestedFocus = false
        init(_ parent: DraftTextEditor) { self.parent = parent }
        func synchronizeFocus(_ view: UITextView, enabled: Bool, requested: Bool) {
            view.isEditable = enabled; view.isSelectable = enabled
            if !enabled { if view.isFirstResponder { view.resignFirstResponder() }; lastRequestedFocus = false; return }
            // A native tap owns focus too. An unrelated preview update must
            // never dismiss its keyboard using an old SwiftUI focus value.
            if requested != lastRequestedFocus {
                lastRequestedFocus = requested
                if requested && !view.isFirstResponder { view.becomeFirstResponder() }
                if !requested && view.isFirstResponder { view.resignFirstResponder() }
            }
        }
        func textViewDidBeginEditing(_ view: UITextView) { lastRequestedFocus = true; parent.focused = true }
        func textViewDidChange(_ view: UITextView) {
            (view as? SourceTextView)?.cancelEndReveal()
            if !parent.edit(view.text, view.markedTextRange != nil) {
                view.text = parent.draft.text
            }
        }
        func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
            (scrollView as? SourceTextView)?.cancelEndReveal()
        }
        func textViewDidEndEditing(_ view: UITextView) {
            _ = parent.edit(view.text, false)
            lastRequestedFocus = false; parent.focused = false; parent.finish()
        }
    }
}

// Keep an in-progress parameter value independent of the last preview parse.
struct DraftParameterField: View {
    let value: String
    let edit: (String) -> Void
    let finish: () -> Void
    @State private var draft: String
    @FocusState private var focused: Bool
    init(value: String, edit: @escaping (String) -> Void, finish: @escaping () -> Void) {
        self.value = value; self.edit = edit; self.finish = finish
        _draft = State(initialValue: value)
    }
    var body: some View {
        TextField("参数值", text: $draft).focused($focused)
            .textFieldStyle(.plain).foregroundStyle(.black)
            .padding(12).background(MinaTheme.button).clipShape(RoundedRectangle(cornerRadius: 12))
            .onChange(of: draft) { _, next in if next != value { edit(next) } }
            .onChange(of: value) { _, next in if !focused { draft = next } }
            .onChange(of: focused) { _, active in if !active { finish() } }
            .onDisappear(perform: finish)
    }
}
