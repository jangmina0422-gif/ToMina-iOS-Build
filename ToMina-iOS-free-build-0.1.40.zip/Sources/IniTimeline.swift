import Foundation

// Matches the APK timeline in milliseconds; a tap owns its clock until completion.
struct IniTimeline {
    struct Operation {
        var type:Int;var value:[Double];var pivot:[Double];var pixelPivot:Bool
        var path:String;var time:Double;var duration:Double
        var id:String="";var tint:UInt32=0
        var pixelValue=false
        func translation(width:Double,height:Double)->[Double] {
            pixelValue ? Array(value.prefix(2)) : [value[0]*width/100,value[1]*height/100]
        }
    }
    struct Frame {
        var operations:[Operation]=[];var running=false
        // TYPE=3 resizes the destination, but non-nine-patch images still
        // scale with it. Keep this separate so nine-patch borders stay fixed.
        func imageScale(_ parent:[Double]=[1,1])->[Double] {
            operations.filter{$0.type==3}.reduce(parent){scale,op in
                [scale[0]*max(0,op.value[0]/100),scale[1]*max(0,op.value[1]/100)]
            }
        }
    }
    var definitions:[String:[String:String]]
    static func number(_ s:String?,_ fallback:Double=0)->Double {
        guard let s,let n=Double(s.trimmingCharacters(in:.whitespaces)),n.isFinite else{return fallback};return n
    }
    static func vector(_ s:String?,_ fallback:Double)->[Double] {
        let a=(s ?? "").components(separatedBy:",");return (0..<3).map{$0<a.count ? number(a[$0],fallback):fallback}
    }
    func duration(_ id:String)->Double { total(id,[],0) }
    private func body(_ d:[String:String],_ seen:Set<String>,_ depth:Int)->Double {
        let ids=(d["BUILD_LIST"] ?? "").split(separator:",").map{$0.trimmingCharacters(in:.whitespaces)}
        if ids.isEmpty{return max(1,min(86400000,Self.number(d["DURATION"],1000)))}
        let lengths=ids.map{total($0,seen,depth+1)}
        return max(1,min(86400000,d["BUILD_METHOD"]=="1" ? lengths.reduce(0,+):(lengths.max() ?? 0)))
    }
    private func total(_ id:String,_ seen:Set<String>,_ depth:Int)->Double {
        guard depth<=16,!seen.contains(id),let d=definitions[id] else{return 0}
        let repeats=Self.number(d["REPEAT_CNT"] ?? "1",0)
        if repeats<=0{return 86400000}
        return min(86400000,max(0,Self.number(d["DELAY"]))+body(d,seen.union([id]),depth)*(d["REPEAT_MODE"]=="1" ? 2:1)*repeats)
    }
    func sample(_ id:String,_ elapsed:Double,removeWhenFinished:Bool=false)->Frame { evaluate(id,elapsed,[],0,removeWhenFinished) }
    private func evaluate(_ id:String,_ elapsed:Double,_ seen:Set<String>,_ depth:Int,_ removeWhenFinished:Bool=false)->Frame {
        guard depth<=16,!seen.contains(id),let d=definitions[id],(0...2).contains(Self.number(d["CATEGORY"])) else{return Frame()}
        let seen=seen.union([id]),delay=max(0,Self.number(d["DELAY"]))
        let b=body(d,seen,depth),cycle=b*(d["REPEAT_MODE"]=="1" ? 2:1),t=max(0,elapsed-delay),repeats=Self.number(d["REPEAT_CNT"] ?? "1",0)
        let done=repeats>0 && t>=cycle*repeats
        if done && (d["REMOVE"]=="1" || (d["REMOVE"]==nil && removeWhenFinished)){return Frame()}
        var local=done ? cycle:t.truncatingRemainder(dividingBy:max(1,cycle))
        if local>b{local=cycle-local}
        var out=Frame(running:!done)
        let children=(d["BUILD_LIST"] ?? "").split(separator:",").map{$0.trimmingCharacters(in:.whitespaces)}
        if !children.isEmpty {
            var offset:Double=0
            for child in children {
                if local>=offset{out.operations += evaluate(child,local-offset,seen,depth+1).operations}
                if d["BUILD_METHOD"]=="1"{offset += total(child,seen,depth+1)}
            }
            return out
        }
        var p=min(1,max(0,local/b))
        switch d["INTPOL"] {
        case "1":p*=p
        case "2":p=1-(1-p)*(1-p)
        case "3":p=(1-cos(p * .pi))/2
        case "4":
            p*=1.1226
            if p<0.3535{p=8*p*p}else if p<0.7408{p-=0.54719;p=8*p*p+0.7}else if p<0.9644{p-=0.8526;p=8*p*p+0.9}else{p-=1.0435;p=8*p*p+0.95}
        default:break
        }
        let type=Int(max(-1,min(100,Self.number(d["TYPE"],-1)))),fallback:Double=(type==3 || type==4) ? 100:0
        let pixelValue=type==2 && (d["FROM_PX"] != nil || d["TO_PX"] != nil)
        let from=Self.vector(d[pixelValue ? "FROM_PX":"FROM"],fallback),to=Self.vector(d[pixelValue ? "TO_PX":"TO"],fallback)
        let path=d["ANIM_PATH"] ?? ""
        guard !path.isEmpty || (0...6).contains(type) else{return out}
        var op=Operation(type:type,value:(0..<3).map{from[$0]+(to[$0]-from[$0])*p},pivot:Self.vector(d["PIVOT_PX"] ?? d["PIVOT"],50),pixelPivot:d["PIVOT_PX"] != nil,path:path,time:local,duration:b,id:id)
        op.pixelValue=pixelValue
        if type==6 {
            let a=Self.color(d["FROM"] ?? "FFFFFF"),z=Self.color(d["TO"] ?? "000000")
            for shift in [0,8,16,24] {
                let av=Double((a>>shift)&255),zv=Double((z>>shift)&255)
                op.tint |= UInt32(max(0,min(255,av+(zv-av)*p))) << shift
            }
        }
        out.operations.append(op)
        return out
    }
    static func color(_ value:String)->UInt32 {
        let hex=value.replacingOccurrences(of:"#",with:"").replacingOccurrences(of:"0x",with:"")
        guard let raw=UInt32(hex,radix:16) else{return 0xffffffff}
        return hex.count<=6 ? raw | 0xff000000:raw
    }
}
