import Foundation
import SwiftUI
import UIKit
import Darwin

@MainActor final class CloudAccount: ObservableObject {
    @Published var authenticated = false
    @Published private(set) var busy = false
    @Published var notice: String?
    private var token = ""
    private var verifiedAt = Date.distantPast
    private var heartbeatTask: Task<Void, Never>?
    private let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 12
        configuration.timeoutIntervalForResource = 15
        configuration.httpShouldSetCookies = false
        return URLSession(configuration: configuration)
    }()
    private static let base = URL(string: "https://candy.mina.center/api/auth/")!
    private struct LoginReply: Decodable { let token: String }
    enum Failure: LocalizedError, Equatable {
        case invalid, limit, busy, connection
        var errorDescription: String? {
            switch self {
            case .invalid: return "账号或密码错误，或登录已失效"
            case .limit: return "在线设备已达上限，请先退出其他设备"
            case .busy: return "尝试过于频繁，请稍后再试"
            case .connection: return "连接失败，请检查网络后重试"
            }
        }
    }
    private func request(_ path: String, body: [String:String] = [:], token: String = "") async throws -> Data {
        var request = URLRequest(url: Self.base.appendingPathComponent(path))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if !token.isEmpty { request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization") }
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let data: Data, response: URLResponse
        do { (data,response) = try await session.data(for: request) }
        catch { throw Failure.connection }
        guard let http = response as? HTTPURLResponse, data.count < 16384 else { throw Failure.connection }
        switch http.statusCode {
        case 200: return data
        case 401,403: throw Failure.invalid
        case 409: throw Failure.limit
        case 429: throw Failure.busy
        default: throw Failure.connection
        }
    }
    private var deviceID: String {
        if let id = UserDefaults.standard.string(forKey:"cloudDeviceID") { return id }
        let id = UUID().uuidString
        UserDefaults.standard.set(id, forKey:"cloudDeviceID"); return id
    }
    private var deviceName: String {
        var info = utsname(); uname(&info)
        let code = withUnsafePointer(to: &info.machine) { pointer in
            pointer.withMemoryRebound(to: CChar.self, capacity: 1) { String(cString:$0) }
        }
        return UIDevice.current.model + " · " + code
    }
    func login(account: String, password: String) async throws {
        guard !busy else { return }
        busy = true; defer { busy = false }
        let data = try await request("login",body:["account":account.trimmingCharacters(in:.whitespacesAndNewlines),
            "password":password,"device_id":deviceID,"device_name":deviceName,"platform":"ios",
            "os_version":UIDevice.current.systemVersion,
            "app_version":Bundle.main.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String ?? ""])
        let reply = try JSONDecoder().decode(LoginReply.self,from:data)
        guard reply.token.count >= 32 else { throw Failure.connection }
        token=reply.token;verifiedAt=Date();authenticated=true;notice=nil
        heartbeatTask?.cancel()
        heartbeatTask=Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for:.seconds(20)) } catch { return }
                guard let self, self.authenticated else { return }
                await self.heartbeat()
            }
        }
    }
    private func heartbeat() async {
        let current = token
        do {
            _ = try await request("heartbeat",token:current)
            if token == current { verifiedAt=Date() }
        } catch {
            guard token == current else { return }
            let invalid: Bool
            if let failure=error as? Failure { invalid = failure == .invalid || failure == .limit }
            else { invalid=false }
            if invalid || Date().timeIntervalSince(verifiedAt) > 75 {
                notice = invalid ? error.localizedDescription : "连接中断，请重新登录"
                logout()
            }
        }
    }
    func logout() {
        heartbeatTask?.cancel();heartbeatTask=nil
        let previous=token;token="";authenticated=false
        if !previous.isEmpty { Task { _ = try? await request("logout",token:previous) } }
    }
}
