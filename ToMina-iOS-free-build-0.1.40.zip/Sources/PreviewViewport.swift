import CoreGraphics

// The top bar lives at negative Y. Fit and hit testing must share the bounds of
// the complete scene, rather than the keyboard's PANEL.SIZE alone.
struct PreviewViewport {
    let bounds: CGRect
    let scale: CGFloat
    let origin: CGPoint

    init(bounds: CGRect, available: CGSize, zoom: CGFloat = 1, pan: CGSize = .zero) {
        self.bounds = bounds
        let fit = max(0.000001, min(max(1, available.width - 16) / max(1, bounds.width),
                                  max(1, available.height - 16) / max(1, bounds.height)))
        scale = fit * zoom
        // At fit size a one-finger key tap/scroll must not leave the top bar off
        // screen. Panning is available after deliberately zooming in.
        let offset = zoom > 1 ? pan : .zero
        origin = CGPoint(x: (available.width - bounds.width * scale) / 2 + offset.width,
                         y: (available.height - bounds.height * scale) / 2 + offset.height)
    }
    func point(_ scene: CGPoint) -> CGPoint {
        CGPoint(x: origin.x + (scene.x - bounds.minX) * scale,
                y: origin.y + (scene.y - bounds.minY) * scale)
    }
    func scenePoint(_ point: CGPoint) -> CGPoint {
        CGPoint(x: (point.x - origin.x) / scale + bounds.minX,
                y: (point.y - origin.y) / scale + bounds.minY)
    }
}
