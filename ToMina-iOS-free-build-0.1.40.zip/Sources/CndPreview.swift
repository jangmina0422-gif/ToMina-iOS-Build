import Foundation

enum CndPreview {
    static func isIcon(_ section: Section) -> Bool {
        section.name.range(of: "^ICON[0-9]+$", options: .regularExpression) != nil
    }
    static func iconNames(_ sections: [Section]) -> [String] {
        sections.filter(isIcon).map { $0.name }
    }
    // A standalone CND is an editor view of every declared icon. The candidate
    // bar attached to a keyboard still follows its original PERSIST conditions.
    static func shown(_ section: Section, standalone: Bool, chosen: String, candidates: Bool) -> Bool {
        if standalone && section.name == "CAND" { return false }
        guard isIcon(section) else { return true }
        if standalone { return chosen.isEmpty || section.name == chosen }
        let persist = (section.values["PERSIST"] ?? "3").trimmingCharacters(in: .whitespacesAndNewlines)
        return persist != "0" && !(persist == "1" && candidates) && !(persist == "2" && !candidates)
    }
}
