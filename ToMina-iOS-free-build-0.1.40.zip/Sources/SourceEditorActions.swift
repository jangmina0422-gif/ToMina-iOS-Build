import SwiftUI

// This control stays next to the panel menu, outside the scrolling details.
struct SourceEditorActions: View {
    let editing: Bool
    let toggleEditing: () -> Void

    var body: some View {
        Button(editing ? "退出编辑" : "编辑源代码", action: toggleEditing)
            .accessibilityIdentifier(editing ? "editor.exit" : "editor.open")
            .buttonStyle(MinaButtonStyle())
    }
}
