import Foundation
import CryptoKit

// Wire fields are decoded structurally. Unrecognized values retain their field numbers.
enum BinaryPlaintext {
    static func encode(_ fields: [Field]) -> Data {
        var out = Data()
        func put(_ value: UInt64) {
            var v = value
            while v >= 128 { out.append(UInt8(v & 127) | 128); v >>= 7 }
            out.append(UInt8(v))
        }
        for f in fields {
            put(UInt64(f.number << 3 | f.wire))
            switch f.wire {
            case 0: put(f.bits)
            case 1,5: for i in 0..<(f.wire == 1 ? 8 : 4) { out.append(UInt8(truncatingIfNeeded:f.bits >> (8*i))) }
            case 2: put(UInt64(f.bytes.count)); out.append(contentsOf:f.bytes)
            default: break
            }
        }
        return out
    }
    struct Field {
        var number: Int; var wire: Int; var offset: Int
        var bits: UInt64 = 0; var bytes: [UInt8] = []; var text: String?
        var children: [Field]?
    }
    static func parse(_ data: [UInt8], depth: Int = 0, budget: inout Int) throws -> [Field] {
        guard depth <= 24 else { throw SkinFailure(message: "二进制嵌套超过限制") }
        var p = 0, fields: [Field] = []
        func varint() throws -> UInt64 {
            var value: UInt64 = 0
            for i in 0..<10 {
                guard p < data.count else { throw SkinFailure(message: "varint 截断") }
                let b = data[p]; p += 1
                guard i < 9 || b <= 1 else { throw SkinFailure(message: "varint 溢出") }
                value |= UInt64(b & 127) << (i * 7)
                if b < 128 { return value }
            }
            throw SkinFailure(message: "varint 过长")
        }
        while p < data.count {
            budget += 1
            guard budget <= 350000 else { throw SkinFailure(message: "字段数量超过限制") }
            let offset = p, tag = try varint()
            guard tag >> 3 > 0, tag >> 3 <= 536870911 else { throw SkinFailure(message: "无效字段号 @\(offset)") }
            var field = Field(number: Int(tag >> 3), wire: Int(tag & 7), offset: offset)
            switch field.wire {
            case 0: field.bits = try varint()
            case 1, 5:
                let length = field.wire == 1 ? 8 : 4
                guard length <= data.count-p else { throw SkinFailure(message: "fixed 字段截断") }
                for i in 0..<length { field.bits |= UInt64(data[p+i]) << (8*i) }; p += length
            case 2:
                let length = try varint()
                guard length <= UInt64(data.count-p) else { throw SkinFailure(message: "length-delimited 越界") }
                field.bytes = Array(data[p..<p+Int(length)]); p += Int(length)
                if let text = String(bytes: field.bytes, encoding: .utf8), !text.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) && ![9,10,13].contains(Int($0.value)) }) { field.text = text }
                if depth < 24 { field.children = try? parse(field.bytes, depth: depth+1, budget: &budget) }
            default: throw SkinFailure(message: "不支持 wire type \(field.wire) @\(offset)")
            }
            fields.append(field)
        }
        return fields
    }
    static func inspection(_ fields: [Field]) -> [[String: Any]] {
        fields.map { f in
            var item: [String: Any] = ["field": f.number, "wire": f.wire, "offset": f.offset]
            if f.wire == 2 {
                item["base64"] = Data(f.bytes).base64EncodedString()
                if let text = f.text { item["text"] = text }
                if let children = f.children, !children.isEmpty { item["message"] = inspection(children) }
            } else {
                item["rawUnsigned"] = String(f.bits)
                if f.wire == 5 { let v = Float(bitPattern: UInt32(truncatingIfNeeded: f.bits)); if v.isFinite { item["float32"] = v } }
                if f.wire == 1 { let v = Double(bitPattern: f.bits); if v.isFinite { item["float64"] = v } }
            }
            return item
        }
    }
    static func decode(_ url: URL, data override:Data?=nil, includeInspection:Bool=true) throws -> Data {
        let data = try override ?? Data(contentsOf: url)
        guard data.count <= 32*1024*1024 else { throw SkinFailure(message: "配置超过 32 MB") }
        var out: [String: Any] = ["source": url.lastPathComponent, "sourceSha256": SHA256.hash(data: data).map { String(format:"%02x",$0) }.joined(), "notice": "明文副本；修改副本不会自动覆盖原二进制。"]
        if let json = try? JSONSerialization.jsonObject(with: data), json is [String: Any] || json is [Any] {
            out["format"] = "JSON"; out["data"] = json
        } else {
            var budget = 0
            let fields = try parse(Array(data), budget: &budget)
            guard !fields.isEmpty else { throw SkinFailure(message: "配置为空") }
            out["format"] = "Binary Config"
            if includeInspection { out["wireInspection"] = inspection(fields) }
            let schemaURL = Bundle.main.url(forResource: "BdaSchemas", withExtension: "json")
            let schemas = schemaURL.flatMap { try? Data(contentsOf:$0) }.flatMap { try? JSONSerialization.jsonObject(with:$0) } as? [String: [String: [String: String]]] ?? [:]
            var recognized = 0, unknown = 0
            func read(_ fields: [Field], _ type: String) -> [String: Any] {
                var result: [String: Any] = [:]
                func value(_ f: Field, _ type: String) -> Any {
                    if type == "string" { return f.text ?? "" }
                    if type == "boolean" { return f.bits != 0 }
                    if type == "number" {
                        if f.wire == 0 { return NSNumber(value: f.bits) }
                        let v = f.wire == 5 ? Double(Float(bitPattern: UInt32(truncatingIfNeeded: f.bits))) : Double(bitPattern: f.bits)
                        return v.isFinite ? v as Any : NSNull()
                    }
                    return read(f.children ?? [], type)
                }
                for f in fields {
                    guard let spec = schemas[type]?[String(f.number)], let name = spec["name"], let raw = spec["type"] else { unknown += 1; continue }
                    let subtype = raw.replacingOccurrences(of: "*", with: "").replacingOccurrences(of: "[]", with: "")
                    if raw.hasPrefix("*") {
                        guard let child = f.children, let key = child.first(where:{$0.number == 1}), let item = child.first(where:{$0.number == 2}) else { unknown += 1; continue }
                        var map = result[name] as? [String: Any] ?? [:]
                        map[key.text ?? String(key.bits)] = value(item, subtype); result[name] = map
                    } else if raw.hasSuffix("[]") {
                        var list = result[name] as? [Any] ?? []; list.append(value(f, subtype)); result[name] = list
                    } else { result[name] = value(f, subtype) }
                    recognized += 1
                }
                return result
            }
            out["decoded"] = read(fields, url.lastPathComponent.replacingOccurrences(of: "Config", with: ""))
            out["recognizedFields"] = recognized; out["unknownFields"] = unknown
        }
        return try JSONSerialization.data(withJSONObject: out, options: [.prettyPrinted, .sortedKeys, .fragmentsAllowed])
    }
}
