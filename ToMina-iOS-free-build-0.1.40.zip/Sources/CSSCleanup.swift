import Foundation

// Keep every original STYLE header. Scan every panel, CND/POP and animation,
// then follow references between styles. Unreadable configurations stop cleanup.
enum CSSCleanup {
    struct Result: Sendable { let text: String; let cleared: [Int] }
    private static let kinds: Set<String> = ["ini", "cnd", "pop", "css", "anim", "ani"]
    private static func styleID(_ name: String) -> Int? {
        guard name.range(of: "^STYLE[0-9]+$", options: .regularExpression) != nil else { return nil }
        return Int(name.dropFirst(5))
    }
    private static func references(_ section: Section) throws -> Set<Int> {
        var ids: Set<Int> = []
        for (key, value) in section.values {
            let upper = key.uppercased()
            guard upper != "STYLE_NUM" else { continue }
            if upper == "STAT_STYLE" {
                // S34_8 means state S34 selects [TIP8], not [STYLE34] or
                // [STYLE8]. TIP sections' BACK/FORE_STYLE fields are scanned
                // separately, so their CSS styles remain protected.
                if !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    for part in value.split(separator: "|", omittingEmptySubsequences: false) {
                        let token = part.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
                        guard token.range(of: "^S[0-9]+_[0-9]+$", options: .regularExpression) != nil else {
                            throw SkinFailure(message: "未知状态补丁 \(section.name).\(key)，未清空任何样式内容")
                        }
                    }
                }
                continue
            }
            if upper == "STYLE" || upper.hasSuffix("_STYLE") || upper.hasSuffix("_STYLES") || upper == "PARTICLE_IMAGE" {
                for part in value.split(separator: ",") {
                    let token = part.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
                    guard let id = Int(token) ?? styleID(token), id >= 0 else {
                        throw SkinFailure(message: "未知样式引用 \(section.name).\(key)，未清空任何样式内容")
                    }
                    ids.insert(id)
                }
            }
            // Explicit STYLE names in less common fields are retained too.
            let expression = try NSRegularExpression(pattern: "(?i)\\bSTYLE([0-9]+)\\b")
            let source = value as NSString
            for match in expression.matches(in: value, range: NSRange(location: 0, length: source.length)) {
                if let id = Int(source.substring(with: match.range(at: 1))) { ids.insert(id) }
            }
        }
        return ids
    }
    static func prepare(_ text: String, file: URL, root: URL, files: [URL]) throws -> Result {
        var documents: [URL: String] = [file: text]
        for other in files where other != file {
            if ["appearanceconfig", "layoutconfig"].contains(other.deletingPathExtension().lastPathComponent.lowercased()) {
                throw SkinFailure(message: "此包包含二进制外观配置，无法确认全部 CSS 调用，未清空任何样式内容")
            }
            guard kinds.contains(other.pathExtension.lowercased()) else { continue }
            guard let value = SkinConfiguration.read(other) else {
                throw SkinFailure(message: "无法完整读取 \(SkinConfiguration.relative(other, root: root))，未清空任何样式内容")
            }
            documents[other] = value
        }
        return try clean(text, external: documents.filter { $0.key != file }.map(\.value))
    }
    static func clean(_ text: String, external: [String]) throws -> Result {
        let sections = SkinConfiguration.parse(text)
        var graph: [Int: Set<Int>] = [:], used: Set<Int> = [], targetIDs: Set<Int> = []
        for section in sections {
            if let id = styleID(section.name) {
                guard graph[id] == nil else { throw SkinFailure(message: "CSS 样式编号重复，未清空任何样式内容") }
                graph[id] = try references(section); targetIDs.insert(id)
            } else { used.formUnion(try references(section)) }
        }
        for document in external {
            for section in SkinConfiguration.parse(document) {
                let refs = try references(section)
                if let id = styleID(section.name) {
                    // A definition is not a call. Follow its references only
                    // when a panel, candidate, popup or animation uses it.
                    graph[id, default: []].formUnion(refs)
                } else { used.formUnion(refs) }
            }
        }
        var pending = Array(used), visited: Set<Int> = []
        while let id = pending.popLast() {
            guard visited.insert(id).inserted else { continue }
            for child in graph[id] ?? [] where used.insert(child).inserted { pending.append(child) }
        }
        let unused = targetIDs.subtracting(used)
        guard !unused.isEmpty else { return Result(text: text, cleared: []) }
        var clearing: Int?, cleared: Set<Int> = []
        let lines = text.components(separatedBy: "\n").compactMap { line -> String? in
            if let name = SkinConfiguration.header(line) {
                if let id = styleID(name), unused.contains(id) { clearing = id }
                else { clearing = nil }
                // Preserve spelling, numbering, comments on the header and order.
                return line
            }
            if let id = clearing, !line.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                cleared.insert(id)
                return nil
            }
            return line
        }
        // Empty headers do not count as another edit; STYLE_NUM stays unchanged.
        return Result(text: lines.joined(separator: "\n"), cleared: cleared.sorted())
    }
}
