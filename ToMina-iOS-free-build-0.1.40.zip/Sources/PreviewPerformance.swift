import Foundation
import SwiftUI
import ImageIO

enum PreviewSizing {
    static func height(available: CGSize, tablet: Bool, keyboardVisible: Bool = false) -> CGFloat {
        if keyboardVisible { return min(96, max(0, available.height - 260)) }
        let maximum: CGFloat
        if tablet {
            maximum = available.width < 520 ? 232 : (available.width < 720 ? 264 : 320)
        } else {
            maximum = 264
        }
        return min(maximum, max(64, available.height - 220))
    }
    static func controlsHeight(available: CGFloat, keyboardVisible: Bool) -> CGFloat {
        min(keyboardVisible ? 60 : 220, max(0, available) / 3)
    }
}

// The display clock only runs while something can change. Deadlines also cover
// delays and the final redraw that removes a completed tap animation.
struct PreviewRefreshPlan: Equatable {
    var continuous = false
    var deadline: Date?
    static let idle = PreviewRefreshPlan()
    static let repeating = PreviewRefreshPlan(continuous: true)
    static func until(_ date: Date) -> Self { Self(deadline: date) }
    func active(at date: Date) -> Bool { continuous || (deadline.map { date < $0 } ?? false) }
    mutating func include(_ other: Self) {
        continuous = continuous || other.continuous
        if let date = other.deadline { deadline = max(deadline ?? date, date) }
    }
}

@MainActor final class PreviewImageCache {
    private final class Source: NSObject {
        let value: CGImageSource
        var delays: [Double]?
        init(_ value: CGImageSource) { self.value = value }
    }
    private final class Frame: NSObject {
        let value: CGImage
        let key: NSString
        var pieces: [String:CGImage] = [:]
        var cost: Int
        init(_ value: CGImage, key: NSString) { self.value = value; self.key = key; cost = value.bytesPerRow * value.height }
    }
    private final class WeakFrame {
        weak var value: Frame?
        init(_ value: Frame) { self.value = value }
    }
    private let sources = NSCache<NSURL, Source>()
    private let frames = NSCache<NSString, Frame>()
    private var owners: [UInt:WeakFrame] = [:]
    private(set) var decodeCount = 0
    private(set) var cropCount = 0
    init() {
        sources.countLimit = 96
        frames.countLimit = 128; frames.totalCostLimit = 48 * 1024 * 1024
    }
    func clear() {
        sources.removeAllObjects(); frames.removeAllObjects(); owners.removeAll()
        decodeCount = 0; cropCount = 0
    }
    private func source(_ url: URL) -> Source? {
        if let cached = sources.object(forKey: url as NSURL) { return cached }
        guard let raw = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let cached = Source(raw); sources.setObject(cached, forKey: url as NSURL)
        return cached
    }
    func animated(_ url: URL) -> Bool {
        if ["mp4", "mov", "m4v"].contains(url.pathExtension.lowercased()) { return true }
        return source(url).map { CGImageSourceGetCount($0.value) > 1 } ?? false
    }
    func loopIndex(_ url: URL, time: TimeInterval) -> Int {
        guard let source = source(url), CGImageSourceGetCount(source.value) > 1 else { return 0 }
        if source.delays == nil {
            source.delays = (0..<min(CGImageSourceGetCount(source.value), 1000)).map { index in
                let info = CGImageSourceCopyPropertiesAtIndex(source.value, index, nil) as? [String: Any] ?? [:]
                let gif = info[kCGImagePropertyGIFDictionary as String] as? [String: Any] ?? [:]
                let png = info[kCGImagePropertyPNGDictionary as String] as? [String: Any] ?? [:]
                let delay = (gif[kCGImagePropertyGIFUnclampedDelayTime as String] ?? gif[kCGImagePropertyGIFDelayTime as String] ?? png[kCGImagePropertyAPNGUnclampedDelayTime as String] ?? png[kCGImagePropertyAPNGDelayTime as String]) as? NSNumber
                return max(0.02, delay?.doubleValue ?? 0.1)
            }
        }
        let delays = source.delays ?? [0.1], duration = delays.reduce(0, +)
        var elapsed = max(0, time).truncatingRemainder(dividingBy: duration), index = 0
        while index < delays.count - 1 && elapsed >= delays[index] { elapsed -= delays[index]; index += 1 }
        return index
    }
    func fitsPixelBudget(_ url: URL, index: Int = 0, limit: Double) -> Bool {
        guard let source = source(url), index >= 0, index < CGImageSourceGetCount(source.value),
              let values = CGImageSourceCopyPropertiesAtIndex(source.value, index, nil) as? [String: Any],
              let width = values[kCGImagePropertyPixelWidth as String] as? NSNumber,
              let height = values[kCGImagePropertyPixelHeight as String] as? NSNumber else { return false }
        let w = width.doubleValue, h = height.doubleValue
        return w.isFinite && h.isFinite && w > 0 && h > 0 && w * h <= limit
    }
    func image(_ url: URL, index: Int = 0, maximum: Int? = nil) -> CGImage? {
        let key = "\(url.path)\n\(index)\n\(maximum ?? 0)" as NSString
        if let cached = frames.object(forKey: key) { return cached.value }
        guard let source = source(url), index >= 0, index < CGImageSourceGetCount(source.value) else { return nil }
        let decoded: CGImage?
        if let maximum {
            decoded = CGImageSourceCreateThumbnailAtIndex(source.value, index, [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceThumbnailMaxPixelSize: maximum, kCGImageSourceCreateThumbnailWithTransform: true, kCGImageSourceShouldCacheImmediately: true] as CFDictionary)
        } else {
            decoded = CGImageSourceCreateImageAtIndex(source.value, index, [kCGImageSourceShouldCacheImmediately: true] as CFDictionary)
        }
        guard let decoded else { return nil }
        return insert(decoded, key: key)
    }
    func frame(key: String, decode: () -> CGImage?) -> CGImage? {
        let key = key as NSString
        if let cached = frames.object(forKey: key) { return cached.value }
        guard let decoded = decode() else { return nil }
        return insert(decoded, key: key)
    }
    private func insert(_ image: CGImage, key: NSString) -> CGImage {
        let frame = Frame(image, key: key)
        if owners.count >= 256 { owners = owners.filter { $0.value.value != nil } }
        owners[UInt(bitPattern: Unmanaged.passUnretained(image).toOpaque())] = WeakFrame(frame)
        frames.setObject(frame, forKey: key, cost: frame.cost)
        decodeCount += 1
        return image
    }
    func crop(_ image: CGImage, rect: CGRect) -> CGImage? {
        guard rect.width > 0, rect.height > 0 else { return nil }
        let identity = UInt(bitPattern: Unmanaged.passUnretained(image).toOpaque())
        let key = "\(rect.origin.x),\(rect.origin.y),\(rect.width),\(rect.height)"
        let owner = owners[identity]?.value
        if let owner, owner.value === image, let cached = owner.pieces[key] { return cached }
        guard let cropped = image.cropping(to: rect) else { return nil }
        cropCount += 1
        if let owner, owner.value === image {
            if owner.pieces.count >= 256 { owner.pieces.removeAll(); owner.cost = image.bytesPerRow * image.height }
            owner.pieces[key] = cropped
            owner.cost += cropped.bytesPerRow * cropped.height
            // Crops leave the cache with their source frame; retained image
            // buffers are included in the decoded-frame cache cost.
            frames.setObject(owner, forKey: owner.key, cost: owner.cost)
        }
        return cropped
    }
}
