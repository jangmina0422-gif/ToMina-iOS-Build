import Foundation
import CoreFoundation
import CoreGraphics

struct Section: Sendable {
    var name:String
    var values:[String:String]=[:]
}

// Text, package selection and resource precedence shared by all preview paths.
enum SkinConfiguration {
    static let gb=String.Encoding(rawValue:CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(CFStringEncodings.GB_18030_2000.rawValue)))
    static func decode(_ data:Data)->(text:String,encoding:String.Encoding)? {
        let encodings:[String.Encoding]=data.starts(with:[0xff,0xfe]) || data.starts(with:[0xfe,0xff]) ? [.utf16,.utf8,gb]:[.utf8,gb]
        for encoding in encodings {if let text=String(data:data,encoding:encoding){return (text,encoding)}}
        return nil
    }
    static func read(_ file:URL)->String? {
        guard let data=try? Data(contentsOf:file),data.count<=2*1024*1024 else{return nil}
        return decode(data)?.text
    }
    static func header(_ raw:String)->String? {
        let line=raw.replacingOccurrences(of:"\u{FEFF}",with:"").trimmingCharacters(in:.whitespacesAndNewlines)
        guard line.first == "[", line.range(of:"^\\[([^]]+)\\]\\s*(?://.*|;.*)?$",options:.regularExpression) != nil,
              let end=line.firstIndex(of:"]") else{return nil}
        return String(line[line.index(after:line.startIndex)..<end]).uppercased()
    }
    static func parse(_ text:String,cancelled:()->Bool={false})->[Section] {
        var out:[Section]=[]
        for (index,raw) in text.components(separatedBy:.newlines).enumerated() {
            if index % 128 == 0 && cancelled() { return [] }
            let line=raw.replacingOccurrences(of:"\u{FEFF}",with:"").trimmingCharacters(in:.whitespacesAndNewlines)
            if let name=header(line){out.append(Section(name:name));continue}
            guard !out.isEmpty,!line.hasPrefix(";"),!line.hasPrefix("#"),!line.hasPrefix("//"),let equal=line.firstIndex(of:"=") else{continue}
            var value=String(line[line.index(after:equal)...])
            if let comment=value.range(of:" //"){value=String(value[..<comment.lowerBound])}
            let key=String(line[..<equal]).trimmingCharacters(in:.whitespaces).uppercased()
            out[out.count-1].values[key]=value.trimmingCharacters(in:.whitespaces)
        }
        return out
    }
    static func numbers(_ value:String?)->[Double] {
        guard let value else{return []}
        let parts=value.components(separatedBy:","),numbers=parts.compactMap{Double($0.trimmingCharacters(in:.whitespaces))}
        return numbers.count==parts.count && numbers.allSatisfy(\.isFinite) ? numbers:[]
    }
    static func renumberKeys(_ text:String)->String {
        var mapping:[String:String]=[:],next=1
        for section in parse(text) where section.name.range(of:"^KEY[0-9]+$",options:.regularExpression) != nil {
            mapping[String(section.name.dropFirst(3))]=String(next);next+=1
        }
        return text.components(separatedBy:"\n").map{raw in
            if let name=header(raw),let value=mapping[String(name.dropFirst(3))],name.hasPrefix("KEY"),
               let range=raw.range(of:"\\[KEY[0-9]+\\]",options:[.regularExpression,.caseInsensitive]) {
                var line=raw;line.replaceSubrange(range,with:"[KEY"+value+"]");return line
            }
            guard let equal=raw.firstIndex(of:"="),raw[..<equal].trimmingCharacters(in:.whitespaces).uppercased()=="BROTHER_ID" else{return raw}
            let original=String(raw[raw.index(after:equal)...]),comment=original.range(of:" //")
            let number=comment.map{String(original[..<$0.lowerBound])} ?? original
            guard let value=mapping[number.trimmingCharacters(in:.whitespacesAndNewlines)] else{return raw}
            return String(raw[...equal])+value+(comment.map{String(original[$0.lowerBound...])} ?? (raw.hasSuffix("\r") ? "\r":""))
        }.joined(separator:"\n")
    }
    static func effective(_ text:String,defaults:[Section])->[Section] {
        effective(parse(text), defaults: defaults)
    }
    static func effective(_ parsed:[Section],defaults:[Section])->[Section] {
        var seen:[String:Int]=[:]
        let defaultsByName = Dictionary(grouping: defaults, by: \.name)
        var result = parsed.map { section in
            let index=seen[section.name,default:0];seen[section.name]=index+1
            var merged=defaultsByName[section.name]?.dropFirst(index).first ?? Section(name:section.name)
            merged.values.merge(section.values){_,new in new};return merged
        }
        // Match Android's composition: an empty [CAND] inherits the first bar,
        // and later bars in gen.ini remain available for preview switching.
        let candidateCount = seen["CAND", default: 0]
        if candidateCount > 0 {
            result.append(contentsOf: defaults.filter { $0.name == "CAND" }.dropFirst(candidateCount))
        }
        return result
    }
    static func relative(_ file:URL,root:URL)->String {
        file.pathComponents.dropFirst(root.pathComponents.count).joined(separator:"/")
    }
    static func score(_ path:String,context:String)->Int {
        let p=Array(path.lowercased().utf16),c=Array(context.lowercased().utf16)
        var result=0
        while result<p.count && result<c.count && p[result]==c[result]{result+=1}
        for token in ["dark","light","port","land"] {
            let a=("/"+path.lowercased()).contains("/"+token+"/"),b=("/"+context.lowercased()).contains("/"+token+"/")
            if a && b{result+=1000}else if a && !b{result-=1000}
        }
        return result
    }
    static func resolve(_ reference:String,root:URL,config:URL,files:[URL])->URL? {
        var name=reference.replacingOccurrences(of:"\\",with:"/").lowercased().trimmingCharacters(in:.whitespacesAndNewlines)
        if name.hasPrefix("./"){name=String(name.dropFirst(2))}
        guard !name.isEmpty,!name.hasPrefix("/"),!name.contains(":"),!name.contains("\0"),!name.components(separatedBy:"/").contains("..") else{return nil}
        let ctx=relative(config.deletingLastPathComponent(),root:root)+"/"
        var paths:[String]=name.contains("/") ? [name]:[],dir=ctx=="/" ? "":ctx
        while true {
            paths += [dir+name,dir+"res/"+name]
            if dir.isEmpty{break}
            let parts=dir.split(separator:"/").dropLast();dir=parts.isEmpty ? "":parts.joined(separator:"/")+"/"
        }
        let index=Dictionary(uniqueKeysWithValues:files.map{(relative($0,root:root).lowercased(),$0)})
        for path in paths {
            if let file=index[path]{return file}
            for ext in ["png","webp","jpg","jpeg","gif","apng"] {if let file=index[path+"."+ext]{return file}}
        }
        let base=(name as NSString).lastPathComponent
        return files.filter{$0.lastPathComponent.lowercased()==base || $0.deletingPathExtension().lastPathComponent.lowercased()==base}.sorted {
            let a=score(relative($0,root:root),context:ctx),b=score(relative($1,root:root),context:ctx)
            return a==b ? $0.path<$1.path:a>b
        }.first
    }
    static func panelFiles(_ files:[URL], preparedSections:[URL:[Section]]?=nil)->[URL] {
        files.filter {file in
            guard file.pathExtension.lowercased()=="ini",file.lastPathComponent.lowercased() != "gen.ini",let parsed=preparedSections?[file] ?? read(file).map({parse($0)}) else{return false}
            return parsed.contains {s in
                guard s.name.range(of:"^(KEY[0-9]+|LIST[0-9]*|ICON[0-9]+)$",options:.regularExpression) != nil else{return false}
                let r=numbers(s.values["VIEW_RECT"])
                if r.count==4,r[2]>0,r[3]>0{return true}
                let p=numbers(s.values["POS"]),size=numbers(s.values[s.name.hasPrefix("LIST") ? "CELL_SIZE":"SIZE"])
                guard p.count==2,size.count==2,size[0]>0,size[1]>0 else{return false}
                if s.name.hasPrefix("ICON"){return true}
                let count=Int(s.values["LIST_NUM"] ?? "") ?? 0
                return s.name.hasPrefix("LIST") && (1...10000).contains(count)
            }
        }.sorted{$0.path<$1.path}
    }
    static func firstLayout(_ files:[URL], preparedSections:[URL:[Section]]?=nil)->URL? {
        let layouts=files.filter {file in
            guard file.pathExtension.lowercased()=="ini",let parsed=preparedSections?[file] ?? read(file).map({parse($0)}) else{return false}
            return parsed.contains {section in
                let r=numbers(section.values["VIEW_RECT"])
                return section.name.range(of:"^KEY[0-9]+$",options:.regularExpression) != nil && r.count==4 && r[2]>0 && r[3]>0
            }
        }.sorted{$0.path<$1.path}
        return layouts.first{$0.path.lowercased().hasSuffix("port/py_26.ini")} ?? layouts.first
    }
    static func usesConfigPreview(_ name:String,files:[URL])->Bool {
        name.lowercased().hasSuffix(".bda") || (files.contains{["appearanceconfig","appearanceconfig.json"].contains($0.lastPathComponent.lowercased())} && firstLayout(files)==nil)
    }
    static func validate(_ text:String)->[String] {
        let sections=parse(text);var seen=Set<String>(),issues:[String]=[]
        for s in sections {
            let at="["+s.name+"] "
            if s.name != "CAND" && !seen.insert(s.name).inserted{issues.append(at+"重复段")}
            if s.name.hasPrefix("KEY"),let brother=s.values["BROTHER_ID"],!sections.contains(where:{$0.name=="KEY"+brother}){issues.append(at+"BROTHER_ID 引用不存在")}
            for (key,value) in s.values.sorted(by:{$0.key<$1.key}) {
                let r=numbers(value)
                if ["VIEW_RECT","TOUCH_RECT","SOURCE_RECT","INNER_RECT"].contains(key),r.count != 4 || r.count==4 && (r[2]<=0 || r[3]<=0){issues.append(at+key+" 应为 x,y,正宽,正高")}
                if ["SIZE","POS","CELL_SIZE"].contains(key),r.count != 2{issues.append(at+key+" 应为两项数字")}
                if key.hasSuffix("_NUM") {
                    let prefix=String(key.dropLast(4))
                    if ["KEY","ICON","TIP","OFFSET","STYLE","IMG"].contains(prefix) {
                        let actual=sections.filter{$0.name.hasPrefix(prefix) && Int($0.name.dropFirst(prefix.count)) != nil}.count
                        if Int(value) != actual{issues.append(at+key+"="+value+"，实际 \(actual)")}
                    }
                }
                if value.contains("，") && (key.hasSuffix("RECT") || key.hasSuffix("STYLE") || ["SIZE","POS"].contains(key)){issues.append(at+key+" 使用了中文逗号")}
                if value.isEmpty{issues.append(at+key+" 为空，请核实是否有意继承")}
            }
            if s.name.range(of:"^LIST[0-9]*$",options:.regularExpression) != nil {
                let cell=numbers(s.values["CELL_SIZE"]),padding=numbers(s.values["PADDING"] ?? "0,0,0,0"),count=Int(s.values["LIST_NUM"] ?? "0") ?? 0
                if cell.count != 2 || cell.contains(where:{$0<=0}){issues.append(at+"CELL_SIZE 应为正宽度,正高度")}
                if count<1 || count>10000{issues.append(at+"LIST_NUM 应为 1–10000")}
                if padding.count != 4{issues.append(at+"PADDING 应为左,上,右,下")}
                else if cell.count==2 && count>0 {
                    let horizontal=s.values["LIST_ORDER"]=="1",w=cell[0]*Double(horizontal ? count:1),h=cell[1]*Double(horizontal ? 1:count)
                    if padding[0]+padding[2]>=w || padding[1]+padding[3]>=h{issues.append(at+"PADDING 已占满列表内部区域")}
                }
            }
            let outer=numbers(s.values["SOURCE_RECT"]),inner=numbers(s.values["INNER_RECT"])
            if outer.count==4 && inner.count==4 && (inner[0]<outer[0] || inner[1]<outer[1] || inner[0]+inner[2]>outer[0]+outer[2] || inner[1]+inner[3]>outer[1]+outer[3]){issues.append(at+"INNER_RECT 超出 SOURCE_RECT")}
        }
        return issues
    }
    static func write(_ pending:[URL:String])throws {
        var data:[URL:Data]=[:],old:[URL:Data]=[:],written:[URL]=[]
        for (file,text) in pending {
            let original=try? Data(contentsOf:file)
            if let original{old[file]=original}
            let encoding=original.flatMap{decode($0)?.encoding} ?? .utf8
            guard let encoded=text.data(using:encoding,allowLossyConversion:false) else{throw ConfigurationError.invalid("原文件编码无法保存")}
            data[file]=encoded
        }
        do {
            for file in data.keys.sorted(by:{$0.path<$1.path}) {
                try FileManager.default.createDirectory(at:file.deletingLastPathComponent(),withIntermediateDirectories:true)
                try data[file]!.write(to:file,options:.atomic);written.append(file)
            }
        }catch{
            for file in written.reversed(){if let bytes=old[file]{try? bytes.write(to:file,options:.atomic)}else{try? FileManager.default.removeItem(at:file)}}
            throw error
        }
    }
}
enum ConfigurationError:LocalizedError {
    case invalid(String)
    var errorDescription:String?{if case .invalid(let message)=self{return message};return nil}
}
