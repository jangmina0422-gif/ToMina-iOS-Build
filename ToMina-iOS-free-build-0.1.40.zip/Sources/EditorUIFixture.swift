#if DEBUG
import Foundation
import ZIPFoundation
import UIKit

// Synthetic data is available only in the Debug UI test process.
@MainActor enum EditorUIFixture {
    static var combined: Bool { ProcessInfo.processInfo.arguments.contains("--combined-preview-fixture") }
    static var requested: Bool { combined || ProcessInfo.processInfo.arguments.contains("--editor-controls-fixture") }
    static var width: CGFloat? { ProcessInfo.processInfo.arguments.contains("--narrow-preview-fixture") ? 375 : nil }
    static func openIfRequested(_ store: SkinStore) async -> Bool {
        guard requested else { return false }
        if combined { return await openCombined(store) }
        do {
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            let skin = folder.appendingPathComponent("skin"), port = skin.appendingPathComponent("port")
            try FileManager.default.createDirectory(at: port, withIntermediateDirectories: true)
            try "[PANEL]\nSIZE=240,120\nKEY_NUM=1\nTIP_NUM=1\n[KEY1]\nVIEW_RECT=0,0,60,50\nCENTER=q\nBACK_STYLE=1\nSTAT_STYLE=S34_1|S36_1|S37_1\n[TIP1]\nFORE_STYLE=3\n"
                .write(to: port.appendingPathComponent("py_26.ini"), atomically: true, encoding: .utf8)
            try "[GLOBAL]\nSTYLE_NUM=3\n[STYLE1]\nNM_COLOR=FFFFFFFF\n[STYLE2]\nNM_COLOR=FF000000\n[STYLE3]\nNM_COLOR=FF000000\n"
                .write(to: skin.appendingPathComponent("styles.css"), atomically: true, encoding: .utf8)
            try "[GLOBAL]\nANIM_NUM=1\n[ANIM1]\nCATEGORY=3\nPARTICLE_IMAGE=1\nTOTAL_NUMBER=1\nLIFE=1000\n"
                .write(to: skin.appendingPathComponent("anim.ini"), atomically: true, encoding: .utf8)
            try ((0..<600).map { "; line \($0) 中文 🎨" }.joined(separator: "\n") + "\n; END")
                .write(to: skin.appendingPathComponent("long.txt"), atomically: true, encoding: .utf8)
            let file = folder.appendingPathComponent("controls.bds")
            try FileManager.default.zipItem(at: skin, to: file, shouldKeepParent: false)
            await store.openArchive(file)
            return store.root != nil && store.error == nil
        } catch { store.error = error.localizedDescription; return false }
    }
    private static func openCombined(_ store: SkinStore) async -> Bool {
        do {
            let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            let skin=folder.appendingPathComponent("skin"),port=skin.appendingPathComponent("port"),res=port.appendingPathComponent("res")
            try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
            try "[PANEL]\nSIZE=1080,640\nBACK_STYLE=1\n[CAND]\nLAYOUT_NAME=cand1\nVIEW_RECT=0,0,1080,120\n".write(to:port.appendingPathComponent("gen.ini"),atomically:true,encoding:.utf8)
            var keyboard="[INPUT]\n[CAND]\n[PANEL]\nKEY_NUM=40\n"
            let captions=Array("qwertyuiopasdfghjkl;zxcvbnm,./1234567890")
            for row in 0..<4 { for col in 0..<10 {
                let index=row*10+col
                keyboard += "[KEY\(index+1)]\nVIEW_RECT=\(col*108),\(row*160),108,160\nBACK_STYLE=3\nCENTER=\(captions[index])\nANIM_STYLE=4\n"
            }}
            try keyboard.write(to:port.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
            try "[CAND]\nBACK_STYLE=2\n[ICON1]\nVIEW_RECT=950,40,60,40\nBACK_STYLE=5\nPERSIST=3\n".write(to:port.appendingPathComponent("cand1.cnd"),atomically:true,encoding:.utf8)
            try "[STYLE1]\nNM_COLOR=FFF8EAD8\n[STYLE2]\nNM_IMG=bar,1\n[STYLE3]\nNM_COLOR=FF4080C0\n[STYLE4]\nPRESS_ANIM=1\n[STYLE5]\nNM_COLOR=FF30A060\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
            try "[IMG1]\nSOURCE_RECT=0,0,1080,120\n".write(to:res.appendingPathComponent("bar.til"),atomically:true,encoding:.utf8)
            let format=UIGraphicsImageRendererFormat();format.scale=1
            let atlas=UIGraphicsImageRenderer(size:CGSize(width:1080,height:120),format:format).image { ctx in
                UIColor(red:248/255,green:234/255,blue:216/255,alpha:1).setFill();ctx.fill(CGRect(x:0,y:0,width:1080,height:120))
                UIColor(red:160/255,green:96/255,blue:64/255,alpha:1).setFill();ctx.fill(CGRect(x:0,y:0,width:1080,height:30))
            }
            try atlas.pngData()!.write(to:res.appendingPathComponent("bar.png"))
            try "[GLOBAL]\nANIM_NUM=1\n[ANIM1]\nTYPE=1\nFROM=0\nTO=10\nDURATION=150\n".write(to:res.appendingPathComponent("anim.ini"),atomically:true,encoding:.utf8)
            let file=folder.appendingPathComponent("combined.bds")
            try FileManager.default.zipItem(at:skin,to:file,shouldKeepParent:false)
            await store.openArchive(file)
            return store.root != nil && store.error == nil
        } catch { store.error=error.localizedDescription;return false }
    }
}
#endif
