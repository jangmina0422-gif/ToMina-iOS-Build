import SwiftUI
import UIKit
import Combine

struct PreparedEditorPreview: Sendable {
    let sections: [Section]
    let overrides: [URL: Data]?
    let configurations: [URL: PreparedConfiguration]
    let failure: String?
    let background: Bool
    static func prepare(_ text: String, file: URL?, files: [URL], linkedBinary: Bool) -> Self {
        let sections = SkinConfiguration.parse(text, cancelled: { Task.isCancelled })
        guard linkedBinary, let file, !Task.isCancelled else {
            return Self(sections: sections, overrides: nil, configurations: [:], failure: nil, background: !Thread.isMainThread)
        }
        do {
            let overrides = try BdaTextSync.preview(file: file, text: text, files: files)
            let configurations = try Dictionary(uniqueKeysWithValues: overrides.map { ($0.key, try PreparedConfiguration.decode($0.key, data: $0.value)) })
            return Self(sections: sections, overrides: overrides, configurations: configurations, failure: nil, background: !Thread.isMainThread)
        } catch {
            return Self(sections: sections, overrides: nil, configurations: [:], failure: error.localizedDescription, background: !Thread.isMainThread)
        }
    }
}

// Typing changes only this buffer. Preview observers are notified after a
// completed edit burst, rather than once for every character in a large file.
@MainActor final class EditorDraft: ObservableObject {
    private(set) var text = ""
    @Published private(set) var revision = 0
    func replace(_ value: String) {
        text = value; revision &+= 1
    }
    func acceptTyping(_ value: String) { text = value }
}

struct DraftTextEditor: UIViewRepresentable {
    @ObservedObject var draft: EditorDraft
    @Binding var focused: Bool
    let edit: (String, Bool) -> Bool
    let finish: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> UITextView {
        let view = UITextView(frame: .zero)
        view.delegate = context.coordinator
        view.font = .systemFont(ofSize: 14)
        view.textColor = .black; view.backgroundColor = .clear
        view.autocorrectionType = .no; view.spellCheckingType = .no
        view.smartQuotesType = .no; view.smartDashesType = .no
        view.smartInsertDeleteType = .no; view.keyboardDismissMode = .interactive
        view.alwaysBounceVertical = true
        view.textContainerInset = UIEdgeInsets(top: 8, left: 4, bottom: 16, right: 4)
        view.layoutManager.allowsNonContiguousLayout = true
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        view.accessibilityLabel = "配置源码"
        return view
    }
    func updateUIView(_ view: UITextView, context: Context) {
        context.coordinator.parent = self
        // Never assign the entire document back during ordinary typing,
        // scrolling, preview redraws or Chinese input composition.
        if context.coordinator.revision != draft.revision {
            let selection = view.selectedRange, offset = view.contentOffset
            view.text = draft.text
            let count = (draft.text as NSString).length
            view.selectedRange = NSRange(location: min(selection.location, count), length: min(selection.length, max(0, count - selection.location)))
            view.setContentOffset(offset, animated: false)
            context.coordinator.revision = draft.revision
        }
        if focused && !view.isFirstResponder { view.becomeFirstResponder() }
        if !focused && view.isFirstResponder { view.resignFirstResponder() }
    }
    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: DraftTextEditor
        var revision = -1
        init(_ parent: DraftTextEditor) { self.parent = parent }
        func textViewDidBeginEditing(_ view: UITextView) { parent.focused = true }
        func textViewDidChange(_ view: UITextView) {
            if !parent.edit(view.text, view.markedTextRange != nil) {
                view.text = parent.draft.text
            }
        }
        func textViewDidEndEditing(_ view: UITextView) {
            _ = parent.edit(view.text, false)
            parent.focused = false; parent.finish()
        }
    }
}

// Keep an in-progress parameter value independent of the last preview parse.
struct DraftParameterField: View {
    let value: String
    let edit: (String) -> Void
    let finish: () -> Void
    @State private var draft: String
    @FocusState private var focused: Bool
    init(value: String, edit: @escaping (String) -> Void, finish: @escaping () -> Void) {
        self.value = value; self.edit = edit; self.finish = finish
        _draft = State(initialValue: value)
    }
    var body: some View {
        TextField("参数值", text: $draft).focused($focused)
            .textFieldStyle(.plain).foregroundStyle(.black)
            .padding(12).background(MinaTheme.button).clipShape(RoundedRectangle(cornerRadius: 12))
            .onChange(of: draft) { _, next in if next != value { edit(next) } }
            .onChange(of: value) { _, next in if !focused { draft = next } }
            .onChange(of: focused) { _, active in if !active { finish() } }
            .onDisappear(perform: finish)
    }
}
