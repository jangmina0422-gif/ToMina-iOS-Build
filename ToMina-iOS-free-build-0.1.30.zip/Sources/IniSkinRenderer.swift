import Foundation
import SwiftUI
import UIKit
import CoreFoundation
import CoreText
import ImageIO

// INI renderer ported from the 0.3.14 Android style and atlas rules.
@MainActor final class IniSkinRenderer {
    private var drafts:[URL:String]=[:]
    private var draftSections:[URL:[Section]]=[:]
    private var preparedTexts:[URL:String]=[:]
    private var preparedRoot:URL?
    private var preparedConfigurations:[URL:PreparedConfiguration]=[:]
    private var preparedConfigurationErrors:[URL:String]=[:]
    private var preparedSections:[URL:[Section]]=[:]
    func prepare(_ archive:PreparedSkinArchive){preparedRoot=archive.folder;preparedTexts=archive.texts;preparedSections=archive.sections;preparedConfigurations=archive.configurations;preparedConfigurationErrors=archive.configurationErrors}
    func invalidatePrepared(_ files:[URL]){for file in files{preparedTexts.removeValue(forKey:file);preparedSections.removeValue(forKey:file);preparedConfigurations.removeValue(forKey:file);preparedConfigurationErrors.removeValue(forKey:file)}}
    private func draftRead(_ url:URL)->String?{drafts[url] ?? preparedTexts[url] ?? Self.read(url)}
    private func parsedRead(_ url:URL)->[Section]{
        if let draft=drafts[url]{return draftSections[url] ?? SkinStore.parse(draft)}
        if let cached=preparedSections[url]{return cached}
        let raw=Self.read(url) ?? "";preparedTexts[url]=raw
        let parsed=SkinStore.parse(raw);preparedSections[url]=parsed;return parsed
    }
    let rasterCache=PreviewRasterCache()
    private var fontFiles:[URL]=[]
    private var fontLookup:[String:String]=[:]
    private(set) var fontLookupCount=0
    private var files: [URL] = []
    private var root: URL?
    private var config: URL?
    private(set) var styles: [String: Section] = [:]
    private var offsets: [String: Section] = [:]
    private var sections: [String: Section] = [:]
    private(set) var effectiveSections:[Section]=[]
    private(set) var panelSection:Section?
    private var resolved:[String:URL]=[:]
    private var unresolved=Set<String>()
    private(set) var warnings=Set<String>()
    let imageCache = PreviewImageCache()
    private(set) var tileReadCount = 0
    private var imageTimelines:[URL:ImageTimeline]=[:]
    private var tiles: [URL: [Section]] = [:]
    private var fonts: [URL: String] = [:]
    private(set) var hasStyles = false
    private var hybrid:BdaPreviewEngine?
    var timeline=IniTimeline(definitions:[:])
    var animationFiles:[String:URL]=[:]
    private(set) var styleFile:URL?
    var floatingChoice=""
    var floatingPausedAt:Date?
    func restartFloating(){floatingStart=Date();floatingPausedAt=nil}
    func toggleFloating(){let now=Date();if let paused=floatingPausedAt{floatingStart=floatingStart.addingTimeInterval(now.timeIntervalSince(paused));floatingPausedAt=nil}else{floatingPausedAt=now}}
    var animationKey="",animationStart=Date(),animationEvent="PRESS_ANIM"
    var animationEnabled=false
    var candidateChoice="",hasCandidates=false
    var cndIconChoice = ""
    var isCnd: Bool { config?.pathExtension.lowercased() == "cnd" }
    var cndIconNames: [String] { isCnd ? CndPreview.iconNames(effectiveSections) : [] }
    var candidateFile:URL?,candidateSize=CGSize.zero,candidateSections:[Section]=[],candidateNames:[String]=[]
    var floatingStart=Date()
    private(set) var floatingAnimations:[String]=[]
    private(set) var floatingLevel=1
    private(set) var floatingDelay:Double=0
    func resetSelection(){animationKey="";animationEnabled=false;candidateChoice="";floatingChoice="";floatingPausedAt=nil;candidateSize = .zero;restartFloating()}
    func visible(_ section:Section)->Bool {
        CndPreview.shown(section, standalone: isCnd, chosen: cndIconChoice, candidates: hasCandidates)
    }
    func floating(size:CGSize,ios:Bool,context:inout GraphicsContext) {
        var layer=context;layer.clip(to:Path(CGRect(origin:.zero,size:size)))
        for id in floatingAnimations {
            guard let d=timeline.definitions[id],d["CATEGORY"]?.trimmingCharacters(in:.whitespacesAndNewlines)=="3" else{continue}
            let seed=id.utf16.reduce(Int32(0)){($0 &* 31) &+ Int32($1)}
            let particles=ParticleTimeline(config:d,ios:ios,seed:Int64(seed)).sample((floatingPausedAt ?? Date()).timeIntervalSince(floatingStart)*1000-floatingDelay,width:size.width,height:size.height)
            for p in particles where p.scale>0 && p.alpha>0 {
                guard let spec=styles["STYLE"+p.style],let reference=spec.values["NM_IMG"] else{continue}
                let parts=reference.components(separatedBy:",")
                guard parts.count==2,let file=resolve((parts[0] as NSString).deletingPathExtension+".til"),let tile=tileSections(file).first(where:{$0.name=="IMG"+parts[1].trimmingCharacters(in:.whitespaces)}) else{continue}
                let r=SkinStore.numbers(tile.values["SOURCE_RECT"]);guard r.count==4,r[2]>0,r[3]>0 else{continue}
                var particle=layer;particle.translateBy(x:p.x,y:p.y);particle.rotate(by:.degrees(p.rotation));particle.scaleBy(x:p.scale,y:p.scale);particle.opacity *= p.alpha/255
                _=drawImage(reference,rect:CGRect(x:-r[2]/2,y:-r[3]/2,width:r[2],height:r[3]),context:&particle)
            }
        }
    }
    func trigger(_ key:String) {animationKey=key;animationStart=Date()}
    static func read(_ url: URL) -> String? {
        SkinConfiguration.read(url)
    }
    func configure(root: URL?, config: URL?, files: [URL], text: String, overrides:[URL:String]=[:], parsedOverrides:[URL:[Section]]=[:], preservingResources:Bool=false) {
        let keepResources = preservingResources && self.root == root?.resolvingSymlinksInPath() && self.config == config?.resolvingSymlinksInPath() && self.files == files
        let previousDrafts = drafts
        if self.config != config?.resolvingSymlinksInPath() { cndIconChoice = "" }
        drafts=Dictionary(overrides.map{($0.key.resolvingSymlinksInPath(),$0.value)},uniquingKeysWith:{_,new in new})
        draftSections=Dictionary(parsedOverrides.map{($0.key.resolvingSymlinksInPath(),$0.value)},uniquingKeysWith:{_,new in new})
        if self.root != root?.resolvingSymlinksInPath() { imageCache.clear(); tiles.removeAll(); fonts.removeAll();floatingChoice="";restartFloating() }
        self.root = root?.resolvingSymlinksInPath(); self.config = config?.resolvingSymlinksInPath(); self.files = preparedRoot==self.root ? files:files.map { $0.resolvingSymlinksInPath() }
        rasterCache.clear()
        if !keepResources {
            imageCache.clear();imageTimelines.removeAll();tileReadCount=0
            fontFiles=self.files.filter{["ttf","otf","ttc"].contains($0.pathExtension.lowercased())};fontLookup=[:];fontLookupCount=0
            tiles.removeAll()
        } else {
            // Cropped pixels remain valid when only text changes. TIL drafts
            // are metadata and must be refreshed without decoding the atlas.
            for file in Set(previousDrafts.keys).union(drafts.keys) where previousDrafts[file] != drafts[file] {
                tiles.removeValue(forKey: file)
            }
        }
        styles.removeAll(); offsets.removeAll(); sections.removeAll();styleFile=nil;effectiveSections=[];panelSection=nil;resolved=[:];unresolved=[];warnings=[]
        guard let root = self.root, let config = self.config else { hasStyles = false; return }
        let files = self.files
        var dir = config.deletingLastPathComponent()
        var defaults: [Section] = []
        while dir.path.split(separator: "/").starts(with: root.path.split(separator: "/")) {
            if defaults.isEmpty,let file=files.first(where:{$0.path.lowercased()==dir.appendingPathComponent("gen.ini").path.lowercased()}), let gen = draftRead(file) { defaults = parsedRead(file) }
            if styles.isEmpty,let file=files.first(where:{$0.path.lowercased()==dir.appendingPathComponent("res/default.css").path.lowercased()}),let css = draftRead(file) {
                styleFile=file
                for s in parsedRead(file) { styles[s.name] = s }
            }
            if dir.path.split(separator: "/") == root.path.split(separator: "/") { break }; dir.deleteLastPathComponent()
        }
        if styles.isEmpty, let css = files.first(where: { $0.lastPathComponent.lowercased() == "default.css" }) {
            styleFile=css
            for s in parsedRead(css) { styles[s.name] = s }
        }
        effectiveSections=SkinConfiguration.effective(draftSections[config] ?? SkinStore.parse(text),defaults:defaults)
        if !cndIconChoice.isEmpty && !CndPreview.iconNames(effectiveSections).contains(cndIconChoice) { cndIconChoice = "" }
        for s in defaults + effectiveSections {
            if s.name.hasPrefix("OFFSET") { offsets[s.name] = s }
            var merged = sections[s.name] ?? Section(name: s.name)
            merged.values.merge(s.values) { _, new in new }
            sections[s.name] = merged
        }
        panelSection=effectiveSections.first{$0.name=="PANEL"} ?? defaults.first{$0.name=="PANEL"}
        hasStyles = !styles.isEmpty
        let previousHybrid = keepResources ? hybrid : nil
        hybrid=nil
        if files.contains(where:{$0.deletingLastPathComponent()==config.deletingLastPathComponent() && ["appearanceConfig","appearanceConfig.json"].contains($0.lastPathComponent)}) {
            let same=files.filter{!$0.lastPathComponent.contains("Config") || $0.deletingLastPathComponent()==config.deletingLastPathComponent()}
            let engine=previousHybrid ?? BdaPreviewEngine(root:root,files:same)
            if previousHybrid == nil {
                engine.prepareConfigurations(preparedConfigurations,errors:preparedConfigurationErrors)
                engine.load(color:config.path.lowercased().contains("/dark/") ? "dark":"light",orientation:config.path.lowercased().contains("/land/") ? "land":"port")
            }
            let name=config.deletingPathExtension().lastPathComponent
            engine.panelID=engine.panels[name] != nil ? name:"py_26"
            if engine.panel != nil{hybrid=engine;hasStyles=true}
        }
        candidateFile=nil;candidateSize = .zero;candidateSections=[]
        let candidateSource=effectiveSections.contains{$0.name=="CAND"} ? effectiveSections:defaults
        let candidates=candidateSource.filter{$0.name=="CAND" && !($0.values["LAYOUT_NAME"] ?? "").isEmpty}
        candidateNames=Array(Set(candidates.compactMap{$0.values["LAYOUT_NAME"]})).sorted()
        if config.pathExtension.lowercased()=="ini",let spec=candidates.first(where:{$0.values["LAYOUT_NAME"]==candidateChoice}) ?? candidates.first {
            let r=SkinStore.numbers(spec.values["VIEW_RECT"])
            if r.count==4,r[2]>0,r[3]>0,let file=resolve((spec.values["LAYOUT_NAME"] ?? "")+".cnd"),let raw=draftRead(file){candidateFile=file;candidateSize=CGSize(width:r[2],height:r[3]);candidateSections=parsedRead(file)}
        }
        if config.pathExtension.lowercased()=="cnd",let spec=defaults.first(where:{$0.name=="CAND" && $0.values["LAYOUT_NAME"]==config.deletingPathExtension().lastPathComponent}) {
            let r=SkinStore.numbers(spec.values["VIEW_RECT"]);if r.count==4,r[2]>0,r[3]>0{candidateSize=CGSize(width:r[2],height:r[3])}
        }
        timeline.definitions=[:];animationFiles=[:]
        let context=SkinConfiguration.relative(config.deletingLastPathComponent(),root:root)+"/"
        var ranks:[String:Int]=[:]
        for file in files.filter({["ini","css","anim","ani"].contains($0.pathExtension.lowercased())}).sorted(by:{$0.path<$1.path}) {
            guard let raw=draftRead(file),raw.uppercased().contains("[ANIM") else{continue}
            for section in parsedRead(file) where section.name.range(of:"^ANIM[0-9]+$",options:.regularExpression) != nil {
                let id=String(section.name.dropFirst(4)),rank=SkinConfiguration.score(SkinConfiguration.relative(file,root:root),context:context)
                if rank >= ranks[id,default:Int.min]{timeline.definitions[id]=section.values;animationFiles[id]=file;ranks[id]=rank}
            }
        }
        for (id,definition) in timeline.definitions where definition["DURATION"]==nil && !(definition["ANIM_PATH"] ?? "").isEmpty {
            if let file=resolve(definition["ANIM_PATH"] ?? "",from:animationFiles[id]),let image=ImageTimeline(file),image.delays.count>1 {
                imageTimelines[file]=image;timeline.definitions[id]?["DURATION"]=String(Int(image.duration))
            }
        }
        configureFloating()
    }
    func configureFloating() {
        floatingAnimations=[];floatingDelay=0
        floatingLevel=Int(IniTimeline.number(panelSection?.values["ANIM_LEVEL"],1))
        func add(_ id:String,_ seen:Set<String>) {
            guard !id.isEmpty,!seen.contains(id),seen.count<=16,let definition=timeline.definitions[id] else{return}
            if !floatingAnimations.contains(id){floatingAnimations.append(id)}
            for child in (definition["BUILD_LIST"] ?? "").components(separatedBy:","){add(child.trimmingCharacters(in:.whitespaces),seen.union([id]))}
        }
        if !floatingChoice.isEmpty{add(floatingChoice,[]);return}
        guard let style=styles["STYLE"+(panelSection?.values["ANIM_STYLE"] ?? "").trimmingCharacters(in:.whitespaces)] else{return}
        add(style.values["SHOW_ANIM"]?.trimmingCharacters(in:.whitespaces) ?? "",[])
        let events=styleFile.flatMap{css in files.first{$0.path.lowercased()==css.deletingLastPathComponent().appendingPathComponent("event.ini").path.lowercased()}}
        let definitions=events.map{parsedRead($0)} ?? []
        for (key,id) in style.values where key.range(of:"^EVENT[0-9]+$",options:.regularExpression) != nil {
            if let event=definitions.first(where:{$0.name==key}),event.values["NAME"]?.uppercased()=="IDLE" {
                floatingDelay=max(floatingDelay,IniTimeline.number(event.values["IDLE_TIME"]))
                add(id.trimmingCharacters(in:.whitespaces),[])
            }else{warnings.insert(key+" 未识别为空闲事件，未自动触发")}
        }
    }
    func resolve(_ name: String,from source:URL?=nil) -> URL? {
        guard let root, let config else { return nil }
        let key=(source ?? config).path+"\n"+name
        if let file=resolved[key]{return file};if unresolved.contains(key){return nil}
        if let file=SkinConfiguration.resolve(name,root:root,config:source ?? config,files:files){resolved[key]=file;return file}
        unresolved.insert(key);warnings.insert("缺少资源："+name);return nil
    }
    private func tileSections(_ file:URL)->[Section] {
        if let cached=tiles[file] {return cached}
        tileReadCount += 1
        let parsed=parsedRead(file)
        tiles[file]=parsed
        return parsed
    }
    func refreshPlan(mode:String,ios:Bool)->PreviewRefreshPlan {
        var plan=PreviewRefreshPlan.idle
        if mode == "floating",floatingPausedAt == nil {
            for id in floatingAnimations {
                guard let d=timeline.definitions[id],d["CATEGORY"]?.trimmingCharacters(in:.whitespacesAndNewlines)=="3" else{continue}
                let duration=ParticleTimeline(config:d,ios:ios,seed:0).playbackDuration
                if let duration {
                    if duration>0 {plan.include(.until(floatingStart.addingTimeInterval((floatingDelay+duration)/1000)))}
                } else {plan.include(.repeating)}
            }
        }
        if animationEnabled,let section=sections[animationKey] {
            let layers=[-2,-1]+Array(0..<(section.values["FORE_ANIM_STYLE"] ?? "").components(separatedBy:",").count)
            for layer in layers {
                let duration=timeline.duration(animationID(section,layer))
                if duration>0 {plan.include(.until(animationStart.addingTimeInterval(duration/1000)))}
            }
        }
        return plan
    }
    private func drawImage(_ reference: String, rect: CGRect, context: inout GraphicsContext) -> Bool {
        let parts = reference.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
        guard parts.count == 2, let til = resolve(parts[0] + ".til"), let png = imageResource(parts[0]) else {
            let base = parts.first ?? ""
            if let fallback=imageResource(base), let image=imageCache.image(fallback) { context.draw(Image(decorative:image,scale:1),in:rect); return true }
            return false
        }
        guard let tile = tileSections(til).first(where: { $0.name == "IMG" + parts[1] }) else { return false }
        let r = SkinStore.numbers(tile.values["SOURCE_RECT"])
        guard r.count == 4, r[2] > 0, r[3] > 0 else { return false }
        guard let image = imageCache.image(png), image.width * image.height <= 8_000_000 else { return false }
        let source = CGRect(x: r[0], y: r[1], width: r[2], height: r[3])
        guard CGRect(x: 0,y: 0,width: image.width,height: image.height).contains(source) else { return false }
        func draw(_ src: CGRect, _ dst: CGRect) {
            guard src.width > 0, src.height > 0, dst.width > 0, dst.height > 0, let crop = imageCache.crop(image, rect: src) else { return }
            context.draw(Image(decorative: crop, scale: 1), in: dst)
        }
        let inner = SkinStore.numbers(tile.values["INNER_RECT"])
        if inner.count == 4, inner[2] > 0, inner[3] > 0, source.contains(CGRect(x: inner[0],y: inner[1],width: inner[2],height: inner[3])) {
            let left = inner[0]-r[0], right = source.maxX-inner[0]-inner[2]
            let top = inner[1]-r[1], bottom = source.maxY-inner[1]-inner[3]
            let fx = min(1,rect.width/max(1,left+right)), fy = min(1,rect.height/max(1,top+bottom))
            let xs = [r[0],inner[0],inner[0]+inner[2],source.maxX], ys = [r[1],inner[1],inner[1]+inner[3],source.maxY]
            let xd = [rect.minX,rect.minX+left*fx,rect.maxX-right*fx,rect.maxX], yd = [rect.minY,rect.minY+top*fy,rect.maxY-bottom*fy,rect.maxY]
            for y in 0..<3 { for x in 0..<3 {
                draw(CGRect(x:xs[x],y:ys[y],width:xs[x+1]-xs[x],height:ys[y+1]-ys[y]),CGRect(x:xd[x],y:yd[y],width:xd[x+1]-xd[x],height:yd[y+1]-yd[y]))
            }}
        } else {
            let w = min(rect.width,r[2]), h = min(rect.height,r[3])
            draw(source,CGRect(x:rect.midX-w/2,y:rect.midY-h/2,width:w,height:h))
        }
        return true
    }
    private func imageResource(_ base: String) -> URL? {
        let value = base.trimmingCharacters(in: .whitespacesAndNewlines)
        let known = Set(["png", "jpg", "jpeg", "webp", "gif", "apng"])
        let ext = URL(fileURLWithPath: value).pathExtension.lowercased()
        if known.contains(ext), let u = resolve(value) { return u }
        for suffix in ["png", "jpg", "jpeg", "webp", "gif", "apng"] {
            if let u = resolve(value + "." + suffix) { return u }
        }
        return nil
    }
    private func color(_ value: String?, fallback: Color) -> Color {
        guard let value else { return fallback }
        let hex = value.replacingOccurrences(of:"#",with:"").replacingOccurrences(of:"0x",with:"")
        guard let n = UInt64(hex,radix:16) else { return fallback }
        return Color(.sRGB,red:Double((n>>16)&255)/255,green:Double((n>>8)&255)/255,blue:Double(n&255)/255,opacity:hex.count<=6 ? 1 : Double((n>>24)&255)/255)
    }
    private func font(_ name: String, size: CGFloat) -> Font {
        let lookup=name.lowercased()
        if let cached=fontLookup[lookup]{return cached.isEmpty ? .system(size:size):.custom(cached,fixedSize:size)}
        fontLookupCount += 1
        let exact = name.isEmpty ? nil : resolve(name)
        let selected = exact ?? fontFiles.filter {
            name.isEmpty || $0.lastPathComponent.lowercased()==lookup || $0.deletingPathExtension().lastPathComponent.lowercased()==lookup
        }.sorted {
            let context=config?.deletingLastPathComponent().path ?? ""
            let a=$0.path.hasPrefix(context+"/"),b=$1.path.hasPrefix(context+"/")
            return a==b ? $0.path<$1.path:a
        }.first
        if let url=selected,fonts[url]==nil {
            CTFontManagerRegisterFontsForURL(url as CFURL,.process,nil)
            if let descriptors=CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor],let descriptor=descriptors.first {
                fonts[url]=CTFontCopyPostScriptName(CTFontCreateWithFontDescriptor(descriptor,size,nil)) as String
            }
        }
        let postscript=selected.flatMap{fonts[$0]} ?? "";fontLookup[lookup]=postscript
        return postscript.isEmpty ? .system(size:size):.custom(postscript,fixedSize:size)
    }
    private func style(_ id: String, rect: CGRect, front: Bool, pressed: Bool, fallback: String, context: inout GraphicsContext) {
        guard let st = styles["STYLE" + id.trimmingCharacters(in: .whitespaces)]?.values else { return }
        let img = st[pressed ? "HL_IMG" : "NM_IMG"] ?? st["NM_IMG"] ?? ""
        if !img.isEmpty, drawImage(img,rect:rect,context:&context) { return }
        let imageLayer = !(st["NM_IMG"] ?? "").isEmpty || !(st["HL_IMG"] ?? "").isEmpty
        let textLayer = st["FONT_SIZE"] != nil || st["FONT_NAME"] != nil
        let label = PreviewLabels.caption(st["SHOW"] ?? (front && !imageLayer && textLayer ? fallback : ""))
        if imageLayer && label.isEmpty { return }
        let ink = color(st[pressed ? "HL_COLOR" : "NM_COLOR"] ?? st["NM_COLOR"],fallback:front ? .black : .white)
        if front || !label.isEmpty {
            let size = Double(st["FONT_SIZE"] ?? "42") ?? 42
            context.draw(Text(label).font(font(st["FONT_NAME"] ?? st["FONT_FILE"] ?? "", size: CGFloat(max(1,min(500,size))))).foregroundColor(ink),at:CGPoint(x:rect.midX,y:rect.midY))
        } else { context.fill(Path(rect),with:.color(ink)) }
    }
    private func foreground(_ s: Section, rect: CGRect, pressed: Bool, fallback: String, context: inout GraphicsContext) {
        let ids = (s.values["FORE_STYLE"] ?? "").split(separator:",",omittingEmptySubsequences:false)
        let positions = (s.values["POS_TYPE"] ?? "").split(separator:",",omittingEmptySubsequences:false)
        for (i,id) in ids.enumerated() {
            var layer=context;if !animationEnabled{layer.clip(to:Path(rect))}
            var target = rect
            if i < positions.count {
                let offset = SkinStore.numbers(offsets["OFFSET" + positions[i].trimmingCharacters(in:.whitespaces)]?.values["POS"])
                if offset.count == 2 { target = target.offsetBy(dx:offset[0],dy:offset[1]) }
            }
            let frame=animationFrame(s,i)
            target=apply(frame,rect:target,context:&layer)
            style(String(id),rect:target,front:true,pressed:pressed,fallback:fallback,context:&layer)
            drawFrames(frame,rect:target,context:&layer)
        }
    }
    func background(size: CGSize, context: inout GraphicsContext) {
        if let hybrid,let p=hybrid.panel {
            let data: [String: Any] = isCnd ? ["backStyle":BdaPreviewEngine.object(p.data["cand"])["candBarStyle"] ?? [:]] : ["backStyle":p.data["backStyle"] ?? [:],"wholeBackStyle":p.data["wholeBackStyle"] ?? [:]]
            hybrid.drawHybrid(data,rect:CGRect(origin:.zero,size:size),pressed:false,context:&context);return
        }
        guard let panel = isCnd ? effectiveSections.first(where: { $0.name == "CAND" }) : panelSection else { return }
        let rect = CGRect(origin:.zero,size:size)
        if let id = panel.values["BACK_STYLE"] { style(id,rect:rect,front:false,pressed:false,fallback:"",context:&context) }
        if panel.values["FORE_STYLE"] != nil { foreground(panel,rect:rect,pressed:false,fallback:"",context:&context) }
    }
    func candidate(pressed:Bool=false,context:inout GraphicsContext) {
        guard candidateFile != nil else{return}
        var c=context;c.translateBy(x:0,y:-candidateSize.height)
        let area=CGRect(origin:.zero,size:candidateSize);c.clip(to:Path(area))
        if let hybrid,let panel=hybrid.panel{hybrid.drawHybrid(["backStyle":BdaPreviewEngine.object(panel.data["cand"])["candBarStyle"] ?? [:]],rect:area,pressed:false,context:&c)}
        if let bg=candidateSections.first(where:{$0.name=="CAND"})?.values["BACK_STYLE"]{style(bg,rect:area,front:false,pressed:false,fallback:"",context:&c)}
        for s in candidateSections where s.name.hasPrefix("ICON") {
            guard visible(s),let rect=IniGeometry.bounds(s,panel:candidateSize) else{continue}
            if let hybrid,let data=hybridKey(s){hybrid.drawHybrid(data,rect:rect,pressed:pressed,context:&c);continue}
            if let id=s.values["BACK_STYLE"]{style(id,rect:rect,front:false,pressed:pressed,fallback:"",context:&c)}
            foreground(s,rect:rect,pressed:pressed,fallback:"",context:&c)
        }
    }
    func previewBounds(panel:CGSize,keys:[KeyShape])->CGRect {
        var bounds=CGRect(origin:.zero,size:panel)
        for key in keys {
            bounds=bounds.union(key.rect)
            if let hybrid,effectiveSections.indices.contains(key.id),let data=hybridKey(effectiveSections[key.id]) {
                bounds=bounds.union(hybrid.contentBounds(data,rect:key.rect))
            }
        }
        if candidateFile != nil {
            bounds=bounds.union(CGRect(x:0,y:-candidateSize.height,width:candidateSize.width,height:candidateSize.height))
        }
        return bounds
    }
    // The editor and regression checks use the same cached composition, including
    // the candidate bar above the keyboard and the current candidate state.
    func drawPreview(panel:CGSize,keys:[KeyShape],pressed:Bool,scale:CGFloat,rasterScale:CGFloat,floatingEnabled:Bool=false,ios:Bool=false,context:inout GraphicsContext) {
        let prefix="ini:\(pressed):\(animationEnabled):\(candidateFile?.path ?? ""):\(hasCandidates):\(cndIconChoice):"
        var commands=[PreviewDrawCommand(id:prefix+"background"){layer in
            self.background(size:panel,context:&layer)
            self.candidate(pressed:pressed,context:&layer)
        }]
        if floatingEnabled,floatingLevel<=0 {
            commands.append(PreviewDrawCommand(id:"particles",dynamic:true){layer in self.floating(size:panel,ios:ios,context:&layer)})
        }
        for key in keys {
            commands.append(PreviewDrawCommand(id:prefix+key.name,dynamic:animationEnabled && animationKey==key.name){layer in
                if self.hasStyles { self.key(key,pressed:pressed,context:&layer) }
                else {
                    layer.stroke(Path(roundedRect:key.rect,cornerRadius:5),with:.color(.gray),lineWidth:1/max(scale,0.01))
                    layer.draw(Text(key.caption).font(.system(size:min(36,key.rect.height*0.3))).foregroundColor(.black),at:CGPoint(x:key.rect.midX,y:key.rect.midY))
                }
            })
        }
        rasterCache.draw(commands,bounds:previewBounds(panel:panel,keys:keys),scale:rasterScale,context:&context)
        if floatingEnabled,floatingLevel>0 { floating(size:panel,ios:ios,context:&context) }
    }
    func key(_ key: KeyShape, pressed: Bool, context: inout GraphicsContext) {
        guard let s = effectiveSections.indices.contains(key.id) ? effectiveSections[key.id]:sections[key.name] else { return }
        var whole=context
        let all=animationFrame(s,-2),rect=apply(all,rect:key.rect,context:&whole)
        if let hybrid,let data=hybridKey(s){
            hybrid.drawHybrid(data,rect:rect,pressed:pressed || (all.running && animationEvent=="PRESS_ANIM"),context:&whole)
            drawFrames(all,rect:rect,context:&whole)
            if (s.values["ANIM_STYLE"] ?? "").isEmpty && (s.values["BACK_ANIM_STYLE"] != nil || s.values["FORE_ANIM_STYLE"] != nil){warnings.insert("R1 混合外观的分层动画映射尚未确认，请使用整体 ANIM_STYLE 预览")}
            return
        }
        var back=whole
        let bg=animationFrame(s,-1),backRect=apply(bg,rect:rect,context:&back)
        let playing=all.running || bg.running || (0..<(s.values["FORE_STYLE"] ?? "").components(separatedBy:",").count).contains{animationFrame(s,$0).running}
        let pressed=pressed || (playing && animationEvent=="PRESS_ANIM")
        if let id = s.values["BACK_STYLE"] { style(id,rect:backRect,front:false,pressed:pressed,fallback:"",context:&back) }
        drawFrames(bg,rect:backRect,context:&back)
        let cells=IniGeometry.cells(s,bounds:rect)
        if cells.isEmpty{foreground(s,rect:rect,pressed:pressed,fallback:key.caption,context:&whole)}
        else {
            let labels=(s.values["NAMES"] ?? "").split(whereSeparator:{$0.isWhitespace}).map{String($0)}
            for (index,cell) in cells.enumerated() where !cell.content.isNull && cell.content.width>0 && cell.content.height>0 {
                var layer=whole;layer.clip(to:Path(cell.content))
                if let id=s.values["CELL_STYLE"]{style(id,rect:cell.cell,front:false,pressed:pressed,fallback:"",context:&layer)}
                foreground(s,rect:cell.content,pressed:pressed,fallback:index<labels.count ? labels[index]:"",context:&layer)
            }
        }
        drawFrames(all,rect:rect,context:&whole)
    }
    private func hybridKey(_ section:Section)->[String:Any]? {
        guard let p=hybrid?.panel else{return nil}
        let action=(section.values["CENTER"] ?? section.values["KEY"] ?? "").trimmingCharacters(in:.whitespaces)
        guard !action.isEmpty else{return nil}
        let icon=section.name.hasPrefix("ICON")
        let keys=BdaPreviewEngine.object(icon ? BdaPreviewEngine.object(p.data["cand"])["candKeys"]:p.data["keys"]),prefix=icon ? "CAND_":"KEY_"
        let d=BdaPreviewEngine.object(keys[prefix+action] ?? keys[prefix+action.uppercased()]);return d.isEmpty ? nil:d
    }
    func boundAnimations(_ key:String)->[String] {
        guard let s=sections[key] else{return []};var ids:[String]=[]
        func add(_ id:String,_ seen:Set<String>) {
            guard !id.isEmpty,!seen.contains(id),seen.count<17 else{return}
            if !ids.contains(id){ids.append(id)}
            for child in (timeline.definitions[id]?["BUILD_LIST"] ?? "").components(separatedBy:","){add(child.trimmingCharacters(in:.whitespaces),seen.union([id]))}
        }
        for layer in -2..<(s.values["FORE_ANIM_STYLE"] ?? "").components(separatedBy:",").count {add(animationID(s,layer),[])}
        return ids
    }
    private func animationID(_ section:Section,_ layer:Int)->String {
        let whole=section.values["ANIM_STYLE"] ?? ""
        let refs=(section.values["FORE_ANIM_STYLE"] ?? "").components(separatedBy:",")
        let ref=layer == -2 ? whole:(!whole.isEmpty ? "":(layer == -1 ? section.values["BACK_ANIM_STYLE"] ?? "":(layer<refs.count ? refs[layer]:"")))
        return styles["STYLE"+ref.trimmingCharacters(in:.whitespaces)]?.values[animationEvent]?.trimmingCharacters(in:.whitespaces) ?? ""
    }
    private func animationFrame(_ s:Section,_ layer:Int)->IniTimeline.Frame {
        guard animationEnabled,s.name==animationKey else{return .init()}
        return timeline.sample(animationID(s,layer),Date().timeIntervalSince(animationStart)*1000)
    }
    private func apply(_ frame:IniTimeline.Frame,rect:CGRect,context:inout GraphicsContext)->CGRect {
        var r=rect
        for op in frame.operations {
            let px=r.minX+(op.pixelPivot ? op.pivot[0]:r.width*op.pivot[0]/100),py=r.minY+(op.pixelPivot ? op.pivot[1]:r.height*op.pivot[1]/100)
            switch op.type {
            case 0:context.opacity *= min(1,max(0,op.value[0]/255))
            case 1:context.translateBy(x:px,y:py);context.rotate(by:.degrees(op.value[0]));context.translateBy(x:-px,y:-py)
            case 2:context.translateBy(x:op.value[0],y:op.value[1])
            case 3:let sx=max(0.001,op.value[0]/100),sy=max(0.001,op.value[1]/100);r=CGRect(x:px+(r.minX-px)*sx,y:py+(r.minY-py)*sy,width:r.width*sx,height:r.height*sy)
            case 4:context.translateBy(x:px,y:py);context.scaleBy(x:op.value[0]/100,y:op.value[1]/100);context.translateBy(x:-px,y:-py)
            case 5:
                let values=AnimationProjection.matrix(op.value,pivot:[px,py])
                var matrix=ProjectionTransform()
                matrix.m11=values[0];matrix.m21=values[1];matrix.m31=values[2]
                matrix.m12=values[3];matrix.m22=values[4];matrix.m32=values[5]
                matrix.m13=values[6];matrix.m23=values[7];matrix.m33=values[8]
                context.addFilter(.projectionTransform(matrix))
            case 6:
                var matrix=ColorMatrix()
                matrix.r1=0;matrix.g2=0;matrix.b3=0
                matrix.r5=Float((op.tint>>16)&255)/255;matrix.g5=Float((op.tint>>8)&255)/255;matrix.b5=Float(op.tint&255)/255;matrix.a4=Float((op.tint>>24)&255)/255
                context.addFilter(.colorMatrix(matrix))
            default:break
            }
        }
        return r
    }
    private func drawFrames(_ frame:IniTimeline.Frame,rect:CGRect,context:inout GraphicsContext) {
        var drawn=Set<String>()
        for op in frame.operations where !op.path.isEmpty {
            guard let file=resolve(op.path,from:animationFiles[op.id]),drawn.insert(file.path).inserted else{continue}
            if imageTimelines[file]==nil{imageTimelines[file]=ImageTimeline(file)}
            guard let timeline=imageTimelines[file] else{continue}
            let index=timeline.index(time:op.time,duration:op.duration)
            guard let raw=imageCache.image(file,index:index),raw.width*raw.height<=8_000_000 else{continue}
            let til=file.deletingPathExtension().appendingPathExtension("til")
            var image=raw
            if let first=tileSections(til).filter({$0.name.hasPrefix("IMG")}).sorted(by:{(Int($0.name.dropFirst(3)) ?? 0)<(Int($1.name.dropFirst(3)) ?? 0)}).first {
                let r=SkinStore.numbers(first.values["SOURCE_RECT"])
                guard r.count==4,r[2]>0,r[3]>0,CGRect(x:0,y:0,width:raw.width,height:raw.height).contains(CGRect(x:r[0],y:r[1],width:r[2],height:r[3])),let crop=imageCache.crop(raw,rect:CGRect(x:r[0],y:r[1],width:r[2],height:r[3])) else{warnings.insert("动效切片超出图片："+op.path);continue};image=crop
            }
            let w=CGFloat(image.width),h=CGFloat(image.height)
            context.draw(Image(decorative:image,scale:1),in:CGRect(x:rect.midX-w/2,y:rect.midY-h/2,width:w,height:h))
        }
    }
}
