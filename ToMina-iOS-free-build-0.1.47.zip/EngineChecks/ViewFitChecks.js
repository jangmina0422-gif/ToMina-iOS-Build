'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const V=require('./ViewFit.js');let count=0;
const test=(name,body)=>{body();count++;console.log('PASS '+name);};
const key=(n,r,extras='')=>`[KEY${n}]\nVIEW_RECT=${r}\nCENTER=${n===4?'F38':'letter'+n}\nUP=上滑\nHOLD=F72\nFORE_ANIM_STYLE=905,905\n${extras}\n`;
const panel=(rows,w=200,h=100)=>`[PANEL]\nSIZE=${w},${h}\nKEY_NUM=1\n${rows}`;
const plain=()=>({files:{'custom.ini':panel(key(1,'0,0,98,48')+key(8,'102,0,98,48')+key(12,'0,52,58,48')+key(19,'62,52,138,48'))},images:{}});
const run=i=>V.run(JSON.parse(JSON.stringify(i)));
function apply(input,result){const out=JSON.parse(JSON.stringify(input));result.edits.forEach(e=>out.files[e.path]=e.text);return out;}
const sections=(input,file)=>V.parse(input.files[file]).sections;
const field=(input,file,name,k)=>sections(input,file).find(s=>s.name===name).values[k];
test('actual sparse KEY sections, stagger, wide space and both axes',()=>{
 const i=plain(),r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(r.reports[0].changedKeys,4);
 assert.equal(field(out,'custom.ini','KEY1','VIEW_RECT'),'0,0,100,50');assert.equal(field(out,'custom.ini','KEY8','VIEW_RECT'),'100,0,100,50');
 assert.equal(field(out,'custom.ini','KEY12','VIEW_RECT'),'0,50,60,50');assert.equal(field(out,'custom.ini','KEY19','VIEW_RECT'),'60,50,140,50');
 assert.equal(field(out,'custom.ini','PANEL','KEY_NUM'),'1');
 for(const s of sections(i,'custom.ini').filter(s=>s.name.startsWith('KEY')))for(const f of ['CENTER','UP','HOLD','FORE_ANIM_STYLE'])assert.equal(field(out,'custom.ini',s.name,f),s.values[f]);
});
test('implicit touches frozen; inherited and zero touches preserved',()=>{
 const i=plain();i.files['custom.ini']=i.files['custom.ini'].replace('CENTER=letter8','TOUCH_RECT=0,0,0,0\nCENTER=letter8');i.files['gen.ini']='[KEY12]\nTOUCH_RECT=3,4,5,6';
 const out=apply(i,run(i));assert.equal(field(out,'custom.ini','KEY1','TOUCH_RECT'),'0,0,98,48');assert.equal(field(out,'custom.ini','KEY8','TOUCH_RECT'),'0,0,0,0');assert.equal(field(out,'custom.ini','KEY12','TOUCH_RECT'),undefined);assert.equal(out.files['gen.ini'],i.files['gen.ini']);
});
test('idempotent: second run has no edits',()=>{const i=plain(),out=apply(i,run(i));assert.equal(run(out).edits.length,0);});
test('recursive arbitrary languages, themes and per-panel inherited size',()=>{
 const i={files:{},images:{}};
 for(const prefix of ['port','land','light/nested','dark/custom','another_language']){const w=prefix==='land'?400:200;i.files[prefix+'/gen.ini']=`[PANEL]\nSIZE=${w},100`;i.files[prefix+'/Любой.INI']='[PANEL]\n'+key(1,`0,0,${w/2-2},100`)+key(2,`${w/2+2},0,${w/2-2},100`);}
 i.files['arbitrary-animation.ini']='[ANIM59]\nVIEW_RECT=1,2,3,4\nDURATION=200';i.files['arbitrary-event.ini']='[EVENT1]\nNAME=IDLE';const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,5);assert.equal(field(out,'land/Любой.INI','KEY1','VIEW_RECT'),'0,0,200,100');assert.equal(out.files['arbitrary-animation.ini'],i.files['arbitrary-animation.ini']);
});
test('vertical LIST joins shared edges while preserving internal padding',()=>{
 const i={files:{'x.ini':panel('[LIST]\nPOS=0,0\nCELL_SIZE=40,25\nLIST_NUM=4\nPADDING=3,2,3,2\n'+key(1,'44,0,76,100')+key(2,'124,0,76,100'))},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'42,0,80,100');assert.equal(field(out,'x.ini','LIST','PADDING'),'3,2,3,2');
});
test('horizontal LIST_ORDER uses width times count',()=>{
 const i={files:{'x.ini':panel('[LIST]\nPOS=0,0\nCELL_SIZE=50,20\nLIST_NUM=4\nLIST_ORDER=1\nPADDING=2,0,2,0\n'+key(1,'0,24,98,76')+key(2,'102,24,98,76'))},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'0,22,100,78');
});
test('handwriting and functional neighbours meet on shared edges',()=>{
 const i={files:{'x.ini':panel('[KEY1]\nVIEW_RECT=0,0,150,70\nCENTER=F53\n'+key(2,'154,0,46,70')+key(3,'0,74,148,26')+key(4,'152,74,48,26'))},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'0,0,152,72');assert.equal(field(out,'x.ini','KEY1','TOUCH_RECT'),'0,0,150,70');
 assert.equal(field(out,'x.ini','KEY3','VIEW_RECT'),'0,72,150,28');assert.equal(run(out).edits.length,0);
});
test('background, intentional conditional overlay and filler preservation',()=>{
 const i=plain();i.files['custom.ini']+='[KEY99]\nVIEW_RECT=0,0,200,100\nSTAT_STYLE=S0\nBACK_STYLE=0\n';const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'custom.ini','KEY99','VIEW_RECT'),'0,0,200,100');
 const f={files:{'f.ini':panel(key(1,'20,0,78,100')+key(2,'102,0,78,100')+'[KEY3]\nVIEW_RECT=0,0,20,100\n[KEY4]\nVIEW_RECT=180,0,20,100\n')},images:{}};assert.equal(run(f).summary.processed,1);
});
test('candidate composite is not covered by ordinary keys',()=>{
 const i={files:{'x.ini':panel('[KEY1]\nVIEW_RECT=0,0,200,60\n[KEY2]\nVIEW_RECT=0,0,200,60\nCENTER=F55\n'+key(3,'0,64,98,36')+key(4,'102,64,98,36'))},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'0,0,200,60');assert.equal(field(out,'x.ini','KEY2','VIEW_RECT'),'0,0,200,60');assert.equal(field(out,'x.ini','KEY3','VIEW_RECT'),'0,60,100,40');
});
test('subpixel and one-pixel overlaps share one integer seam',()=>{
 const i={files:{'x.ini':panel(key(1,'0,0,100.4,100')+key(2,'99.7,0,100.3,100'))},images:{}};const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'0,0,100,100');assert.equal(field(out,'x.ini','KEY2','VIEW_RECT'),'100,0,100,100');
});
test('invalid dimensions, duplicate keys, malformed touches, huge gaps are uncertain',()=>{
 for(const text of ['[KEY1]\nVIEW_RECT=0,0,20,20\nCENTER=A',panel(key(1,'0,0,98,100')+key(1,'102,0,98,100')),panel(key(1,'0,0,98,100','TOUCH_RECT=broken')+key(2,'102,0,98,100')),panel(key(1,'0,0,20,100')+key(2,'180,0,20,100'))]){const r=run({files:{'bad.ini':text},images:{}});assert.equal(r.summary.uncertain,1);assert.equal(r.edits.length,0);}
});
test('substantial functional overlaps not flattened',()=>{const r=run({files:{'bad.ini':panel(key(1,'0,0,120,100')+key(2,'80,0,120,100'))},images:{}});assert.equal(r.summary.uncertain,1);assert.equal(r.edits.length,0);});
test('mixed binary appearance blocks false success',()=>{const i=plain();i.inventory=['appearanceConfig'];assert.equal(run(i).summary.uncertain,1);});
function atlas(){
 const i={files:{},images:{'res/paper.png':[100,100],'res/pressed.png':[100,100]}};
 i.files['res/default.css']='[GLOBAL]\nSTYLE_NUM=4\n';let tile='[GLOBAL]\nTILE_NUM=4\n';
 let rows='';for(let j=0;j<4;j++){const x=j%2,y=Math.floor(j/2);rows+=key(j+1,`${x*102},${y*52},98,48`,`BACK_STYLE=${j+1}`);i.files['res/default.css']+=`[STYLE${j+1}]\nNM_IMG=paper,${j+1}\nHL_IMG=pressed,${j+1}\nPRESS_ANIM=51\n`;tile+=`[IMG${j+1}]\nSOURCE_RECT=${x*50},${y*50},50,50\n`;}
 i.files['res/paper.til']=tile;i.files['res/pressed.til']=tile;i.files['port/different_name.ini']=panel(rows);i.files['land/different_name.ini']=panel(rows.replace(/VIEW_RECT=(\d+),(\d+),(\d+),(\d+)/g,(_,x,y,w,h)=>`VIEW_RECT=${+x*2},${y},${+w*2},${h}`),400,100);return i;
}
test('layout fitting never changes CSS, TIL, images or source/display mapping',()=>{
 const i=atlas(),r=run(i),out=apply(i,r);assert.equal(r.summary.processed,2);assert.equal(field(out,'land/different_name.ini','KEY1','VIEW_RECT'),'0,0,200,50');
 for(const p of Object.keys(i.files).filter(p=>p.startsWith('res/')))assert.equal(out.files[p],i.files[p]);
 assert.ok(r.edits.every(e=>e.path.endsWith('.ini')));assert.equal(run(out).edits.length,0);
 for(const p of ['port/different_name.ini','land/different_name.ini'])for(let n=1;n<=4;n++)assert.equal(field(out,p,'KEY'+n,'BACK_STYLE'),String(n));
});
test('missing images do not block VIEW fitting or create image references',()=>{
 const i=atlas();i.images={};delete i.files['res/paper.til'];delete i.files['res/pressed.til'];delete i.files['res/default.css'];
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,2);assert.equal(r.summary.uncertain,0);assert.ok(r.edits.every(e=>e.path.endsWith('.ini')));
 assert.deepEqual(Object.keys(out.files),Object.keys(i.files));
});
test('invalid image slice metadata is unrelated to layout fitting',()=>{
 const i=atlas();i.files['res/paper.til']=i.files['res/paper.til'].replace('0,0,50,50','-2,0,52,50');
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,2);assert.equal(out.files['res/paper.til'],i.files['res/paper.til']);
});
test('state switch keeps actions and isolates VIEW overrides in a separate TIP',()=>{
 const i=atlas();i.files['port/different_name.ini']=i.files['port/different_name.ini'].replace('BACK_STYLE=1','BACK_STYLE=1\nSTAT_STYLE=S7_1')+'[TIP1]\nBACK_STYLE=1\nVIEW_RECT=0,0,98,48\nCENTER=F22\n';
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,2);assert.equal(field(out,'port/different_name.ini','KEY1','STAT_STYLE'),'S7_2');assert.equal(field(out,'port/different_name.ini','TIP2','CENTER'),'F22');assert.equal(field(out,'port/different_name.ini','TIP2','VIEW_RECT'),'0,0,100,50');assert.equal(field(out,'port/different_name.ini','TIP1','VIEW_RECT'),'0,0,98,48');assert.equal(run(out).edits.length,0);
});
test('ambiguous sibling image resources do not affect independent layouts',()=>{
 const i=atlas();i.images['light/paper.png']=i.images['res/paper.png'];i.images['dark/paper.png']=i.images['res/paper.png'];delete i.images['res/paper.png'];const r=run(i);assert.equal(r.summary.processed,2);assert.equal(r.summary.uncertain,0);
});
test('unknown source encoding and unreadable defaults explicitly reported',()=>{
 const i=plain();i.inventory=['gen.ini'];i.unreadable=[{path:'gen.ini',reason:'invalid encoding'}];const r=run(i);assert.equal(r.edits.length,0);assert.equal(r.summary.uncertain,2);
});
test('line endings, comments, duplicate CAND and actions retained',()=>{
 const i=plain();i.files['custom.ini']=('\uFEFF'+i.files['custom.ini']+'[CAND]\nTYPE=1\n[CAND]\nTYPE=2\n').replace('VIEW_RECT=0,0,98,48','VIEW_RECT=0,0,98,48 // Keep comment').replace(/\n/g,'\r\n');const out=apply(i,run(i)).files['custom.ini'];assert.ok(out.startsWith('\uFEFF'));assert.ok(out.includes('VIEW_RECT=0,0,100,50 // Keep comment\r\n'));assert.equal(V.parse(out).sections.filter(s=>s.name==='CAND').length,2);assert.equal(out.replace(/\r\n/g,'').includes('\n'),false);
});
test('path traversal rejected',()=>{assert.throws(()=>run({files:{'../evil.ini':'[KEY1]'},images:{}}));});
test('POS_TYPE zero preserves ASCII comma count, spacing, comments and actions',()=>{
 const i={operation:'zeroPositionTypes',files:{'dark/land/custom.ini':'[KEY99]\r\nPOS_TYPE=46 // comment\r\nCENTER=a\r\n[TIP2]\r\nPOS_TYPE=7, 3,-4,1.5\r\n'},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(out.files['dark/land/custom.ini'],'[KEY99]\r\nPOS_TYPE=0 // comment\r\nCENTER=a\r\n[TIP2]\r\nPOS_TYPE=0, 0,0,0\r\n');assert.equal(run(out).edits.length,0);
});
test('POS_TYPE zero checks all configurations without adding missing fields',()=>{
 const i={operation:'zeroPositionTypes',files:{'a.ini':'[KEY1]\nCENTER=q','b.cnd':'[ICON1]\nPOS_TYPE=3,2','c.pop':'[TIP1]\nPOS_TYPE=46','res/a.css':'[STYLE3]\nPOS_TYPE=1,1,1','d.ini':'[KEY2]\nPOS_TYPE=0,0'},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,3);assert.equal(r.summary.unchanged,2);assert.equal(out.files['a.ini'],i.files['a.ini']);
});
test('POS_TYPE malformed values keep the entire file and report a reason',()=>{
 for(const value of ['3，4','3,,4','abc','']){const i={operation:'zeroPositionTypes',files:{'x.ini':'[KEY1]\nPOS_TYPE=46\n[KEY2]\nPOS_TYPE='+value},images:{}};const r=run(i);assert.equal(r.summary.uncertain,1);assert.equal(r.edits.length,0);}
});
const insetRows=()=>({files:{'port/custom.ini':panel(key(1,'12,8,76,34')+key(2,'112,8,76,34')+key(3,'30,58,58,34')+key(4,'112,58,58,34'))}});
test('outer margins and staggered row ends reach their own panel bounds',()=>{
 const i=insetRows(),r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);
 assert.equal(field(out,'port/custom.ini','KEY1','VIEW_RECT'),'0,0,100,50');
 assert.equal(field(out,'port/custom.ini','KEY4','VIEW_RECT'),'100,50,100,50');
 assert.equal(field(out,'port/custom.ini','KEY3','TOUCH_RECT'),'30,58,58,34');
 assert.equal(run(out).edits.length,0);
});
test('list corner shares boundaries without abandoning nine-key panels',()=>{
 const i={files:{'custom.ini':panel('[LIST]\nPOS=10,8\nCELL_SIZE=40,34\nLIST_NUM=2\nPADDING=2,0,2,0\n'+key(1,'58,8,62,30')+key(2,'128,8,62,30')+key(3,'58,46,62,30')+key(4,'128,46,62,30')+key(5,'8,84,42,30')+key(6,'58,84,62,30')+key(7,'128,84,62,30'),200,120)}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);
 const boxes=sections(out,'custom.ini').filter(s=>s.name.startsWith('KEY')).map(s=>s.values.VIEW_RECT.split(',').map(Number));
 for(let n=0;n<boxes.length;n++)for(let m=n+1;m<boxes.length;m++){
  const a=boxes[n],b=boxes[m];assert.ok(Math.min(a[0]+a[2],b[0]+b[2])<=Math.max(a[0],b[0])||Math.min(a[1]+a[3],b[1]+b[3])<=Math.max(a[1],b[1]));
 }
 assert.equal(field(out,'custom.ini','LIST','POS'),'0,0');assert.equal(run(out).edits.length,0);
});
test('fixed candidate survives adjustable LIST and lower-row shared edge',()=>{
 const i={files:{'c.ini':panel('[LIST]\nPOS=8,6\nCELL_SIZE=40,32\nLIST_NUM=2\nPADDING=0\n[KEY1]\nVIEW_RECT=56,6,136,62\nCENTER=F55\n'+key(2,'8,78,84,34')+key(3,'108,78,84,34'),200,120)}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);
 assert.equal(field(out,'c.ini','KEY1','VIEW_RECT'),'56,6,136,62');
 assert.equal(field(out,'c.ini','KEY2','VIEW_RECT'),'0,68,100,52');assert.equal(field(out,'c.ini','LIST','CELL_SIZE'),'56,34');assert.equal(run(out).edits.length,0);
});
test('functional overlay inside handwriting is preserved while outside keys fit',()=>{
 const i={files:{'h.ini':panel('[KEY1]\nVIEW_RECT=0,0,200,60\nCENTER=F53\n[KEY2]\nVIEW_RECT=10,40,30,18\nCENTER=F78\n'+key(3,'8,68,84,24')+key(4,'108,68,84,24'))}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'h.ini','KEY2','VIEW_RECT'),'10,40,30,18');
 assert.equal(field(out,'h.ini','KEY3','VIEW_RECT'),'0,64,100,36');
});
test('horizontal expansion is included before discovering vertical neighbours',()=>{
 const i={files:{'m.ini':panel(key(1,'60,8,58,34')+key(2,'126,8,66,34')+key(3,'8,58,44,34')+key(4,'60,58,58,34')+key(5,'126,58,66,34'))}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'m.ini','KEY3','VIEW_RECT'),'0,50,56,50');assert.equal(run(out).edits.length,0);
});
test('old partially fitted coordinates get outer gaps closed on upgrade',()=>{
 const i={files:{'a.ini':panel(key(1,'15,12,85,38')+key(2,'100,12,85,38')+key(3,'35,50,65,38')+key(4,'100,50,65,38'))}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'a.ini','KEY1','VIEW_RECT'),'0,0,100,50');assert.equal(field(out,'a.ini','KEY4','VIEW_RECT'),'100,50,100,50');assert.equal(run(out).edits.length,0);
});
const listPanel=()=>({files:{'dark/port/letters.ini':panel('[LIST]\nPOS=8,6\nCELL_SIZE=36,22\nLIST_NUM=4\nPADDING=2,1,2,1\nNAMES=甲 乙\nVALUES=a b\nTYPE=0\n'+key(1,'52,6,140,88'))}});
test('LIST changes POS and CELL_SIZE in the actual source without inventing VIEW_RECT',()=>{
 const i=listPanel(),r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(r.reports[0].changedLists,1);
 assert.equal(field(out,'dark/port/letters.ini','LIST','POS'),'0,0');assert.equal(field(out,'dark/port/letters.ini','LIST','CELL_SIZE'),'48,25');
 assert.equal(field(out,'dark/port/letters.ini','LIST','VIEW_RECT'),undefined);
 for(const f of ['LIST_NUM','PADDING','NAMES','VALUES','TYPE'])assert.equal(field(out,'dark/port/letters.ini','LIST',f),field(i,'dark/port/letters.ini','LIST',f));
 assert.equal(field(out,'dark/port/letters.ini','KEY1','VIEW_RECT'),'48,0,152,100');assert.equal(field(out,'dark/port/letters.ini','KEY1','TOUCH_RECT'),'52,6,140,88');assert.equal(run(out).edits.length,0);
});
test('LIST-only panels and inherited numbered LIST geometry are included',()=>{
 const i={files:{'land/gen.ini':'[PANEL]\nSIZE=200,100\n[LIST7]\nCELL_SIZE=46,80\nLIST_ORDER=1\nPADDING=2,2,2,2\n','land/symbols.ini':'[PANEL]\n[LIST7]\nPOS=6,10\nLIST_NUM=4\nNAMES=a b c d\nVALUES=A B C D\n'}};
 const out=apply(i,run(i));assert.equal(field(out,'land/symbols.ini','LIST7','POS'),'0,0');assert.equal(field(out,'land/symbols.ini','LIST7','CELL_SIZE'),'50,100');assert.equal(out.files['land/gen.ini'],i.files['land/gen.ini']);assert.equal(run(out).edits.length,0);
});
test('two LIST regions share exact horizontal and vertical seams',()=>{
 for(const horizontal of [false,true]){
  const i={files:{'x.ini':panel(`[LIST1]\nPOS=4,4\nCELL_SIZE=${horizontal?'23,92':'92,23'}\nLIST_NUM=4\nLIST_ORDER=${horizontal?1:0}\n[LIST2]\nPOS=104,4\nCELL_SIZE=${horizontal?'23,92':'92,23'}\nLIST_NUM=4\nLIST_ORDER=${horizontal?1:0}\n`)}};
  const r=run(i),out=apply(i,r);assert.equal(r.reports[0].changedLists,2);assert.equal(field(out,'x.ini','LIST1','POS'),'0,0');assert.equal(field(out,'x.ini','LIST2','POS'),'100,0');assert.equal(field(out,'x.ini','LIST1','CELL_SIZE'),horizontal?'25,100':'100,25');assert.equal(run(out).edits.length,0);
 }
});
test('non-divisible full-height LIST uses integer cells with remainder only at exposed edge',()=>{
 const i={files:{'x.ini':panel('[LIST]\nPOS=4,4\nCELL_SIZE=36,23\nLIST_NUM=4\n'+key(1,'48,4,148,92'),200,101)}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','LIST','POS'),'0,0');assert.equal(field(out,'x.ini','LIST','CELL_SIZE'),'44,25');assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'44,0,156,101');assert.ok(r.reports[0].notes.some(n=>n.includes('余数')));assert.equal(run(out).edits.length,0);
});
test('LIST duplicate or invalid geometry does not produce a partial file edit',()=>{
 for(const extra of ['[LIST]\nPOS=0,0\nCELL_SIZE=10,20\nLIST_NUM=3\n','[LIST2]\nPOS=0,0\nCELL_SIZE=0,20\nLIST_NUM=3\n']){const i=listPanel();i.files['dark/port/letters.ini']+=extra;const r=run(i);assert.equal(r.summary.uncertain,1);assert.equal(r.edits.length,0);}
});
test('LIST state overrides keep independent geometry and retain state actions',()=>{
 const i=listPanel();i.files['dark/port/letters.ini']=i.files['dark/port/letters.ini'].replace('TYPE=0','TYPE=0\nSTAT_STYLE=S7_1')+'[TIP1]\nPOS=8,6\nCELL_SIZE=36,22\nVALUES=C D\n';
 const out=apply(i,run(i));assert.equal(field(out,'dark/port/letters.ini','LIST','STAT_STYLE'),'S7_2');assert.equal(field(out,'dark/port/letters.ini','TIP2','POS'),'0,0');assert.equal(field(out,'dark/port/letters.ini','TIP2','CELL_SIZE'),'48,25');assert.equal(field(out,'dark/port/letters.ini','TIP2','VALUES'),'C D');assert.equal(run(out).edits.length,0);
});
test('CND LIST uses its own candidate size instead of inherited keyboard dimensions',()=>{
 const input={files:{'port/gen.ini':'[PANEL]\nSIZE=200,600\n[CAND]\nLAYOUT_NAME=bar\nVIEW_RECT=0,0,200,40\n','port/bar.cnd':'[CAND]\n[LIST]\nPOS=4,4\nCELL_SIZE=46,32\nLIST_NUM=4\nLIST_ORDER=1\n'}};
 const out=apply(input,run(input));assert.equal(field(out,'port/bar.cnd','LIST','CELL_SIZE'),'50,40');assert.equal(run(out).edits.length,0);
 input.files['port/bar.cnd']=input.files['port/bar.cnd'].replace('[CAND]','[CAND]\nSIZE=240,48');
 assert.equal(run(input).summary.uncertain,1);
 input.files['port/gen.ini']='[PANEL]\nSIZE=200,600\n';
 const explicit=apply(input,run(input));assert.equal(field(explicit,'port/bar.cnd','LIST','CELL_SIZE'),'60,48');
});

test('CND LIST with unknown or conflicting dimensions remains unchanged',()=>{
 for(const refs of ['','[CAND]\nLAYOUT_NAME=bar\nVIEW_RECT=0,0,200,40\n[CAND]\nLAYOUT_NAME=bar\nVIEW_RECT=0,0,300,40\n']){
  const input={files:{'port/gen.ini':'[PANEL]\nSIZE=200,600\n'+refs,'port/bar.cnd':'[LIST]\nPOS=4,4\nCELL_SIZE=46,32\nLIST_NUM=4\nLIST_ORDER=1\n'}};
  const r=run(input);assert.equal(r.summary.uncertain,1);assert.equal(r.edits.length,0);
 }
});

const handwriting=()=>({files:{'nested/dark/port/custom.ini':panel('[KEY1]\nVIEW_RECT=8,8,164,72\nCENTER=F53\nBACK_STYLE=12\nFORE_ANIM_STYLE=45\n'+key(2,'180,8,52,32')+key(3,'180,48,52,32')+key(4,'8,88,100,24')+key(5,'116,88,116,24')+'[KEY6]\nVIEW_RECT=12,62,30,14\nCENTER=F78\n',240,120)}});
function coveredArea(boxes){
 const xs=[...new Set(boxes.flatMap(r=>[r[0],r[0]+r[2]]))].sort((a,b)=>a-b);let area=0;
 for(let n=1;n<xs.length;n++){
  const segments=boxes.filter(r=>r[0]<xs[n]&&r[0]+r[2]>xs[n-1]).map(r=>[r[1],r[1]+r[3]]).sort((a,b)=>a[0]-b[0]);
  let high=-Infinity,length=0;for(const [lo,hi] of segments){length+=Math.max(0,hi-Math.max(lo,high));high=Math.max(high,hi);}area+=(xs[n]-xs[n-1])*length;
 }return area;
}
test('inset handwriting closes all margins without changing overlay or effective touch',()=>{
 const input=handwriting(),r=run(input),out=apply(input,r),p=Object.keys(input.files)[0];assert.equal(r.summary.processed,1);
 const before=sections(input,p),after=sections(out,p);
 assert.equal(field(out,p,'KEY1','VIEW_RECT'),'0,0,176,84');assert.equal(field(out,p,'KEY1','TOUCH_RECT'),'8,8,164,72');
 assert.equal(field(out,p,'KEY6','VIEW_RECT'),'12,62,30,14');assert.equal(field(out,p,'KEY6','TOUCH_RECT'),undefined);
 const boxes=after.filter(s=>/^KEY[1-5]$/.test(s.name)).map(s=>s.values.VIEW_RECT.split(',').map(Number));
 assert.equal(coveredArea(boxes),240*120);assert.equal(boxes.reduce((a,r)=>a+r[2]*r[3],0),240*120);
 for(const original of before.filter(s=>/^KEY/.test(s.name)))for(const [key,value] of Object.entries(original.values))if(key!=='VIEW_RECT')assert.equal(field(out,p,original.name,key),value);
 assert.equal(run(out).edits.length,0);
});
test('named handwriting surface and contained buttons are recognised by content',()=>{
 const i=handwriting(),p=Object.keys(i.files)[0];i.files[p]=i.files[p].replace('[KEY1]','[HANDWRITING]').replace('CENTER=F53\n','');
 const out=apply(i,run(i));assert.equal(field(out,p,'HANDWRITING','VIEW_RECT'),'0,0,176,84');assert.equal(field(out,p,'KEY6','VIEW_RECT'),'12,62,30,14');assert.equal(run(out).edits.length,0);
});
test('handwriting with explicit touch and an already fitted neighbouring strip stays functional',()=>{
 const i=handwriting(),p=Object.keys(i.files)[0];i.files[p]=i.files[p].replace('CENTER=F53','TOUCH_RECT=0,0,178,82\nCENTER=F53').replace('180,8,52,32','172,0,68,44').replace('180,48,52,32','172,44,68,36');
 const out=apply(i,run(i));assert.equal(field(out,p,'KEY1','VIEW_RECT'),'0,0,172,84');assert.equal(field(out,p,'KEY1','TOUCH_RECT'),'0,0,178,82');assert.equal(run(out).edits.length,0);
});

// Fixtures used by the iOS bridge regression tests contain synthetic content only.
if(process.argv.includes('--fixtures')) {
 fs.mkdirSync(path.join(__dirname,'fixtures'),{recursive:true});
 for(const [name,input] of [['plain',plain()],['atlas',atlas()],['inset',insetRows()],['list',listPanel()],['handwriting',handwriting()]])fs.writeFileSync(path.join(__dirname,'fixtures',name+'.json'),JSON.stringify({input,expected:run(input)},null,2));
}
console.log(`${count} test groups passed`);
