import XCTest
import UIKit

final class PreviewCheckUITests:XCTestCase {
    override func setUpWithError() throws {continueAfterFailure=false}
    private func preview(_ app:XCUIApplication)->XCUIElement {
        app.descendants(matching:.any).matching(identifier:"editor.preview").firstMatch
    }
    private func screenshot(_ app:XCUIApplication,name:String,panel:String)->Data {
        let canvas=preview(app)
        XCTAssertTrue(canvas.waitForExistence(timeout:5))
        XCTAssertEqual(canvas.label,"顶栏与键盘预览")
        XCTAssertEqual(canvas.value as? String,panel+" · cand1.cnd")
        let screenshot=XCUIScreen.main.screenshot(),raw=screenshot.image
        let attachment=XCTAttachment(screenshot:screenshot);attachment.name=name;attachment.lifetime = .keepAlways;add(attachment)
        let format=UIGraphicsImageRendererFormat();format.scale=raw.scale
        let image=UIGraphicsImageRenderer(size:raw.size,format:format).image{_ in raw.draw(in:CGRect(origin:.zero,size:raw.size))}
        guard let cg=image.cgImage else{XCTFail("No screen pixels");return Data()}
        let area=canvas.frame,scale=min((area.width-16)/1080,(area.height-16)/755)
        let point=CGPoint(x:area.midX+(910-540)*scale,y:area.midY-755*scale/2+20*scale)
        let density=CGFloat(cg.width)/image.size.width,x=Int(point.x*density),y=Int(point.y*density)
        var rgba=[UInt8](repeating:0,count:4)
        guard let pixel=cg.cropping(to:CGRect(x:x,y:y,width:1,height:1)),
              let context=CGContext(data:&rgba,width:1,height:1,bitsPerComponent:8,bytesPerRow:4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else{XCTFail("Missing top bar screen area");return Data()}
        context.draw(pixel,in:CGRect(x:0,y:0,width:1,height:1))
        // ICON3's cand_line atlas is green and occupies the top-right bar. ICON2's
        // 1x1 slice is an empty placeholder and is not a visible-bar colour probe.
        for (actual,expected) in zip(rgba.prefix(3),[81,199,171]) {XCTAssertEqual(Double(actual),Double(expected),accuracy:9,"Top bar not drawn in the actual application window")}
        let crop=CGRect(x:area.minX*density,y:area.minY*density,width:area.width*density,height:area.height*density)
        return cg.cropping(to:crop).flatMap{UIImage(cgImage:$0).pngData()} ?? Data()
    }
    private func run(original:Bool) {
        XCUIDevice.shared.orientation = .portrait
        let app=XCUIApplication();app.launchArguments=["--iqoo-preview-fixture"]+(original ? ["--iqoo-original-fixture"]:[]);app.launch()
        XCTAssertTrue(app.buttons["editor.panel"].waitForExistence(timeout:30))
        let first=screenshot(app,name:"IQOO-imported-top-bar",panel:"py_26")
        app.buttons["editor.panel"].tap()
        let handwriting=app.buttons.matching(NSPredicate(format:"label ENDSWITH %@"," · port/hw_grid.ini")).firstMatch
        let panels=app.collectionViews.firstMatch
        XCTAssertTrue(panels.waitForExistence(timeout:5))
        for _ in 0..<12 {
            if handwriting.exists && handwriting.isHittable {break}
            panels.swipeUp()
        }
        XCTAssertTrue(handwriting.exists && handwriting.isHittable,"Scroll the complete panel menu to the handwriting entry")
        handwriting.tap()
        XCTAssertNotEqual(screenshot(app,name:"IQOO-handwriting-top-bar",panel:"hw_grid"),first)
        app.buttons["⋮"].tap();app.buttons["预览检查"].tap()
        let report=app.staticTexts["preview.check.report"]
        XCTAssertTrue(report.waitForExistence(timeout:5))
        XCTAssertTrue(report.label.contains("最后绘制：port/hw_grid.ini"))
        XCTAssertTrue(report.label.contains("顶栏绘制：port/cand1.cnd"))
        XCTAssertTrue(report.label.contains("兼容 · 直接绘制"))
        let attachment=XCTAttachment(screenshot:XCUIScreen.main.screenshot());attachment.name="Preview-check-report";attachment.lifetime = .keepAlways;add(attachment)
        let reload=app.buttons["preview.check.reload"]
        let reportScroll=app.scrollViews.containing(.staticText,identifier:"preview.check.report").firstMatch
        for _ in 0..<3 {if reload.isHittable {break};reportScroll.swipeUp()}
        XCTAssertTrue(reload.isHittable);reload.tap()
        _=screenshot(app,name:"IQOO-handwriting-after-reload",panel:"hw_grid")
        XCUIDevice.shared.orientation = .landscapeLeft
        _=screenshot(app,name:"IQOO-handwriting-landscape-window",panel:"hw_grid")
    }
    func testOriginalIQOOPreviewAndReport(){run(original:true)}
    func testExportedIQOOPreviewAndReport(){run(original:false)}
}
