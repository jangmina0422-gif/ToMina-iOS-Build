import XCTest
import SwiftUI
import UIKit
import ZIPFoundation
import ImageIO
@testable import ToMina

final class SkinRegressionTests:XCTestCase {
    private func fixture(_ name:String)->URL {
        let bundle=Bundle(for:Self.self),parts=name.components(separatedBy:".")
        return bundle.url(forResource:parts[0],withExtension:parts[1],subdirectory:"Fixtures") ?? bundle.url(forResource:parts[0],withExtension:parts[1])!
    }
    @MainActor private func open(_ name:String) async ->SkinStore {
        let store=SkinStore();await store.openArchive(fixture(name))
        XCTAssertNil(store.error,"\(name): \(store.error ?? "")")
        XCTAssertNotNil(store.root);XCTAssertGreaterThan(store.keys.count,20)
        return store
    }
    @MainActor private func render(_ store:SkinStore)throws->UIImage {
        let width:CGFloat=540,minY=store.bda?.minY ?? -store.renderer.candidateSize.height
        let scale=width/max(1,store.panel.width),height=(store.panel.height-minY)*scale
        let canvas=Canvas(rendersAsynchronously:false){context,_ in
            context.scaleBy(x:scale,y:scale);context.translateBy(x:0,y:-minY)
            context.fill(Path(CGRect(origin:.zero,size:store.panel)),with:.color(.white))
            if let bda=store.bda{bda.draw(context:&context,time:0,pressed:false,debug:false,scale:scale,playing:false)}
            else{store.renderer.background(size:store.panel,context:&context);store.renderer.candidate(context:&context);for key in store.keys{store.renderer.key(key,pressed:false,context:&context)}}
        }.frame(width:width,height:height)
        let renderer=ImageRenderer(content:canvas);renderer.scale=1
        return try XCTUnwrap(renderer.uiImage,store.filename+" preview did not render")
    }
    @MainActor func testRealPackagesImportAndRender() async throws {
        for name in ["sticker.bds","iqoo.bds","r1.bds","official.bdi","bda.bda"] {
            let store=await open(name)
            defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
            if name=="official.bdi" || name=="bda.bda"{XCTAssertNotNil(store.bda);XCTAssertFalse(store.bda?.images.isEmpty ?? true)}
            else{XCTAssertNil(store.bda);XCTAssertTrue(store.renderer.hasStyles)}
            let image=try render(store)
            let bytes=try XCTUnwrap(image.cgImage?.dataProvider?.data)
            let buffer=CFDataGetBytePtr(bytes)!,length=CFDataGetLength(bytes)
            var different=0
            for offset in stride(from:0,to:length-3,by:4){if Int(buffer[offset])+Int(buffer[offset+1])+Int(buffer[offset+2])<690{different+=1}}
            XCTAssertGreaterThan(different,1000,name+" rendered a blank preview")
            let attachment=XCTAttachment(image:image);attachment.name=name+" preview";attachment.lifetime = .keepAlways;add(attachment)
        }
    }
    @MainActor func testLanguagePanelsAndViewGuideExport() async throws {
        let store=await open("sushi.bds"),root=store.root!
        defer{try? FileManager.default.removeItem(at:root)}
        let references=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:fixture("GuideReference.json"))) as? [String:Any])
        let expectedPanels=try XCTUnwrap(references["panelFiles"] as? [String])
        XCTAssertEqual(store.panelFiles.map{store.relative($0)},expectedPanels,"Android and iOS disagree on the real INI panel list")
        let captions=try XCTUnwrap(references["functions"] as? [String:String])
        for (code,text) in captions {XCTAssertEqual(PreviewLabels.caption(code),text)}
        let expected=try XCTUnwrap(references["panels"] as? [[String:Any]])
        for spec in expected {
            let path=try XCTUnwrap(spec["path"] as? String)
            try store.open(root.appendingPathComponent(path));XCTAssertNil(store.error)
            XCTAssertGreaterThan(store.keys.count,20,path)
            let regions=PreviewGuides.regions(store)
            let reference=try XCTUnwrap(spec["regions"] as? [[String:Any]])
            XCTAssertEqual(regions.count,reference.count,path)
            for (region,record) in zip(regions,reference) {
                XCTAssertEqual(region.name,record["name"] as? String)
                let r=try XCTUnwrap(record["rect"] as? [Double])
                XCTAssertEqual(region.rect,CGRect(x:r[0],y:r[1],width:r[2],height:r[3]),path+" "+region.name)
            }
            if path.hasPrefix("port/") && !path.contains("shifts") {
                let image=try render(store),attachment=XCTAttachment(image:image)
                attachment.name=path.replacingOccurrences(of:"/",with:"-")+" preview";attachment.lifetime = .keepAlways;add(attachment)
            }
        }
        try store.open(root.appendingPathComponent("port/cj.ini"))
        let source=try Data(contentsOf:store.current!),regions=PreviewGuides.regions(store)
        let key=try XCTUnwrap(regions.first{$0.name=="KEY1"})
        XCTAssertEqual(key.rect,CGRect(x:35,y:18,width:92,height:127))
        XCTAssertNotEqual(key.rect,CGRect(x:20,y:0,width:112,height:168),"TOUCH_RECT substituted for VIEW_RECT")
        let file=try PreviewGuides.export(store)
        defer{try? FileManager.default.removeItem(at:file.deletingLastPathComponent())}
        XCTAssertEqual(source,try Data(contentsOf:store.current!),"guide export changed the source configuration")
        let image=try XCTUnwrap(UIImage(contentsOfFile:file.path)),cg=try XCTUnwrap(image.cgImage)
        let bounds=PreviewGuides.bounds(store.panel,regions)
        XCTAssertEqual(cg.width,Int(ceil(bounds.width)));XCTAssertEqual(cg.height,Int(ceil(bounds.height)))
        let format=UIGraphicsImageRendererFormat();format.opaque=false;format.scale=1
        let rgba=UIGraphicsImageRenderer(size:image.size,format:format).image{_ in image.draw(at:.zero)}
        let data=try XCTUnwrap(rgba.cgImage?.dataProvider?.data),buffer=CFDataGetBytePtr(data)!
        var transparent=0,visible=0
        for i in stride(from:3,to:CFDataGetLength(data),by:4){if buffer[i]==0{transparent+=1}else{visible+=1}}
        XCTAssertGreaterThan(transparent,visible*3,"exported auxiliary lines have an opaque background")
        XCTAssertGreaterThan(visible,1000,"PNG exported without lines")
        let attachment=XCTAttachment(image:image);attachment.name="cj VIEW transparent guides";attachment.lifetime = .keepAlways;add(attachment)
    }
    @MainActor func testHybridWholeAnimationChangesPreview() async throws {
        let store=await open("r1.bds"),root=store.root!
        defer{try? FileManager.default.removeItem(at:root)}
        let key=try XCTUnwrap(store.keys.first{$0.caption.lowercased()=="q"})
        try store.addKeyAnimation(key.name)
        let before=try render(store).pngData()
        store.renderer.animationEnabled=true;store.renderer.trigger(key.name)
        store.renderer.animationStart=Date().addingTimeInterval(-0.08)
        let after=try render(store)
        XCTAssertNotEqual(before,after.pngData(),"R1 hybrid appearance skipped the added key animation")
        let attachment=XCTAttachment(image:after);attachment.name="r1 key animation";attachment.lifetime = .keepAlways;add(attachment)
    }
    @MainActor func testAnimationEditingExportAndDocumentSwitch() async throws {
        let store=await open("sticker.bds"),root=store.root!
        defer{try? FileManager.default.removeItem(at:root)}
        let key=try XCTUnwrap(store.keys.first{$0.name.range(of:"^KEY[0-9]+$",options:.regularExpression) != nil})
        try store.addKeyAnimation(key.name)
        XCTAssertFalse(store.renderer.boundAnimations(key.name).isEmpty)
        XCTAssertTrue(store.animationText.contains("TO=85,85"))
        store.animationText=store.animationText.replacingOccurrences(of:"TO=85,85",with:"TO=75,75")
        XCTAssertTrue(store.saveAnimationSource())
        let saved=store.renderer.boundAnimations(key.name).compactMap{store.renderer.timeline.definitions[$0]?["TO"]}
        XCTAssertTrue(saved.contains("75,75"))
        let exported=try store.export(),copy=root.deletingLastPathComponent().appendingPathComponent(UUID().uuidString)
        defer{try? FileManager.default.removeItem(at:exported.deletingLastPathComponent());try? FileManager.default.removeItem(at:copy)}
        try FileManager.default.unzipItem(at:exported,to:copy)
        XCTAssertNotNil(SkinConfiguration.firstLayout(SystemMigration.allFiles(copy)))
        let css=try XCTUnwrap(store.renderer.styleFile),revision=store.documentRevision
        try store.open(css)
        XCTAssertGreaterThan(store.documentRevision,revision);XCTAssertEqual(store.animationText,"");XCTAssertEqual(store.renderer.animationKey,"")
        XCTAssertGreaterThan(store.keys.count,20,"opening CSS discarded the layout")
    }
    @MainActor func testAtlasReferencesAndCandidateInheritance() async throws {
        for name in ["sticker.bds","iqoo.bds"] {
            let store=await open(name),root=store.root!
            defer{try? FileManager.default.removeItem(at:root)}
            var references=Set<String>()
            for s in store.renderer.effectiveSections {
                let ids=([s.values["BACK_STYLE"] ?? ""]+(s.values["FORE_STYLE"] ?? "").components(separatedBy:","))
                for id in ids {if let image=store.renderer.styles["STYLE"+id]?.values["NM_IMG"],!image.isEmpty{references.insert(image)}}
            }
            XCTAssertFalse(references.isEmpty,name+" has no image references")
            // The supplied sticker archive refers to 26ovo but contains neither
            // its image nor its TIL. Keep this source defect distinct from a
            // resolver regression, and fail if any other resource disappears.
            let expectedMissing:Set<String> = name=="sticker.bds" ? ["26ovo"] : []
            var missing=Set<String>()
            for reference in references {
                let atlas=reference.components(separatedBy:",")[0]
                let til=store.renderer.resolve(atlas+".til"),image=store.renderer.resolve(atlas)
                if expectedMissing.contains(atlas) {
                    XCTAssertFalse(store.files.contains{$0.deletingPathExtension().lastPathComponent.lowercased()==atlas.lowercased()},"known source defect no longer applies")
                    XCTAssertNil(til);XCTAssertNil(image)
                    XCTAssertTrue(store.renderer.warnings.contains("缺少资源："+atlas))
                    missing.insert(atlas)
                } else {
                    XCTAssertNotNil(til,reference+" TIL missing")
                    XCTAssertNotNil(image,reference+" image missing")
                }
            }
            XCTAssertEqual(missing,expectedMissing,"source resource inventory changed")
            if store.renderer.candidateFile != nil {XCTAssertGreaterThan(store.renderer.candidateSize.height,0)}
        }
    }
    @MainActor func testFloatingUsesPanelBindingAndIdleDelay() async throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer{try? FileManager.default.removeItem(at:root)}
        let layout=root.appendingPathComponent("port/py_26.ini"),css=root.appendingPathComponent("port/res/default.css"),events=root.appendingPathComponent("port/res/event.ini")
        let text="[PANEL]\nANIM_STYLE=1\nANIM_LEVEL=0\n[KEY1]\nVIEW_RECT=0,0,100,100\n"
        try SkinConfiguration.write([layout:text,css:"[STYLE1]\nSHOW_ANIM=1\nEVENT1=3\n[ANIM1]\nBUILD_LIST=2\n[ANIM2]\nCATEGORY=3\n[ANIM3]\nCATEGORY=3\n[ANIM4]\nCATEGORY=3\n",events:"[EVENT1]\nNAME=IDLE\nIDLE_TIME=1000\n"])
        let renderer=IniSkinRenderer();renderer.configure(root:root,config:layout,files:[layout,css,events],text:text)
        XCTAssertEqual(Set(renderer.floatingAnimations),Set(["1","2","3"]))
        XCTAssertEqual(renderer.floatingLevel,0);XCTAssertEqual(renderer.floatingDelay,1000)
        renderer.floatingChoice="4";renderer.configureFloating()
        XCTAssertEqual(renderer.floatingAnimations,["4"]);XCTAssertEqual(renderer.floatingDelay,0)
    }
    @MainActor func testUnsupportedSystemConversionPreservesSource() async throws {
        let store=await open("official.bdi"),root=store.root!,files=store.files
        defer{try? FileManager.default.removeItem(at:root)}
        let before=try files.map{try Data(contentsOf:$0)}
        XCTAssertThrowsError(try store.convertSystem())
        for (file,data) in zip(files,before){XCTAssertEqual(try Data(contentsOf:file),data)}
    }
    @MainActor func testToolboxScalesCommentedGeometry() async {
        let source="\u{FEFF}[PANEL]\r\nSIZE=1080,642 // original size\r\n// POS=1,2\r\n[KEY1]\r\nVIEW_RECT=35,18,92,127 // key bounds\r\n"
        let result=SkinTools.scaledLayout(source,ratio:0.5,width:540,candidate:false)
        XCTAssertEqual(SkinConfiguration.parse(result)[0].values["SIZE"],"540,321")
        XCTAssertEqual(SkinConfiguration.parse(result)[1].values["VIEW_RECT"],"18,9,46,64")
        XCTAssertTrue(result.contains("// original size") && result.contains("// key bounds") && result.contains("// POS=1,2"))
    }
    @MainActor func testKeyDeletionPreservesReferencesAndCounts() async throws {
        let store=await open("sticker.bds"),root=store.root!
        defer{try? FileManager.default.removeItem(at:root)}
        let source="[PANEL]\nSIZE=1080,642\nKEY_NUM=3 // count\n[KEY2]\nVIEW_RECT=0,0,100,100\nCENTER=q\n[KEY7]\nVIEW_RECT=100,0,100,100\nBROTHER_ID=2 // sibling\nCENTER=w\n[KEY10]\nVIEW_RECT=200,0,100,100\nCENTER=e\n"
        store.change(source);XCTAssertNil(store.error)
        store.deleteKey("KEY2");XCTAssertEqual(store.text,source);XCTAssertNotNil(store.error)
        store.error=nil;store.deleteKey("KEY10");XCTAssertNil(store.error)
        let sections=SkinStore.parse(store.text)
        XCTAssertEqual(sections.map(\.name),["PANEL","KEY1","KEY2"])
        XCTAssertEqual(sections[0].values["KEY_NUM"],"2");XCTAssertEqual(sections[2].values["BROTHER_ID"],"1")
        XCTAssertTrue(store.text.contains("// count") && store.text.contains("// sibling"))
    }
    @MainActor func testLivePanelAndStyleEditing() async throws {
        let store=await open("sticker.bds"),root=store.root!,layout=store.current!,original=store.text
        defer{try? FileManager.default.removeItem(at:root)}
        XCTAssertEqual(store.panel,CGSize(width:1080,height:570))
        store.setParameter(section:"PANEL",key:"SIZE",value:"900.5,590.25")
        XCTAssertNil(store.error);XCTAssertEqual(store.panel,CGSize(width:900.5,height:590.25))
        XCTAssertEqual(PanelMetrics.dimension(store.panel.width),"900.5")
        store.setParameter(section:"KEY1",key:"VIEW_RECT",value:"41,22,93,128")
        XCTAssertEqual(store.keys.first{$0.name=="KEY1"}?.rect,CGRect(x:41,y:22,width:93,height:128))
        store.change(original);XCTAssertEqual(store.panel,CGSize(width:1080,height:570),"Removed SIZE retained the previous draft")
        let gen=try XCTUnwrap(store.files.first{$0.deletingLastPathComponent()==layout.deletingLastPathComponent() && $0.lastPathComponent=="gen.ini"})
        try store.open(gen);store.setParameter(section:"PANEL",key:"SIZE",value:"900.5,590.25")
        XCTAssertEqual(store.panel,CGSize(width:900.5,height:590.25),"gen.ini edits did not refresh the selected layout")
        store.setParameter(section:"CAND",key:"VIEW_RECT",value:"0,0,900.5,97.25")
        XCTAssertEqual(store.renderer.candidateSize,CGSize(width:900.5,height:97.25))
        XCTAssertTrue(store.blankPreview,"INI without visible keys must be blank")
        try store.open(layout)
        let css=try XCTUnwrap(store.renderer.styleFile);try store.open(css)
        store.setParameter(section:"STYLE450",key:"PRESS_SOUND_PATH",value:"hc.ogg")
        XCTAssertNil(store.error);XCTAssertEqual(store.soundFile("KEY1")?.lastPathComponent,"hc.aiff")
        XCTAssertEqual(store.panel,CGSize(width:900.5,height:590.25),"Editing CSS discarded the active panel")
        try store.open(layout)
        let animationKey=try XCTUnwrap(store.keys.first{!store.renderer.boundAnimations($0.name).isEmpty})
        store.loadAnimationSource(animationKey.name)
        let section=try XCTUnwrap(SkinStore.parse(store.animationText).first)
        store.animationText=try AnimationEdits.set(store.animationText,section:section.name,field:"DURATION",value:"777")
        XCTAssertEqual(store.renderer.timeline.definitions[String(section.name.dropFirst(4))]?["DURATION"],"777","Animation draft waits for Save")
        XCTAssertTrue(store.saveAnimationSource());XCTAssertNil(store.error)
        let image=try render(store),attachment=XCTAttachment(image:image)
        attachment.name="live panel dimensions preview";attachment.lifetime = .keepAlways;add(attachment)
    }
    @MainActor func testKeyboardSoundFormatsAndIndependentToggle() async throws {
        let store=await open("sticker.bds"),root=store.root!,previous=store.soundEnabled
        defer{store.soundEnabled=previous;store.soundPreview.clear();try? FileManager.default.removeItem(at:root)}
        let reference=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:fixture("SoundReference.json"))) as? [String:Any])
        let keys=try XCTUnwrap(reference["keys"] as? [[String:Any]])
        XCTAssertGreaterThan(keys.count,30)
        for item in keys {
            let key=try XCTUnwrap(item["key"] as? String),file=try XCTUnwrap(store.soundFile(key))
            XCTAssertEqual(file.lastPathComponent,item["ios"] as? String,"Android and iOS sound bindings differ for "+key)
            XCTAssertEqual(file.pathExtension,"aiff")
            let data=try Data(contentsOf:file);XCTAssertEqual(String(data:data.prefix(4),encoding:.ascii),"FORM")
        }
        store.soundEnabled=false;store.pressSound("KEY1");XCTAssertEqual(store.soundPreview.playedCount,0)
        store.soundEnabled=true;store.renderer.animationEnabled=false;store.pressSound("KEY1")
        XCTAssertEqual(store.soundPreview.playedCount,1,store.soundPreview.lastError ?? "normal preview produced no sound")
        store.renderer.animationEnabled=true;store.pressSound("KEY1");XCTAssertEqual(store.soundPreview.playedCount,2)
        store.renderer.floatingChoice="1";store.pressSound("KEY1");XCTAssertEqual(store.soundPreview.playedCount,3)
        XCTAssertTrue(store.renderer.animationEnabled,"Sound changed animation mode")
        store.soundEnabled=false;store.pressSound("KEY1");XCTAssertEqual(store.soundPreview.playedCount,3)
        store.soundEnabled=true;store.pressSound("missing-key");XCTAssertEqual(store.soundPreview.playedCount,4)
        XCTAssertEqual(store.soundPreview.lastFile?.pathExtension,"aiff")
        let native=await open("bda.bda");defer{native.soundEnabled=false;native.soundPreview.clear();if let root=native.root{try? FileManager.default.removeItem(at:root)}}
        native.soundEnabled=true;native.pressSound(try XCTUnwrap(native.keys.first?.name))
        XCTAssertEqual(native.soundPreview.playedCount,1,native.soundPreview.lastError ?? "BDA fallback click missing")
    }
    @MainActor func testLiveBinaryDraftsPreservePackageUntilSave() async throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
        defer{try? FileManager.default.removeItem(at:root)}
        let binary=root.appendingPathComponent("layoutConfig"),copy=root.appendingPathComponent("layoutConfig.txt")
        func message(_ number:Int,_ children:[BinaryPlaintext.Field])->BinaryPlaintext.Field {
            BinaryPlaintext.Field(number:number,wire:2,offset:0,bytes:Array(BinaryPlaintext.encode(children)))
        }
        let size=message(7,[BinaryPlaintext.Field(number:1,wire:0,offset:0,bits:1080),BinaryPlaintext.Field(number:2,wire:0,offset:0,bits:642)])
        let entry=message(1,[BinaryPlaintext.Field(number:1,wire:2,offset:0,bytes:Array("py_26".utf8)),message(2,[size])])
        let original=BinaryPlaintext.encode([entry,BinaryPlaintext.Field(number:99,wire:0,offset:0,bits:42)])
        let text="{\"panels\":{\"py_26\":{\"size\":{\"width\":1080,\"height\":642}}}}"
        try original.write(to:binary);try text.write(to:copy,atomically:true,encoding:.utf8)
        let store=SkinStore();store.root=root;store.files=[binary,copy];store.filename="draft.bda"
        store.bda=BdaPreviewEngine(root:root,files:store.files);store.reloadBda()
        XCTAssertEqual(store.panel,CGSize(width:1080,height:642))
        try store.open(copy);store.text=text.replacingOccurrences(of:"642",with:"777");store.refresh()
        XCTAssertEqual(store.panel,CGSize(width:1080,height:777),"BDA TXT draft did not update panel dimensions")
        XCTAssertEqual(try Data(contentsOf:binary),original,"Draft preview wrote the binary before Save")
        XCTAssertEqual(try String(contentsOf:copy,encoding:.utf8),text)
        store.text="{";store.refresh();XCTAssertEqual(store.panel.height,777,"Incomplete JSON discarded the last valid preview")
        store.text=text.replacingOccurrences(of:"642",with:"777");try store.save();store.refresh()
        XCTAssertEqual(store.panel.height,777)
        var budget=0;let fields=try BinaryPlaintext.parse(Array(Data(contentsOf:binary)),budget:&budget)
        XCTAssertEqual(fields.first{$0.number==99}?.bits,42,"Saving a draft lost an unknown binary field")
    }
    func testGIFFrameTiming() async throws {
        let file=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString+".gif")
        defer{try? FileManager.default.removeItem(at:file)}
        let space=CGColorSpaceCreateDeviceRGB(),context=try XCTUnwrap(CGContext(data:nil,width:8,height:8,bitsPerComponent:8,bytesPerRow:32,space:space,bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue))
        let destination=try XCTUnwrap(CGImageDestinationCreateWithURL(file as CFURL,"com.compuserve.gif" as CFString,2,nil))
        for delay in [0.1,0.4] {
            context.setFillColor(UIColor.orange.cgColor);context.fill(CGRect(x:0,y:0,width:8,height:8))
            CGImageDestinationAddImage(destination,try XCTUnwrap(context.makeImage()),[kCGImagePropertyGIFDictionary:[kCGImagePropertyGIFDelayTime:delay]] as CFDictionary)
        }
        XCTAssertTrue(CGImageDestinationFinalize(destination))
        let image=try XCTUnwrap(ImageTimeline(file))
        XCTAssertEqual(image.duration,500,accuracy:1)
        XCTAssertEqual(image.index(time:150,duration:500),1,"GIF selected frames by count instead of actual delay")
        XCTAssertEqual(image.index(time:99,duration:500),0)
    }

    @MainActor func testOverwriteOriginalAndResumeEditor() async throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        defer{try? FileManager.default.removeItem(at:dir)}
        let original=dir.appendingPathComponent("source.bds"),record=dir.appendingPathComponent("state/editor-resume.json")
        try FileManager.default.copyItem(at:fixture("sticker.bds"),to:original)
        let before=try Data(contentsOf:original),store=SkinStore();await store.openArchive(original);XCTAssertNil(store.error)
        defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
        let layout=try XCTUnwrap(store.current),relative=store.relative(layout)
        store.setParameter(section:"PANEL",key:"SIZE",value:"900.5,590.25")
        store.setParameter(section:"KEY1",key:"VIEW_RECT",value:"41,22,93,128")
        let animationKey=try XCTUnwrap(store.keys.first{!store.renderer.boundAnimations($0.name).isEmpty})
        store.loadAnimationSource(animationKey.name)
        let animation=try XCTUnwrap(SkinStore.parse(store.animationText).first)
        store.animationText=try AnimationEdits.set(store.animationText,section:animation.name,field:"DURATION",value:"777")
        var state=EditorViewState();state.selected=animationKey.name;state.editing=true;state.effect="key";state.parameter="TOUCH_RECT";state.zoom=2.25;state.panX=23;state.panY=17;state.view=true
        try await store.saveSession(state,recordFile:record)
        XCTAssertNotEqual(try Data(contentsOf:original),before,"Save did not replace the original file")
        let contents=try OriginalSkinDocument.unpack(original)
        defer{try? FileManager.default.removeItem(at:contents)}
        XCTAssertEqual(SkinConfiguration.parse(try String(contentsOf:contents.appendingPathComponent(relative),encoding:.utf8)).first{$0.name=="PANEL"}?.values["SIZE"],"900.5,590.25")
        let originalArchive=try Archive(data:before,accessMode:.read),savedArchive=try Archive(url:original,accessMode:.read)
        XCTAssertEqual(Set(originalArchive.filter{ $0.type == .file }.map{ $0.path }),Set(savedArchive.filter{ $0.type == .file }.map{ $0.path }),"Save lost or invented archive entries")
        for file in store.files { XCTAssertEqual(try Data(contentsOf:file),try Data(contentsOf:contents.appendingPathComponent(store.relative(file))),"Original archive lost " + store.relative(file)) }
        XCTAssertEqual(try FileManager.default.contentsOfDirectory(at:record.deletingLastPathComponent(),includingPropertiesForKeys:nil).map{ $0.lastPathComponent },["editor-resume.json"],"Stored an extra output package in the app")
        let restored=SkinStore(),returned=try await restored.restoreSession(recordFile:record)
        defer{if let root=restored.root{try? FileManager.default.removeItem(at:root)}}
        XCTAssertEqual(returned,state);XCTAssertEqual(restored.panel,CGSize(width:900.5,height:590.25));XCTAssertEqual(restored.relative(try XCTUnwrap(restored.current)),relative)
        XCTAssertEqual(restored.renderer.timeline.definitions[String(animation.name.dropFirst(4))]?["DURATION"],"777")
        XCTAssertTrue(restored.renderer.animationEnabled);XCTAssertTrue(restored.animationText.contains("DURATION=777"))
        let file=contents.appendingPathComponent(relative)
        let text=try String(contentsOf:file,encoding:.utf8)
        try AnimationEdits.set(text,section:"PANEL",field:"SIZE",value:"900.5,675.75").write(to:file,atomically:true,encoding:.utf8)
        try OriginalSkinDocument.overwrite(root:contents,original:original)
        let fresh=SkinStore();_=try await fresh.restoreSession(recordFile:record)
        defer{if let root=fresh.root{try? FileManager.default.removeItem(at:root)}}
        XCTAssertEqual(fresh.panel.height,675.75,"Reopen used an internal snapshot instead of the original file")
    }
    @MainActor func testBlankIniSwitchAndLiveKeys() async throws {
        let store=await open("sticker.bds"),root=store.root!,layout=store.current!
        defer{try? FileManager.default.removeItem(at:root)}
        let empty=layout.deletingLastPathComponent().appendingPathComponent("empty.ini")
        try "[PANEL]\nSIZE=500,300\n[KEY1]\nVIEW_RECT=0,0,0,20\n".write(to:empty,atomically:true,encoding:.utf8)
        try store.open(empty);XCTAssertTrue(store.blankPreview);XCTAssertTrue(store.keys.isEmpty);XCTAssertEqual(store.panel,CGSize(width:500,height:300))
        store.change("[PANEL]\nSIZE=500,300\n[KEY1]\nVIEW_RECT=10,20,100,80\nCENTER=q\n")
        XCTAssertFalse(store.blankPreview);XCTAssertEqual(store.keys.first{$0.name=="KEY1"}?.rect,CGRect(x:10,y:20,width:100,height:80))
        store.change("[PANEL]\nSIZE=500,300\n");XCTAssertTrue(store.blankPreview);XCTAssertTrue(store.keys.isEmpty)
        try store.open(layout);XCTAssertFalse(store.blankPreview);XCTAssertGreaterThan(store.keys.count,20)
        let candidate=try XCTUnwrap(store.renderer.candidateFile);try store.open(candidate)
        XCTAssertFalse(store.blankPreview,"Candidate file was treated as an empty keyboard")
        XCTAssertFalse(store.keys.isEmpty)
    }
    @MainActor func testOriginalSaveFailureKeepsSessionAndChecksPaths() async throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        defer{try? FileManager.default.removeItem(at:dir)}
        let original=dir.appendingPathComponent("source.bds"),record=dir.appendingPathComponent("editor-resume.json")
        try FileManager.default.copyItem(at:fixture("sticker.bds"),to:original)
        let store=SkinStore();await store.openArchive(original);XCTAssertNil(store.error)
        defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
        try await store.saveSession(EditorViewState(),recordFile:record)
        let before=try Data(contentsOf:record)
        try FileManager.default.removeItem(at:original)
        store.setParameter(section:"PANEL",key:"SIZE",value:"800,400")
        do{try await store.saveSession(EditorViewState(),recordFile:record);XCTFail("Missing original was silently recreated")}catch{}
        XCTAssertFalse(store.busy);XCTAssertEqual(try Data(contentsOf:record),before);XCTAssertFalse(FileManager.default.fileExists(atPath:original.path))
        for name in ["../outside.ini","/outside.ini","x/../../outside.ini","./test.ini"] {XCTAssertThrowsError(try OriginalSkinDocument.path(name,root:try XCTUnwrap(store.root)))}
    }
    @MainActor func testNativeOriginalSaveAndRestore() async throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        defer{try? FileManager.default.removeItem(at:dir)}
        for name in ["official.bdi","bda.bda"] {
            let original=dir.appendingPathComponent(name),record=dir.appendingPathComponent(name+".json")
            try FileManager.default.copyItem(at:fixture(name),to:original)
            let store=SkinStore();await store.openArchive(original);XCTAssertNil(store.error);XCTAssertNotNil(store.bda)
            defer{if let root=store.root{try? FileManager.default.removeItem(at:root)}}
            var state=EditorViewState();state.panel=try XCTUnwrap(store.bda).panelID;state.color="dark";state.view=true;state.debug=true;state.playing=false;state.zoom=1.75
            try await store.saveSession(state,recordFile:record)
            let restored=SkinStore();let view=try await restored.restoreSession(recordFile:record)
            defer{if let root=restored.root{try? FileManager.default.removeItem(at:root)}}
            XCTAssertEqual(view,state);XCTAssertNotNil(restored.bda);XCTAssertEqual(restored.bdaColor,"dark");XCTAssertFalse(restored.blankPreview);XCTAssertGreaterThan(restored.keys.count,20)
        }
    }

}
