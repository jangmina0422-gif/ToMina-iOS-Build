import Foundation
import UIKit
import ZIPFoundation
import Combine
import CoreFoundation

struct SkinFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}
struct KeyShape: Identifiable {
    var id: Int
    var name: String
    var rect: CGRect
    var caption: String
}
@MainActor final class SkinStore: ObservableObject {
    let soundPreview=PreviewSound()
    @Published var soundEnabled=UserDefaults.standard.bool(forKey:"previewSound") {didSet{UserDefaults.standard.set(soundEnabled,forKey:"previewSound");soundPreview.enabled=soundEnabled}}
    func soundFile(_ key:String)->URL? {
        guard let root else{return nil}
        let section=renderer.effectiveSections.first{$0.name==key}
        let reference=PreviewSoundBinding.reference(key:section,panel:renderer.panelSection,styles:renderer.styles)
        return PreviewSoundBinding.resolve(reference,root:root,config:renderer.styleFile ?? layoutFile,files:files)
    }
    func pressSound(_ key:String){soundPreview.enabled=soundEnabled;soundPreview.press(soundFile(key))}
    let renderer = IniSkinRenderer()
    @Published var bda: BdaPreviewEngine?
    @Published var bdaColor="light"
    @Published var bdaOrientation="port"
    @Published var root: URL?
    @Published var filename = "导入"
    @Published var files: [URL] = []
    @Published var fileRevision = 0
    @Published var current: URL?
    private var layoutFile: URL?
    private var originalURL: URL?
    private var originalBookmark: Data?
    @Published private(set) var requiresSaveDestination = false
    @Published var blankPreview = false
    var restoredView: EditorViewState?
    var resumeRevision: Int?
    private var restoringSession = false
    var panelFiles:[URL] {cachedPanelFiles}
    var previewPanelName:String {bda?.panelID ?? layoutFile?.deletingPathExtension().lastPathComponent ?? "panel"}
    let sourceDraft = EditorDraft()
    let animationDraft = EditorDraft()
    var text: String {
        get { sourceDraft.text }
        set {
            cancelSourcePreview()
            sourceDraft.replace(newValue); parsedText = Self.parse(newValue)
        }
    }
    private(set) var parsedText:[Section]=[]
    private var sourcePreviewTask: Task<Void, Never>?
    private var animationPreviewTask: Task<Void, Never>?
    private var sourceEditGeneration = 0
    private var animationEditGeneration = 0
    private var sourcePreviewPending = false
    private var animationPreviewPending = false
    private(set) var editorPreviewCount = 0
    private(set) var editorParseWasBackground = false
    private var sourceUndoGrouped = false
    private(set) var importPreparedOffMain=false
    private var relativeNames:[URL:String]=[:]
    private var cachedPanelFiles:[URL]=[]
    @Published var error: String?
    @Published var busy = false
    @Published var viewFitReport = ""
    func fitGlobalViews() async throws {
        guard !busy, let root, bda == nil else { throw SkinFailure(message:"请先打开可编辑的 INI 皮肤") }
        guard saveAnimationSource() else { throw SkinFailure(message:"请先修正动效代码") }
        try save()
        busy=true; defer { busy=false }
        let result=try await Task.detached(priority:.userInitiated) { try GlobalViewFit.run(root:root) }.value
        // Replace drafts before refreshing: stale text must never overwrite the transaction.
        if let current, let decoded=SkinConfiguration.decode(try Data(contentsOf:current)) {
            encoding=decoded.encoding; text=decoded.text; savedText=decoded.text
        }
        animationText="";animationSaved="";animationSourceFiles=[:]
        undoStack.removeAll();redoStack.removeAll();documentRevision+=1
        viewFitReport=result.report;rescan()
    }
    @Published var documentRevision=0
    var animationText: String {
        get { animationDraft.text }
        set {
            cancelAnimationPreview(); animationDraft.replace(newValue)
            refreshAnimationDraft()
        }
    }
    func refreshAnimationDraft(sections: [Section]? = nil, rendererReloaded: Bool = false){
        let hadAdditions = !animationPreviewAdditions.isEmpty
        if rendererReloaded { animationPreviewAdditions.removeAll() }
        else { removeAnimationPreviewAdditions() }
        if animationText == animationSaved && (rendererReloaded || !animationPreviewActive) {
            animationPreviewActive = false; return
        }
        guard !animationSourceFiles.isEmpty || !animationText.isEmpty else{return}
        guard let sections = try? AnimationSourceEdits.validate(animationText,
            expected:Set(animationSourceFiles.keys),occupied:Set(renderer.animationFiles.keys),parsed:sections) else {
            if hadAdditions { renderer.rasterCache.clear();renderer.configureFloating();objectWillChange.send() }
            return
        }
        let appendFile = animationAppendFile
        for section in sections {
            let id = String(section.name.dropFirst(4))
            renderer.timeline.definitions[id] = section.values
            if animationSourceFiles[section.name] == nil, let target = appendFile {
                renderer.animationFiles[id] = target; animationPreviewAdditions.insert(id)
            }
        }
        animationPreviewActive = animationText != animationSaved
        renderer.rasterCache.clear();renderer.configureFloating();objectWillChange.send()
    }
    private var animationSourceFiles:[String:URL]=[:]
    private var animationSaved=""
    private var animationPreviewAdditions = Set<String>()
    private var animationPreviewActive = false
    private func removeAnimationPreviewAdditions() {
        for id in animationPreviewAdditions {
            renderer.timeline.definitions.removeValue(forKey:id)
            renderer.animationFiles.removeValue(forKey:id)
        }
        animationPreviewAdditions.removeAll()
    }
    private var animationAppendFile: URL? {
        // Preserve the primary bound animation's resource directory, including
        // light/dark and portrait/landscape variants. Never choose from a Set.
        for section in Self.parse(animationSaved) {
            if let file = animationSourceFiles[section.name] { return file }
        }
        guard let directory = (renderer.styleFile ?? layoutFile)?.deletingLastPathComponent() else { return nil }
        let candidate = directory.appendingPathComponent("anim.ini")
        return files.first { $0.path.caseInsensitiveCompare(candidate.path) == .orderedSame } ?? candidate
    }
    func loadAnimationSource(_ key:String,floating:Bool=false) {
        guard saveAnimationSource() else{return}
        removeAnimationPreviewAdditions()
        renderer.configureFloating()
        let ids=floating ? renderer.floatingAnimations:renderer.boundAnimations(key)
        animationSourceFiles=[:];var blocks:[String]=[]
        for id in ids {
            guard let file=renderer.animationFiles[id],let text=IniSkinRenderer.read(file),let range=Self.blockRange(text,"ANIM"+id) else{continue}
            animationSourceFiles["ANIM"+id]=file
            blocks.append(text.components(separatedBy:"\n")[range].joined(separator:"\n").trimmingCharacters(in:.whitespacesAndNewlines))
        }
        animationSaved=blocks.joined(separator:"\n\n");animationText=animationSaved
    }
    func editAnimationBinding(_ key:String,values:[String:String])throws {
        guard bda==nil,current?.pathExtension.lowercased()=="ini" else{throw SkinFailure(message:"请打开 INI 布局并选择按键")}
        guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
        var next=text
        for field in ["ANIM_STYLE","BACK_ANIM_STYLE","FORE_ANIM_STYLE"] {
            next=try AnimationEdits.set(next,section:key,field:field,value:AnimationEdits.ids(values[field] ?? ""))
        }
        guard let current else{throw SkinFailure(message:"请打开布局")};try writeAnimationChanges([current:next]);loadAnimationSource(key);renderer.trigger(key)
    }
    private func writeAnimationChanges(_ pending:[URL:String])throws {
        renderer.invalidatePrepared(Array(pending.keys))
        try SkinConfiguration.write(pending)
        if let current,let value=pending[current]{text=value;savedText=value}
        rescan()
    }
    func editAnimationEvents(_ style:String,press:String,show:String,key:String)throws {
        guard saveAnimationSource(),let file=renderer.styleFile,let original=IniSkinRenderer.read(file) else{throw SkinFailure(message:"没有可编辑的样式文件")}
        var next=try AnimationEdits.set(original,section:"STYLE"+style,field:"PRESS_ANIM",value:AnimationEdits.ids(press,allowMany:false))
        next=try AnimationEdits.set(next,section:"STYLE"+style,field:"SHOW_ANIM",value:AnimationEdits.ids(show,allowMany:false))
        try writeAnimationChanges([file:next]);loadAnimationSource(key);renderer.trigger(key)
    }
    func editAnimationImage(_ id:String,value:String,floating:Bool,key:String)throws {
        guard saveAnimationSource(),let file=renderer.animationFiles[id],let original=IniSkinRenderer.read(file) else{throw SkinFailure(message:"没有可编辑的动画文件")}
        let value = try (floating ? AnimationEdits.ids(value) : value)
        if floating {let count=value.split(separator:",").count;guard (1...10).contains(count) else{throw SkinFailure(message:"请选择 1–10 个底包图片样式")}}
        let next=try AnimationEdits.set(original,section:"ANIM"+id,field:floating ? "PARTICLE_IMAGE":"ANIM_PATH",value:value)
        try writeAnimationChanges([file:next]);loadAnimationSource(key,floating:floating);renderer.trigger(key);renderer.restartFloating()
    }
    func editStyleImage(_ style:String,field:String,reference:String,key:String)throws {
        guard ["NM_IMG","HL_IMG"].contains(field),saveAnimationSource(),let file=renderer.styleFile,let original=IniSkinRenderer.read(file) else{throw SkinFailure(message:"没有可编辑的样式")}
        let next=try AnimationEdits.set(original,section:"STYLE"+style,field:field,value:reference)
        try writeAnimationChanges([file:next]);loadAnimationSource(key);renderer.trigger(key)
    }
    func animationLog(_ key:String,floating:Bool)->String {
        let ids=floating ? renderer.timeline.definitions.keys.filter{renderer.timeline.definitions[$0]?["CATEGORY"]=="3"}.sorted():renderer.boundAnimations(key)
        var rows=["按键："+key,"样式文件："+(renderer.styleFile.map(relative) ?? "未找到"),"触发："+renderer.animationEvent]
        if ids.isEmpty{rows.append("未找到绑定动画")}
        for id in ids {rows.append("ANIM"+id+" · "+(renderer.animationFiles[id].map(relative) ?? "文件未找到"))}
        return rows.joined(separator:"\n")
    }
    var tileReferences:[String] {
        var result:[String]=[]
        for file in files where file.pathExtension.lowercased()=="til" {
            guard let text=IniSkinRenderer.read(file) else{continue}
            let atlas=(relative(file) as NSString).deletingPathExtension
            for section in Self.parse(text) where section.name.hasPrefix("IMG") && Int(section.name.dropFirst(3)) != nil {
                if Self.numbers(section.values["SOURCE_RECT"]).count==4{result.append(atlas+","+section.name.dropFirst(3))}
            }
        }
        return result.sorted()
    }
    func addKeyAnimation(_ key:String)throws {
        guard bda==nil,let current,current.pathExtension.lowercased()=="ini",Self.parse(text).contains(where:{$0.name==key && key.hasPrefix("KEY")}) else{throw SkinFailure(message:"请先选择按键")}
        guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")};try save()
        let anim=(renderer.timeline.definitions.keys.compactMap{Int($0)}.max() ?? 0)+1
        let style=(renderer.styles.keys.compactMap{Int($0.dropFirst(5))}.max() ?? 0)+1
        let css=renderer.styleFile ?? current.deletingLastPathComponent().appendingPathComponent("res/default.css")
        let file=css.deletingLastPathComponent().appendingPathComponent("anim.ini")
        var at=(IniSkinRenderer.read(file) ?? "[GLOBAL]\nANIM_NUM=0\n")+"\n[ANIM\(anim)]\nTYPE=4\nFROM=100,100\nTO=85,85\nDURATION=180\nREPEAT_CNT=1\nREPEAT_MODE=1\nREMOVE=1\n"
        var ct=(IniSkinRenderer.read(css) ?? "[GLOBAL]\nSTYLE_NUM=0\n")+"\n[STYLE\(style)]\nPRESS_ANIM=\(anim)\n"
        if Self.blockRange(at,"GLOBAL") != nil{at=try AnimationEdits.set(at,section:"GLOBAL",field:"ANIM_NUM",value:String(Self.parse(at).filter{$0.name.range(of:"^ANIM[0-9]+$",options:.regularExpression) != nil}.count))}
        if Self.blockRange(ct,"GLOBAL") != nil{ct=try AnimationEdits.set(ct,section:"GLOBAL",field:"STYLE_NUM",value:String(Self.parse(ct).filter{$0.name.range(of:"^STYLE[0-9]+$",options:.regularExpression) != nil}.count))}
        let next=try AnimationEdits.set(text,section:key,field:"ANIM_STYLE",value:String(style))
        try writeAnimationChanges([file:at,css:ct,current:next]);loadAnimationSource(key);renderer.trigger(key)
    }
    static func blockRange(_ text:String,_ name:String)->Range<Int>? {
        let lines=text.components(separatedBy:"\n");var start:Int?
        for (i,line) in lines.enumerated() {
            if let section=SkinConfiguration.header(line) {
                if let start{return start..<i}
                if section==name.uppercased(){start=i}
            }
        };return start.map{$0..<lines.count}
    }
    @discardableResult func saveAnimationSource()->Bool {
        cancelAnimationPreview()
        guard animationText != animationSaved else{return true}
        removeAnimationPreviewAdditions()
        do {
            let parsed = try AnimationSourceEdits.validate(animationText,
                expected:Set(animationSourceFiles.keys),occupied:Set(renderer.animationFiles.keys))
            let names=parsed.map{$0.name}
            var destinations = animationSourceFiles
            let appendFile = animationAppendFile
            for name in names where destinations[name] == nil {
                guard let target = appendFile else { throw SkinFailure(message:"请先打开 INI 布局后添加动效") }
                destinations[name] = target
            }
            var pending:[URL:String]=[:]
            for file in Set(destinations.values) {
                let original: String
                if FileManager.default.fileExists(atPath:file.path) {
                    guard let decoded = SkinConfiguration.decode(try Data(contentsOf:file)) else { throw SkinFailure(message:"无法读取原配置") }
                    original = decoded.text
                } else {
                    guard !animationSourceFiles.values.contains(file) else { throw SkinFailure(message:"原动画文件已不存在，请重新打开") }
                    original = ""
                }
                pending[file] = try AnimationSourceEdits.merge(original,draft:animationText,
                    names:names.filter { destinations[$0] == file },existing:Set(animationSourceFiles.keys))
            }
            try writeAnimationChanges(pending)
            animationSourceFiles=destinations;animationSaved=animationText
            animationPreviewAdditions.removeAll();animationPreviewActive=false
            return true
        }catch{self.error=error.localizedDescription;return false}
    }
    @Published var keys: [KeyShape] = []
    @Published var panel = CGSize(width: 1080, height: 642)
    @Published var previewNote = "导入皮肤"
    private var undoStack: [String] = []
    private var redoStack: [String] = []
    var canUndo: Bool { !undoStack.isEmpty }
    var canRedo: Bool { !redoStack.isEmpty }
    private func cancelSourcePreview() {
        sourcePreviewTask?.cancel(); sourcePreviewTask = nil
        sourceEditGeneration &+= 1; sourcePreviewPending = false; sourceUndoGrouped = false
    }
    private func cancelAnimationPreview() {
        animationPreviewTask?.cancel(); animationPreviewTask = nil
        animationEditGeneration &+= 1; animationPreviewPending = false
    }
    // The native editor already owns its text storage and selection. This hot
    // path does no parsing, file I/O, renderer rebuild or store publication.
    @discardableResult func editSource(_ next: String, composing: Bool = false) -> Bool {
        guard next != text else {
            if sourcePreviewPending && !composing { sourcePreviewTask?.cancel(); scheduleSourcePreview() }
            return true
        }
        if !sourceUndoGrouped {
            guard saveAnimationSource() else { return false }
            undoStack.append(text)
            if undoStack.count > 40 { undoStack.removeFirst() }
            redoStack.removeAll(); sourceUndoGrouped = true
        }
        sourceDraft.acceptTyping(next); sourcePreviewPending = true
        sourceEditGeneration &+= 1; sourcePreviewTask?.cancel()
        guard !composing else { return true }
        scheduleSourcePreview(); return true
    }
    private func scheduleSourcePreview() {
        let generation = sourceEditGeneration
        sourcePreviewTask = Task { [weak self] in
            do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
            guard let self, !Task.isCancelled else { return }
            let snapshot = self.text
            let file = self.current, files = self.files, linkedBinary = self.linkedBinaryText
            let worker = Task.detached(priority: .userInitiated) {
                PreparedEditorPreview.prepare(snapshot, file: file, files: files, linkedBinary: linkedBinary)
            }
            let result = await withTaskCancellationHandler(operation: { await worker.value }, onCancel: { worker.cancel() })
            guard !Task.isCancelled, generation == self.sourceEditGeneration else { return }
            self.parsedText = result.sections; self.editorParseWasBackground = result.background
            self.sourcePreviewPending = false; self.sourceUndoGrouped = false
            self.sourcePreviewTask = nil; self.editorPreviewCount += 1
            if result.failure == nil { self.refresh(preservingResources: true, preparedBda: result) }
            else { self.objectWillChange.send() }
        }
    }
    @discardableResult func editAnimationSource(_ next: String, composing: Bool = false) -> Bool {
        guard next != animationText || (animationPreviewPending && !composing) else { return true }
        animationDraft.acceptTyping(next); animationPreviewPending = true
        animationEditGeneration &+= 1; animationPreviewTask?.cancel()
        guard !composing else { return true }
        let generation = animationEditGeneration
        animationPreviewTask = Task { [weak self] in
            do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
            guard let self, !Task.isCancelled else { return }
            let snapshot = self.animationText
            let worker = Task.detached(priority: .userInitiated) { SkinConfiguration.parse(snapshot, cancelled: { Task.isCancelled }) }
            let parsed = await withTaskCancellationHandler(operation: { await worker.value }, onCancel: { worker.cancel() })
            guard !Task.isCancelled, generation == self.animationEditGeneration else { return }
            self.animationPreviewPending = false; self.animationPreviewTask = nil
            self.editorPreviewCount += 1; self.refreshAnimationDraft(sections: parsed)
            self.objectWillChange.send()
        }
        return true
    }
    func editParameter(section: String, key: String, value: String) {
        do { _ = editSource(try AnimationEdits.set(text, section: section, field: key, value: value)) }
        catch { self.error = error.localizedDescription }
    }
    private func flushSourcePreview() {
        guard sourcePreviewPending else { return }
        cancelSourcePreview(); parsedText = Self.parse(text)
        editorPreviewCount += 1; refresh(preservingResources: true)
    }
    func finishSourceEditing() {
        do { try save() } catch { self.error = error.localizedDescription }
    }
    func finishAnimationEditing() { _ = saveAnimationSource() }
    func change(_ next: String) {
        flushSourcePreview()
        guard next != text else { return }
        guard saveAnimationSource() else{return}
        undoStack.append(text)
        if undoStack.count > 40 { undoStack.removeFirst() }
        redoStack.removeAll()
        text = next
        if !linkedBinaryText || (try? JSONSerialization.jsonObject(with:Data(text.utf8))) != nil {
            do { try save() } catch { self.error = error.localizedDescription }
        }
        refresh(preservingResources: true)
    }
    func history(redo: Bool) {
        flushSourcePreview()
        guard saveAnimationSource() else{return}
        if redo { guard let next = redoStack.popLast() else { return }; undoStack.append(text); text = next }
        else { guard let next = undoStack.popLast() else { return }; redoStack.append(text); text = next }
        do { try save() } catch { self.error = error.localizedDescription }
        refresh(preservingResources: true)
    }
    func sectionRange(_ name: String) -> Range<Int>? {
        Self.blockRange(text,name)
    }
    func setParameter(section: String, key: String, value: String) {
        do{change(try AnimationEdits.set(text,section:section,field:key,value:value))}catch{self.error=error.localizedDescription}
    }
    func addKey(copy name: String? = nil) -> String? {
        guard current?.pathExtension.lowercased() == "ini" else { error = "请选择 INI 布局"; return nil }
        let index = (Self.parse(text).compactMap { s -> Int? in
            guard s.name.hasPrefix("KEY") else { return nil }
            return Int(s.name.dropFirst(3))
        }.max() ?? 0) + 1
        let nextName = "KEY\(index)"
        var content = "BACK_STYLE=2\nFORE_STYLE=3\nVIEW_RECT=10,10,100,100\nTOUCH_RECT=10,10,100,100\nCENTER=F38"
        if let name, let range = sectionRange(name) {
            content = text.components(separatedBy: "\n")[range].dropFirst().joined(separator: "\n")
        }
        change(Self.updateCounts(text + "\n[" + nextName + "]\n" + content + "\n"))
        return nextName
    }
    func deleteKey(_ name: String) {
        guard name.range(of:"^KEY[0-9]+$",options:.regularExpression) != nil, let range = sectionRange(name) else { return }
        let number=String(name.dropFirst(3))
        guard !Self.parse(text).contains(where:{$0.name != name && $0.values["BROTHER_ID"]==number}) else {
            error="此按键被 BROTHER_ID 引用，请先修改引用";return
        }
        var lines = text.components(separatedBy: "\n"); lines.removeSubrange(range)
        change(Self.updateCounts(SkinConfiguration.renumberKeys(lines.joined(separator: "\n"))))
    }
    static func updateCounts(_ text: String) -> String {
        let sections = parse(text)
        var counts: [String: Int] = [:]
        for prefix in ["KEY", "TIP", "ICON", "OFFSET", "STYLE", "IMG"] {
            counts[prefix + "_NUM"] = sections.filter {
                $0.name.hasPrefix(prefix) && Int($0.name.dropFirst(prefix.count)) != nil
            }.count
        }
        return text.components(separatedBy: "\n").map { line in
            guard let equal = line.firstIndex(of: "=") else { return line }
            let key = line[..<equal].trimmingCharacters(in: .whitespaces).uppercased()
            guard let count = counts[key] else { return line }
            let original=String(line[line.index(after:equal)...]),comment=original.range(of:" //")
            return String(line[...equal]) + String(count) + (comment.map{String(original[$0.lowerBound...])} ?? (line.hasSuffix("\r") ? "\r" : ""))
        }.joined(separator: "\n")
    }
    func checkLayout() -> String {
        let issues=SkinConfiguration.validate(text)
        return issues.isEmpty ? "当前文件配置检查通过；实际导入与效果仍需真机验证。":issues.joined(separator:"\n")
    }
    private var encoding = String.Encoding.utf8
    private var savedText = ""

    static func parse(_ text: String) -> [Section] {
        SkinConfiguration.parse(text)
    }
    static func numbers(_ value: String?) -> [CGFloat] {
        SkinConfiguration.numbers(value).map{CGFloat($0)}
    }
    func openArchive(_ url: URL, asCopy: Bool = false) async {
        guard !busy else{return}
        busy=true;defer{busy=false}
        do {
            guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
            try save()
            let access=url.startAccessingSecurityScopedResource()
            defer{if access{url.stopAccessingSecurityScopedResource()}}
            let bookmark: Data?
            if asCopy { bookmark = nil } else { bookmark = try OriginalSkinDocument.bookmark(url) }
            let prepared=try await Task.detached(priority:.userInitiated){try PreparedSkinArchive.open(url)}.value
            try adopt(prepared,filename:url.lastPathComponent)
            originalURL=asCopy ? nil:url;originalBookmark=bookmark;requiresSaveDestination=asCopy
            restoredView=nil;resumeRevision=nil;error=nil
        }catch{self.error=error.localizedDescription}
    }
    private func adopt(_ archive:PreparedSkinArchive,filename name:String)throws {
        let folder=archive.folder
        root=folder;filename=name;current=nil;layoutFile=nil;text="";savedText="";bda=nil
        panel=CGSize(width:1080,height:642);keys=[];blankPreview=false
        renderer.resetSelection();renderer.prepare(archive);bdaColor="light";bdaOrientation="port"
        documentRevision += 1
        animationText="";animationSaved="";animationSourceFiles=[:]
        files=archive.files;cachedPanelFiles=archive.panelFiles;fileRevision += 1
        relativeNames=Dictionary(files.map{($0,OriginalSkinDocument.relative($0, root: folder))},uniquingKeysWith:{_,new in new})
        importPreparedOffMain=archive.backgroundPrepared
        if filename.lowercased().hasSuffix(".bda") || archive.usesConfigPreview {
            let engine=BdaPreviewEngine(root:folder,files:files)
            engine.prepareConfigurations(archive.configurations,errors:archive.configurationErrors);bda=engine;reloadBda()
        }else if let first=archive.firstLayout{try open(first)}
        else{keys=[];blankPreview=true;previewNote="未找到可预览布局，请打开文件查看配置"}
    }
    func saveSession(_ view: EditorViewState, recordFile: URL = OriginalSkinDocument.sessionFile) async throws {
        guard !busy else { throw SkinFailure(message: "正在处理文件，请稍候") }
        guard !requiresSaveDestination else { throw SkinFailure(message: "请通过保存按钮选择原文件位置并确认替换") }
        guard saveAnimationSource() else { throw SkinFailure(message: "请先修正动效代码") }
        try save()
        guard let root, let originalURL, let originalBookmark else { throw SkinFailure(message: "请先导入原皮肤文件") }
        if filename.lowercased().hasSuffix(".bda") { _ = try BdaTextSync.synchronize(files: files) }
        busy = true; defer { busy = false }
        let bookmark: Data
        do {
            bookmark = try await Task.detached {
                let destination = try OriginalSkinDocument.resolve(originalBookmark)
                let access = DocumentAccess(destination); defer { access.close() }
                try OriginalSkinDocument.overwrite(root: root, original: destination)
                return try OriginalSkinDocument.bookmark(destination)
            }.value
        } catch { requiresSaveDestination = true; throw error }
        self.originalBookmark = bookmark
        let record = EditorResumeRecord(bookmark: bookmark, filename: filename,
            current: current.map(relative) ?? "", preview: layoutFile.map(relative) ?? "", view: view)
        try OriginalSkinDocument.write(record, at: recordFile)
    }
    func overwriteSelectedOriginal(_ destination: URL, view: EditorViewState,
                                   recordFile: URL = OriginalSkinDocument.sessionFile) async throws {
        guard !busy, let root, requiresSaveDestination else { throw SkinFailure(message: "请先导入皮肤文件") }
        guard destination.lastPathComponent == filename else { throw SkinFailure(message: "请选择同名原文件：" + filename) }
        guard saveAnimationSource() else { throw SkinFailure(message: "请先修正动效代码") }
        try save()
        let access = destination.startAccessingSecurityScopedResource()
        defer { if access { destination.stopAccessingSecurityScopedResource() } }
        if filename.lowercased().hasSuffix(".bda") { _ = try BdaTextSync.synchronize(files: files) }
        busy = true; defer { busy = false }
        try await Task.detached(priority: .userInitiated) {
            try OriginalSkinDocument.overwrite(root: root, original: destination)
        }.value
        originalURL = destination; originalBookmark = try OriginalSkinDocument.bookmark(destination); requiresSaveDestination = false
        let record = EditorResumeRecord(bookmark: originalBookmark!, filename: filename,
            current: current.map(relative) ?? "", preview: layoutFile.map(relative) ?? "", view: view)
        try OriginalSkinDocument.write(record, at: recordFile)
    }
    func prepareCopySave() async throws -> URL {
        guard !busy, let root else { throw SkinFailure(message: "请先导入文件") }
        guard saveAnimationSource() else { throw SkinFailure(message: "请先修正动效代码") }
        try save()
        if filename.lowercased().hasSuffix(".bda") { _ = try BdaTextSync.synchronize(files: files) }
        let name = filename
        busy = true; defer { busy = false }
        return try await Task.detached(priority: .userInitiated) {
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let url = folder.appendingPathComponent(name)
            do { try FileManager.default.zipItem(at: root, to: url, shouldKeepParent: false); return url }
            catch { try? FileManager.default.removeItem(at: folder); throw error }
        }.value
    }
    func finishCopySave(_ view: EditorViewState, recordFile: URL = OriginalSkinDocument.sessionFile) throws {
        guard requiresSaveDestination, let root,
              try OriginalSkinDocument.cachedRoot(root.lastPathComponent) == root.resolvingSymlinksInPath() else {
            throw SkinFailure(message: "文件已保存，当前编辑记录无法恢复，请重新导入该文件")
        }
        // The external save is completed by UIDocumentPicker. This records only
        // the editor state and references the existing unpacked working folder.
        // Never treat the system's imported temporary copy as the original file.
        let record = EditorResumeRecord(version: 2, bookmark: Data(), filename: filename,
            current: current.map(relative) ?? "", preview: layoutFile.map(relative) ?? "", view: view,
            workingDirectory: root.lastPathComponent)
        try OriginalSkinDocument.write(record, at: recordFile)
    }
    func finishExportSave(_ view: EditorViewState, recordFile: URL = OriginalSkinDocument.sessionFile) throws {
        // Export returns a destination URL, not permission to modify it again.
        // Keep the latest local edits and present the system save panel next time.
        originalURL = nil; originalBookmark = nil; requiresSaveDestination = true
        try saveWorkingSession(view, recordFile: recordFile)
    }
    @discardableResult func restoreSession(recordFile: URL = OriginalSkinDocument.sessionFile) async throws -> EditorViewState? {
        guard FileManager.default.fileExists(atPath: recordFile.path) else { return nil }
        guard !busy else { return nil }
        busy = true; restoringSession = true
        defer { busy = false; restoringSession = false }
        let data = try Data(contentsOf: recordFile)
        guard data.count <= 1024*1024 else { throw SkinFailure(message: "保存的编辑记录无效") }
        let record = try JSONDecoder().decode(EditorResumeRecord.self, from: data)
        guard (1...3).contains(record.version) else { throw SkinFailure(message: "保存的编辑记录版本无效") }
        let original: URL?
        let archive: PreparedSkinArchive
        if record.version == 2 || record.version == 3 {
            guard (record.version == 3 || record.bookmark.isEmpty), let name = record.workingDirectory else { throw SkinFailure(message: "保存的编辑记录无效") }
            let cached = try OriginalSkinDocument.cachedRoot(name)
            archive = try await Task.detached(priority: .userInitiated) { try PreparedSkinArchive.index(cached) }.value
            original = record.version == 3 ? try? OriginalSkinDocument.resolve(record.bookmark) : nil
        } else {
            let url = try OriginalSkinDocument.resolve(record.bookmark)
            archive = try await Task.detached(priority:.userInitiated) { try PreparedSkinArchive.open(url) }.value
            original = url
        }
        let folder=archive.folder
        let edited = try OriginalSkinDocument.restoredPath(record.current, archive: archive)
        let preview = try OriginalSkinDocument.restoredPath(record.preview, archive: archive)
        try adopt(archive, filename: original?.lastPathComponent ?? record.filename)
        // Older releases saved a standalone CND after a tap on the combined
        // bar. Recover the linked keyboard when restoring that editing session.
        let restoredPreview = preview == nil || preview == renderer.candidateFile ? layoutFile : preview
        if let edited { try open(edited) }
        layoutFile = restoredPreview; bdaColor = record.view.color; bdaOrientation = record.view.orientation
        if let bda { bda.panelID = record.view.panel; bda.animationChoice = record.view.animation }
        refresh()
        renderer.hasCandidates = record.view.hasCandidates; renderer.candidateChoice = record.view.candidate
        renderer.floatingChoice = record.view.floating; renderer.animationEvent = record.view.event
        refresh()
        renderer.animationEnabled = record.view.effect == "key"
        if !record.view.effect.isEmpty { loadAnimationSource(record.view.selected, floating: record.view.effect == "floating") }
        if record.view.floatingPaused { renderer.floatingPausedAt = Date() }
        originalURL = original
        requiresSaveDestination = original == nil
        if let original {
            let access = original.startAccessingSecurityScopedResource()
            defer { if access { original.stopAccessingSecurityScopedResource() } }
            originalBookmark = try OriginalSkinDocument.bookmark(original)
        } else { originalBookmark = nil }
        var view = record.view
        if restoredPreview != preview { view.zoom = 1; view.panX = 0; view.panY = 0 }
        if edited == nil && !record.current.isEmpty { view.selected = ""; view.selection = [] }
        restoredView = view; documentRevision += 1; resumeRevision = documentRevision
        var repaired = record
        repaired.current = current.map(relative) ?? ""
        repaired.preview = layoutFile.map(relative) ?? ""
        repaired.view = view
        if let originalBookmark { repaired.bookmark = originalBookmark }
        try OriginalSkinDocument.write(repaired, at: recordFile)
        return view
    }
    func saveWorkingSession(_ view: EditorViewState, recordFile: URL = OriginalSkinDocument.sessionFile, alreadySaved: Bool = false) throws {
        guard let root else { return }
        if !alreadySaved {
            guard saveAnimationSource() else { throw SkinFailure(message: "请先修正动效代码") }
            try save()
        }
        guard try OriginalSkinDocument.cachedRoot(root.lastPathComponent) == root.resolvingSymlinksInPath() else {
            throw SkinFailure(message: "当前编辑目录无效")
        }
        let bookmark = requiresSaveDestination ? nil : originalBookmark
        let record = EditorResumeRecord(version: bookmark == nil ? 2 : 3, bookmark: bookmark ?? Data(), filename: filename,
            current: current.map(relative) ?? "", preview: layoutFile.map(relative) ?? "", view: view, workingDirectory: root.lastPathComponent)
        try OriginalSkinDocument.write(record, at: recordFile)
    }
    func clearHistoryCache(_ view: EditorViewState) async throws -> Int {
        guard !busy else { throw SkinFailure(message: "正在处理文件，请稍候") }
        try saveWorkingSession(view)
        busy = true; defer { busy = false }
        soundPreview.clear()
        let root = root, original = originalURL
        return try await Task.detached(priority: .utility) {
            try HistoryCache.clear(documents: FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0],
                temporary: FileManager.default.temporaryDirectory, keeping: root, original: original)
        }.value
    }
    func relative(_ url: URL) -> String {
        if let cached=relativeNames[url]{return cached}
        guard let root else { return url.lastPathComponent }
        let base = root.resolvingSymlinksInPath().pathComponents
        let path = url.resolvingSymlinksInPath().pathComponents
        guard path.starts(with: base) else { return url.lastPathComponent }
        return path.dropFirst(base.count).joined(separator: "/")
    }
    func rescan(){
        guard let root,let iterator=FileManager.default.enumerator(at:root,includingPropertiesForKeys:[.isRegularFileKey]) else{return}
        let updated=iterator.compactMap{$0 as? URL}.filter{(try? $0.resourceValues(forKeys:[.isRegularFileKey]).isRegularFile)==true}.sorted{$0.path<$1.path}
        let inventoryChanged = updated != files
        files=updated;cachedPanelFiles=SkinConfiguration.panelFiles(files)
        relativeNames=Dictionary(files.map{($0,OriginalSkinDocument.relative($0, root: root))},uniquingKeysWith:{_,new in new})
        fileRevision += 1;renderer.invalidatePrepared(files)
        if inventoryChanged, let previous=bda {
            let engine=BdaPreviewEngine(root:root,files:files)
            engine.panelID=previous.panelID;engine.animationChoice=previous.animationChoice;bda=engine
        }else{bda?.invalidatePreparedConfigurations()}
        refresh()
    }
    func deleteArchiveFile(_ file: URL) async throws {
        try await deleteArchiveFiles([file])
    }
    @discardableResult func copyArchiveFile(_ file: URL) async throws -> URL {
        guard !busy, let root else { throw SkinFailure(message: "请先打开文件，或等待当前操作完成") }
        guard saveAnimationSource() else { throw SkinFailure(message: "请先修正动效代码") }
        try save()
        busy = true; defer { busy = false }
        let (copy, archive) = try await Task.detached(priority: .userInitiated) {
            let copy = try ArchiveFiles.copyFile(file, root: root)
            do { return (copy, try PreparedSkinArchive.index(root)) }
            catch { try? FileManager.default.removeItem(at: copy); throw error }
        }.value
        applyArchiveFileChanges(archive)
        return copy
    }
    func deleteArchiveFiles(_ files: [URL]) async throws {
        guard !busy, let root else { throw SkinFailure(message: "请先打开文件，或等待当前操作完成") }
        guard !files.isEmpty else { return }
        guard saveAnimationSource() else { throw SkinFailure(message: "请先修正动效代码") }
        try save()
        busy = true; defer { busy = false }
        let deleted = Set(try await Task.detached(priority: .userInitiated) { try ArchiveFiles.removeFiles(files, root: root) }.value)
        if let current, deleted.contains(current.resolvingSymlinksInPath().standardizedFileURL) {
            self.current = nil; text = ""; savedText = ""; undoStack = []; redoStack = []
        }
        if let layoutFile, deleted.contains(layoutFile.resolvingSymlinksInPath().standardizedFileURL) { self.layoutFile = nil }
        animationText = ""; animationSaved = ""; animationSourceFiles = [:]
        restoredView = nil; resumeRevision = nil
        let archive = try await Task.detached(priority: .userInitiated) { try PreparedSkinArchive.index(root) }.value
        applyArchiveFileChanges(archive)
        if bda == nil {
            if layoutFile == nil { layoutFile = cachedPanelFiles.first }
            if current == nil, let layoutFile { try open(layoutFile) } else { refresh() }
        }
        documentRevision += 1
    }
    private func applyArchiveFileChanges(_ archive: PreparedSkinArchive) {
        renderer.prepare(archive); files = archive.files; cachedPanelFiles = archive.panelFiles
        relativeNames = Dictionary(files.map { ($0, SkinConfiguration.relative($0, root: archive.folder)) }, uniquingKeysWith: { _, new in new })
        if let previous = bda {
            let engine = BdaPreviewEngine(root: archive.folder, files: files)
            engine.prepareConfigurations(archive.configurations, errors: archive.configurationErrors)
            engine.panelID = previous.panelID; engine.animationChoice = previous.animationChoice; bda = engine
        }
        fileRevision += 1; soundPreview.clear(); refresh()
    }
    @discardableResult func renameArchiveEntry(_ entry: URL, to name: String) async throws -> ArchiveRename {
        guard !busy, let root else { throw SkinFailure(message: "请先打开文件，或等待当前操作完成") }
        guard saveAnimationSource() else { throw SkinFailure(message: "请先修正动效代码") }
        try save()
        busy = true; defer { busy = false }
        let (rename, archive) = try await Task.detached(priority: .userInitiated) {
            let rename = try ArchiveFiles.rename(entry, to: name, root: root)
            do { return (rename, try PreparedSkinArchive.index(root)) }
            catch {
                if rename.original.path != rename.destination.path {
                    try? FileManager.default.moveItem(at: rename.destination, to: rename.original)
                }
                throw error
            }
        }.value
        current = current.map(rename.relocated); layoutFile = layoutFile.map(rename.relocated)
        animationSourceFiles = animationSourceFiles.mapValues(rename.relocated)
        renderer.prepare(archive)
        files = archive.files; cachedPanelFiles = archive.panelFiles
        relativeNames = Dictionary(files.map { ($0, SkinConfiguration.relative($0, root: root)) }, uniquingKeysWith: { _, new in new })
        if let previous = bda {
            let engine = BdaPreviewEngine(root: root, files: files)
            engine.prepareConfigurations(archive.configurations, errors: archive.configurationErrors)
            engine.panelID = previous.panelID; engine.animationChoice = previous.animationChoice; bda = engine
        }
        restoredView = nil; resumeRevision = nil; fileRevision += 1
        soundPreview.clear(); refresh()
        return rename
    }
    var defaultResourceDirectory: URL? {
        guard let root else { return nil }
        return (layoutFile?.deletingLastPathComponent() ?? root).appendingPathComponent("res",isDirectory:true)
    }
    func importResources(_ batch:ResourceBatch,into requested:URL?,policy:ResourceImport.ConflictPolicy) async throws -> Int {
        guard !busy,!batch.files.isEmpty else { return 0 }
        guard saveAnimationSource() else { throw SkinFailure(message:"请先修正动效代码") };try save()
        busy=true;defer{busy=false}
        if let root {
            let folder=requested ?? defaultResourceDirectory ?? root
            let parent=folder.deletingLastPathComponent().resolvingSymlinksInPath()
            if !FileManager.default.fileExists(atPath:folder.path) {
                _=try ArchiveFiles.directory(parent,root:root)
                try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:false)
            }
            let (written, archive) = try await Task.detached(priority: .userInitiated) {
                let written = try ResourceImport.insert(batch.files, into: folder, root: root, policy: policy)
                return (written, try PreparedSkinArchive.index(root))
            }.value
            renderer.prepare(archive); files = archive.files; cachedPanelFiles = archive.panelFiles
            importPreparedOffMain = archive.backgroundPrepared
            relativeNames = Dictionary(files.map { ($0, SkinConfiguration.relative($0, root: root)) }, uniquingKeysWith: { _, new in new })
            if let previous = bda {
                let engine = BdaPreviewEngine(root: root, files: files)
                engine.prepareConfigurations(archive.configurations, errors: archive.configurationErrors)
                engine.panelID = previous.panelID; engine.animationChoice = previous.animationChoice; bda = engine
            }
            fileRevision += 1; soundPreview.clear()
            if let current, written.contains(current) { try openForEditing(current) } else { refresh() }
            return written.count
        }
        // A shared drawing can arrive before a skin has been opened. Keep it in
        // an ordinary editable ZIP, which the Save button exports to Files.
        let folder=FileManager.default.urls(for:.documentDirectory,in:.userDomainMask)[0].appendingPathComponent(UUID().uuidString,isDirectory:true)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        do {
            let prepared=try await Task.detached(priority:.userInitiated){
                _=try ResourceImport.insert(batch.files,into:folder,root:folder,policy:policy)
                return try PreparedSkinArchive.index(folder)
            }.value
            try adopt(prepared,filename:"素材.zip")
            originalURL=nil;originalBookmark=nil;requiresSaveDestination=true
            restoredView=nil;resumeRevision=nil;error=nil
            return batch.files.count
        }catch{try? FileManager.default.removeItem(at:folder);throw error}
    }
    // Opening shared source changes the editor, not the keyboard composition.
    // A panel chosen explicitly through open(_:) can still be previewed alone.
    func openForEditing(_ url: URL) throws {
        let previous = layoutFile
        let candidate = renderer.candidateChoice
        let linkedCandidates = renderer.candidateNames
        let name = url.lastPathComponent.lowercased()
        let shared = url.pathExtension.lowercased() == "cnd" || ["gen.ini", "anim.ini", "event.ini"].contains(name)
        try open(url)
        if let previous, previous.pathExtension.lowercased() == "ini", shared {
            // Preserve an explicitly selected candidate variant when opening its
            // source; open(_:) resets renderer selection for standalone panels.
            renderer.candidateChoice = linkedCandidates.first {
                ($0 as NSString).deletingPathExtension.lowercased() == url.deletingPathExtension().lastPathComponent.lowercased()
            } ?? candidate
            layoutFile = previous; refresh()
        }
    }
    func editCandidateBar() throws {
        guard let file = renderer.candidateFile else { return }
        try openForEditing(file)
    }
    func editPreviewKeyboard() throws {
        guard let file = layoutFile, current != file else { return }
        try open(file)
    }
    @discardableResult func removeUnusedCSS() async throws -> Int {
        guard !busy, let root, let current, current.pathExtension.lowercased() == "css" else {
            throw SkinFailure(message: "请先打开 CSS 文件")
        }
        guard saveAnimationSource() else { throw SkinFailure(message: "请先修正动效代码") }
        try save()
        let original = text, inventory = files
        busy = true; defer { busy = false }
        let result = try await Task.detached(priority: .userInitiated) {
            try CSSCleanup.prepare(original, file: current, root: root, files: inventory)
        }.value
        change(result.text)
        return result.cleared.count
    }
    func open(_ url: URL) throws {
        if !restoringSession { restoredView = nil; resumeRevision = nil }
        guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
        try save()
        guard ["ini","css","txt","json","til","cnd","pop","anim","ani"].contains(url.pathExtension.lowercased()) else { throw SkinFailure(message: "该文件原样保留；当前编辑器只打开文本配置") }
        let data = try Data(contentsOf: url)
        guard data.count <= 2*1024*1024 else { throw SkinFailure(message: "文本超过 2 MB") }
        guard let decoded=SkinConfiguration.decode(data) else { throw SkinFailure(message: "无法识别文本编码，未修改文件") }
        encoding=decoded.encoding
        current = URL(fileURLWithPath: url.path, isDirectory: false); text = decoded.text; savedText = decoded.text
        if ["ini","cnd","pop"].contains(url.pathExtension.lowercased()){layoutFile=url;panel=CGSize(width:1080,height:642)}
        animationText="";animationSaved="";animationSourceFiles=[:];renderer.resetSelection();documentRevision+=1
        undoStack.removeAll(); redoStack.removeAll(); refresh()
    }
    private var linkedBinaryText:Bool {
        guard filename.lowercased().hasSuffix(".bda"),let current,["json","txt"].contains(current.pathExtension.lowercased()) else{return false}
        return ["appearanceconfig","layoutconfig","animationconfig","sceneconfig","soundconfig"].contains(current.deletingPathExtension().lastPathComponent.lowercased())
    }
    func save() throws {
        flushSourcePreview()
        guard let current else { return }
        guard text != savedText else { return }
        guard FileManager.default.fileExists(atPath: current.deletingLastPathComponent().path) else {
            throw SkinFailure(message: "当前编辑目录已失效。请先复制未保存的代码，再重新导入皮肤。")
        }
        guard let data = text.data(using: encoding, allowLossyConversion: false) else { throw SkinFailure(message: "当前编码不能保存输入内容") }
        let original=try Data(contentsOf:current)
        do {
            try data.write(to: current, options: .atomic)
            if linkedBinaryText{_=try BdaTextSync.synchronize(files:files)}
        }catch{try? original.write(to:current,options:.atomic);throw error}
        renderer.invalidatePrepared([current]);if linkedBinaryText{bda?.invalidatePreparedConfigurations()}
        savedText = text
    }
    func refresh(preservingResources: Bool = false, preparedBda: PreparedEditorPreview? = nil) {
        if bda != nil { blankPreview = false; reloadBda(preservingResources: preservingResources, prepared: preparedBda);return }
        keys = []; blankPreview = true
        guard let layoutFile else { previewNote = "选择 INI 布局预览"; return }
        let layoutText = current == layoutFile ? text : (IniSkinRenderer.read(layoutFile) ?? "")
        renderer.configure(root: root, config: layoutFile, files: files, text: layoutText, overrides:current.map{[$0:text]} ?? [:], parsedOverrides:current.map{[$0:parsedText]} ?? [:], preservingResources:preservingResources)
        let sections = renderer.effectiveSections
        panel=PanelMetrics.size(sections)
        if layoutFile.pathExtension.lowercased()=="cnd",renderer.candidateSize.width>0{panel=renderer.candidateSize}
        var nextKeys:[KeyShape]=[]
        for (index, s) in sections.enumerated() {
            if !renderer.visible(s){continue}
            if s.name=="CAND" && layoutFile.pathExtension.lowercased()=="ini" && !(s.values["LAYOUT_NAME"] ?? "").isEmpty{continue}
            guard let rect=IniGeometry.bounds(s,panel:panel) else{continue}
            let action=s.values["CENTER"] ?? s.values["KEY"] ?? s.name
            let label=PreviewLabels.caption(action)
            nextKeys.append(KeyShape(id:index,name:s.name,rect:rect,caption:label))
        }
        keys=nextKeys
        blankPreview = layoutFile.pathExtension.lowercased() == "ini" && !keys.contains { $0.name.range(of: "^KEY[0-9]+$", options: .regularExpression) != nil }
        if blankPreview { keys = []; previewNote = ""; return }
        refreshAnimationDraft(rendererReloaded: true)
        previewNote = renderer.hasStyles ? "INI 样式预览" : "布局线框 · 当前配置未找到 CSS 样式"
    }
    func export() throws -> URL {
        guard saveAnimationSource() else{throw SkinFailure(message:"请先修正动效代码")}
        try save()
        guard let root else { throw SkinFailure(message: "请先导入") }
        if filename.lowercased().hasSuffix(".bda"){_=try BdaTextSync.synchronize(files:files)}
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let url = folder.appendingPathComponent(filename)
        try FileManager.default.zipItem(at: root, to: url, shouldKeepParent: false)
        return url
    }
    func reloadBda(preservingResources: Bool = false, prepared: PreparedEditorPreview? = nil) {
        var drafts:[URL:Data]=prepared?.overrides ?? [:]
        if prepared?.overrides == nil, linkedBinaryText,text != savedText,let current {
            do{drafts=try BdaTextSync.preview(file:current,text:text,files:files)}
            catch{return}
        }
        bda?.load(color:bdaColor,orientation:bdaOrientation,overrides:drafts,preparedDrafts:prepared?.configurations ?? [:],preservingResources:preservingResources);syncBda()
    }
    func syncBda() {
        guard let bda else{return}
        panel=bda.size
        keys=(bda.panel?.items ?? []).enumerated().compactMap { i,item in
            guard item.kind=="keys",item.visible,let rect=item.rect else{return nil}
            return KeyShape(id:i,name:item.id,rect:rect,caption:"")
        }
        previewNote=keys.isEmpty ? "未恢复布局 · 查看解析日志":((bda.panel?.items.contains{$0.source=="semanticInference" || $0.source=="fallback"}) == true ? "推算布局 · 调试可查看坐标来源":"BDA 布局预览")
        objectWillChange.send()
    }
    func batch(_ names: [String], operation: String, factor: Double = 1) {
        let sections=Self.parse(text)
        var replacements:[String:[String:String]]=[:]
        func format(_ values:[CGFloat]) -> String { values.map{String(Int(floor($0+0.5)))}.joined(separator:",") }
        if operation=="scale" {
            guard factor.isFinite,(0.1...5).contains(factor) else { error="倍数须在 0.1 至 5 之间";return }
            for s in sections { for (key,value) in s.values where ["VIEW_RECT","TOUCH_RECT","SIZE","POS","PADDING","ICON_ON_SWITCH_SIZE","ICON_ON_SWITCH_POS"].contains(key) {
                let values=Self.numbers(value).map{$0*CGFloat(factor)}
                if !values.isEmpty,values.allSatisfy({abs($0)<1e12}) { replacements[s.name,default:[:]][key]=format(values) }
            }}
        } else {
            let chosen=names.compactMap{name in sections.first{$0.name==name}}
            guard chosen.count>=2 else { error="请多选至少两个按键";return }
            let base=Self.numbers(chosen[0].values["VIEW_RECT"])
            guard base.count==4 else { error="首个按键没有有效 VIEW_RECT";return }
            if operation=="swap" {
                guard chosen.count==2 else { error="交换需要恰好两个按键";return }
                for i in 0..<2 {
                    let other=chosen[1-i]
                    replacements[chosen[i].name] = ["VIEW_RECT":other.values["VIEW_RECT"] ?? "", "TOUCH_RECT":other.values["TOUCH_RECT"] ?? other.values["VIEW_RECT"] ?? ""]
                }
            } else {
                let axis=operation=="left" ? 0:1
                for s in chosen {
                    var r=Self.numbers(s.values["VIEW_RECT"])
                    guard r.count==4 else { continue }
                    let delta=base[axis]-r[axis];r[axis]=base[axis]
                    replacements[s.name,default:[:]]["VIEW_RECT"]=format(r)
                    var touch=Self.numbers(s.values["TOUCH_RECT"])
                    if touch.count==4 { touch[axis]+=delta;replacements[s.name,default:[:]]["TOUCH_RECT"]=format(touch) }
                }
            }
        }
        var section="", seen=Set<String>(), lines:[String]=[]
        func appendMissing() {
            for (key,value) in (replacements[section] ?? [:]).sorted(by:{$0.key<$1.key}) where !seen.contains(key) { lines.append(key+"="+value) }
        }
        for raw in text.components(separatedBy:"\n") {
            let line=raw.trimmingCharacters(in:.whitespacesAndNewlines)
            if line.hasPrefix("["),let end=line.firstIndex(of:"]") { appendMissing();seen=[];section=String(line[line.index(after:line.startIndex)..<end]).uppercased();lines.append(raw);continue }
            guard let equal=raw.firstIndex(of:"=") else { lines.append(raw);continue }
            let key=raw[..<equal].trimmingCharacters(in:.whitespaces).uppercased()
            seen.insert(key)
            guard let value=replacements[section]?[key] else { lines.append(raw);continue }
            lines.append(String(raw[...equal])+value+(raw.hasSuffix("\r") ? "\r":""))
        }
        appendMissing()
        change(lines.joined(separator:"\n"))
    }
    func generatePlaintext() {
        do {
            guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
            try save()
            var count = 0, logs: [String] = []
            for file in files where ["appearanceconfig", "layoutconfig", "animationconfig", "sceneconfig", "soundconfig"].contains(file.lastPathComponent.lowercased()) {
                do {
                    let data = try BinaryPlaintext.decode(file)
                    var output = file.appendingPathExtension("decoded.json"), index = 2
                    while FileManager.default.fileExists(atPath: output.path) {
                        output = file.appendingPathExtension("decoded-\(index).json"); index += 1
                    }
                    try data.write(to: output, options: .atomic); files.append(output)
                    count += 1; logs.append(relative(output))
                } catch { logs.append(relative(file) + "：" + error.localizedDescription) }
            }
            files.sort { $0.path < $1.path }
            error = "已生成 \(count) 份明文副本\n" + logs.joined(separator: "\n") + "\n点击顶部文件名查看。原二进制保持不变。"
        } catch { self.error = error.localizedDescription }
    }
    var canConvert: Bool { root != nil && ["bds","bdi"].contains((filename as NSString).pathExtension.lowercased()) }
    func convertSystem() throws -> URL {
        guard canConvert, let root else { throw SkinFailure(message:"仅支持 BDS / BDI") }
        try save()
        guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
        let target=try SystemMigration.convert(root:root,files:files)
        let ios=SystemMigration.allFiles(target).filter{$0.lastPathComponent.lowercased()=="info.txt"}.contains { (IniSkinRenderer.read($0) ?? "").contains("SupportPlatform=I") }
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        let output=directory.appendingPathComponent((filename as NSString).deletingPathExtension + (ios ? "_iOS.bdi":"_Android.bds"))
        try FileManager.default.zipItem(at:target,to:output,shouldKeepParent:false)
        return output
    }
    func convertLandscape(width: Int) {
        do {
            guard canConvert, let root else { throw SkinFailure(message:"仅支持 BDS / BDI") }
            try save()
            guard saveAnimationSource() else{throw SkinFailure(message:"动效代码未保存")}
            let previous = current.map(relative) ?? "port/py_26.ini"
            let target = try SkinTools.landscape(root:root,files:files,width:width)
            self.root = target; current = nil; layoutFile = nil; text = ""
            animationText="";animationSaved="";animationSourceFiles=[:];renderer.resetSelection();documentRevision+=1
            files = (FileManager.default.enumerator(at:target,includingPropertiesForKeys:[.isRegularFileKey])?.allObjects as? [URL] ?? []).filter { (try? $0.resourceValues(forKeys:[.isRegularFileKey]).isRegularFile) == true }.sorted{$0.path < $1.path}
            var parts = previous.components(separatedBy:"/")
            if let index = parts.firstIndex(where:{$0.lowercased()=="port"}) { parts[index] = "land" }
            let preferred = parts.joined(separator:"/")
            let first = files.first(where:{relative($0)==preferred}) ?? files.first(where:{$0.path.contains("/land/") && $0.pathExtension=="ini"})
            if let first { try open(first) }
        } catch { self.error = error.localizedDescription }
    }
}
