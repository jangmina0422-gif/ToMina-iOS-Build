import Foundation

/// Keep the security scope alive across dismissal of the picker and async work.
final class DocumentAccess {
    let url: URL
    private var active: Bool
    init(_ url: URL) { self.url = url; active = url.startAccessingSecurityScopedResource() }
    func close() { if active { active = false; url.stopAccessingSecurityScopedResource() } }
    deinit { close() }
}

enum HistoryCache {
    static func clear(documents: URL, temporary: URL, keeping current: URL?, original: URL? = nil) throws -> Int {
        let fm = FileManager.default
        let documents = documents.resolvingSymlinksInPath().standardizedFileURL
        let temporary = temporary.resolvingSymlinksInPath().standardizedFileURL
        let keys: Set<URLResourceKey> = [.isDirectoryKey, .isSymbolicLinkKey, .contentModificationDateKey]
        let children = try fm.contentsOfDirectory(at: documents, includingPropertiesForKeys: Array(keys))
        let histories = children.filter {
            guard UUID(uuidString: $0.lastPathComponent) != nil,
                  let values = try? $0.resourceValues(forKeys: keys) else { return false }
            return values.isDirectory == true && values.isSymbolicLink != true
        }
        let latest = current ?? histories.max {
            ((try? $0.resourceValues(forKeys: keys).contentModificationDate) ?? .distantPast) <
            ((try? $1.resourceValues(forKeys: keys).contentModificationDate) ?? .distantPast)
        }
        let protected = [latest, original].compactMap { $0?.resolvingSymlinksInPath().standardizedFileURL }
        func protectedItem(_ item: URL) -> Bool {
            let parts = item.resolvingSymlinksInPath().standardizedFileURL.pathComponents
            return protected.contains { $0.pathComponents.starts(with: parts) }
        }
        func remove(_ item: URL, under parent: URL) throws -> Bool {
            guard item.resolvingSymlinksInPath().deletingLastPathComponent() == parent,
                  !protectedItem(item) else { return false }
            try fm.removeItem(at: item); return true
        }
        var count = 0
        for item in histories { if try remove(item, under: documents) { count += 1 } }
        for item in try fm.contentsOfDirectory(at: temporary, includingPropertiesForKeys: [.isSymbolicLinkKey]) {
            let name = item.lastPathComponent
            let owned = UUID(uuidString: item.deletingPathExtension().lastPathComponent) != nil ||
                ["resource-", "archive-delete-"].contains { prefix in
                    name.hasPrefix(prefix) && UUID(uuidString: String(name.dropFirst(prefix.count))) != nil
                }
            if owned, try item.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink != true,
               try remove(item, under: temporary) { count += 1 }
        }
        return count
    }
}
