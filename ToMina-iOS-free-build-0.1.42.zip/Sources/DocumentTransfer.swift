import Foundation
import SwiftUI
import UIKit
import UniformTypeIdentifiers
import OSLog

enum SigningCompatibility {
    // This only chooses a public document-picker mode. It does not change or
    // validate the signature, provisioning profile, or access entitlements.
    static let prefersCopy: Bool = {
        guard let file = Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision"),
              let data = try? Data(contentsOf: file, options: .mappedIfSafe),
              let identifier = Bundle.main.bundleIdentifier else { return false }
        return prefersCopy(profile: data, bundleIdentifier: identifier)
    }()
    static func prefersCopy(profile: Data, bundleIdentifier: String) -> Bool {
        guard profile.count <= 4 * 1024 * 1024,
              let start = profile.range(of: Data("<plist".utf8)),
              let end = profile.range(of: Data("</plist>".utf8), in: start.lowerBound..<profile.endIndex),
              let object = try? PropertyListSerialization.propertyList(from: profile[start.lowerBound..<end.upperBound], format: nil) as? [String: Any],
              let entitlements = object["Entitlements"] as? [String: Any],
              let full = entitlements["application-identifier"] as? String,
              let separator = full.firstIndex(of: "."), !bundleIdentifier.isEmpty else { return false }
        let identifier = String(full[full.index(after: separator)...])
        guard !identifier.isEmpty else { return false }
        if identifier == "*" { return false }
        if identifier.hasSuffix(".*") { return !bundleIdentifier.hasPrefix(String(identifier.dropLast()) ) }
        return identifier != bundleIdentifier
    }
}

struct SkinPickerRequest: Identifiable {
    enum Action {
        case archive(asCopy: Bool)
        case resource(directory: URL?)
        case save(URL, EditorViewState)
        case overwrite(EditorViewState)
    }
    let id = UUID()
    let action: Action
    static func archive(asCopy: Bool) -> Self { Self(action: .archive(asCopy: asCopy)) }
    static var resource: Self { Self(action: .resource(directory: nil)) }
    static func resource(in directory: URL) -> Self { Self(action: .resource(directory: directory)) }
}

@MainActor struct SkinDocumentPicker: UIViewControllerRepresentable {
    let contentTypes: [UTType]
    let asCopy: Bool
    var exporting: URL? = nil
    var title: String? = nil
    let completion: (Result<URL?, Error>) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(completion: completion) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = Self.controller(contentTypes: contentTypes, asCopy: asCopy, exporting: exporting)
        picker.title = title
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        picker.shouldShowFileExtensions = true
        #if DEBUG
        // A fresh CI simulator has no remembered Files location. Point only
        // synthetic UI fixtures at their own document container.
        if exporting != nil && EditorUIFixture.requested {
            picker.directoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        }
        #endif
        return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    static func controller(contentTypes: [UTType], asCopy: Bool, exporting: URL? = nil) -> UIDocumentPickerViewController {
        if let exporting { return UIDocumentPickerViewController(forExporting: [exporting], asCopy: true) }
        return UIDocumentPickerViewController(forOpeningContentTypes: contentTypes, asCopy: asCopy)
    }
    @MainActor final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private let completion: (Result<URL?, Error>) -> Void
        private var completed = false
        private let logger = Logger(subsystem: "com.mina.tomina", category: "DocumentImport")
        init(completion: @escaping (Result<URL?, Error>) -> Void) { self.completion = completion }
        private func finish(_ result: Result<URL?, Error>) {
            guard !completed else { return }; completed = true; completion(result)
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            logger.info("Document picker completed, count: \(urls.count)")
            guard urls.count == 1, let url = urls.first, url.isFileURL else {
                finish(.failure(SkinFailure(message: "系统未返回可读取的文件，请重新导入或使用兼容导入"))); return
            }
            finish(.success(url))
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            logger.info("Document picker cancelled"); finish(.success(nil))
        }
    }
}
