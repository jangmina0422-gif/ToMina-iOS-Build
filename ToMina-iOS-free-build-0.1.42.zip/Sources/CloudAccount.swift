import Foundation
import SwiftUI
import UIKit
import Darwin

@MainActor final class CloudAccount: ObservableObject {
    @Published var authenticated = false
    @Published private(set) var busy = false
    @Published private(set) var hasSession = false
    @Published private(set) var connectionMessage = "正在恢复登录…"
    @Published var notice: String?
    private var token = ""
    private var verifiedAt = Date.distantPast
    private var heartbeatTask: Task<Void, Never>?
    private var generation = 0
    private var foreground = true
    private let storage: SessionTokenStore
    private let automaticHeartbeat: Bool
    private let session: URLSession
    private static func makeSession() -> URLSession {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 12
        configuration.timeoutIntervalForResource = 15
        configuration.httpShouldSetCookies = false
        return URLSession(configuration: configuration)
    }
    init(session: URLSession? = nil, storage: SessionTokenStore = KeychainSessionTokenStore(), automaticHeartbeat: Bool = true) {
        self.session = session ?? Self.makeSession()
        self.storage = storage
        self.automaticHeartbeat = automaticHeartbeat
        token = storage.load() ?? ""
        hasSession = !token.isEmpty
    }
    private static let base = URL(string: "https://candy.mina.center/api/auth/")!
    private struct LoginReply: Decodable { let token: String }
    enum Failure: LocalizedError, Equatable {
        case invalid, limit, busy, connection, storage
        var errorDescription: String? {
            switch self {
            case .invalid: return "账号或密码错误，或登录已失效"
            case .limit: return "在线设备已达上限，请先退出其他设备"
            case .busy: return "尝试过于频繁，请稍后再试"
            case .connection: return "连接失败，请检查网络后重试"
            case .storage: return "登录状态未能安全保存，请重试"
            }
        }
    }
    private func request(_ path: String, body: [String:String] = [:], token: String = "") async throws -> Data {
        var request = URLRequest(url: Self.base.appendingPathComponent(path))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if !token.isEmpty { request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization") }
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let data: Data, response: URLResponse
        do { (data,response) = try await session.data(for: request) }
        catch { throw Failure.connection }
        guard let http = response as? HTTPURLResponse, data.count < 16384 else { throw Failure.connection }
        switch http.statusCode {
        case 200: return data
        case 401,403: throw Failure.invalid
        case 409: throw Failure.limit
        case 429: throw Failure.busy
        default: throw Failure.connection
        }
    }
    private var deviceID: String {
        if let id = UserDefaults.standard.string(forKey:"cloudDeviceID") { return id }
        let id = UUID().uuidString
        UserDefaults.standard.set(id, forKey:"cloudDeviceID"); return id
    }
    private var deviceName: String {
        var info = utsname(); uname(&info)
        let code = withUnsafePointer(to: &info.machine) { pointer in
            pointer.withMemoryRebound(to: CChar.self, capacity: 1) { String(cString:$0) }
        }
        return UIDevice.current.model + " · " + code
    }
    func login(account: String, password: String) async throws {
        guard !busy else { throw Failure.busy }
        let revision = generation
        busy = true; defer { busy = false }
        let data = try await request("login",body:["account":account.trimmingCharacters(in:.whitespacesAndNewlines),
            "password":password,"device_id":deviceID,"device_name":deviceName,"platform":"ios",
            "os_version":UIDevice.current.systemVersion,
            "app_version":Bundle.main.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String ?? ""])
        let reply = try JSONDecoder().decode(LoginReply.self,from:data)
        guard reply.token.count >= 32 else { throw Failure.connection }
        guard revision == generation else { throw CancellationError() }
        do { try storage.save(reply.token) }
        catch { Task { _ = try? await request("logout", token: reply.token) }; throw error }
        token=reply.token;hasSession=true;verifiedAt=Date();authenticated=foreground;notice=nil
        startHeartbeat()
    }
    private func startHeartbeat() {
        heartbeatTask?.cancel()
        guard automaticHeartbeat, foreground, hasSession else { return }
        heartbeatTask=Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for:.seconds(20)) } catch { return }
                guard let self, self.foreground, self.hasSession else { return }
                await self.validate(requireFresh: !self.authenticated)
            }
        }
    }
    func resume() async {
        foreground = true
        guard hasSession else { return }
        await validate(requireFresh: !authenticated)
        startHeartbeat()
    }
    func suspend() {
        foreground = false
        authenticated = false
        heartbeatTask?.cancel(); heartbeatTask = nil
    }
    func validate(requireFresh: Bool = false) async {
        guard !busy, hasSession, foreground else { return }
        busy = true; defer { busy = false }
        let revision = generation
        let current = token
        do {
            _ = try await request("heartbeat",token:current)
            guard token == current, revision == generation else { return }
            verifiedAt=Date();authenticated=foreground;connectionMessage=""
        } catch {
            guard token == current, revision == generation else { return }
            if (error as? Failure) == .invalid {
                clearSession(); notice = "登录已失效，请重新登录"
            } else {
                // Offline and device-limit responses retain the token. The
                // editor stays locked until this device is admitted again.
                if requireFresh || (error as? Failure) == .limit || Date().timeIntervalSince(verifiedAt) > 75 {
                    authenticated = false
                }
                connectionMessage = (error as? Failure) == .limit ? Failure.limit.localizedDescription : "连接暂不可用，恢复后自动继续"
            }
        }
    }
    private func clearSession() {
        generation += 1
        heartbeatTask?.cancel();heartbeatTask=nil
        storage.clear();token="";hasSession=false;authenticated=false;verifiedAt = .distantPast
    }
    func logout() {
        let previous=token
        clearSession()
        if !previous.isEmpty { Task { _ = try? await request("logout",token:previous) } }
    }
}
