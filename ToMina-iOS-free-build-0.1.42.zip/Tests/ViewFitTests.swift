import XCTest
import ZIPFoundation
@testable import ToMina

final class ViewFitTests: XCTestCase {
    let text="[PANEL]\nSIZE=200,100\nKEY_NUM=2\n[KEY1]\nVIEW_RECT=0,0,98,100\nCENTER=文字\nUP=F12\nHOLD=F72\n[KEY2]\nVIEW_RECT=102,0,98,100\nCENTER=F38\n"
    func folder() throws -> URL {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
        return root
    }
    func testJavaScriptCoreMatchesNodeFixtureResults() throws {
        for name in ["plain","atlas"] {
            let file=try XCTUnwrap(Bundle(for:Self.self).url(forResource:name,withExtension:"json",subdirectory:"Fixtures/ViewFit"))
            let fixture=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:file)) as? [String:Any])
            let input=try XCTUnwrap(fixture["input"] as? [String:Any]), expected=try XCTUnwrap(fixture["expected"] as? [String:Any])
            let actual=try GlobalViewFit.evaluate(input)
            XCTAssertEqual(try JSONSerialization.data(withJSONObject:actual,options:.sortedKeys),try JSONSerialization.data(withJSONObject:expected,options:.sortedKeys))
        }
    }
    func testNativeFitPreservesEveryResourceByteAndIgnoresMissingPictures() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=root.appendingPathComponent("custom.ini")
        try (text+"[TIP1]\nFORE_STYLE=1\n").write(to:file,atomically:true,encoding:.utf8)
        let resources=["default.css":Data("[STYLE1]\nNM_IMG=missing,9\n".utf8),"broken.til":Data([0xff,0x00,0xfe]),"picture.png":Data([1,2,3,4,5])]
        for (name,bytes) in resources {try bytes.write(to:root.appendingPathComponent(name))}
        let result=try GlobalViewFit.run(root:root)
        XCTAssertEqual(result.changedFiles,1);XCTAssertFalse(result.report.contains("无法确定 · 保留原文件\ncustom.ini"))
        XCTAssertTrue(try String(contentsOf:file,encoding:.utf8).contains("VIEW_RECT=0,0,100,100"))
        for (name,bytes) in resources {XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent(name)),bytes)}
        XCTAssertFalse(FileManager.default.fileExists(atPath:root.appendingPathComponent("missing.png").path))
    }
    func testNativeWritesPreserveBOMEncodingActionsAndTouch() throws {
        for (encoding,bom) in [(String.Encoding.utf8,Data()),(.utf8,Data([0xef,0xbb,0xbf])),(.utf16LittleEndian,Data([0xff,0xfe])),(.utf16BigEndian,Data([0xfe,0xff])),(SkinConfiguration.gb,Data())] {
            let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
            let file=root.appendingPathComponent("any-language.ini"), original=bom+text.data(using:encoding)!
            try original.write(to:file)
            let report=try GlobalViewFit.run(root:root)
            XCTAssertEqual(report.changedFiles,1)
            let decoded=try GlobalViewFit.decode(Data(contentsOf:file))
            XCTAssertEqual(decoded.bom,bom);XCTAssertEqual(decoded.encoding,encoding)
            XCTAssertTrue(decoded.text.contains("TOUCH_RECT=0,0,98,100"))
            XCTAssertTrue(decoded.text.contains("VIEW_RECT=0,0,100,100"))
            XCTAssertTrue(decoded.text.contains("CENTER=文字\nUP=F12\nHOLD=F72"))
            XCTAssertEqual(try GlobalViewFit.run(root:root).changedFiles,0)
        }
    }
    func testConcurrentModificationRejectsEveryWrite() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let a=root.appendingPathComponent("a.ini"),b=root.appendingPathComponent("b.ini"),bytes=Data(text.utf8)
        try bytes.write(to:a);try bytes.write(to:b)
        let original=try GlobalViewFit.decode(bytes)
        try Data("changed externally".utf8).write(to:b)
        XCTAssertThrowsError(try GlobalViewFit.apply([["path":"a.ini","text":"new a"],["path":"b.ini","text":"new b"]],root:root,snapshot:["a.ini":original,"b.ini":original]))
        XCTAssertEqual(try Data(contentsOf:a),bytes)
        XCTAssertEqual(try String(contentsOf:b,encoding:.utf8),"changed externally")
    }
    func testNativePositionZeroPreservesCommasAndOtherFields() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=root.appendingPathComponent("candidate.cnd")
        let original="[ICON1]\r\nPOS_TYPE=7,3,46\r\nCENTER=F22\r\nVIEW_RECT=1,2,3,4\r\n"
        try original.write(to:file,atomically:true,encoding:.utf8)
        XCTAssertEqual(try GlobalViewFit.run(root:root,operation:"zeroPositionTypes").changedFiles,1)
        XCTAssertEqual(try String(contentsOf:file,encoding:.utf8),original.replacingOccurrences(of:"7,3,46",with:"0,0,0"))
        XCTAssertEqual(try GlobalViewFit.run(root:root,operation:"zeroPositionTypes").changedFiles,0)
    }
    func testUnsafeResultsAndSymlinksCannotWriteOutsideRoot() throws {
        let root=try folder(),outside=try folder();defer{try? FileManager.default.removeItem(at:root);try? FileManager.default.removeItem(at:outside)}
        let file=outside.appendingPathComponent("protected.ini");try Data(text.utf8).write(to:file)
        try FileManager.default.createSymbolicLink(at:root.appendingPathComponent("link.ini"),withDestinationURL:file)
        XCTAssertThrowsError(try GlobalViewFit.child("../escape.ini",root:root))
        XCTAssertThrowsError(try GlobalViewFit.child("link.ini",root:root))
        let result=try GlobalViewFit.run(root:root);XCTAssertEqual(result.changedFiles,0)
        XCTAssertEqual(try String(contentsOf:file,encoding:.utf8),text)
    }
    @MainActor func testPreviewCurrentDraftAndExportReopenShareAllPanelEdits() async throws {
        let fm=FileManager.default,base=try folder();defer{try? fm.removeItem(at:base)}
        let source=base.appendingPathComponent("input"),port=source.appendingPathComponent("port"),dark=source.appendingPathComponent("dark/land")
        try fm.createDirectory(at:port,withIntermediateDirectories:true);try fm.createDirectory(at:dark,withIntermediateDirectories:true)
        try text.write(to:port.appendingPathComponent("arbitrary.ini"),atomically:true,encoding:.utf8)
        try text.write(to:dark.appendingPathComponent("extra-symbols.ini"),atomically:true,encoding:.utf8)
        let archive=base.appendingPathComponent("global.bds");try fm.zipItem(at:source,to:archive,shouldKeepParent:false)
        let original=try Data(contentsOf:archive),store=SkinStore();await store.openArchive(archive)
        let root=try XCTUnwrap(store.root);defer{try? fm.removeItem(at:root)}
        try store.open(root.appendingPathComponent("port/arbitrary.ini"));store.text += "\n; latest draft\n"
        try await store.fitGlobalViews()
        XCTAssertTrue(store.text.contains("latest draft"));XCTAssertTrue(store.text.contains("VIEW_RECT=0,0,100,100"))
        XCTAssertEqual(store.keys.first(where:{$0.name=="KEY1"})?.rect.width,100)
        let exported=try store.export();defer{try? fm.removeItem(at:exported.deletingLastPathComponent())}
        let reopened=try OriginalSkinDocument.unpack(exported);defer{try? fm.removeItem(at:reopened)}
        for name in ["port/arbitrary.ini","dark/land/extra-symbols.ini"] {
            let saved=try String(contentsOf:reopened.appendingPathComponent(name),encoding:.utf8)
            XCTAssertTrue(saved.contains("VIEW_RECT=0,0,100,100"));XCTAssertTrue(saved.contains("TOUCH_RECT=102,0,98,100"))
        }
        XCTAssertEqual(try Data(contentsOf:archive),original)
    }
}
