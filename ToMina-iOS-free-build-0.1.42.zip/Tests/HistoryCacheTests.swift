import XCTest
import ZIPFoundation
@testable import ToMina

final class HistoryCacheTests: XCTestCase {
    func testClearKeepsLatestEditsOriginalAndUnrelatedFiles() throws {
        let fm = FileManager.default, base = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let docs = base.appendingPathComponent("Documents"), temp = base.appendingPathComponent("tmp")
        let latest = docs.appendingPathComponent(UUID().uuidString), old = docs.appendingPathComponent(UUID().uuidString)
        let external = base.appendingPathComponent("outside"), originalFolder = temp.appendingPathComponent(UUID().uuidString)
        for folder in [latest, old, temp, external, originalFolder] { try fm.createDirectory(at: folder, withIntermediateDirectories: true) }
        defer { try? fm.removeItem(at: base) }
        let original = originalFolder.appendingPathComponent("original.bds")
        try Data("original".utf8).write(to: original)
        try Data("latest edits".utf8).write(to: latest.appendingPathComponent("layout.ini"))
        let other = docs.appendingPathComponent("user.bds"); try Data("user".utf8).write(to: other)
        let staleExport = temp.appendingPathComponent(UUID().uuidString + ".zip"); try Data().write(to: staleExport)
        let link = docs.appendingPathComponent(UUID().uuidString); try fm.createSymbolicLink(at: link, withDestinationURL: external)
        XCTAssertEqual(try HistoryCache.clear(documents: docs, temporary: temp, keeping: latest, original: original), 2)
        XCTAssertTrue(fm.fileExists(atPath: latest.appendingPathComponent("layout.ini").path))
        XCTAssertTrue(fm.fileExists(atPath: other.path)); XCTAssertTrue(fm.fileExists(atPath: original.path))
        XCTAssertTrue(fm.fileExists(atPath: external.path)); XCTAssertFalse(fm.fileExists(atPath: old.path))
        XCTAssertFalse(fm.fileExists(atPath: staleExport.path))
        XCTAssertEqual(try HistoryCache.clear(documents: docs, temporary: temp, keeping: latest, original: original), 0)
    }
    @MainActor func testExportSaveFromOriginalKeepsNameEditsAndResumesLatestCopy() async throws {
        let fm = FileManager.default, base = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let skin = base.appendingPathComponent("skin/port")
        try fm.createDirectory(at: skin, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: base) }
        try "[PANEL]\nSIZE=720,400\n[KEY1]\nVIEW_RECT=0,0,40,40\nCENTER=q\n".write(to: skin.appendingPathComponent("py_26.ini"), atomically: true, encoding: .utf8)
        let original = base.appendingPathComponent("fixture.bds"), record = base.appendingPathComponent("resume.json")
        try fm.zipItem(at: skin.deletingLastPathComponent(), to: original, shouldKeepParent: false)
        let before = try Data(contentsOf: original), store = SkinStore()
        await store.openArchive(original)
        let root = try XCTUnwrap(store.root); defer { try? fm.removeItem(at: root) }
        store.setParameter(section: "PANEL", key: "SIZE", value: "910,510")
        let export = try await store.prepareCopySave(); defer { try? fm.removeItem(at: export.deletingLastPathComponent()) }
        XCTAssertEqual(export.lastPathComponent, original.lastPathComponent)
        XCTAssertEqual(try Data(contentsOf: original), before, "Preparing the system save panel must not write the original")
        let opened = try OriginalSkinDocument.unpack(export); defer { try? fm.removeItem(at: opened) }
        XCTAssertTrue(try String(contentsOf: opened.appendingPathComponent("port/py_26.ini"), encoding: .utf8).contains("910,510"))
        try store.finishExportSave(EditorViewState(), recordFile: record)
        let restored = SkinStore(); _ = try await restored.restoreSession(recordFile: record)
        XCTAssertEqual(restored.panel.width, 910); XCTAssertEqual(restored.root, root)
        XCTAssertTrue(restored.requiresSaveDestination)
    }
}
