import XCTest
@testable import ToMina

private final class TestTokenStore: SessionTokenStore {
    var token: String?
    var failSave = false
    func load() -> String? { token }
    func save(_ token: String) throws { if failSave { throw CloudAccount.Failure.storage }; self.token = token }
    func clear() { token = nil }
}
private final class SessionURLProtocol: URLProtocol {
    static var status = 200
    static var offline = false
    static let token = String(repeating: "a", count: 64)
    static var pending: SessionURLProtocol?
    static var hold = false
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        if Self.hold && request.url?.lastPathComponent == "heartbeat" { Self.pending = self; return }
        complete()
    }
    func complete() {
        if Self.offline { client?.urlProtocol(self, didFailWithError: URLError(.notConnectedToInternet)); return }
        let response = HTTPURLResponse(url: request.url!, statusCode: Self.status, httpVersion: nil, headerFields: nil)!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data("{\"token\":\"\(Self.token)\"}".utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
@MainActor final class PersistentSessionTests: XCTestCase {
    private func account(_ storage: TestTokenStore) -> CloudAccount {
        SessionURLProtocol.status = 200; SessionURLProtocol.offline = false; SessionURLProtocol.hold = false; SessionURLProtocol.pending = nil
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [SessionURLProtocol.self]
        return CloudAccount(session: URLSession(configuration: configuration), storage: storage, automaticHeartbeat: false)
    }
    func testLoginSurvivesBackgroundAndRelaunchWithoutPassword() async throws {
        let vault = TestTokenStore()
        let auth = account(vault)
        try await auth.login(account: "fixture", password: "synthetic-password")
        XCTAssertTrue(auth.authenticated); XCTAssertEqual(vault.token, SessionURLProtocol.token)
        auth.suspend(); XCTAssertFalse(auth.authenticated); XCTAssertNotNil(vault.token)
        await auth.resume(); XCTAssertTrue(auth.authenticated)
        let reopened = account(vault)
        XCTAssertFalse(reopened.authenticated); XCTAssertTrue(reopened.hasSession)
        await reopened.resume(); XCTAssertTrue(reopened.authenticated)
    }
    func testOfflineAndDeviceLimitKeepCredentialsButBlockUnverifiedEditor() async throws {
        let vault = TestTokenStore(); vault.token = SessionURLProtocol.token
        let auth = account(vault)
        SessionURLProtocol.offline = true; await auth.resume()
        XCTAssertFalse(auth.authenticated); XCTAssertTrue(auth.hasSession); XCTAssertNotNil(vault.token)
        SessionURLProtocol.offline = false; SessionURLProtocol.status = 409; await auth.resume()
        XCTAssertFalse(auth.authenticated); XCTAssertNotNil(vault.token)
        SessionURLProtocol.status = 200; await auth.resume(); XCTAssertTrue(auth.authenticated)
    }
    func testRevocationClearsPersistedSessionAndCannotRestore() async {
        for status in [401, 403] {
            let vault = TestTokenStore(); vault.token = SessionURLProtocol.token
            let auth = account(vault); SessionURLProtocol.status = status
            await auth.resume()
            XCTAssertFalse(auth.authenticated); XCTAssertFalse(auth.hasSession); XCTAssertNil(vault.token)
        }
    }
    func testLateValidationCannotUndoLogout() async {
        let vault = TestTokenStore(); vault.token = SessionURLProtocol.token
        let auth = account(vault); SessionURLProtocol.hold = true
        let check = Task { await auth.resume() }
        for _ in 0..<100 where SessionURLProtocol.pending == nil { try? await Task.sleep(for: .milliseconds(10)) }
        let pending = SessionURLProtocol.pending
        XCTAssertNotNil(pending)
        SessionURLProtocol.hold = false; auth.logout(); pending?.complete(); await check.value
        XCTAssertFalse(auth.authenticated); XCTAssertNil(vault.token)
    }
    func testFailedSecureStorageDoesNotAdmitLogin() async {
        let vault = TestTokenStore(); vault.failSave = true; let auth = account(vault)
        do { try await auth.login(account: "fixture", password: "synthetic-password"); XCTFail("Storage failure admitted login") } catch {}
        XCTAssertFalse(auth.authenticated); XCTAssertNil(vault.token)
    }
}
