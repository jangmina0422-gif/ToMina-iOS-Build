'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const V=require('./ViewFit.js');let count=0;
const test=(name,body)=>{body();count++;console.log('PASS '+name);};
const key=(n,r,extras='')=>`[KEY${n}]\nVIEW_RECT=${r}\nCENTER=${n===4?'F38':'letter'+n}\nUP=上滑\nHOLD=F72\nFORE_ANIM_STYLE=905,905\n${extras}\n`;
const panel=(rows,w=200,h=100)=>`[PANEL]\nSIZE=${w},${h}\nKEY_NUM=1\n${rows}`;
const plain=()=>({files:{'custom.ini':panel(key(1,'0,0,98,48')+key(8,'102,0,98,48')+key(12,'0,52,58,48')+key(19,'62,52,138,48'))},images:{}});
const run=i=>V.run(JSON.parse(JSON.stringify(i)));
function apply(input,result){const out=JSON.parse(JSON.stringify(input));result.edits.forEach(e=>out.files[e.path]=e.text);return out;}
const sections=(input,file)=>V.parse(input.files[file]).sections;
const field=(input,file,name,k)=>sections(input,file).find(s=>s.name===name).values[k];
test('actual sparse KEY sections, stagger, wide space and both axes',()=>{
 const i=plain(),r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(r.reports[0].changedKeys,4);
 assert.equal(field(out,'custom.ini','KEY1','VIEW_RECT'),'0,0,100,50');assert.equal(field(out,'custom.ini','KEY8','VIEW_RECT'),'100,0,100,50');
 assert.equal(field(out,'custom.ini','KEY12','VIEW_RECT'),'0,50,60,50');assert.equal(field(out,'custom.ini','KEY19','VIEW_RECT'),'60,50,140,50');
 assert.equal(field(out,'custom.ini','PANEL','KEY_NUM'),'1');
 for(const s of sections(i,'custom.ini').filter(s=>s.name.startsWith('KEY')))for(const f of ['CENTER','UP','HOLD','FORE_ANIM_STYLE'])assert.equal(field(out,'custom.ini',s.name,f),s.values[f]);
});
test('implicit touches frozen; inherited and zero touches preserved',()=>{
 const i=plain();i.files['custom.ini']=i.files['custom.ini'].replace('CENTER=letter8','TOUCH_RECT=0,0,0,0\nCENTER=letter8');i.files['gen.ini']='[KEY12]\nTOUCH_RECT=3,4,5,6';
 const out=apply(i,run(i));assert.equal(field(out,'custom.ini','KEY1','TOUCH_RECT'),'0,0,98,48');assert.equal(field(out,'custom.ini','KEY8','TOUCH_RECT'),'0,0,0,0');assert.equal(field(out,'custom.ini','KEY12','TOUCH_RECT'),undefined);assert.equal(out.files['gen.ini'],i.files['gen.ini']);
});
test('idempotent: second run has no edits',()=>{const i=plain(),out=apply(i,run(i));assert.equal(run(out).edits.length,0);});
test('recursive arbitrary languages, themes and per-panel inherited size',()=>{
 const i={files:{},images:{}};
 for(const prefix of ['port','land','light/nested','dark/custom','another_language']){const w=prefix==='land'?400:200;i.files[prefix+'/gen.ini']=`[PANEL]\nSIZE=${w},100`;i.files[prefix+'/Любой.INI']='[PANEL]\n'+key(1,`0,0,${w/2-2},100`)+key(2,`${w/2+2},0,${w/2-2},100`);}
 i.files['arbitrary-animation.ini']='[ANIM59]\nVIEW_RECT=1,2,3,4\nDURATION=200';i.files['arbitrary-event.ini']='[EVENT1]\nNAME=IDLE';const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,5);assert.equal(field(out,'land/Любой.INI','KEY1','VIEW_RECT'),'0,0,200,100');assert.equal(out.files['arbitrary-animation.ini'],i.files['arbitrary-animation.ini']);
});
test('vertical LIST and padding excluded from fillable gaps',()=>{
 const i={files:{'x.ini':panel('[LIST]\nPOS=0,0\nCELL_SIZE=40,25\nLIST_NUM=4\nPADDING=3,2,3,2\n'+key(1,'44,0,76,100')+key(2,'124,0,76,100'))},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'40,0,82,100');assert.equal(field(out,'x.ini','LIST','PADDING'),'3,2,3,2');
});
test('horizontal LIST_ORDER uses width times count',()=>{
 const i={files:{'x.ini':panel('[LIST]\nPOS=0,0\nCELL_SIZE=50,20\nLIST_NUM=4\nLIST_ORDER=1\nPADDING=2,0,2,0\n'+key(1,'0,24,98,76')+key(2,'102,24,98,76'))},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'0,20,100,80');
});
test('handwriting is fixed, functional neighbours fitted',()=>{
 const i={files:{'x.ini':panel('[KEY1]\nVIEW_RECT=0,0,150,70\nCENTER=F53\n'+key(2,'154,0,46,70')+key(3,'0,74,148,26')+key(4,'152,74,48,26'))},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'0,0,150,70');assert.equal(field(out,'x.ini','KEY3','VIEW_RECT'),'0,70,150,30');
});
test('background, intentional conditional overlay and filler preservation',()=>{
 const i=plain();i.files['custom.ini']+='[KEY99]\nVIEW_RECT=0,0,200,100\nSTAT_STYLE=S0\nBACK_STYLE=0\n';const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'custom.ini','KEY99','VIEW_RECT'),'0,0,200,100');
 const f={files:{'f.ini':panel(key(1,'20,0,78,100')+key(2,'102,0,78,100')+'[KEY3]\nVIEW_RECT=0,0,20,100\n[KEY4]\nVIEW_RECT=180,0,20,100\n')},images:{}};assert.equal(run(f).summary.processed,1);
});
test('candidate composite is not covered by ordinary keys',()=>{
 const i={files:{'x.ini':panel('[KEY1]\nVIEW_RECT=0,0,200,60\n[KEY2]\nVIEW_RECT=0,0,200,60\nCENTER=F55\n'+key(3,'0,64,98,36')+key(4,'102,64,98,36'))},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'0,0,200,60');assert.equal(field(out,'x.ini','KEY2','VIEW_RECT'),'0,0,200,60');assert.equal(field(out,'x.ini','KEY3','VIEW_RECT'),'0,60,100,40');
});
test('subpixel and one-pixel overlaps share one integer seam',()=>{
 const i={files:{'x.ini':panel(key(1,'0,0,100.4,100')+key(2,'99.7,0,100.3,100'))},images:{}};const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(field(out,'x.ini','KEY1','VIEW_RECT'),'0,0,100,100');assert.equal(field(out,'x.ini','KEY2','VIEW_RECT'),'100,0,100,100');
});
test('invalid dimensions, duplicate keys, malformed touches, huge gaps are uncertain',()=>{
 for(const text of ['[KEY1]\nVIEW_RECT=0,0,20,20\nCENTER=A',panel(key(1,'0,0,98,100')+key(1,'102,0,98,100')),panel(key(1,'0,0,98,100','TOUCH_RECT=broken')+key(2,'102,0,98,100')),panel(key(1,'0,0,20,100')+key(2,'180,0,20,100'))]){const r=run({files:{'bad.ini':text},images:{}});assert.equal(r.summary.uncertain,1);assert.equal(r.edits.length,0);}
});
test('substantial functional overlaps not flattened',()=>{const r=run({files:{'bad.ini':panel(key(1,'0,0,120,100')+key(2,'80,0,120,100'))},images:{}});assert.equal(r.summary.uncertain,1);assert.equal(r.edits.length,0);});
test('mixed binary appearance blocks false success',()=>{const i=plain();i.inventory=['appearanceConfig'];assert.equal(run(i).summary.uncertain,1);});
function atlas(){
 const i={files:{},images:{'res/paper.png':[100,100],'res/pressed.png':[100,100]}};
 i.files['res/default.css']='[GLOBAL]\nSTYLE_NUM=4\n';let tile='[GLOBAL]\nTILE_NUM=4\n';
 let rows='';for(let j=0;j<4;j++){const x=j%2,y=Math.floor(j/2);rows+=key(j+1,`${x*102},${y*52},98,48`,`BACK_STYLE=${j+1}`);i.files['res/default.css']+=`[STYLE${j+1}]\nNM_IMG=paper,${j+1}\nHL_IMG=pressed,${j+1}\nPRESS_ANIM=51\n`;tile+=`[IMG${j+1}]\nSOURCE_RECT=${x*50},${y*50},50,50\n`;}
 i.files['res/paper.til']=tile;i.files['res/pressed.til']=tile;i.files['port/different_name.ini']=panel(rows);i.files['land/different_name.ini']=panel(rows.replace(/VIEW_RECT=(\d+),(\d+),(\d+),(\d+)/g,(_,x,y,w,h)=>`VIEW_RECT=${+x*2},${y},${+w*2},${h}`),400,100);return i;
}
test('global sticker uses independent source/display scale',()=>{
 const i=atlas(),r=run(i),out=apply(i,r);assert.equal(r.summary.processed,2);assert.equal(field(out,'land/different_name.ini','KEY1','VIEW_RECT'),'0,0,200,50');assert.equal(r.reports.find(r=>r.path.startsWith('land')).mappedImages,2);
 assert.equal(out.files['res/paper.til'],i.files['res/paper.til']);assert.equal(run(out).edits.length,0);
});
test('source slices cloned without changing original shared slices',()=>{
 const i=atlas();for(const p of ['res/paper.til','res/pressed.til'])i.files[p]=i.files[p].replace('0,0,50,50','0,0,49,48').replace('50,0,50,50','51,0,49,48').replace('0,50,50,50','0,52,49,48').replace('50,50,50,50','51,52,49,48');
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,2);assert.ok(r.reports.every(r=>r.tiles===8));assert.equal(field(out,'res/paper.til','IMG1','SOURCE_RECT'),'0,0,49,48');assert.equal(field(out,'res/paper.til','IMG5','SOURCE_RECT'),'0,0,50,50');const id=field(out,'port/different_name.ini','KEY1','BACK_STYLE');assert.notEqual(id,'1');assert.equal(field(out,'res/default.css','STYLE'+id,'PRESS_ANIM'),'51');assert.equal(run(out).edits.length,0);
});
test('invalid TIL rolls back the whole panel including CSS clones',()=>{
 const i=atlas();i.files['res/paper.til']=i.files['res/paper.til'].replace('0,0,50,50','-2,0,52,50');const r=run(i);assert.equal(r.summary.uncertain,2);assert.equal(r.edits.length,0);
});
test('state switch keeps actions and uses a separate correctly mapped TIP',()=>{
 const i=atlas();i.files['port/different_name.ini']=i.files['port/different_name.ini'].replace('BACK_STYLE=1','BACK_STYLE=1\nSTAT_STYLE=S7_1')+'[TIP1]\nBACK_STYLE=1\nVIEW_RECT=0,0,98,48\nCENTER=F22\n';
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,2);assert.equal(field(out,'port/different_name.ini','KEY1','STAT_STYLE'),'S7_2');assert.equal(field(out,'port/different_name.ini','TIP2','CENTER'),'F22');assert.equal(field(out,'port/different_name.ini','TIP2','VIEW_RECT'),'0,0,100,50');assert.equal(field(out,'port/different_name.ini','TIP1','VIEW_RECT'),'0,0,98,48');assert.equal(run(out).edits.length,0);
});
test('ambiguous sibling theme resources not guessed',()=>{
 const i=atlas();i.images['light/paper.png']=i.images['res/paper.png'];i.images['dark/paper.png']=i.images['res/paper.png'];delete i.images['res/paper.png'];const r=run(i);assert.equal(r.summary.uncertain,2);
});
test('unknown source encoding and unreadable defaults explicitly reported',()=>{
 const i=plain();i.inventory=['gen.ini'];i.unreadable=[{path:'gen.ini',reason:'invalid encoding'}];const r=run(i);assert.equal(r.edits.length,0);assert.equal(r.summary.uncertain,2);
});
test('line endings, comments, duplicate CAND and actions retained',()=>{
 const i=plain();i.files['custom.ini']=('\uFEFF'+i.files['custom.ini']+'[CAND]\nTYPE=1\n[CAND]\nTYPE=2\n').replace('VIEW_RECT=0,0,98,48','VIEW_RECT=0,0,98,48 // Keep comment').replace(/\n/g,'\r\n');const out=apply(i,run(i)).files['custom.ini'];assert.ok(out.startsWith('\uFEFF'));assert.ok(out.includes('VIEW_RECT=0,0,100,50 // Keep comment\r\n'));assert.equal(V.parse(out).sections.filter(s=>s.name==='CAND').length,2);assert.equal(out.replace(/\r\n/g,'').includes('\n'),false);
});
test('path traversal rejected',()=>{assert.throws(()=>run({files:{'../evil.ini':'[KEY1]'},images:{}}));});
test('POS_TYPE zero preserves ASCII comma count, spacing, comments and actions',()=>{
 const i={operation:'zeroPositionTypes',files:{'dark/land/custom.ini':'[KEY99]\r\nPOS_TYPE=46 // comment\r\nCENTER=a\r\n[TIP2]\r\nPOS_TYPE=7, 3,-4,1.5\r\n'},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,1);assert.equal(out.files['dark/land/custom.ini'],'[KEY99]\r\nPOS_TYPE=0 // comment\r\nCENTER=a\r\n[TIP2]\r\nPOS_TYPE=0, 0,0,0\r\n');assert.equal(run(out).edits.length,0);
});
test('POS_TYPE zero checks all configurations without adding missing fields',()=>{
 const i={operation:'zeroPositionTypes',files:{'a.ini':'[KEY1]\nCENTER=q','b.cnd':'[ICON1]\nPOS_TYPE=3,2','c.pop':'[TIP1]\nPOS_TYPE=46','res/a.css':'[STYLE3]\nPOS_TYPE=1,1,1','d.ini':'[KEY2]\nPOS_TYPE=0,0'},images:{}};
 const r=run(i),out=apply(i,r);assert.equal(r.summary.processed,3);assert.equal(r.summary.unchanged,2);assert.equal(out.files['a.ini'],i.files['a.ini']);
});
test('POS_TYPE malformed values keep the entire file and report a reason',()=>{
 for(const value of ['3，4','3,,4','abc','']){const i={operation:'zeroPositionTypes',files:{'x.ini':'[KEY1]\nPOS_TYPE=46\n[KEY2]\nPOS_TYPE='+value},images:{}};const r=run(i);assert.equal(r.summary.uncertain,1);assert.equal(r.edits.length,0);}
});
// Fixtures used by the iOS bridge regression tests contain synthetic content only.
if(process.argv.includes('--fixtures')) {
 fs.mkdirSync(path.join(__dirname,'fixtures'),{recursive:true});
 for(const [name,input] of [['plain',plain()],['atlas',atlas()]])fs.writeFileSync(path.join(__dirname,'fixtures',name+'.json'),JSON.stringify({input,expected:run(input)},null,2));
}
console.log(`${count} test groups passed`);
