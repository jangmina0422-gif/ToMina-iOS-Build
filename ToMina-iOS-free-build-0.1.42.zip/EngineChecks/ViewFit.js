/* To.Mina VIEW fitting. Pure, deterministic engine shared by Android/iOS.
   Input is an immutable package snapshot. Output is a transaction, never file IO.
   Coordinates in layout space and source-image space are deliberately separate. */
(function (global) {
  'use strict';
  const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  const dict = () => Object.create(null);
  const fail = s => { throw new Error(s); };
  const eq = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
  const nums = s => {
    if (typeof s !== 'string' || !s.trim()) return [];
    const a = s.split(',').map(v => v.trim() === '' ? NaN : Number(v.trim()));
    return a.every(Number.isFinite) ? a : [];
  };
  function parse(text) {
    const lines = text.split(/\r\n|\n|\r/), sections = []; let current;
    lines.forEach((line, i) => {
      const h = line.replace(/^\uFEFF/, '').match(/^\s*\[([^\]]+)\]\s*(?:(?:;|\/\/).*)?$/);
      if (h) {
        if (current) current.end = i;
        current = {name:h[1].trim().toUpperCase(), start:i, end:lines.length, values:dict()};
        sections.push(current);
      } else if (current && !/^\s*(;|#|\/\/)/.test(line)) {
        const m = line.match(/^\s*([^=]+?)\s*=(.*)$/);
        if (m) current.values[m[1].trim().toUpperCase()] = m[2].split(' //')[0].trim();
      }
    });
    return {text, lines, sections, nl:text.indexOf('\r\n') >= 0 ? '\r\n' : text.indexOf('\r') >= 0 ? '\r' : '\n'};
  }
  // Modify only named fields; retain ordering, comments, duplicate sections and actions.
  function patch(text, changes) {
    const p = parse(text);
    Object.keys(changes).map(Number).sort((a,b) => b-a).forEach(index => {
      const s = p.sections[index]; if (!s) fail('配置段在检查后改变');
      const values = changes[index], found = dict();
      for (let i=s.start+1; i<s.end; i++) {
        const m = p.lines[i].match(/^(\s*([^=;#]+?)\s*=)(.*)$/);
        const key = m && m[2].trim().toUpperCase();
        if (key && own(values,key)) {
          const comment = m[3].indexOf(' //');
          p.lines[i] = m[1] + values[key] + (comment < 0 ? '' : m[3].slice(comment)); found[key] = true;
        }
      }
      const added = Object.keys(values).filter(k => !found[k]).map(k => k+'='+values[k]);
      p.lines.splice(s.start+1,0,...added);
    });
    return p.lines.join(p.nl);
  }
  function normalized(path) {
    if (typeof path !== 'string' || /[:\x00]/.test(path) || /^[\\/]/.test(path)) fail('资源路径不安全');
    const parts=path.replace(/\\/g,'/').split('/').filter(p=>p!=='.' && p!=='');
    if (parts.some(p=>p==='..')) fail('资源路径超出皮肤包');
    return parts.join('/');
  }
  const dir = p => p.includes('/') ? p.slice(0,p.lastIndexOf('/')) : '';
  const base = p => p.slice(p.lastIndexOf('/')+1);
  const join = (a,b) => a ? a+'/'+b : b;
  function parents(path) { const out=[];let p=dir(path); for (;;) {out.push(p);if (!p) return out;p=dir(p);} }
  function effective(local, defaults) {
    const seen=dict();return local.map((s,index)=>{
      const n=seen[s.name] || 0;seen[s.name]=n+1;
      const d=defaults.filter(v=>v.name===s.name)[n];
      return {name:s.name,index,values:Object.assign(dict(),d && d.values,s.values)};
    });
  }
  function rect(value, label) {
    const r=nums(value);
    if(r.length!==4 || r[2]<=0 || r[3]<=0) fail(label+' 的 VIEW_RECT 无效');
    return r;
  }
  const end = (r,a) => r[a]+r[a+2];
  const overlap = (a,b,axis) => Math.min(end(a,axis),end(b,axis))-Math.max(a[axis],b[axis]);
  const intersects = (a,b) => overlap(a,b,0)>0.001 && overlap(a,b,1)>0.001;
  const action = v => Object.keys(v).some(k=>/^(?:CENTER|KEY|LEFT|RIGHT|UP|DOWN|HOLD|LONG_PRESS|SWIPE.*)$/.test(k) && v[k]!=='' );
  const area = r => r[2]*r[3];
  const median = a => a.slice().sort((x,y)=>x-y)[Math.floor(a.length/2)] || 0;
  const boxText = r => r.join(',');
  function contained(r,w,h,t=0) { return r[0]>=-t && r[1]>=-t && end(r,0)<=w+t && end(r,1)<=h+t; }
  function classify(sections,w,h) {
    const all=[], reserved=[], notes=[];
    for (const s of sections) {
      const v=s.values;
      if (/^KEY\d+$/.test(s.name)) {
        const r=rect(v.VIEW_RECT,s.name);
        if (!contained(r,w,h,2)) fail(s.name+' 超出本面板尺寸，无法确定原有布局意图');
        const k={s,r,next:r.slice(), fixed:false, kind:'key'};
        // STAT_STYLE also selects ordinary keys' state appearances. It does not
        // by itself make a key an overlay. POS_TYPE positions content, not VIEW.
        if ((!action(v) && v.STAT_STYLE==='S0') || Math.min(r[2],r[3])<=2) k.kind='overlay';
        else if (['F53','F55'].includes((v.CENTER||'').toUpperCase())) {k.kind='reserved';k.fixed=true;reserved.push(k);}
        else if (!action(v)) k.kind='decoration';
        all.push(k);
      } else if (/^LIST\d*$/.test(s.name)) {
        const pos=nums(v.POS),cell=nums(v.CELL_SIZE),count=Number(v.LIST_NUM),pad=nums(v.PADDING||'0');
        if(pos.length!==2 || cell.length!==2 || !Number.isInteger(count) || count<1 || cell.some(v=>v<=0) || ![1,2,4].includes(pad.length) || pad.some(v=>v<0)) fail(s.name+' 缺少有效 POS / CELL_SIZE / LIST_NUM / PADDING');
        if(v.LIST_ORDER && !['0','1'].includes(v.LIST_ORDER)) fail(s.name+' 的排列方向无法确定');
        const r=[pos[0],pos[1],cell[0]*(v.LIST_ORDER==='1'?count:1),cell[1]*(v.LIST_ORDER==='1'?1:count)];
        // Padding is internal content space, not space available for neighbouring keys.
        if(!contained(r,w,h)) fail(s.name+' 的列表区域超出面板');
        const k={s,r,next:r.slice(),fixed:true,kind:'reserved'};reserved.push(k);all.push(k);
      } else if (/^(?:ICON\d+|CAND|SCAND|HW\d*|HANDWRITING)$/.test(s.name) && v.VIEW_RECT && !v.LAYOUT_NAME) {
        const r=rect(v.VIEW_RECT,s.name);
        if(contained(r,w,h)) {const k={s,r,next:r.slice(),fixed:true,kind:'reserved'};reserved.push(k);all.push(k);}
      }
    }
    const keys=all.filter(k=>k.kind==='key');
    const mw=median(keys.map(k=>k.r[2]));
    all.filter(k=>k.kind==='decoration').forEach(k=>{
      if(all.some(other=>other!==k && other.kind!=='overlay' && intersects(k.r,other.r))) k.kind='overlay';
      else if(k.r[2]<=mw*0.65 && keys.some(o=>Math.abs(o.r[1]-k.r[1])<=2 && Math.abs(end(o.r,1)-end(k.r,1))<=2 && Math.min(Math.abs(end(o.r,0)-k.r[0]),Math.abs(end(k.r,0)-o.r[0]))<=2)) k.kind='filler';
      else {k.kind='reserved';k.fixed=true;reserved.push(k);}
    });
    notes.push('保留 '+all.filter(k=>k.kind==='overlay').length+' 个叠加/背景区，'+reserved.length+' 个固定区域，识别 '+all.filter(k=>k.kind==='filler').length+' 个补边块');
    return {all,active:all.filter(k=>k.kind!=='overlay'),notes};
  }
  function fitGeometry(model,w,h) {
    const items=model.active,n=items.length;
    if(n>1024) fail('区域超过 1024 个，未进行不完整处理');
    const oldOverlaps=new Set();
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++) {
      const a=items[i],b=items[j];
      if(intersects(a.r,b.r)) {
        if(a.fixed && b.fixed) {oldOverlaps.add(i+':'+j);continue;}
        if(Math.min(overlap(a.r,b.r,0),overlap(a.r,b.r,1))>3) fail(a.s.name+' 与 '+b.s.name+' 存在非取整误差的叠加，需确认分层');
      }
    }
    const seams=[];
    for(let axis=0;axis<2;axis++) {
      const parent=Array.from({length:n*2},(_,i)=>i), locks=dict(), vals=[];
      const root=i=>{while(parent[i]!==i){parent[i]=parent[parent[i]];i=parent[i];}return i;};
      const union=(a,b)=>{parent[root(b)]=root(a);};
      items.forEach((k,i)=>{
        vals.push(k.r[axis],end(k.r,axis));
        if(k.fixed) {locks[2*i]=k.r[axis];locks[2*i+1]=end(k.r,axis);}
        else {if(Math.abs(k.r[axis])<=2) locks[2*i]=0;if(Math.abs(end(k.r,axis)-(axis?h:w))<=2) locks[2*i+1]=axis?h:w;}
      });
      for(let i=0;i<n;i++) for(let j=0;j<n;j++) {
        if(i===j)continue; const a=items[i],b=items[j],cross=1-axis;
        if(b.r[axis]+b.r[axis+2]/2<=a.r[axis]+a.r[axis+2]/2)continue;
        const span=overlap(a.r,b.r,cross);
        if(span < Math.max(1,Math.min(a.r[cross+2],b.r[cross+2])*.25))continue;
        const gap=b.r[axis]-end(a.r,axis);
        if(gap < -3)continue;
        const low=Math.max(a.r[cross],b.r[cross]),high=Math.min(end(a.r,cross),end(b.r,cross));
        const blocked=items.some((k,index)=>index!==i && index!==j && k.r[axis]>=end(a.r,axis)-3 && end(k.r,axis)<=b.r[axis]+3 && Math.min(end(k.r,cross),high)-Math.max(k.r[cross],low)>0.001);
        if(blocked)continue;
        if(gap>Math.min(a.r[axis+2],b.r[axis+2])*.55) {
          if(!a.fixed && !b.fixed) fail(a.s.name+' / '+b.s.name+' 之间的留白较大，无法确定是否属于同一排布区域');
          continue;
        }
        if(a.fixed && b.fixed)continue;
        union(2*i+1,2*j);seams.push({i,j,axis});
      }
      const groups=dict();for(let i=0;i<vals.length;i++){const r=root(i);(groups[r]||(groups[r]=[])).push(i);}
      Object.keys(groups).forEach(id=>{
        const members=groups[id],fixed=Array.from(new Set(members.filter(i=>own(locks,i)).map(i=>locks[i])));
        if(fixed.length>1) fail('共享边界与列表或面板固定边界冲突');
        const values=Array.from(new Set(members.map(i=>vals[i])));
        const value=fixed.length?fixed[0]:Math.round(values.reduce((s,v)=>s+v,0)/values.length);
        members.forEach(i=>{const k=items[Math.floor(i/2)];if(i%2)k.next[axis+2]=value;else k.next[axis]=value;});
      });
      items.forEach(k=>{k.next[axis+2]-=k.next[axis];});
    }
    for(const k of items) {
      if(k.next[2]<=0 || k.next[3]<=0 || !contained(k.next,w,h)) fail(k.s.name+' 贴合后尺寸无效或越界');
      if(k.fixed && !eq(k.r,k.next)) fail(k.s.name+' 的保留区域发生移动');
    }
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)if(!oldOverlaps.has(i+':'+j) && intersects(items[i].next,items[j].next)) fail(items[i].s.name+' 与 '+items[j].s.name+' 贴合后产生重叠');
    seams.forEach(s=>{if(end(items[s.i].next,s.axis)!==items[s.j].next[s.axis])fail('共享边界校验失败');});
    return seams.length;
  }
  function fitAxis(samples,axis) {
    const x=samples.map(s=>s.item.r[axis]+s.item.r[axis+2]/2),y=samples.map(s=>s.source[axis]+s.source[axis+2]/2);
    const xm=x.reduce((a,b)=>a+b,0)/x.length,ym=y.reduce((a,b)=>a+b,0)/y.length;
    const variance=x.reduce((s,v)=>s+(v-xm)*(v-xm),0);
    if(variance<1)return null;
    const scale=x.reduce((s,v,i)=>s+(v-xm)*(y[i]-ym),0)/variance,offset=ym-scale*xm;
    const error=Math.max(...x.map((v,i)=>Math.abs(v*scale+offset-y[i])));
    return {scale,offset,error,span:Math.max(...x)-Math.min(...x)};
  }
  function stateItems(model,sections,defaults) {
    const virtual=[];
    for(const item of model.all.filter(k=>k.kind!=='overlay')) {
      for(const field of Object.keys(item.s.values).filter(k=>/^STAT_STYLE\d*$/.test(k))) {
        const value=item.s.values[field],tokens=value.match(/S\d+_\d+/g)||[];
        if(tokens.length && !/^\s*S\d+(?:_\d+)?(?:\s*\|\s*S\d+(?:_\d+)?)*\s*$/.test(value))fail(item.s.name+' 的状态表达式无法确定');
        for(const token of Array.from(new Set(tokens))) {
          const name='TIP'+token.split('_')[1],tip=sections.find(s=>s.name===name)||defaults.find(s=>s.name===name);
          if(!tip)fail(item.s.name+' 的状态 '+token+' 缺少 '+name);
          if(tip.values.VIEW_RECT && !eq(nums(tip.values.VIEW_RECT),item.r))fail(item.s.name+' 的状态 '+token+' 使用不同 VIEW，无法自动确定共用边界');
          const s={name:item.s.name+'/'+name,index:-virtual.length-1,values:Object.assign(dict(),tip.values)};
          const k={s,r:item.r,next:item.next,kind:'state',base:item,tip,field,token};virtual.push(k);
        }
      }
    }
    model.all.push(...virtual);return virtual;
  }
  function run(input) {
    const files=dict(), originals=dict(), images=dict(), index=dict(), reports=[];
    Object.keys(input.files||{}).sort().forEach(path=>{const p=normalized(path);if(own(index,p.toLowerCase()))fail('存在大小写冲突路径：'+p);index[p.toLowerCase()]=p;files[p]=String(input.files[path]);originals[p]=files[p];});
    Object.keys(input.images||{}).sort().forEach(path=>{const p=normalized(path);images[p]=input.images[path];if(own(index,p.toLowerCase()))fail('存在重复资源路径：'+p);index[p.toLowerCase()]=p;});
    (input.inventory||[]).forEach(path=>{const p=normalized(path);if(!own(index,p.toLowerCase()))index[p.toLowerCase()]=p;});
    const lookup=p=>index[p.toLowerCase()];
    function resolve(name,context,extensions) {
      name=normalized(name);const candidates=[];
      const add=p=>{for(const ext of extensions){const v=lookup(p+ext);if(v && !candidates.includes(v))candidates.push(v);}return candidates.length>0;};
      for(const p of parents(context)) {if(add(join(p,name)))return candidates.length===1?candidates[0]:fail('资源引用有歧义：'+name);if(add(join(p,'res/'+name)))return candidates.length===1?candidates[0]:fail('资源引用有歧义：'+name);}
      if(add(name))return candidates.length===1?candidates[0]:fail('资源引用有歧义：'+name);
      // Only an unambiguous package-wide match is safe outside the ancestor chain.
      const choices=Object.keys(index).filter(p=>extensions.some(e=>base(p)===(base(name)+e).toLowerCase()));
      if(choices.length===1)return index[choices[0]];if(choices.length>1)fail('跨目录资源引用无法确定：'+name);return null;
    }
    function defaultsFor(path) {for(const p of parents(path)){const hit=lookup(join(p,'gen.ini'));if(hit && hit!==path)return hit;}return null;}
    function cssFor(path) {for(const p of parents(path)){const hit=lookup(join(p,'res/default.css'));if(hit)return hit;}const choices=Object.keys(files).filter(p=>base(p).toLowerCase()==='default.css');return choices.length===1?choices[0]:null;}
    function appendSection(path,name,values) {
      const p=parse(files[path]);let result=files[path];if(!result.endsWith(p.nl))result+=p.nl;
      result+=p.nl+'['+name+']'+p.nl+Object.keys(values).map(k=>k+'='+values[k]).join(p.nl)+p.nl;files[path]=result;
    }
    function nextID(path,prefix,countField) {
      const p=parse(files[path]),max=Math.max(0,...p.sections.filter(s=>s.name.startsWith(prefix) && /^\d+$/.test(s.name.slice(prefix.length))).map(s=>Number(s.name.slice(prefix.length))));
      // Declared counts can be a reserved upper bound; allocate beyond it too.
      const g=p.sections.findIndex(s=>s.name==='GLOBAL'),declared=g<0?0:Number(p.sections[g].values[countField]||0);
      const id=Math.max(max,Number.isFinite(declared)?declared:0)+1;
      if(id>1000000)fail('样式或切片编号超过支持范围');
      if(g>=0)files[path]=patch(files[path],{[g]:{[countField]:String(id)}});
      return id;
    }
    function auditImages(path,model,w,h,changes) {
      const css=cssFor(path), sections=css?parse(files[css]).sections:[],styles=dict(),groups=dict(), refs=[];
      sections.forEach(s=>{if(/^STYLE\d+$/.test(s.name))styles[s.name.slice(5)]=s.values;});
      for(const item of model.all) {
        if(item.kind==='overlay')continue;
        for(const field of ['BACK_STYLE','FORE_STYLE']) {
          const ids=(item.s.values[field]||'').split(',').map(s=>s.trim()).filter(Boolean);
          for(let slot=0;slot<ids.length;slot++) {
            const id=ids[slot],style=styles[id];
            if(!style) {if(!eq(item.r,item.next) && /^\d{1,6}$/.test(id) && Number(id)!==0)fail(item.s.name+' 引用的样式 '+id+' 不存在或 CSS 有歧义');continue;}
            const record={item,field,slot,ids,id,style,updates:dict()};refs.push(record);
            for(const property of Object.keys(style).filter(k=>/(?:^|_)IMG$/.test(k))) {
              const parts=style[property].split(',').map(s=>s.trim());if(!parts[0])continue;
              const image=resolve(parts[0],css,['','.png','.webp','.jpg','.jpeg','.gif','.apng']);
              if(!image || !images[image] || images[image].length!==2)fail(item.s.name+' 图片不存在或无法读取尺寸：'+parts[0]);
              const size=images[image],tileName=image.replace(/\.[^/.]+$/,'')+'.til',til=lookup(tileName);
              const tileID=parts.length>1?Number(parts[1]):0;
              if(!Number.isInteger(tileID)||tileID<0)fail(item.s.name+' 切片编号无效');
              if(!til || !tileID) {if(tileID>0)fail(item.s.name+' 缺少 TIL：'+tileName);continue;}
              const matches=parse(files[til]).sections.filter(s=>s.name==='IMG'+tileID),tile=matches[matches.length-1];
              const source=tile && nums(tile.values.SOURCE_RECT);
              if(!source || source.length!==4 || source[2]<=0 || source[3]<=0 || !contained(source,size[0],size[1]))fail(item.s.name+' 的图片切片缺失或越界：'+tileName+' / IMG'+tileID);
              if(tile.values.INNER_RECT) {
                const inner=nums(tile.values.INNER_RECT);
                if(inner.length!==4 || inner[0]<source[0] || inner[1]<source[1] || end(inner,0)>end(source,0) || end(inner,1)>end(source,1))fail(item.s.name+' 的九宫格 INNER_RECT 无效');
                continue;
              }
              if(Object.keys(tile.values).some(k=>/^SCALE/.test(k)))continue;
              const sample={item,source,til,tile,property,parts,record,image,size};
              (groups[image]||(groups[image]=[])).push(sample);
            }
          }
        }
      }
      let mapped=0,tiles=0;const tileCache=dict(),styleCache=dict();
      for(const image of Object.keys(groups)) {
        const samples=groups[image], unique=[];
        samples.filter(s=>s.item.kind!=='state').forEach(s=>{if(!unique.some(t=>t.item===s.item && eq(t.source,s.source)))unique.push(s);});
        const distinct=new Set(unique.map(s=>s.source.join(','))).size;
        if(distinct<4)continue; // A repeated button/icon atlas is not a global sticker.
        const strip=[0,1].some(a=>new Set(unique.map(s=>s.source[a]+s.source[a+2]/2)).size===1);
        if(strip)continue; // One-dimensional animation/icon strips keep their own mapping.
        let mx=fitAxis(unique,0),my=fitAxis(unique,1);
        const width=samples[0].size[0],height=samples[0].size[1];
        const normalizedFits=unique.every(s=>[0,1].every(a=>Math.abs((s.item.r[a]+s.item.r[a+2]/2)*((a?height:width)/(a?h:w))-(s.source[a]+s.source[a+2]/2))<=2));
        if(normalizedFits) {mx={scale:width/w,offset:0,error:0,span:w};my={scale:height/h,offset:0,error:0,span:h};}
        if(!mx || !my || mx.scale<=0 || my.scale<=0 || mx.error>2 || my.error>2 || mx.span<w*.35 || my.span<h*.35) {
          const sheetLike=unique.reduce((sum,s)=>sum+area(s.source),0)>width*height*.6 && distinct>5;
          if(sheetLike && unique.some(s=>!eq(s.item.r,s.item.next)))fail('图片 '+image+' 疑似整图切片，但与面板的映射不一致');
          continue;
        }
        // Reject packed, reused or rotated sprites that only happen to fit centres.
        if(unique.some(s=>[0,1].some(a=>Math.abs(s.source[a+2]-s.item.r[a+2]*(a?my:mx).scale)>Math.max(4,s.source[a+2]*.22)))) {
          if(unique.some(s=>!eq(s.item.r,s.item.next)))fail('图片 '+image+' 的中心与切片尺寸映射冲突');continue;
        }
        mapped++;
        for(const s of samples) {
          if(s.item.kind==='state') {
            const prior=s.item.r;
            if([0,1].some(a=>Math.abs((prior[a]+prior[a+2]/2)*(a?my:mx).scale+(a?my:mx).offset-(s.source[a]+s.source[a+2]/2))>2))fail(s.item.s.name+' 的状态切片与整图坐标不对应');
          }
          const r=s.item.next, x=Math.round(r[0]*mx.scale+mx.offset),y=Math.round(r[1]*my.scale+my.offset);
          const source=[x,y,Math.round(end(r,0)*mx.scale+mx.offset)-x,Math.round(end(r,1)*my.scale+my.offset)-y];
          if(source[2]<=0 || source[3]<=0 || !contained(source,width,height))fail('贴合后的切片超出图片：'+image);
          if(eq(source,s.source))continue;
          const cacheKey=s.til+'|'+s.tile.name+'|'+source.join(',');let id=tileCache[cacheKey];
          if(!id) {id=nextID(s.til,'IMG','TILE_NUM');appendSection(s.til,'IMG'+id,Object.assign(dict(),s.tile.values,{SOURCE_RECT:source.join(',')}));tileCache[cacheKey]=id;tiles++;}
          s.record.updates[s.property]=[s.parts[0],String(id)].concat(s.parts.slice(2)).join(',');
        }
      }
      for(const r of refs)if(Object.keys(r.updates).length) {
        const key=r.id+'|'+JSON.stringify(r.updates);let id=styleCache[key];
        if(!id) {id=nextID(css,'STYLE','STYLE_NUM');appendSection(css,'STYLE'+id,Object.assign(dict(),r.style,r.updates));styleCache[key]=id;}
        const fields=changes[r.item.s.index]||(changes[r.item.s.index]=dict());
        const ids=(fields[r.field]||r.item.s.values[r.field]).split(',').map(s=>s.trim());ids[r.slot]=String(id);fields[r.field]=ids.join(',');
      }
      return {mapped,tiles};
    }
    const candidates=Object.keys(files).filter(p=>/\.(ini|cnd|pop)$/i.test(p));
    const defaultsUsed=new Set(candidates.map(defaultsFor).filter(Boolean));
    for(const path of candidates) {
      const before=Object.assign(dict(),files),report={path,status:'unchanged',reason:'',keys:0,changedKeys:0,touches:0,mappedImages:0,tiles:0,notes:[]};
      try {
        const local=parse(files[path]).sections, def=defaultsFor(path);
        if(def && !own(files,def))fail('继承配置无法无损读取：'+def);
        const defs=def?parse(files[def]).sections:[],sections=effective(local,defs);
        const keys=sections.filter(s=>/^KEY\d+$/.test(s.name));report.keys=keys.length;
        if(!keys.length) {report.reason=sections.some(s=>/^(PANEL|LIST\d*|ICON\d+|CAND)$/.test(s.name))?'无独立 KEY 拼合区域；保留候选/图标/继承配置':'非布局 INI，未修改';reports.push(report);continue;}
        if(['appearanceConfig','appearanceConfig.json','appearanceConfig.txt'].some(n=>lookup(join(dir(path),n))))fail('此面板使用混合/二进制外观，不能仅修改 INI 与 TIL 保证图像对应');
        if(defaultsUsed.has(path))fail('此文件作为共享继承配置使用，需在引用面板内展开修改');
        if(keys.length>1024)fail('KEY 段超过 1024 个');
        if(new Set(keys.map(s=>s.name)).size!==keys.length)fail('重复 KEY 段，无法确定运行时的实际键位');
        const panel=sections.find(s=>s.name==='PANEL') || defs.find(s=>s.name==='PANEL'),size=nums(panel && panel.values.SIZE);
        if(size.length!==2 || size.some(v=>!Number.isInteger(v)||v<=0||v>32768))fail('缺少有效的本面板/继承 PANEL.SIZE');
        const model=classify(sections,size[0],size[1]),changes=dict();
        report.seams=fitGeometry(model,size[0],size[1]);
        for(const k of model.active)if(!eq(k.r,k.next)) {
          const v=changes[k.s.index]||(changes[k.s.index]=dict());v.VIEW_RECT=boxText(k.next);report.changedKeys++;
          if(/^KEY\d+$/.test(k.s.name)) {
            const touch=k.s.values.TOUCH_RECT;
            if(touch && nums(touch).length!==4)fail(k.s.name+' 的 TOUCH_RECT 无效，无法保持触摸范围');
            if(!touch) {v.TOUCH_RECT=boxText(k.r);report.touches++;}
          }
        }
        const variants=stateItems(model,sections,defs);
        for(const item of variants)if(item.tip.values.VIEW_RECT && !eq(item.r,item.next))changes[item.s.index]={VIEW_RECT:boxText(item.next)};
        const mapping=auditImages(path,model,size[0],size[1],changes);report.mappedImages=mapping.mapped;report.tiles=mapping.tiles;
        let tipID=Math.max(0,Number(panel && panel.values.TIP_NUM)||0,...sections.concat(defs).filter(s=>/^TIP\d+$/.test(s.name)).map(s=>Number(s.name.slice(3))));
        const extraTips=[];
        for(const item of variants)if(changes[item.s.index]) {
          const id=++tipID, fields=changes[item.base.s.index]||(changes[item.base.s.index]=dict());
          fields[item.field]=(fields[item.field]||item.base.s.values[item.field]).split('|').map(t=>t.trim()===item.token?item.token.split('_')[0]+'_'+id:t).join('|');
          extraTips.push({name:'TIP'+id,values:Object.assign(dict(),item.tip.values,changes[item.s.index])});delete changes[item.s.index];
        }
        if(extraTips.length) {
          const panelIndex=sections.findIndex(s=>s.name==='PANEL');if(panelIndex<0)fail('状态贴片需要本地 PANEL 段');
          (changes[panelIndex]||(changes[panelIndex]=dict())).TIP_NUM=String(tipID);
          report.notes.push('为状态切换保留独立 TIP，未改变状态与输入动作');
        }
        const declared=Number(panel && panel.values.KEY_NUM);
        if(Number.isFinite(declared) && declared!==keys.length)report.notes.push('声明 KEY_NUM='+declared+'，按实际 '+keys.length+' 个 KEY 段检查；保留编号和声明以免改变启用范围');
        if(Object.keys(changes).length)files[path]=patch(files[path],changes);
        extraTips.forEach(s=>appendSection(path,s.name,s.values));
        report.status=Object.keys(files).some(p=>files[p]!==before[p])?'processed':'unchanged';
        report.reason=report.status==='processed'?'已应用到包内配置：'+report.changedKeys+' 个 VIEW，'+report.touches+' 个隐式触摸范围保持原值，'+report.tiles+' 个独立切片':'边界已贴合，未改变原布局';
        report.notes.push(...Array.from(new Set(model.notes)));report.size=size;report.defaults=def || '';
      } catch(e) {
        Object.keys(files).forEach(p=>{files[p]=before[p];});report.status='uncertain';report.reason=e.message || String(e);report.changedKeys=0;report.touches=0;report.tiles=0;
      }
      reports.push(report);
    }
    for(const entry of input.unreadable||[])reports.push({path:entry.path,status:'uncertain',reason:entry.reason||'文件编码或格式无法确定'});
    const edits=Object.keys(files).filter(p=>files[p]!==originals[p]).map(path=>({path,text:files[path]}));
    const summary={processed:reports.filter(r=>r.status==='processed').length,unchanged:reports.filter(r=>r.status==='unchanged').length,uncertain:reports.filter(r=>r.status==='uncertain').length,files:edits.length};
    return {version:1,summary,reports,edits};
  }
  global.ViewFit={run,parse,patch};
  if(typeof module!=='undefined' && module.exports)module.exports=global.ViewFit;
})(typeof globalThis!=='undefined'?globalThis:this);
