import Foundation

// Keep the original STYLE identifiers. Scan every panel, CND/POP and animation,
// then follow references between styles. Unreadable configurations stop cleanup.
enum CSSCleanup {
    struct Result: Sendable { let text: String; let removed: [Int] }
    private static let kinds: Set<String> = ["ini", "cnd", "pop", "css", "anim", "ani"]
    private static func styleID(_ name: String) -> Int? {
        guard name.range(of: "^STYLE[0-9]+$", options: .regularExpression) != nil else { return nil }
        return Int(name.dropFirst(5))
    }
    private static func references(_ section: Section) throws -> Set<Int> {
        var ids: Set<Int> = []
        for (key, value) in section.values {
            let upper = key.uppercased()
            guard upper != "STYLE_NUM" else { continue }
            if upper == "STYLE" || upper.hasSuffix("_STYLE") || upper.hasSuffix("_STYLES") || upper == "PARTICLE_IMAGE" {
                for part in value.split(separator: ",") {
                    let token = part.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
                    guard let id = Int(token) ?? styleID(token), id >= 0 else {
                        throw SkinFailure(message: "未知样式引用 \(section.name).\(key)，未删除任何样式")
                    }
                    ids.insert(id)
                }
            }
            // Explicit STYLE names in less common fields are retained too.
            let expression = try NSRegularExpression(pattern: "(?i)\\bSTYLE([0-9]+)\\b")
            let source = value as NSString
            for match in expression.matches(in: value, range: NSRange(location: 0, length: source.length)) {
                if let id = Int(source.substring(with: match.range(at: 1))) { ids.insert(id) }
            }
        }
        return ids
    }
    static func prepare(_ text: String, file: URL, root: URL, files: [URL]) throws -> Result {
        var documents: [URL: String] = [file: text]
        for other in files where other != file {
            if ["appearanceconfig", "layoutconfig"].contains(other.deletingPathExtension().lastPathComponent.lowercased()) {
                throw SkinFailure(message: "此包包含二进制外观配置，无法确认全部 CSS 调用，未删除任何样式")
            }
            guard kinds.contains(other.pathExtension.lowercased()) else { continue }
            guard let value = SkinConfiguration.read(other) else {
                throw SkinFailure(message: "无法完整读取 \(SkinConfiguration.relative(other, root: root))，未删除任何样式")
            }
            documents[other] = value
        }
        return try clean(text, external: documents.filter { $0.key != file }.map(\.value))
    }
    static func clean(_ text: String, external: [String]) throws -> Result {
        let sections = SkinConfiguration.parse(text)
        var graph: [Int: Set<Int>] = [:], used: Set<Int> = [], targetIDs: Set<Int> = []
        for section in sections {
            if let id = styleID(section.name) {
                guard graph[id] == nil else { throw SkinFailure(message: "CSS 样式编号重复，未删除任何样式") }
                graph[id] = try references(section); targetIDs.insert(id)
            } else { used.formUnion(try references(section)) }
        }
        for document in external {
            for section in SkinConfiguration.parse(document) {
                let refs = try references(section)
                if let id = styleID(section.name) {
                    // A definition is not a call. Follow its references only
                    // when a panel, candidate, popup or animation uses it.
                    graph[id, default: []].formUnion(refs)
                } else { used.formUnion(refs) }
            }
        }
        var pending = Array(used), visited: Set<Int> = []
        while let id = pending.popLast() {
            guard visited.insert(id).inserted else { continue }
            for child in graph[id] ?? [] where used.insert(child).inserted { pending.append(child) }
        }
        let removed = targetIDs.filter { !used.contains($0) }.sorted()
        guard !removed.isEmpty else { return Result(text: text, removed: []) }
        let discarded = Set(removed), ceiling = targetIDs.filter { !discarded.contains($0) }.max() ?? 0
        var dropping = false
        let lines = text.components(separatedBy: "\n").compactMap { line -> String? in
            if let name = SkinConfiguration.header(line) {
                dropping = styleID(name).map { discarded.contains($0) } ?? false
                return dropping ? nil : line
            }
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if dropping {
                // Comments are user content and remain in the plaintext copy.
                return trimmed.isEmpty || trimmed.hasPrefix(";") || trimmed.hasPrefix("#") || trimmed.hasPrefix("//") ? line : nil
            }
            if let equal = line.firstIndex(of: "="), line[..<equal].trimmingCharacters(in: .whitespaces).uppercased() == "STYLE_NUM" {
                let value = String(line[line.index(after: equal)...]), comment = value.range(of: " //")
                return String(line[...equal]) + String(ceiling) + (comment.map { String(value[$0.lowerBound...]) } ?? (line.hasSuffix("\r") ? "\r" : ""))
            }
            return line
        }
        return Result(text: lines.joined(separator: "\n"), removed: removed)
    }
}
