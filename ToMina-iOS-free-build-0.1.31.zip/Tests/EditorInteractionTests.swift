import XCTest
import SwiftUI
import UIKit
@testable import ToMina

final class EditorInteractionTests: XCTestCase {
    @MainActor private final class Focus: ObservableObject { @Published var active = false }
    @MainActor private func input(_ view: UIView) -> UITextView? {
        if let value = view as? UITextView { return value }
        return view.subviews.lazy.compactMap { input($0) }.first
    }
    @MainActor func testNativeTapOpensKeyboardAndTypingSurvivesPreviewUpdates() async throws {
        let draft = EditorDraft(), focus = Focus(); draft.replace("[PANEL]\nSIZE=240,120\n")
        var finishes = 0
        func editor() -> DraftTextEditor {
            DraftTextEditor(draft: draft, focused: Binding(get: { focus.active }, set: { focus.active = $0 }),
                edit: { value, _ in draft.acceptTyping(value); return true }, finish: { finishes += 1 })
        }
        let host = UIHostingController(rootView: editor()), window = UIWindow(frame: CGRect(x: 0,y: 0,width: 400,height: 600))
        window.rootViewController = host; window.makeKeyAndVisible(); defer { window.isHidden = true }
        host.view.layoutIfNeeded()
        let view = try XCTUnwrap(input(host.view))
        XCTAssertTrue(view.isEditable); XCTAssertTrue(view.becomeFirstResponder())
        XCTAssertTrue(focus.active)
        for _ in 0..<4 { host.rootView = editor(); host.view.layoutIfNeeded(); await Task.yield() }
        XCTAssertTrue(view.isFirstResponder, "Preview updates closed the native keyboard")
        view.selectedRange = NSRange(location: (view.text as NSString).length, length: 0)
        view.insertText("; typing works")
        XCTAssertTrue(draft.text.hasSuffix("; typing works"))
        focus.active = false; host.rootView = editor(); host.view.layoutIfNeeded()
        try await Task.sleep(for: .milliseconds(100))
        XCTAssertFalse(view.isFirstResponder); XCTAssertGreaterThan(finishes, 0)
        XCTAssertTrue(view.becomeFirstResponder(), "The editor cannot reopen the keyboard")
    }
    @MainActor func testAnimationEditorFocusAndDisableFinishLatestDraft() async throws {
        let draft = EditorDraft(), focus = Focus(); draft.replace("[ANIM1]\nDURATION=180\n")
        var latest = ""
        func editor(_ enabled: Bool) -> some View {
            DraftTextEditor(draft: draft, focused: Binding(get: { focus.active }, set: { focus.active = $0 }),
                edit: { value, _ in draft.acceptTyping(value); return true }, finish: { latest = draft.text }).disabled(!enabled)
        }
        let host = UIHostingController(rootView: AnyView(editor(true))), window = UIWindow(frame: CGRect(x: 0,y: 0,width: 380,height: 500))
        window.rootViewController = host; window.makeKeyAndVisible(); defer { window.isHidden = true }
        host.view.layoutIfNeeded()
        let view = try XCTUnwrap(input(host.view)); XCTAssertTrue(view.becomeFirstResponder())
        view.selectedRange = NSRange(location: (view.text as NSString).length, length: 0); view.insertText("; 中文")
        host.rootView = AnyView(editor(false)); host.view.layoutIfNeeded()
        try await Task.sleep(for: .milliseconds(100))
        XCTAssertFalse(view.isFirstResponder); XCTAssertFalse(view.isEditable); XCTAssertTrue(latest.hasSuffix("; 中文"))
        host.rootView = AnyView(editor(true)); host.view.layoutIfNeeded()
        try await Task.sleep(for: .milliseconds(100))
        XCTAssertTrue(view.isEditable); XCTAssertTrue(view.becomeFirstResponder())
    }
}
