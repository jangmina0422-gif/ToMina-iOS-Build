import XCTest
import UIKit
import UniformTypeIdentifiers
import ZIPFoundation
import ImageIO
@testable import ToMina

final class DropImportTests: XCTestCase {
    private func directory() throws -> URL {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true); return root
    }
    private func provider(_ file: URL, type: String) -> NSItemProvider {
        let provider = NSItemProvider(); provider.suggestedName = file.lastPathComponent
        provider.registerFileRepresentation(forTypeIdentifier:type,fileOptions:[],visibility:.all) { done in done(file,false,nil);return nil }
        return provider
    }
    func testMixedFileRepresentationsAreCopiedBeforeSenderRemovesThem() async throws {
        let source = try directory(); defer { try? FileManager.default.removeItem(at:source) }
        let names = ["keyboard.bds","drawing.procreate","layers.psd","notes.ini"]
        for name in names { try Data([80,75,3,4,12,255]).write(to:source.appendingPathComponent(name)) }
        let providers = names.map { provider(source.appendingPathComponent($0),type:UTType.data.identifier) }
        let batch = await ResourceImport.stageProviders(providers); defer { batch.discard() }
        XCTAssertTrue(batch.failures.isEmpty); XCTAssertEqual(batch.files.map(\.name),names)
        try FileManager.default.removeItem(at:source)
        for file in batch.files { XCTAssertEqual(try Data(contentsOf:file.url),Data([80,75,3,4,12,255])) }
    }
    func testTypedFileURLAndProviderFailureDoNotLoseOtherFiles() async throws {
        let source = try directory(); defer { try? FileManager.default.removeItem(at:source) }
        let file = source.appendingPathComponent("readme.txt"); try Data("text".utf8).write(to:file)
        let failure = NSItemProvider(); failure.suggestedName = "failed.bin"
        failure.registerFileRepresentation(forTypeIdentifier:UTType.data.identifier,fileOptions:[],visibility:.all) { done in
            done(nil,false,NSError(domain:NSCocoaErrorDomain,code:NSFileReadNoSuchFileError));return nil
        }
        let url = NSItemProvider(object:file as NSURL)
        let batch = await ResourceImport.stageProviders([failure,url]); defer { batch.discard() }
        XCTAssertEqual(batch.failures.count,1); XCTAssertEqual(batch.files.count,1)
        XCTAssertEqual(try Data(contentsOf: XCTUnwrap(batch.files.first).url),Data("text".utf8))
    }
    @MainActor func testPNGExportPreservesBytesAndImageObjectsUseBoundedEncoding() async throws {
        let source = try directory(); defer { try? FileManager.default.removeItem(at:source) }
        let format = UIGraphicsImageRendererFormat(); format.scale = 1
        let image = UIGraphicsImageRenderer(size:CGSize(width:64,height:32),format:format).image { ctx in
            UIColor.red.setFill();ctx.fill(CGRect(x:0,y:0,width:64,height:32))
        }
        let png = try XCTUnwrap(image.pngData()), file = source.appendingPathComponent("original.png"); try png.write(to:file)
        let object = NSItemProvider(object:image); object.suggestedName = "drawing"
        let batch = await ResourceImport.stageProviders([provider(file,type:UTType.png.identifier),object]); defer { batch.discard() }
        XCTAssertTrue(batch.failures.isEmpty); XCTAssertEqual(batch.files.count,2)
        XCTAssertEqual(try Data(contentsOf:batch.files[0].url),png)
        let pixels = try XCTUnwrap(CGImageSourceCreateWithURL(batch.files[1].url as CFURL,nil))
        let properties = try XCTUnwrap(CGImageSourceCopyPropertiesAtIndex(pixels,0,nil) as? [String:Any])
        XCTAssertEqual(properties[kCGImagePropertyPixelWidth as String] as? Int,64)
        XCTAssertEqual(properties[kCGImagePropertyPixelHeight as String] as? Int,32)
        XCTAssertTrue(ResourceImport.safeImageObject(width:4096,height:4096))
        for (width,height) in [(CGFloat.infinity,CGFloat(1)),(-1,100),(8192,8192),(0,300)] {
            XCTAssertFalse(ResourceImport.safeImageObject(width:width,height:height))
        }
    }
    @MainActor func testDropImportIndexesInBackgroundAndKeepsCurrentKeyboard() async throws {
        let source = try directory(); defer { try? FileManager.default.removeItem(at:source) }
        let skin = source.appendingPathComponent("skin");try FileManager.default.createDirectory(at:skin,withIntermediateDirectories:true)
        try "[PANEL]\nSIZE=240,120\n[KEY1]\nVIEW_RECT=0,0,60,50\nCENTER=q\n".write(to:skin.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
        let original = source.appendingPathComponent("keyboard.bds");try FileManager.default.zipItem(at:skin,to:original,shouldKeepParent:false)
        let bytes = try Data(contentsOf:original), store = SkinStore();await store.openArchive(original)
        defer { if let root = store.root { try? FileManager.default.removeItem(at:root) } }
        let current = store.current, root = try XCTUnwrap(store.root), file = source.appendingPathComponent("layers.psd")
        try Data([56,66,80,83]).write(to:file)
        let batch = await ResourceImport.stageProviders([provider(file,type:UTType.data.identifier)]);defer{batch.discard()}
        let count = try await store.importResources(batch,into:root,policy:.keepBoth)
        XCTAssertEqual(count,1);XCTAssertTrue(store.importPreparedOffMain);XCTAssertFalse(store.busy)
        XCTAssertEqual(store.current,current);XCTAssertEqual(store.previewPanelName,"py_26");XCTAssertFalse(store.blankPreview)
        XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("layers.psd")),Data([56,66,80,83]))
        XCTAssertEqual(try Data(contentsOf:original),bytes)
    }
}
