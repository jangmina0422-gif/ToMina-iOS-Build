import XCTest
import SwiftUI
import UIKit
import ZIPFoundation
@testable import ToMina

final class IqooPreviewTests: XCTestCase {
    @MainActor func testActualIQOOLayoutAndCandidateConfiguration() async throws {
        let fixture=try XCTUnwrap(Bundle(for:Self.self).url(forResource:"preview-fixtures",withExtension:"json",subdirectory:"Fixtures"))
        let packages=try JSONDecoder().decode([String:[String:String]].self,from:Data(contentsOf:fixture))
        for (name,files) in packages {
            let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            let skin=folder.appendingPathComponent("skin")
            for (path,text) in files {
                let file=skin.appendingPathComponent(path)
                try FileManager.default.createDirectory(at:file.deletingLastPathComponent(),withIntermediateDirectories:true)
                try text.write(to:file,atomically:true,encoding:.utf8)
            }
            let archive=folder.appendingPathComponent(name)
            try FileManager.default.zipItem(at:skin,to:archive,shouldKeepParent:false)
            let store=SkinStore();await store.openArchive(archive,asCopy:true)
            XCTAssertNil(store.error)
            defer {if let root=store.root{try? FileManager.default.removeItem(at:root)};try? FileManager.default.removeItem(at:folder)}
            for relative in ["port/py_26.ini","port/hw_grid.ini","port/num_9.ini","land/py_26.ini","land/hw_grid.ini"] {
                let file=try XCTUnwrap(store.files.first{$0.path.hasSuffix("/"+relative)})
                try store.open(file)
                XCTAssertFalse(store.blankPreview,relative)
                XCTAssertEqual(store.renderer.candidateFile?.lastPathComponent,"cand1.cnd",name+" "+relative)
                XCTAssertGreaterThan(store.renderer.candidateSize.height,0)
                let bounds=store.renderer.previewBounds(panel:store.panel,keys:store.keys)
                XCTAssertLessThan(bounds.minY,0)
                let scene=Canvas{context,_ in
                    context.translateBy(x:-bounds.minX,y:-bounds.minY)
                    store.renderer.drawPreview(panel:store.panel,keys:store.keys,pressed:false,scale:1,rasterScale:1,context:&context)
                }.frame(width:bounds.width,height:bounds.height)
                let renderer=ImageRenderer(content:scene);renderer.scale=1
                let image=try XCTUnwrap(renderer.uiImage)
                let attachment=XCTAttachment(image:image);attachment.name=name+"-"+relative;attachment.lifetime = .keepAlways;add(attachment)
                print("IQOO",name,relative,"bar",store.renderer.candidateSize,"keys",store.keys.count,"bounds",bounds)
            }
        }
    }
}
