from pathlib import Path
import os,subprocess,zipfile,json

base=Path(__file__).resolve().parent
sdk=Path(os.environ['ANDROID_HOME'])
bt=sorted((sdk/'build-tools').iterdir())[-1]
android=sorted((sdk/'platforms').glob('*/android.jar'))[-1]
out=base/'build';out.mkdir(exist_ok=True)
def run(*args):subprocess.run([str(x) for x in args],check=True)
key=out/'test.jks'
run('keytool','-genkeypair','-keystore',key,'-storepass','android','-keypass','android','-alias','test','-dname','CN=Preview Regression Test','-keyalg','RSA','-validity','30')
fixtures=json.loads((base/'fixtures.json').read_text())
for target in ['app','test']:
    folder=out/target;folder.mkdir(exist_ok=True)
    assets=folder/'assets';assets.mkdir()
    if target=='test':
        for fixture,files in fixtures.items():
            with zipfile.ZipFile(assets/fixture,'w',zipfile.ZIP_DEFLATED) as z:
                for name,text in files.items():z.writestr(name,text)
    else:
        (folder/'res/values').mkdir(parents=True)
        (folder/'res/values/styles.xml').write_text((base/'styles.xml').read_text())
        run(bt/'aapt2','compile','--dir',folder/'res','-o',folder/'res.zip')
    args=[bt/'aapt2','link','-o',folder/'base.apk','--manifest',base/(target+'-manifest.xml'),'-I',android,'-A',assets]
    if target=='app':args.append(folder/'res.zip')
    run(*args)
    with zipfile.ZipFile(folder/'base.apk') as old,zipfile.ZipFile(folder/'unsigned.apk','w',zipfile.ZIP_DEFLATED) as new:
        for name in old.namelist():new.writestr(name,old.read(name))
        new.write(base/(target+'.dex'),'classes.dex')
    run(bt/'zipalign','-f','4',folder/'unsigned.apk',folder/'aligned.apk')
    run(bt/'apksigner','sign','--ks',key,'--ks-pass','pass:android','--key-pass','pass:android','--out',out/(target+'.apk'),folder/'aligned.apk')
