#if DEBUG
import Foundation
import ZIPFoundation
import UIKit

// Synthetic data is available only in the Debug UI test process.
@MainActor enum EditorUIFixture {
    static var combined: Bool { ProcessInfo.processInfo.arguments.contains("--combined-preview-fixture") }
    static var iqoo: Bool { ProcessInfo.processInfo.arguments.contains("--iqoo-preview-fixture") }
    static var requested: Bool { combined || iqoo || ProcessInfo.processInfo.arguments.contains("--editor-controls-fixture") }
    static var width: CGFloat? { ProcessInfo.processInfo.arguments.contains("--narrow-preview-fixture") ? 375 : nil }
    static func openIfRequested(_ store: SkinStore) async -> Bool {
        guard requested else { return false }
        if iqoo {
            do {
                let name=ProcessInfo.processInfo.arguments.contains("--iqoo-original-fixture") ? "iqoo.bds":"user-iqoo-3.bds"
                store.compatiblePreview=true
                await store.openArchive(try PreviewTestFixtures.archive(name))
                return store.root != nil && store.error == nil
            } catch {store.error=error.localizedDescription;return false}
        }
        if combined { return await openCombined(store) }
        do {
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            let skin = folder.appendingPathComponent("skin"), port = skin.appendingPathComponent("port")
            try FileManager.default.createDirectory(at: port, withIntermediateDirectories: true)
            if ProcessInfo.processInfo.arguments.contains("--bdi-gif-tool-fixture") {
                try Data(base64Encoded:"IjUKAmphEi86BAgBEBZSBAgBEBYaEQoHS0VZX+OBnxIGEgQIAhAMsgQNdW5rbm93bi1wYW5lbCI4CgVvdGhlchIvOgQIARAWUgQIARAWGhEKB0tFWV/jgZ8SBhIECAIQDLIEDXVua25vd24tcGFuZWy6BAx1bmtub3duLXJvb3QwuAg=")!.write(to:port.appendingPathComponent("appearanceConfig"))
                let preview:[String:Any] = ["designWidth":1080,"designHeight":640,"panels":["ja":["width":1080,"height":640],"other":["width":1080,"height":640]]]
                try JSONSerialization.data(withJSONObject:preview).write(to:port.appendingPathComponent("appearanceConfig.json"))
                try "SupportPlatform=I\nSkinType=1\n".write(to:skin.appendingPathComponent("Info.txt"),atomically:true,encoding:.utf8)
                let archive=folder.appendingPathComponent("controls.bdi")
                try FileManager.default.zipItem(at:skin,to:archive,shouldKeepParent:false)
                await store.openArchive(archive);return store.root != nil && store.error == nil
            }
            try "[PANEL]\nSIZE=240,120\nKEY_NUM=1\nTIP_NUM=1\n[KEY1]\nVIEW_RECT=0,0,60,50\nCENTER=q\nBACK_STYLE=1\nSTAT_STYLE=S34_1|S36_1|S37_1\n[TIP1]\nFORE_STYLE=3\n"
                .write(to: port.appendingPathComponent("py_26.ini"), atomically: true, encoding: .utf8)
            if ProcessInfo.processInfo.arguments.contains("--view-fit-fixture") {
                let inset="[PANEL]\nSIZE=240,120\nKEY_NUM=4\n[KEY1]\nVIEW_RECT=12,8,96,44\nCENTER=q\n[KEY2]\nVIEW_RECT=132,8,96,44\nCENTER=w\n[KEY3]\nVIEW_RECT=12,68,96,44\nCENTER=a\n[KEY4]\nVIEW_RECT=132,68,96,44\nCENTER=F38\n"
                try inset.write(to:port.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
                try inset.replacingOccurrences(of:"CENTER=q",with:"CENTER=other").write(to:skin.appendingPathComponent("other.ini"),atomically:true,encoding:.utf8)
            }
            if ProcessInfo.processInfo.arguments.contains("--list-fit-fixture") {
                let list="[PANEL]\nSIZE=240,120\nKEY_NUM=2\n[LIST]\nPOS=8,8\nCELL_SIZE=40,26\nLIST_NUM=4\nPADDING=0,0,0,0\nNAMES=1 2 3 4\nVALUES=a b c d\n[KEY1]\nVIEW_RECT=56,8,176,48\nCENTER=q\n[KEY2]\nVIEW_RECT=56,64,176,48\nCENTER=F38\n"
                try list.write(to:port.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
            }
            if ProcessInfo.processInfo.arguments.contains("--handwriting-fit-fixture") {
                let handwriting="[PANEL]\nSIZE=240,120\n[KEY1]\nVIEW_RECT=8,8,164,72\nCENTER=F53\n[KEY2]\nVIEW_RECT=180,8,52,32\nCENTER=F36\n[KEY3]\nVIEW_RECT=180,48,52,32\nCENTER=。\n[KEY4]\nVIEW_RECT=8,88,100,24\nCENTER=F1\n[KEY5]\nVIEW_RECT=116,88,116,24\nCENTER=F38\n[KEY6]\nVIEW_RECT=12,62,30,14\nCENTER=F78\n"
                try handwriting.write(to:port.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
            }
            try "[GLOBAL]\nSTYLE_NUM=3\n[STYLE1]\nNM_COLOR=FFFFFFFF\n[STYLE2]\nNM_COLOR=FF000000\n[STYLE3]\nNM_COLOR=FF000000\n"
                .write(to: skin.appendingPathComponent("styles.css"), atomically: true, encoding: .utf8)
            if ProcessInfo.processInfo.arguments.contains("--multiple-css-fixture") {
                try "[STYLE99]\nNM_COLOR=FF123456\n".write(to: skin.appendingPathComponent("extra.css"), atomically: true, encoding: .utf8)
            }
            try "[GLOBAL]\nANIM_NUM=1\n[ANIM1]\nCATEGORY=3\nPARTICLE_IMAGE=1\nTOTAL_NUMBER=1\nLIFE=1000\n"
                .write(to: skin.appendingPathComponent("anim.ini"), atomically: true, encoding: .utf8)
            try ((0..<600).map { "; line \($0) 中文 🎨" }.joined(separator: "\n") + "\n; END")
                .write(to: skin.appendingPathComponent("long.txt"), atomically: true, encoding: .utf8)
            let file = folder.appendingPathComponent(ProcessInfo.processInfo.arguments.contains("--half-bda-tool-fixture") ? "controls.bda":"controls.bds")
            try FileManager.default.zipItem(at: skin, to: file, shouldKeepParent: false)
            await store.openArchive(file)
            return store.root != nil && store.error == nil
        } catch { store.error = error.localizedDescription; return false }
    }
    private static func openCombined(_ store: SkinStore) async -> Bool {
        do {
            let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            let skin=folder.appendingPathComponent("skin"),port=skin.appendingPathComponent("port"),res=port.appendingPathComponent("res")
            try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
            try "[PANEL]\nSIZE=1080,640\nBACK_STYLE=1\n[CAND]\nLAYOUT_NAME=cand1\nVIEW_RECT=0,0,1080,120\n".write(to:port.appendingPathComponent("gen.ini"),atomically:true,encoding:.utf8)
            var keyboard="[INPUT]\n[CAND]\n[PANEL]\nKEY_NUM=40\n"
            let captions=Array("qwertyuiopasdfghjkl;zxcvbnm,./1234567890")
            for row in 0..<4 { for col in 0..<10 {
                let index=row*10+col
                keyboard += "[KEY\(index+1)]\nVIEW_RECT=\(col*108),\(row*160),108,160\nBACK_STYLE=3\nCENTER=\(captions[index])\nANIM_STYLE=4\n"
            }}
            try keyboard.write(to:port.appendingPathComponent("py_26.ini"),atomically:true,encoding:.utf8)
            try "[CAND]\nBACK_STYLE=2\n[ICON1]\nVIEW_RECT=950,40,60,40\nBACK_STYLE=5\nPERSIST=3\n".write(to:port.appendingPathComponent("cand1.cnd"),atomically:true,encoding:.utf8)
            try "[STYLE1]\nNM_COLOR=FFF8EAD8\n[STYLE2]\nNM_IMG=bar,1\n[STYLE3]\nNM_COLOR=FF4080C0\n[STYLE4]\nPRESS_ANIM=1\n[STYLE5]\nNM_COLOR=FF30A060\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
            try "[IMG1]\nSOURCE_RECT=0,0,1080,120\n".write(to:res.appendingPathComponent("bar.til"),atomically:true,encoding:.utf8)
            let format=UIGraphicsImageRendererFormat();format.scale=1
            let atlas=UIGraphicsImageRenderer(size:CGSize(width:1080,height:120),format:format).image { ctx in
                UIColor(red:248/255,green:234/255,blue:216/255,alpha:1).setFill();ctx.fill(CGRect(x:0,y:0,width:1080,height:120))
                UIColor(red:160/255,green:96/255,blue:64/255,alpha:1).setFill();ctx.fill(CGRect(x:0,y:0,width:1080,height:30))
            }
            try atlas.pngData()!.write(to:res.appendingPathComponent("bar.png"))
            try "[GLOBAL]\nANIM_NUM=1\n[ANIM1]\nTYPE=1\nFROM=0\nTO=10\nDURATION=150\n".write(to:res.appendingPathComponent("anim.ini"),atomically:true,encoding:.utf8)
            let file=folder.appendingPathComponent("combined.bds")
            try FileManager.default.zipItem(at:skin,to:file,shouldKeepParent:false)
            await store.openArchive(file)
            return store.root != nil && store.error == nil
        } catch { store.error=error.localizedDescription;return false }
    }
}
#endif
