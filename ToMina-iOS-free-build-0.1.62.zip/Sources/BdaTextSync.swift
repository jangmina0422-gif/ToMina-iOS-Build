import Foundation
import CoreFoundation

enum BdaTextSync {
    typealias Schemas=[String:[String:[String:String]]]
    static func patch(_ binary:Data,json:Data,type:String,schemas:Schemas) throws -> Data {
        guard let object=try JSONSerialization.jsonObject(with:json) as? [String:Any] else{throw SkinFailure(message:"同名文本必须为 JSON 对象")}
        var budget=0,fields=try BinaryPlaintext.parse(Array(binary),budget:&budget)
        func failure(_ message:String)->SkinFailure{SkinFailure(message:message+"，未覆盖二进制")}
        func value(_ f:inout BinaryPlaintext.Field,_ object:Any,_ type:String,_ depth:Int) throws {
            if type=="string" {
                guard f.wire==2,let s=object as? String else{throw failure("字符串结构不匹配")};f.bytes=Array(s.utf8);return
            }
            if type=="boolean" {
                guard f.wire==0,let n=object as? NSNumber,CFGetTypeID(n)==CFBooleanGetTypeID() else{throw failure("布尔结构不匹配")};f.bits=n.boolValue ? 1:0;return
            }
            if type=="number" {
                guard let n=object as? NSNumber,CFGetTypeID(n) != CFBooleanGetTypeID(),n.doubleValue.isFinite else{throw failure("数值无效")}
                let d=n.doubleValue
                switch f.wire {
                case 0:
                    guard d.rounded()==d,d>=Double(Int64.min),d<Double(Int64.max) else{throw failure("整数越界")}
                    f.bits=UInt64(bitPattern:n.int64Value)
                case 5:guard Float(d).isFinite else{throw failure("浮点数越界")};f.bits=UInt64(Float(d).bitPattern)
                case 1:f.bits=d.bitPattern
                default:throw failure("数值编码不匹配")
                };return
            }
            guard f.wire==2,var children=f.children,let object=object as? [String:Any] else{throw failure("子结构不匹配")}
            try message(&children,object,type,depth+1);f.children=children;f.bytes=Array(BinaryPlaintext.encode(children))
        }
        func message(_ fields:inout [BinaryPlaintext.Field],_ object:[String:Any],_ type:String,_ depth:Int) throws {
            guard depth<=24,let specs=schemas[type] else{throw failure("未验证结构 "+type)}
            for (name,object) in object {
                guard let entry=specs.first(where:{$0.value["name"]==name}),let number=Int(entry.key),let raw=entry.value["type"] else{throw failure("未验证字段 "+type+"."+name)}
                let indices=fields.indices.filter{fields[$0].number==number},subtype=raw.replacingOccurrences(of:"*",with:"").replacingOccurrences(of:"[]",with:"")
                if raw.hasPrefix("*") {
                    guard let map=object as? [String:Any] else{throw failure("映射类型不匹配")};var seen=Set<String>()
                    for i in indices {
                        guard var children=fields[i].children,let key=children.first(where:{$0.number==1}),let v=children.firstIndex(where:{$0.number==2}) else{throw failure("映射缺少键值")}
                        let name=key.text ?? String(key.bits)
                        if let object=map[name]{try value(&children[v],object,subtype,depth);fields[i].children=children;fields[i].bytes=Array(BinaryPlaintext.encode(children));seen.insert(name)}
                    }
                    guard Set(map.keys).isSubset(of:seen) else{throw failure("新增映射项目尚未验证")}
                } else if raw.hasSuffix("[]") {
                    guard let array=object as? [Any],array.count==indices.count else{throw failure("数组数量变化尚未验证")}
                    for (j,i) in indices.enumerated(){try value(&fields[i],array[j],subtype,depth)}
                } else {
                    guard indices.count==1 else{throw failure("字段缺失或重复 "+name)}
                    try value(&fields[indices[0]],object,subtype,depth)
                }
            }
        }
        try message(&fields,object,type,0)
        let output=BinaryPlaintext.encode(fields);budget=0
        _=try BinaryPlaintext.parse(Array(output),budget:&budget)
        return output
    }
    static func preview(file:URL,text:String,files:[URL])throws->[URL:Data] {
        let name=file.deletingPathExtension().lastPathComponent
        guard ["appearanceConfig","layoutConfig","animationConfig","sceneConfig","soundConfig"].contains(name),
              let binary=files.first(where:{$0.deletingLastPathComponent()==file.deletingLastPathComponent() && $0.lastPathComponent==name}),
              let data=text.data(using:.utf8),
              let schemaURL=Bundle.main.url(forResource:"BdaSchemas",withExtension:"json"),
              let schemas=try JSONSerialization.jsonObject(with:Data(contentsOf:schemaURL)) as? Schemas else{throw SkinFailure(message:"缺少已验证字段映射")}
        let patched=try patch(Data(contentsOf:binary),json:data,type:name.replacingOccurrences(of:"Config",with:""),schemas:schemas)
        return [file:data,binary:patched]
    }
    @MainActor static func synchronize(files:[URL]) throws -> String {
        guard let schemaURL=Bundle.main.url(forResource:"BdaSchemas",withExtension:"json"),let schemas=try JSONSerialization.jsonObject(with:Data(contentsOf:schemaURL)) as? Schemas else{throw SkinFailure(message:"缺少已验证字段映射")}
        var pending:[URL:Data]=[:],logs:[String]=[]
        for file in files where ["json","txt"].contains(file.pathExtension.lowercased()) {
            let name=file.deletingPathExtension().lastPathComponent
            guard ["appearanceConfig","layoutConfig","animationConfig","sceneConfig","soundConfig"].contains(name),let binary=files.first(where:{$0.deletingLastPathComponent()==file.deletingLastPathComponent() && $0.lastPathComponent==name}) else{continue}
            let siblings=files.filter{$0.deletingLastPathComponent()==file.deletingLastPathComponent() && $0.deletingPathExtension().lastPathComponent==name && ["json","txt"].contains($0.pathExtension.lowercased())}
            guard siblings.count==1 else{throw SkinFailure(message:"同名 JSON 和 TXT 同时存在，请保留一个后导出")}
            guard let text=IniSkinRenderer.read(file),let data=text.data(using:.utf8) else{throw SkinFailure(message:"无法读取 "+file.lastPathComponent)}
            pending[binary]=try patch(Data(contentsOf:binary),json:data,type:name.replacingOccurrences(of:"Config",with:""),schemas:schemas)
            logs.append(file.lastPathComponent+"：已同步")
        }
        var originals:[URL:Data]=[:]
        do {for (file,data) in pending {originals[file]=try Data(contentsOf:file);try data.write(to:file,options:.atomic)}}
        catch {for (file,data) in originals{try? data.write(to:file,options:.atomic)};throw error}
        return logs.joined(separator:"\n")
    }

    struct UpdateResult: Sendable {
        var updated = 0
        var unchanged = 0
        var logs: [String] = []
        var report: String {
            "已更新 \(updated) 个二进制，\(unchanged) 个已是最新。\n" + logs.joined(separator:"\n") + "\n\n更新已写入当前工程；保存或导出即可使用。"
        }
    }
    /// Draft text and all binaries form one transaction; validation never writes files.
    static let noEditableConfigs = "当前包没有半 BDA 的配套 JSON/TXT 配置。普通 INI 修改直接保存或导出即可，无需更新半 BDA。"
    static func editableKind(_ file:URL)->String? {
        guard ["json","txt"].contains(file.pathExtension.lowercased()) else{return nil}
        return ["appearanceConfig","layoutConfig","animationConfig","sceneConfig","soundConfig"].first{$0.lowercased()==file.deletingPathExtension().lastPathComponent.lowercased()}
    }
    static func updateHalfBda(root: URL, files: [URL], drafts: [URL:Data] = [:], schemas supplied: Schemas? = nil) throws -> UpdateResult {
        func kind(_ file:URL)->String? { editableKind(file) }
        let texts = files.filter { kind($0) != nil }.sorted { $0.path < $1.path }
        guard !texts.isEmpty else { throw SkinFailure(message:noEditableConfigs) }
        let schemas: Schemas
        if let supplied { schemas = supplied }
        else {
            guard let url=Bundle.main.url(forResource:"BdaSchemas",withExtension:"json"),let decoded=try JSONSerialization.jsonObject(with:Data(contentsOf:url)) as? Schemas else { throw SkinFailure(message:"缺少已验证字段映射") }
            schemas=decoded
        }
        var result=UpdateResult(),pending:[URL:Data]=[:],originals:[URL:Data]=[:]
        for text in texts {
            let name=kind(text)!,path=SkinConfiguration.relative(text,root:root)
            do {
                let neighbors=files.filter { $0.deletingLastPathComponent()==text.deletingLastPathComponent() }
                let binaries=neighbors.filter { $0.lastPathComponent.lowercased()==name.lowercased() }
                guard !binaries.isEmpty else { throw SkinFailure(message:"缺少同目录的 \(name) 二进制") }
                guard binaries.count==1,neighbors.filter({kind($0)==name}).count==1 else { throw SkinFailure(message:"同名 JSON/TXT 或二进制存在冲突，请只保留一份") }
                let binary=binaries[0],old=try Data(contentsOf:binary),textBefore=try Data(contentsOf:text),textData=drafts[text] ?? textBefore
                guard let decoded=SkinConfiguration.decode(textData) else { throw SkinFailure(message:"无法识别文本编码") }
                let next=try patch(old,json:Data(decoded.text.utf8),type:name.replacingOccurrences(of:"Config",with:""),schemas:schemas)
                if next==old { result.unchanged+=1;result.logs.append(path+"：已是最新") }
                else { pending[binary]=next;originals[binary]=old;result.updated+=1;result.logs.append(path+"：已更新二进制") }
                if textData != textBefore { pending[text]=textData;originals[text]=textBefore }
            } catch { throw SkinFailure(message:path+"："+error.localizedDescription+"\n本次未更新任何二进制。") }
        }
        var written:[URL]=[]
        do { for file in pending.keys.sorted(by:{$0.path<$1.path}) { written.append(file);try pending[file]!.write(to:file,options:.atomic) } }
        catch {
            var restored=true
            for file in written { do { try originals[file]!.write(to:file,options:.atomic) } catch { restored=false } }
            throw SkinFailure(message:restored ? "写入失败，已恢复原文件。":"写入失败，部分文件未能恢复，请重新导入原包。")
        }
        return result
    }
}
