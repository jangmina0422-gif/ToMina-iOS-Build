import SwiftUI
import UniformTypeIdentifiers

struct ArchiveBrowser: View {
    @ObservedObject var store: SkinStore
    @Binding var relativeDirectory: String
    let openFile: (URL) -> Void
    let chooseFiles: (URL) -> Void
    let dropped: ([NSItemProvider], URL) -> Bool
    let close: () -> Void
    @State private var search = ""
    @State private var entries: [ArchiveEntry] = []
    @State private var newFolder = false
    @State private var folderName = ""
    @State private var error: String?
    @State private var targeted = false
    @State private var deleting: ArchiveEntry?
    @State private var renaming: ArchiveEntry?
    @State private var renameName = ""
    @State private var selecting = false
    @State private var selectedFiles: Set<URL> = []
    @State private var deletingSelection = false
    @State private var notice = ""
    private var folder: URL? { store.root?.appendingPathComponent(relativeDirectory, isDirectory: true) }
    private var rows: [ArchiveEntry] {
        if search.isEmpty { return entries }
        let folders = entries.filter { $0.directory && store.relative($0.url).localizedCaseInsensitiveContains(search) }
        return folders + store.files.filter { store.relative($0).localizedCaseInsensitiveContains(search) }.map { ArchiveEntry(url: $0, directory: false) }
    }
    var body: some View {
        NavigationStack {
            browserContent
                .searchable(text: $search, prompt: "搜索包内文件")
                .navigationTitle("包内文件夹")
                .toolbar { folderToolbar }
                .task(id: refreshKey) { await loadEntries() }
                .onChange(of: relativeDirectory) { _, _ in selectedFiles.removeAll(); notice = "" }
                .onChange(of: search) { _, _ in selectedFiles.removeAll() }
                .onChange(of: store.fileRevision) { _, _ in selectedFiles.formIntersection(Set(store.files)) }
                .interactiveDismissDisabled(store.busy)
                .alert("新建文件夹", isPresented: $newFolder) {
                    TextField("文件夹名称", text: $folderName)
                    Button("创建", action: createFolder)
                    Button("取消", role: .cancel) {}
                }
                .alert("删除包内文件？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
                    Button("删除", role: .destructive) { removeFile() }
                    Button("取消", role: .cancel) { deleting = nil }
                } message: {
                    Text("删除 " + (deleting.map { store.relative($0.url) } ?? "") + "？保存后会从原包移除。")
                }
                .alert("删除所选 \(selectedFiles.count) 个文件？", isPresented: $deletingSelection) {
                    Button("删除", role: .destructive) { removeSelectedFiles() }
                    Button("取消", role: .cancel) {}
                } message: {
                    Text(selectedFiles.sorted { $0.path < $1.path }.prefix(8).map { store.relative($0) }.joined(separator: "\n")
                         + (selectedFiles.count > 8 ? "\n……" : "") + "\n保存后会从原包移除。")
                }
                .alert("更名", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                    TextField("新名称", text: $renameName)
                    Button("确定") { renameEntry() }
                    Button("取消", role: .cancel) { renaming = nil }
                } message: { Text(renaming?.url.lastPathComponent ?? "") }
                .alert("提示", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                    Button("确定") { error = nil }
                } message: { Text(error ?? "") }
        }.preferredColorScheme(.light)
    }
    private var refreshKey: String { (store.root?.path ?? "") + "/" + relativeDirectory + ":" + String(store.fileRevision) }
    private var browserContent: some View {
        VStack(spacing: 0) {
            pathBar
            folderActions.padding(.horizontal,12).padding(.bottom,12)
            List(rows) { entry in entryRow(entry) }.listStyle(.plain)
            if selecting {
                HStack {
                    Text("已选 \(selectedFiles.count) 个文件").font(.caption)
                    Spacer()
                    Button("删除所选", role: .destructive) { deletingSelection = true }
                        .accessibilityIdentifier("archive.deleteSelected").disabled(selectedFiles.isEmpty || store.busy)
                }.padding(12)
            } else {
                Text(notice.isEmpty ? "长按文件可复制；多选后可批量删除" : notice)
                    .font(.caption).foregroundStyle(MinaTheme.muted).padding(12)
            }
        }.background(MinaTheme.background).contentShape(Rectangle())
            .overlay { dropBorder }
            .onDrop(of: [UTType.item.identifier], isTargeted: $targeted) { providers in
                guard let folder else { return false }; return dropped(providers, folder)
            }
    }
    private var pathBar: some View {
        HStack {
            if !relativeDirectory.isEmpty {
                Button { relativeDirectory = (relativeDirectory as NSString).deletingLastPathComponent } label: {
                    Label { Text("上一级") } icon: { MinaIcon(name: "arrow.up") }
                }.disabled(store.busy)
            }
            Text(relativeDirectory.isEmpty ? store.filename : store.filename + "/" + relativeDirectory).font(.caption).lineLimit(2)
            Spacer()
        }.padding(12).foregroundStyle(MinaTheme.ink)
    }
    private func entryRow(_ entry: ArchiveEntry) -> some View {
        Button {
            if entry.directory { relativeDirectory = store.relative(entry.url); search = "" }
            else if selecting {
                if selectedFiles.contains(entry.url) { selectedFiles.remove(entry.url) }
                else { selectedFiles.insert(entry.url) }
            }
            else { openFile(entry.url) }
        } label: {
            Label {
                Text(search.isEmpty ? entry.url.lastPathComponent : store.relative(entry.url)).foregroundStyle(MinaTheme.ink)
            } icon: {
                MinaIcon(name: entry.directory ? "folder" : (selecting ? (selectedFiles.contains(entry.url) ? "checkmark.circle" : "circle") : "doc"))
            }
        }
        .contextMenu {
            if !selecting {
            Button {
                renameName = entry.url.lastPathComponent; renaming = entry
            } label: { Label { Text("更名") } icon: { MinaIcon(name: "character.cursor.ibeam") } }
            if !entry.directory {
                Button { openFile(entry.url) } label: { Label { Text("编辑") } icon: { MinaIcon(name: "pencil") } }
                Button { copyFile(entry) } label: { Label { Text("复制文件") } icon: { MinaIcon(name: "doc.on.doc") } }
                Button(role: .destructive) { deleting = entry } label: { Label { Text("删除") } icon: { MinaIcon(name: "trash") } }
            }
            }
        }.disabled(store.busy)
    }
    private func copyFile(_ entry: ArchiveEntry) {
        Task {
            do {
                let copy = try await store.copyArchiveFile(entry.url)
                notice = "已复制为 " + copy.lastPathComponent
            } catch { self.error = error.localizedDescription }
        }
    }
    private func removeSelectedFiles() {
        let files = Array(selectedFiles)
        Task {
            do {
                try await store.deleteArchiveFiles(files)
                selectedFiles.removeAll(); selecting = false; notice = "已删除 \(files.count) 个文件"
            } catch { self.error = error.localizedDescription }
        }
    }
    private func removeFile() {
        guard let entry = deleting else { return }; deleting = nil
        Task {
            do { try await store.deleteArchiveFile(entry.url) }
            catch { self.error = error.localizedDescription }
        }
    }
    private func renameEntry() {
        guard let entry = renaming else { return }
        let name = renameName; renaming = nil
        Task {
            do {
                let previous = folder
                let result = try await store.renameArchiveEntry(entry.url, to: name)
                if let previous { relativeDirectory = store.relative(result.relocated(previous)) }
            } catch { self.error = error.localizedDescription }
        }
    }
    @ViewBuilder private var dropBorder: some View {
        if targeted { RoundedRectangle(cornerRadius: 12).stroke(MinaTheme.ink, lineWidth: 2).padding(4).allowsHitTesting(false) }
    }
    @ToolbarContentBuilder private var folderToolbar: some ToolbarContent {
        ToolbarItem(placement:.topBarTrailing) {
            Button("关闭",action:close).frame(minWidth:44,minHeight:44).accessibilityIdentifier("archive.close").disabled(store.busy)
        }
    }
    private var folderActions: some View {
        MinaFlow(spacing:10) {
            if selecting {
                Button(selectedFiles == Set(rows.filter{!$0.directory}.map(\.url)) ? "取消全选":"全选") {
                    let visible=Set(rows.filter{!$0.directory}.map(\.url));selectedFiles=selectedFiles == visible ? []:visible
                }.accessibilityIdentifier("archive.selectAll")
                Button("取消多选") { selecting=false;selectedFiles.removeAll() }.accessibilityIdentifier("archive.cancelSelection")
            } else {
                Button { folderName="";newFolder=true } label: { Label("新建文件夹",systemImage:"folder.badge.plus") }
                    .accessibilityIdentifier("archive.newFolder")
                Button("导入文件") { if let folder { chooseFiles(folder) } }.accessibilityIdentifier("archive.importFiles")
                Button("多选") { selecting=true;selectedFiles.removeAll();notice="" }.accessibilityIdentifier("archive.selectFiles")
            }
        }.buttonStyle(MinaButtonStyle()).disabled(store.busy)
    }
    @MainActor private func loadEntries() async {
        guard let root = store.root, let folder else { entries = []; return }
        do { entries = try await Task.detached { try ArchiveFiles.entries(in: folder, root: root) }.value }
        catch { entries = []; self.error = error.localizedDescription }
    }
    private func createFolder() {
        guard let root = store.root, let folder else { return }
        do { try ArchiveFiles.createFolder(folderName, in: folder, root: root); store.rescan() }
        catch { self.error = error.localizedDescription }
    }
}
