import XCTest
@testable import ToMina

final class ArchiveFolderNameTests: XCTestCase {
    func testFolderNamesRejectInvisibleControlsAndCaseOrUnicodeCollisions() throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
        defer {try? FileManager.default.removeItem(at:root)}
        try ArchiveFiles.createFolder("Images",in:root,root:root)
        try ArchiveFiles.createFolder("café",in:root,root:root)
        for name in ["images"," ","bad\nname","cafe\u{301}",String(repeating:"中",count:86)] {
            XCTAssertThrowsError(try ArchiveFiles.createFolder(name,in:root,root:root),name)
        }
        XCTAssertEqual(try FileManager.default.contentsOfDirectory(atPath:root.path).count,2)
    }
}
