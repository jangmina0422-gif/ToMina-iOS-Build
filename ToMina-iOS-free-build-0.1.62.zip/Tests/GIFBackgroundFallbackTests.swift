import XCTest
import UIKit
import ImageIO
import ZIPFoundation
@testable import ToMina

final class GIFBackgroundFallbackTests: XCTestCase {
    func testMissingAtlasAppliesAnimatedGIFAndRoundTripsWithOriginalSource() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer {try? fm.removeItem(at:root)}
        let project=root.appendingPathComponent("project"),res=project.appendingPathComponent("port/res")
        try fm.createDirectory(at:res,withIntermediateDirectories:true)
        let texts=[
            "port/py_26.ini":"[PANEL]\nSIZE=1080,640\nBACK_STYLE=1\n[KEY1]\nCENTER=q\nVIEW_RECT=0,0,108,160\nBACK_STYLE=1\nFORE_STYLE=2\n",
            "port/res/default.css":"[STYLE1]\nNM_IMG=btn_fhl,1\n[STYLE2]\nSHOW=Q\nFONT_SIZE=20\nNM_COLOR=FF112233\n",
            "port/res/btn_fhl.til":"[IMG1]\nSOURCE_RECT=0,0,1,1\n"
        ]
        for (path,text) in texts {try Data(text.utf8).write(to:project.appendingPathComponent(path))}
        let fixture=try XCTUnwrap(Bundle(for:Self.self).url(forResource:"GIFBackgroundAnimated",withExtension:"gif",subdirectory:"Fixtures"))
        let bytes=try Data(contentsOf:fixture),gif=try SingleGIFCompiler.GIF(name:"py26bj.gif",bytes:bytes)
        let output=try SingleGIFCompiler.compile(project:project,name:"keyboard.bds",backgrounds:["port/py_26.ini":gif.name],gifs:[gif])
        defer {try? fm.removeItem(at:output.folder.deletingLastPathComponent())}
        XCTAssertFalse(output.report.contains("缺少"))
        let image=try XCTUnwrap(UIImage(contentsOfFile:output.folder.appendingPathComponent("port/res/mina_gif_transparent.png").path)?.cgImage)
        XCTAssertEqual(image.width,1);XCTAssertEqual(image.height,1)
        var pixel=[UInt8](repeating:255,count:4)
        pixel.withUnsafeMutableBytes { p in
            let ctx=CGContext(data:p.baseAddress,width:1,height:1,bitsPerComponent:8,bytesPerRow:4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
            ctx.clear(CGRect(x:0,y:0,width:1,height:1));ctx.draw(image,in:CGRect(x:0,y:0,width:1,height:1))
        }
        XCTAssertEqual(pixel[3],0)
        try SingleGIFCompiler.apply(output,to:project)
        for (path,text) in texts {XCTAssertEqual(try Data(contentsOf:project.appendingPathComponent(path)),Data(text.utf8))}
        let archive=root.appendingPathComponent("keyboard.bds"),reopened=root.appendingPathComponent("reopened")
        try fm.zipItem(at:project,to:archive,shouldKeepParent:false)
        try fm.createDirectory(at:reopened,withIntermediateDirectories:true);try fm.unzipItem(at:archive,to:reopened)
        let actual=try Data(contentsOf:reopened.appendingPathComponent("res/py26bj.gif"))
        XCTAssertEqual(actual,bytes)
        let frames=try XCTUnwrap(CGImageSourceCreateWithData(actual as CFData,nil));XCTAssertGreaterThan(CGImageSourceGetCount(frames),1)
        XCTAssertEqual(SingleGIFCompiler.background(reopened.appendingPathComponent("port/py_26.ini")),gif.name)
        XCTAssertTrue(fm.fileExists(atPath:reopened.appendingPathComponent("port/res/mina_gif_transparent.png").path))
    }
}
