#if DEBUG
import Foundation
import ZIPFoundation

// Synthetic data is available only in the Debug UI test process.
@MainActor enum EditorUIFixture {
    static func openIfRequested(_ store: SkinStore) async -> Bool {
        guard ProcessInfo.processInfo.arguments.contains("--editor-controls-fixture") else { return false }
        do {
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            let skin = folder.appendingPathComponent("skin"), port = skin.appendingPathComponent("port")
            try FileManager.default.createDirectory(at: port, withIntermediateDirectories: true)
            try "[PANEL]\nSIZE=240,120\nKEY_NUM=1\n[KEY1]\nVIEW_RECT=0,0,60,50\nCENTER=q\nBACK_STYLE=1\n"
                .write(to: port.appendingPathComponent("py_26.ini"), atomically: true, encoding: .utf8)
            try "[GLOBAL]\nSTYLE_NUM=2\n[STYLE1]\nNM_COLOR=FFFFFFFF\n[STYLE2]\nNM_COLOR=FF000000\n"
                .write(to: skin.appendingPathComponent("styles.css"), atomically: true, encoding: .utf8)
            let file = folder.appendingPathComponent("controls.bds")
            try FileManager.default.zipItem(at: skin, to: file, shouldKeepParent: false)
            await store.openArchive(file)
            return store.root != nil && store.error == nil
        } catch { store.error = error.localizedDescription; return false }
    }
}
#endif
