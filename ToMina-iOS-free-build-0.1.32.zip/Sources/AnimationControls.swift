import SwiftUI

struct AnimationControls:View {
    @ObservedObject var store:SkinStore
    let key:String
    let floating:Bool
    @State private var sheet=""
    private var particles:[String] {store.renderer.timeline.definitions.keys.filter{store.renderer.timeline.definitions[$0]?["CATEGORY"]=="3"}.sorted()}
    var body:some View {
        MinaFlow {
            Button("重播"){if store.saveAnimationSource(){store.renderer.trigger(key);store.renderer.restartFloating();store.objectWillChange.send()}}
            if floating {
                Button(store.renderer.floatingPausedAt == nil ? "暂停":"继续"){store.renderer.toggleFloating();store.objectWillChange.send()}
                Menu {
                    Button("面板绑定"){choose("")}
                    ForEach(particles,id:\.self){id in Button("ANIM"+id){choose(id)}}
                } label:{MinaMenuLabel(title:store.renderer.floatingChoice.isEmpty ? "面板绑定":"ANIM"+store.renderer.floatingChoice)}
            } else {
                Button(store.renderer.animationEvent=="PRESS_ANIM" ? "按下动效":"常态动效"){
                    if store.saveAnimationSource(){store.renderer.animationEvent=store.renderer.animationEvent=="PRESS_ANIM" ? "SHOW_ANIM":"PRESS_ANIM";store.loadAnimationSource(key);store.renderer.trigger(key);store.objectWillChange.send()}
                }
                Button("绑定"){sheet="绑定"}.disabled(key.isEmpty)
                Button("触发"){sheet="触发"}.disabled(key.isEmpty)
                Button("添加动效"){do{try store.addKeyAnimation(key)}catch{store.error=error.localizedDescription}}.disabled(key.isEmpty)
            }
            Button("底包图片"){sheet="底包图片"}
            if !floating{Button("按键切片"){sheet="按键切片"}}
            Button("日志"){store.error=store.animationLog(key,floating:floating)}
        }.buttonStyle(MinaButtonStyle())
        .sheet(isPresented:Binding(get:{!sheet.isEmpty},set:{if !$0{sheet=""}})) {
            AnimationSettings(store:store,key:key,floating:floating,mode:sheet)
        }
    }
    private func choose(_ id:String){if store.saveAnimationSource(){store.renderer.floatingChoice=id;store.loadAnimationSource(key,floating:true);store.renderer.restartFloating();store.objectWillChange.send()}}
}

struct AnimationSettings:View {
    @ObservedObject var store:SkinStore
    let key:String
    let floating:Bool
    let mode:String
    @Environment(\.dismiss) private var dismiss
    @State private var binding=""
    @State private var back=""
    @State private var fore=""
    @State private var style=""
    @State private var press=""
    @State private var show=""
    @State private var anim=""
    @State private var image=""
    @State private var imageField="NM_IMG"
    @State private var failure=""
    private var animations:[String] {store.renderer.timeline.definitions.keys.filter{!floating || store.renderer.timeline.definitions[$0]?["CATEGORY"]=="3"}.sorted()}
    private var styleIDs:[String] {store.renderer.styles.keys.filter{$0.hasPrefix("STYLE")}.map{String($0.dropFirst(5))}.sorted()}
    var body:some View {
        NavigationStack {
            Form {
                if mode=="绑定" {
                    TextField("整体 ANIM_STYLE",text:$binding)
                    TextField("背景 BACK_ANIM_STYLE",text:$back)
                    TextField("前景 FORE_ANIM_STYLE",text:$fore)
                    Text("填写样式编号，多项用逗号分隔；留空清除绑定。").font(.caption)
                } else if mode=="触发" {
                    Picker("样式",selection:$style){ForEach(styleIDs,id:\.self){Text("STYLE"+$0).tag($0)}}
                        .onChange(of:style){_,_ in loadEvents()}
                    TextField("按下 PRESS_ANIM",text:$press)
                    TextField("常态 SHOW_ANIM",text:$show)
                    Text("填写动画编号，留空清除事件。").font(.caption)
                } else if mode=="按键切片" {
                    Picker("样式",selection:$style){ForEach(styleIDs,id:\.self){Text("STYLE"+$0).tag($0)}}
                    Picker("状态",selection:$imageField){Text("普通态").tag("NM_IMG");Text("按下态").tag("HL_IMG")}
                    Text(image.isEmpty ? "请选择底包中的 TIL 切片":image).font(.caption)
                    ForEach(store.tileReferences,id:\.self){ref in Button(ref){image=ref}}
                } else {
                    Picker("动画",selection:$anim){ForEach(animations,id:\.self){Text("ANIM"+$0).tag($0)}}
                        .onChange(of:anim){_,_ in loadImage()}
                    TextField(floating ? "PARTICLE_IMAGE 样式编号":"ANIM_PATH 图片路径",text:$image)
                    if floating {
                        ForEach(styleIDs.filter{!(store.renderer.styles["STYLE"+$0]?.values["NM_IMG"] ?? "").isEmpty},id:\.self){id in
                            Button("STYLE"+id+" · "+(store.renderer.styles["STYLE"+id]?.values["NM_IMG"] ?? "")){
                                var ids=image.split(separator:",").map{String($0).trimmingCharacters(in:.whitespaces)}
                                if ids.contains(id){ids.removeAll{$0==id}}else if ids.count<10{ids.append(id)}
                                image=ids.joined(separator:",")
                            }
                        }
                    } else {
                        ForEach(store.files.filter{["png","jpg","jpeg","gif","webp","bmp"].contains($0.pathExtension.lowercased())},id:\.self){file in
                            Button(store.relative(file)){image=store.relative(file)}
                        }
                    }
                }
                if !failure.isEmpty{Text(failure).foregroundStyle(.red)}
            }.navigationTitle(mode).toolbar {
                ToolbarItem(placement:.cancellationAction){Button("取消"){dismiss()}}
                ToolbarItem(placement:.confirmationAction){Button("保存"){save()}}
            }
        }.preferredColorScheme(.light).onAppear {
            let fields=SkinStore.parse(store.text).first{$0.name==key}?.values ?? [:]
            binding=fields["ANIM_STYLE"] ?? "";back=fields["BACK_ANIM_STYLE"] ?? "";fore=fields["FORE_ANIM_STYLE"] ?? ""
            style=binding.split(separator:",").first.map(String.init) ?? styleIDs.first ?? ""
            anim=animations.first ?? "";loadEvents();loadImage();if mode=="按键切片"{image=""}
        }
    }
    private func loadEvents(){let values=store.renderer.styles["STYLE"+style]?.values ?? [:];press=values["PRESS_ANIM"] ?? "";show=values["SHOW_ANIM"] ?? ""}
    private func loadImage(){image=store.renderer.timeline.definitions[anim]?[floating ? "PARTICLE_IMAGE":"ANIM_PATH"] ?? ""}
    private func save(){
        do {
            if mode=="绑定"{try store.editAnimationBinding(key,values:["ANIM_STYLE":binding,"BACK_ANIM_STYLE":back,"FORE_ANIM_STYLE":fore])}
            else if mode=="触发"{try store.editAnimationEvents(style,press:press,show:show,key:key)}
            else if mode=="按键切片"{guard !image.isEmpty else{throw SkinFailure(message:"请选择切片")};try store.editStyleImage(style,field:imageField,reference:image,key:key)}
            else{try store.editAnimationImage(anim,value:image,floating:floating,key:key)}
            dismiss()
        }catch{failure=error.localizedDescription}
    }
}
