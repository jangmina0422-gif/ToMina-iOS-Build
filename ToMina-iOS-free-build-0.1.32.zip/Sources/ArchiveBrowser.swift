import SwiftUI
import UniformTypeIdentifiers

struct ArchiveBrowser: View {
    @ObservedObject var store: SkinStore
    @Binding var relativeDirectory: String
    let openFile: (URL) -> Void
    let chooseFiles: (URL) -> Void
    let dropped: ([NSItemProvider], URL) -> Bool
    let close: () -> Void
    @State private var search = ""
    @State private var entries: [ArchiveEntry] = []
    @State private var newFolder = false
    @State private var folderName = ""
    @State private var error: String?
    @State private var targeted = false
    @State private var deleting: ArchiveEntry?
    @State private var renaming: ArchiveEntry?
    @State private var renameName = ""
    private var folder: URL? { store.root?.appendingPathComponent(relativeDirectory, isDirectory: true) }
    private var rows: [ArchiveEntry] {
        if search.isEmpty { return entries }
        let folders = entries.filter { $0.directory && store.relative($0.url).localizedCaseInsensitiveContains(search) }
        return folders + store.files.filter { store.relative($0).localizedCaseInsensitiveContains(search) }.map { ArchiveEntry(url: $0, directory: false) }
    }
    var body: some View {
        NavigationStack {
            browserContent
                .searchable(text: $search, prompt: "搜索包内文件")
                .navigationTitle("包内文件夹")
                .toolbar { folderToolbar }
                .task(id: refreshKey) { await loadEntries() }
                .alert("新建文件夹", isPresented: $newFolder) {
                    TextField("文件夹名称", text: $folderName)
                    Button("创建", action: createFolder)
                    Button("取消", role: .cancel) {}
                }
                .alert("删除包内文件？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
                    Button("删除", role: .destructive) { removeFile() }
                    Button("取消", role: .cancel) { deleting = nil }
                } message: {
                    Text("删除 " + (deleting.map { store.relative($0.url) } ?? "") + "？保存后会从原包移除。")
                }
                .alert("更名", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                    TextField("新名称", text: $renameName)
                    Button("确定") { renameEntry() }
                    Button("取消", role: .cancel) { renaming = nil }
                } message: { Text(renaming?.url.lastPathComponent ?? "") }
                .alert("提示", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                    Button("确定") { error = nil }
                } message: { Text(error ?? "") }
        }.preferredColorScheme(.light)
    }
    private var refreshKey: String { (store.root?.path ?? "") + "/" + relativeDirectory + ":" + String(store.fileRevision) }
    private var browserContent: some View {
        VStack(spacing: 0) {
            pathBar
            List(rows) { entry in entryRow(entry) }.listStyle(.plain)
            Text("可拖入多个文件或图片，导入到当前文件夹")
                .font(.caption).foregroundStyle(MinaTheme.muted).padding(12)
        }.background(MinaTheme.background).contentShape(Rectangle())
            .overlay { dropBorder }
            .onDrop(of: [UTType.item.identifier], isTargeted: $targeted) { providers in
                guard let folder else { return false }; return dropped(providers, folder)
            }
    }
    private var pathBar: some View {
        HStack {
            if !relativeDirectory.isEmpty {
                Button { relativeDirectory = (relativeDirectory as NSString).deletingLastPathComponent } label: {
                    Label("上一级", systemImage: "arrow.up")
                }
            }
            Text(relativeDirectory.isEmpty ? store.filename : store.filename + "/" + relativeDirectory).font(.caption).lineLimit(2)
            Spacer()
        }.padding(12).foregroundStyle(MinaTheme.ink)
    }
    private func entryRow(_ entry: ArchiveEntry) -> some View {
        Button {
            if entry.directory { relativeDirectory = store.relative(entry.url); search = "" }
            else { openFile(entry.url) }
        } label: {
            Label {
                Text(search.isEmpty ? entry.url.lastPathComponent : store.relative(entry.url)).foregroundStyle(MinaTheme.ink)
            } icon: {
                Image(systemName: entry.directory ? "folder" : "doc").foregroundStyle(MinaTheme.muted)
            }
        }
        .contextMenu {
            Button("更名", systemImage: "character.cursor.ibeam") {
                renameName = entry.url.lastPathComponent; renaming = entry
            }
            if !entry.directory {
                Button("编辑", systemImage: "pencil") { openFile(entry.url) }
                Button("删除", systemImage: "trash", role: .destructive) { deleting = entry }
            }
        }.disabled(store.busy)
    }
    private func removeFile() {
        guard let entry = deleting else { return }; deleting = nil
        Task {
            do { try await store.deleteArchiveFile(entry.url) }
            catch { self.error = error.localizedDescription }
        }
    }
    private func renameEntry() {
        guard let entry = renaming else { return }
        let name = renameName; renaming = nil
        Task {
            do {
                let previous = folder
                let result = try await store.renameArchiveEntry(entry.url, to: name)
                if let previous { relativeDirectory = store.relative(result.relocated(previous)) }
            } catch { self.error = error.localizedDescription }
        }
    }
    @ViewBuilder private var dropBorder: some View {
        if targeted { RoundedRectangle(cornerRadius: 12).stroke(MinaTheme.ink, lineWidth: 2).padding(4).allowsHitTesting(false) }
    }
    @ToolbarContentBuilder private var folderToolbar: some ToolbarContent {
        ToolbarItemGroup(placement: .topBarTrailing) {
            Button { folderName = ""; newFolder = true } label: { Image(systemName: "folder.badge.plus") }
                .accessibilityLabel("新建文件夹").disabled(store.busy)
            Button("导入文件") { if let folder { chooseFiles(folder) } }.disabled(store.busy)
            Button("关闭", action: close)
        }
    }
    @MainActor private func loadEntries() async {
        guard let root = store.root, let folder else { entries = []; return }
        do { entries = try await Task.detached { try ArchiveFiles.entries(in: folder, root: root) }.value }
        catch { entries = []; self.error = error.localizedDescription }
    }
    private func createFolder() {
        guard let root = store.root, let folder else { return }
        do { try ArchiveFiles.createFolder(folderName, in: folder, root: root); store.rescan() }
        catch { self.error = error.localizedDescription }
    }
}
