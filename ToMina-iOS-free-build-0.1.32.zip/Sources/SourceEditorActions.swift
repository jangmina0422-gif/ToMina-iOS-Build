import SwiftUI

// Essential editor actions stay outside the scrolling preview controls.
struct SourceEditorActions: View {
    let editing: Bool
    let css: Bool
    let toggleEditing: () -> Void
    let cleanup: () -> Void

    var body: some View {
        HStack(spacing: 8) {
            Button(editing ? "退出编辑" : "编辑源代码", action: toggleEditing)
                .accessibilityIdentifier(editing ? "editor.exit" : "editor.open")
            Spacer(minLength: 4)
            if css {
                Button("CSS 整理", action: cleanup)
                    .accessibilityIdentifier("editor.cssCleanup")
                    .accessibilityHint("删除当前 CSS 中没有被调用的样式，可撤销")
            }
        }.buttonStyle(MinaButtonStyle()).padding(.vertical, 3)
    }
}
