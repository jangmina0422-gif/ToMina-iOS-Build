import XCTest
import ZIPFoundation
@testable import ToMina

final class CSSCleanupTests: XCTestCase {
    func testReachabilityIncludesPanelsCandidatePopupParticlesAndCycles() throws {
        let css = "; keep this comment\r\n[GLOBAL]\r\nSTYLE_NUM=20 // original ceiling\r\n\r\n[STYLE1]\r\nBACK_STYLE=2\r\n[STYLE2]\r\nNM_COLOR=FFFFFFFF\r\n[STYLE3]\r\nNM_IMG=atlas,1\r\n[STYLE4]\r\nNM_COLOR=FF00FF00\r\n[STYLE5]\r\nFORE_STYLE=1\r\n[STYLE7]\r\nFORE_STYLE=8\r\n; preserve notes\r\n[STYLE8]\r\nFORE_STYLE=7\r\n[STYLE20]\r\nSHOW=unused\r\n"
        let references = ["[KEY1]\nFORE_STYLE=1\n", "[ICON1]\nBACK_STYLE=3\n", "[POP]\nBACK_STYLE=4\n", "[ANIM2]\nPARTICLE_IMAGE=5\n"]
        let result = try CSSCleanup.clean(css, external: references)
        XCTAssertEqual(result.removed,[7,8,20]); XCTAssertTrue(result.text.contains("STYLE_NUM=5 // original ceiling\r\n"))
        for id in 1...5 { XCTAssertTrue(result.text.contains("[STYLE\(id)]")) }
        XCTAssertTrue(result.text.contains("; keep this comment")); XCTAssertTrue(result.text.contains("; preserve notes"))
        XCTAssertFalse(result.text.contains("SHOW=unused")); XCTAssertTrue(result.text.contains("NM_IMG=atlas,1"))
        XCTAssertEqual(try CSSCleanup.clean(result.text,external:references).removed,[])
    }
    func testUnknownReferencesAndDuplicateStylesStopDeletion() throws {
        for css in ["[STYLE1]\nFORE_STYLE=dynamicValue\n[STYLE2]\n", "[STYLE1]\nSHOW=a\n[STYLE1]\nSHOW=b\n"] {
            XCTAssertThrowsError(try CSSCleanup.clean(css,external:[]))
        }
        XCTAssertEqual(try CSSCleanup.clean("[STYLE1]\nNM_COLOR=FFFFFFFF\n",external:["[KEY1]\nBACK_STYLE=1\n"]).removed,[])
    }
    @MainActor func testAllLanguageDirectoriesAreScannedAndCleanupUndoRestoresCSS() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let skin = folder.appendingPathComponent("skin"), res = skin.appendingPathComponent("port/res")
        try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:folder) }
        let css = "[GLOBAL]\nSTYLE_NUM=6\n" + (1...6).map { "[STYLE\($0)]\nNM_COLOR=FFFFFFFF\n" }.joined()
        try css.write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try "[PANEL]\nSIZE=240,120\n[KEY1]\nVIEW_RECT=0,0,60,50\nBACK_STYLE=1\n".write(to:skin.appendingPathComponent("port/py_26.ini"),atomically:true,encoding:.utf8)
        for (index,name) in ["cj.ini","zhuyin.ini","jp.ini","kor.ini"].enumerated() {
            let directory = skin.appendingPathComponent("land"); try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
            try "[KEY1]\nFORE_STYLE=\(index+2)\n".write(to:directory.appendingPathComponent(name),atomically:true,encoding:.utf8)
        }
        let original = folder.appendingPathComponent("keyboard.bds")
        try FileManager.default.zipItem(at:skin,to:original,shouldKeepParent:false)
        let originalBytes = try Data(contentsOf:original), store = SkinStore(); await store.openArchive(original)
        defer { if let root = store.root { try? FileManager.default.removeItem(at:root) } }
        try store.openForEditing(try XCTUnwrap(store.files.first { $0.lastPathComponent == "default.css" }))
        let count = try await store.removeUnusedCSS()
        XCTAssertEqual(count,1); XCTAssertFalse(store.text.contains("[STYLE6]"))
        XCTAssertTrue(store.canUndo); store.history(redo:false); XCTAssertEqual(store.text,css)
        XCTAssertEqual(try Data(contentsOf:original),originalBytes)
        let blocked = try XCTUnwrap(store.root).appendingPathComponent("broken.ini")
        try Data(repeating:65,count:2*1024*1024+1).write(to:blocked); store.rescan()
        do { _ = try await store.removeUnusedCSS(); XCTFail("Unreadable references must stop cleanup") } catch {}
        XCTAssertEqual(store.text,css)
    }
}
