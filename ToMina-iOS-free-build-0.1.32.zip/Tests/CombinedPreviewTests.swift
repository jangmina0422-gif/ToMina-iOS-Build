import XCTest
import SwiftUI
import UIKit
import ZIPFoundation
@testable import ToMina

final class CombinedPreviewTests: XCTestCase {
    @MainActor private func fixture() async throws -> (SkinStore,URL) {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString), skin = folder.appendingPathComponent("skin")
        let res = skin.appendingPathComponent("port/res");try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        try "[PANEL]\nSIZE=240,120\n[CAND]\nLAYOUT_NAME=bar.cnd\nVIEW_RECT=0,0,240,40\n".write(to:skin.appendingPathComponent("port/gen.ini"),atomically:true,encoding:.utf8)
        try "[PANEL]\n[KEY1]\nVIEW_RECT=10,10,60,60\nBACK_STYLE=2\nCENTER=q\n".write(to:skin.appendingPathComponent("port/py_26.ini"),atomically:true,encoding:.utf8)
        try "[CAND]\nBACK_STYLE=1\nFORE_STYLE=4\n[ICON1]\nVIEW_RECT=10,5,20,20\nBACK_STYLE=3\nPERSIST=3\n".write(to:skin.appendingPathComponent("port/bar.cnd"),atomically:true,encoding:.utf8)
        try "[STYLE1]\nNM_COLOR=FFFF0000\n[STYLE2]\nNM_COLOR=FF0000FF\n[STYLE3]\nNM_COLOR=FF00FF00\n[STYLE4]\nNM_IMG=decor,1\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try "[IMG1]\nSOURCE_RECT=0,0,8,8\n".write(to:res.appendingPathComponent("decor.til"),atomically:true,encoding:.utf8)
        let format = UIGraphicsImageRendererFormat();format.scale=1
        let image = UIGraphicsImageRenderer(size:CGSize(width:8,height:8),format:format).image { ctx in UIColor.yellow.setFill();ctx.fill(CGRect(x:0,y:0,width:8,height:8)) }
        try XCTUnwrap(image.pngData()).write(to:res.appendingPathComponent("decor.png"))
        let original=folder.appendingPathComponent("keyboard.bds");try FileManager.default.zipItem(at:skin,to:original,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(original);XCTAssertNil(store.error)
        return (store,folder)
    }
    @MainActor private func cleanup(_ store:SkinStore,_ folder:URL) {
        store.finishSourceEditing();if let root=store.root{try? FileManager.default.removeItem(at:root)}
        try? FileManager.default.removeItem(at:folder)
    }
    private func rgb(_ image:CGImage,_ x:Int,_ y:Int)throws->[UInt8] {
        var bytes=[UInt8](repeating:0,count:image.width*image.height*4)
        let bitmap=try XCTUnwrap(CGContext(data:&bytes,width:image.width,height:image.height,bitsPerComponent:8,bytesPerRow:image.width*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue))
        bitmap.draw(image,in:CGRect(x:0,y:0,width:image.width,height:image.height))
        let offset=(y*image.width+x)*4;return Array(bytes[offset..<offset+3])
    }
    @MainActor func testKeyboardTopBarIconsAndBarForegroundRenderTogether() async throws {
        let (store,folder)=try await fixture();defer{cleanup(store,folder)}
        XCTAssertEqual(store.renderer.candidateFile?.lastPathComponent,"bar.cnd")
        let bounds=store.renderer.previewBounds(panel:store.panel,keys:store.keys)
        XCTAssertEqual(bounds,CGRect(x:0,y:-40,width:240,height:160))
        let scene=Canvas { context,_ in
            context.translateBy(x:0,y:40)
            store.renderer.drawPreview(panel:store.panel,keys:store.keys,pressed:false,scale:1,rasterScale:1,context:&context)
        }.frame(width:240,height:160)
        let painter=ImageRenderer(content:scene);painter.scale=1;let pixels=try XCTUnwrap(painter.cgImage)
        XCTAssertEqual(try rgb(pixels,2,2),[255,0,0])
        XCTAssertEqual(try rgb(pixels,15,12),[0,255,0])
        XCTAssertEqual(try rgb(pixels,120,20),[255,255,0])
        XCTAssertEqual(try rgb(pixels,20,90),[0,0,255])
    }
    @MainActor func testCandidateAndGenLongPressEditingKeepFullKeyboardPreview() async throws {
        let (store,folder)=try await fixture();defer{cleanup(store,folder)}
        let preview=store.previewPanelName,cnd=try XCTUnwrap(store.files.first{$0.lastPathComponent=="bar.cnd"})
        try store.openForEditing(cnd)
        XCTAssertEqual(store.current,cnd);XCTAssertEqual(store.previewPanelName,preview);XCTAssertTrue(store.keys.contains{$0.name=="KEY1"})
        _=store.editSource(store.text.replacingOccurrences(of:"BACK_STYLE=1",with:"BACK_STYLE=3"));store.finishSourceEditing()
        XCTAssertEqual(store.renderer.candidateSections.first?.values["BACK_STYLE"],"3")
        let gen=try XCTUnwrap(store.files.first{$0.lastPathComponent=="gen.ini"});try store.openForEditing(gen)
        _=store.editSource(store.text.replacingOccurrences(of:"240,40",with:"240,64"));store.finishSourceEditing()
        XCTAssertEqual(store.previewPanelName,preview);XCTAssertEqual(store.renderer.candidateSize.height,64)
        XCTAssertTrue(store.keys.contains{$0.name=="KEY1"})
    }
    @MainActor func testEmptyIniRemainsBlankWithAvailableTopBar() async throws {
        let (store,folder)=try await fixture();defer{cleanup(store,folder)}
        store.change("[PANEL]\nSIZE=240,120\n[CAND]\n")
        XCTAssertTrue(store.blankPreview);XCTAssertTrue(store.keys.isEmpty)
    }
}
