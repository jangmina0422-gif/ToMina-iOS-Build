import XCTest

final class EditorControlsUITests: XCTestCase {
    override func setUpWithError() throws { continueAfterFailure = false }

    private func openApp() -> XCUIApplication {
        XCUIDevice.shared.orientation = .portrait
        let app = XCUIApplication()
        app.launchArguments = ["--editor-controls-fixture"]
        app.launch()
        XCTAssertTrue(app.buttons["包内文件夹：controls.bds"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.staticTexts["app.version"].exists)
        return app
    }
    private func edit(_ file: String, in app: XCUIApplication, folder: String? = nil) {
        app.buttons["包内文件夹：controls.bds"].tap()
        if let folder { app.buttons[folder].tap() }
        let row = app.buttons[file]
        XCTAssertTrue(row.waitForExistence(timeout: 5))
        row.tap() // Both the row and its context-menu Edit command call openArchiveFile.
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout: 5))
    }
    private func proof(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways
        add(attachment)
    }
    func testINIEditorHasOneVisibleExitAndCanReturn() {
        let app = openApp(); edit("py_26.ini", in: app, folder: "port")
        XCTAssertTrue(app.buttons["editor.exit"].isHittable)
        XCTAssertEqual(app.buttons.matching(identifier: "editor.exit").count, 1)
        XCTAssertTrue(app.buttons["editor.cssCleanup"].isHittable)
        proof(app, name: "INI-editor-exit")
        app.buttons["editor.exit"].tap()
        XCTAssertTrue(app.buttons["editor.open"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.textViews.firstMatch.exists)
        app.buttons["editor.open"].tap()
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout: 5))
    }
    func testCSSCleanupIsVisibleAndDeletesUnusedStyle() {
        let app = openApp(); edit("styles.css", in: app)
        let button = app.buttons["editor.cssCleanup"]
        XCTAssertTrue(button.isHittable)
        XCTAssertEqual(app.buttons.matching(identifier: "editor.cssCleanup").count, 1)
        XCTAssertTrue(app.buttons["编辑操作"].isHittable)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]"))
        proof(app, name: "CSS-editor-visible-actions")
        button.tap()
        XCTAssertTrue(app.staticTexts["已删除 1 个未调用样式，可撤销"].waitForExistence(timeout: 5))
        XCTAssertFalse((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE1]"))
        app.buttons["编辑操作"].tap(); app.buttons["撤销"].tap()
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]"))
    }
    func testCSSCleanupCanBeOpenedFromINIWithoutHiddenMenu() {
        let app = openApp(); edit("py_26.ini", in: app, folder: "port")
        app.buttons["editor.cssCleanup"].tap()
        XCTAssertTrue(app.staticTexts["已删除 1 个未调用样式，可撤销"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["editor.exit"].isHittable)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE1]"))
        XCTAssertFalse((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]"))
    }
    func testEditorActionsRemainHittableWithKeyboardAndLandscape() {
        let app = openApp(); edit("styles.css", in: app)
        app.textViews.firstMatch.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["editor.exit"].isHittable)
        XCTAssertTrue(app.buttons["editor.cssCleanup"].isHittable)
        XCUIDevice.shared.orientation = .landscapeLeft
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["editor.exit"].isHittable)
        XCTAssertTrue(app.buttons["editor.cssCleanup"].isHittable)
        proof(app, name: "CSS-editor-keyboard-landscape")
        app.buttons["editor.exit"].tap()
        XCTAssertTrue(app.buttons["editor.open"].waitForExistence(timeout: 5))
    }
}
