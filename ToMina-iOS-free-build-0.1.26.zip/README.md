# To.Mina 0.1.26 build 27 core build

This repository builds the iOS application code with synthetic preview performance, CND and save/restore
tests. Account verification hashes, user skin archives, artwork, sounds and
binary field mappings are excluded. The generated core artifact denies all
login attempts and is not a distributable application.

Private resources are added to the unsigned IPA locally before signing.
The existing private project and account data are not published here.
