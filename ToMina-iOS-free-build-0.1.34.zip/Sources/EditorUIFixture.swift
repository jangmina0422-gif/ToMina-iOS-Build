#if DEBUG
import Foundation
import ZIPFoundation

// Synthetic data is available only in the Debug UI test process.
@MainActor enum EditorUIFixture {
    static var requested: Bool { ProcessInfo.processInfo.arguments.contains("--editor-controls-fixture") }
    static func openIfRequested(_ store: SkinStore) async -> Bool {
        guard requested else { return false }
        do {
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            let skin = folder.appendingPathComponent("skin"), port = skin.appendingPathComponent("port")
            try FileManager.default.createDirectory(at: port, withIntermediateDirectories: true)
            try "[PANEL]\nSIZE=240,120\nKEY_NUM=1\nTIP_NUM=1\n[KEY1]\nVIEW_RECT=0,0,60,50\nCENTER=q\nBACK_STYLE=1\nSTAT_STYLE=S34_1|S36_1|S37_1\n[TIP1]\nFORE_STYLE=3\n"
                .write(to: port.appendingPathComponent("py_26.ini"), atomically: true, encoding: .utf8)
            try "[GLOBAL]\nSTYLE_NUM=3\n[STYLE1]\nNM_COLOR=FFFFFFFF\n[STYLE2]\nNM_COLOR=FF000000\n[STYLE3]\nNM_COLOR=FF000000\n"
                .write(to: skin.appendingPathComponent("styles.css"), atomically: true, encoding: .utf8)
            try "[GLOBAL]\nANIM_NUM=1\n[ANIM1]\nCATEGORY=3\nPARTICLE_IMAGE=1\nTOTAL_NUMBER=1\nLIFE=1000\n"
                .write(to: skin.appendingPathComponent("anim.ini"), atomically: true, encoding: .utf8)
            let file = folder.appendingPathComponent("controls.bds")
            try FileManager.default.zipItem(at: skin, to: file, shouldKeepParent: false)
            await store.openArchive(file)
            return store.root != nil && store.error == nil
        } catch { store.error = error.localizedDescription; return false }
    }
}
#endif
