import XCTest
import SwiftUI
import UIKit
@testable import ToMina

@MainActor final class PreviewDiagnosticsTests:XCTestCase {
    private func render(_ store:SkinStore)throws->UIImage {
        let bounds=store.renderer.previewBounds(panel:store.panel,keys:store.keys)
        let canvas=Canvas(rendersAsynchronously:false){context,_ in
            context.translateBy(x:-bounds.minX,y:-bounds.minY)
            store.renderer.drawPreview(panel:store.panel,keys:store.keys,pressed:false,scale:1,rasterScale:1,context:&context)
        }.frame(width:bounds.width,height:bounds.height)
        let renderer=ImageRenderer(content:canvas);renderer.scale=1
        return try XCTUnwrap(renderer.uiImage)
    }
    func testIQOOImportPanelChangesTopBarAndReportInBothDrawingModes() async throws {
        let previous=UserDefaults.standard.object(forKey:"compatiblePreview")
        defer{UserDefaults.standard.set(previous,forKey:"compatiblePreview")}
        for name in ["iqoo.bds","user-iqoo-3.bds"] {
            let archive=try PreviewTestFixtures.archive(name)
            defer{try? FileManager.default.removeItem(at:archive.deletingLastPathComponent())}
            let store=SkinStore();await store.openArchive(archive);XCTAssertNil(store.error)
            let root=try XCTUnwrap(store.root);defer{try? FileManager.default.removeItem(at:root)}
            // Check the first imported frame before opening any other configuration.
            _=try render(store)
            XCTAssertEqual(store.renderer.drawnPanel,"port/py_26.ini")
            XCTAssertEqual(store.renderer.drawnCandidate,"port/cand1.cnd")
            var modes:[String:Data]=[:]
            for compatible in [false,true] {
                store.compatiblePreview=compatible
                var pinyin:Data?
                for path in ["port/py_26.ini","port/hw_grid.ini","port/num_9.ini","land/hw_grid.ini","port/py_26.ini"] {
                    let file=root.appendingPathComponent(path),original=try Data(contentsOf:file)
                    try store.open(file)
                    XCTAssertNotEqual(store.renderer.configurationRevision,store.renderer.drawnRevision,"Loaded state must not pretend it was already drawn")
                    let image=try render(store),pixels=try XCTUnwrap(image.pngData())
                    XCTAssertEqual(store.renderer.drawnPanel,path)
                    XCTAssertEqual(store.renderer.configurationRevision,store.renderer.drawnRevision)
                    XCTAssertEqual(store.renderer.drawnFingerprint,PreviewDiagnostics.fingerprint(store.text))
                    XCTAssertEqual(store.renderer.drawnBounds.minY,-store.renderer.candidateSize.height)
                    XCTAssertLessThan(store.renderer.drawnBounds.minY,0)
                    XCTAssertTrue(store.previewDiagnostics().contains("最后绘制："+path))
                    XCTAssertFalse(store.previewDiagnostics().contains(root.path))
                    XCTAssertFalse(store.previewDiagnostics().contains("candy.mina.center"))
                    if let pinyin,path != "port/py_26.ini" {XCTAssertNotEqual(pixels,pinyin)}
                    if path == "port/py_26.ini" {pinyin=pixels}
                    if !compatible {modes[path]=pixels}
                    else {XCTAssertEqual(image.size,UIImage(data:try XCTUnwrap(modes[path]))?.size)}
                    try store.reloadPreview();_=try render(store)
                    XCTAssertEqual(store.renderer.drawnPanel,path)
                    XCTAssertEqual(try Data(contentsOf:file),original,"Drawing and reloading must not edit the layout")
                    if compatible {
                        let attachment=XCTAttachment(image:image);attachment.name=name+"-"+path;attachment.lifetime = .keepAlways;add(attachment)
                    }
                }
            }
        }
    }
}
