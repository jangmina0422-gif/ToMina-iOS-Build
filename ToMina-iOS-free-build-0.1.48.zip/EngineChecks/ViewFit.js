/* To.Mina VIEW fitting. Pure, deterministic engine shared by Android/iOS.
   Input is an immutable package snapshot. Output is a transaction, never file IO.
   Only layout coordinates are edited; image resources and mappings stay untouched. */
(function (global) {
  'use strict';
  const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  const dict = () => Object.create(null);
  const fail = s => { throw new Error(s); };
  const eq = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
  const nums = s => {
    if (typeof s !== 'string' || !s.trim()) return [];
    const a = s.split(',').map(v => v.trim() === '' ? NaN : Number(v.trim()));
    return a.every(Number.isFinite) ? a : [];
  };
  function parse(text) {
    const lines = text.split(/\r\n|\n|\r/), sections = []; let current;
    lines.forEach((line, i) => {
      const h = line.replace(/^\uFEFF/, '').match(/^\s*\[([^\]]+)\]\s*(?:(?:;|\/\/).*)?$/);
      if (h) {
        if (current) current.end = i;
        current = {name:h[1].trim().toUpperCase(), start:i, end:lines.length, values:dict()};
        sections.push(current);
      } else if (current && !/^\s*(;|#|\/\/)/.test(line)) {
        const m = line.match(/^\s*([^=]+?)\s*=(.*)$/);
        if (m) current.values[m[1].trim().toUpperCase()] = m[2].split(' //')[0].trim();
      }
    });
    return {text, lines, sections, nl:text.indexOf('\r\n') >= 0 ? '\r\n' : text.indexOf('\r') >= 0 ? '\r' : '\n'};
  }
  // Modify only named fields; retain ordering, comments, duplicate sections and actions.
  function patch(text, changes) {
    const p = parse(text);
    Object.keys(changes).map(Number).sort((a,b) => b-a).forEach(index => {
      const s = p.sections[index]; if (!s) fail('配置段在检查后改变');
      const values = changes[index], found = dict();
      for (let i=s.start+1; i<s.end; i++) {
        const m = p.lines[i].match(/^(\s*([^=;#]+?)\s*=)(.*)$/);
        const key = m && m[2].trim().toUpperCase();
        if (key && own(values,key)) {
          const comment = m[3].indexOf(' //');
          p.lines[i] = m[1] + values[key] + (comment < 0 ? '' : m[3].slice(comment)); found[key] = true;
        }
      }
      const added = Object.keys(values).filter(k => !found[k]).map(k => k+'='+values[k]);
      p.lines.splice(s.start+1,0,...added);
    });
    return p.lines.join(p.nl);
  }
  function normalized(path) {
    if (typeof path !== 'string' || /[:\x00]/.test(path) || /^[\\/]/.test(path)) fail('资源路径不安全');
    const parts=path.replace(/\\/g,'/').split('/').filter(p=>p!=='.' && p!=='');
    if (parts.some(p=>p==='..')) fail('资源路径超出皮肤包');
    return parts.join('/');
  }
  const dir = p => p.includes('/') ? p.slice(0,p.lastIndexOf('/')) : '';
  const base = p => p.slice(p.lastIndexOf('/')+1);
  const join = (a,b) => a ? a+'/'+b : b;
  function parents(path) { const out=[];let p=dir(path); for (;;) {out.push(p);if (!p) return out;p=dir(p);} }
  function effective(local, defaults) {
    const seen=dict();return local.map((s,index)=>{
      const n=seen[s.name] || 0;seen[s.name]=n+1;
      const d=defaults.filter(v=>v.name===s.name)[n];
      return {name:s.name,index,values:Object.assign(dict(),d && d.values,s.values)};
    });
  }
  function rect(value, label) {
    const r=nums(value);
    if(r.length!==4 || r[2]<=0 || r[3]<=0) fail(label+' 的 VIEW_RECT 无效');
    return r;
  }
  const end = (r,a) => r[a]+r[a+2];
  const overlap = (a,b,axis) => Math.min(end(a,axis),end(b,axis))-Math.max(a[axis],b[axis]);
  const intersects = (a,b) => overlap(a,b,0)>0.001 && overlap(a,b,1)>0.001;
  const action = v => Object.keys(v).some(k=>/^(?:CENTER|KEY|LEFT|RIGHT|UP|DOWN|HOLD|LONG_PRESS|SWIPE.*)$/.test(k) && v[k]!=='' );
  const area = r => r[2]*r[3];
  const median = a => a.slice().sort((x,y)=>x-y)[Math.floor(a.length/2)] || 0;
  const boxText = r => r.join(',');
  function contained(r,w,h,t=0) { return r[0]>=-t && r[1]>=-t && end(r,0)<=w+t && end(r,1)<=h+t; }
  function classify(sections,w,h) {
    const all=[], reserved=[], notes=[];
    for (const s of sections) {
      const v=s.values;
      if (/^KEY\d+$/.test(s.name)) {
        const r=rect(v.VIEW_RECT,s.name);
        if (!contained(r,w,h,2)) fail(s.name+' 超出本面板尺寸，无法确定原有布局意图');
        const k={s,r,next:r.slice(), fixed:false, kind:'key'};
        // STAT_STYLE also selects ordinary keys' state appearances. It does not
        // by itself make a key an overlay. POS_TYPE positions content, not VIEW.
        if ((!action(v) && v.STAT_STYLE==='S0') || Math.min(r[2],r[3])<=2) k.kind='overlay';
        else if ((v.CENTER||'').toUpperCase()==='F53') k.kind='handwriting';
        else if ((v.CENTER||'').toUpperCase()==='F55') k.kind='symbol';
        else if ((v.CENTER||'').toUpperCase()==='F80') {k.kind='reserved';k.fixed=true;reserved.push(k);}
        else if (!action(v)) k.kind='decoration';
        all.push(k);
      } else if (/^LIST\d*$/.test(s.name)) {
        const pos=nums(v.POS),cell=nums(v.CELL_SIZE),count=Number(v.LIST_NUM),pad=nums(v.PADDING||'0');
        if(pos.length!==2 || cell.length!==2 || !Number.isInteger(count) || count<1 || cell.some(v=>v<=0) || ![1,2,4].includes(pad.length) || pad.some(v=>v<0)) fail(s.name+' 缺少有效 POS / CELL_SIZE / LIST_NUM / PADDING');
        if(v.LIST_ORDER && !['0','1'].includes(v.LIST_ORDER)) fail(s.name+' 的排列方向无法确定');
        const r=[pos[0],pos[1],cell[0]*(v.LIST_ORDER==='1'?count:1),cell[1]*(v.LIST_ORDER==='1'?1:count)];
        // Padding is internal content space, not space available for neighbouring keys.
        if(!contained(r,w,h)) fail(s.name+' 的列表区域超出面板');
        if(['2','3'].includes(v.TYPE)) {notes.push(s.name+' 为面板外列表，保留其独立坐标');continue;}
        if(pad.length===4 && (pad[0]+pad[2]>=r[2] || pad[1]+pad[3]>=r[3]))fail(s.name+' 的 PADDING 已占满列表');
        const k={s,r,next:r.slice(),fixed:false,kind:'list',list:{count,horizontal:v.LIST_ORDER==='1',pad}};all.push(k);
      } else if (/^(?:ICON\d+|CAND|SCAND|HW\d*|HANDWRITING)$/.test(s.name) && v.VIEW_RECT && !v.LAYOUT_NAME) {
        const r=rect(v.VIEW_RECT,s.name);
        if(contained(r,w,h)) {
          const handwriting=/^(?:HW\d*|HANDWRITING)$/.test(s.name);
          const k={s,r,next:r.slice(),fixed:!handwriting,kind:handwriting?'handwriting':'reserved'};
          if(!handwriting)reserved.push(k);all.push(k);
        }
      }
    }
    // A symbol grid and its coincident, actionless background are one layout
    // surface. Fit it once, then give every layer the same rectangle. Treating
    // F55 as fixed left KEY1/KEY2 untouched while their neighbours expanded.
    for (const k of all.filter(k=>/^KEY\d+$/.test(k.s.name) && !action(k.s.values) && Math.min(k.r[2],k.r[3])>2)) {
      const owners=all.filter(o=>(o.kind==='symbol' || o.kind==='list') && Math.abs(o.r[0]-k.r[0])<=2 && Math.abs(end(o.r,0)-end(k.r,0))<=2 && k.r[1]<=o.r[1]+2 && end(k.r,1)>=end(o.r,1)-2);
      if(owners.length===1) {k.kind='symbol-layer';k.geometryOwner=owners[0];}
    }
    // Buttons contained in a handwriting/candidate/voice surface are intentional
    // layers. Keep their geometry instead of rejecting the whole panel.
    all.filter(k=>k.kind==='key').forEach(k=>{
      if(all.some(o=>(o.kind==='handwriting' || o.s.name.startsWith('KEY') && ['F55','F80'].includes((o.s.values.CENTER||'').toUpperCase())) &&
        k.r[0]>=o.r[0]-2 && k.r[1]>=o.r[1]-2 && end(k.r,0)<=end(o.r,0)+2 && end(k.r,1)<=end(o.r,1)+2))k.kind='overlay';
    });
    const keys=all.filter(k=>k.kind==='key');
    const mw=median(keys.map(k=>k.r[2]));
    all.filter(k=>k.kind==='decoration').forEach(k=>{
      if(all.some(other=>other!==k && other.kind!=='overlay' && intersects(k.r,other.r))) k.kind='overlay';
      else if(k.r[2]<=mw*0.65 && keys.some(o=>Math.abs(o.r[1]-k.r[1])<=2 && Math.abs(end(o.r,1)-end(k.r,1))<=2 && Math.min(Math.abs(end(o.r,0)-k.r[0]),Math.abs(end(k.r,0)-o.r[0]))<=2)) k.kind='filler';
      else {k.kind='reserved';k.fixed=true;reserved.push(k);}
    });
    if(all.some(k=>k.kind==='handwriting'))notes.push('手写区域参与共边贴合；原触摸范围及内部叠加按钮保留');
    notes.push('参与贴合 '+all.filter(k=>k.kind==='list').length+' 个 LIST；保留 '+all.filter(k=>k.kind==='overlay').length+' 个叠加/背景区，'+reserved.length+' 个固定区域，识别 '+all.filter(k=>k.kind==='filler').length+' 个补边块');
    return {all,active:all.filter(k=>k.kind!=='overlay' && !k.geometryOwner),notes};
  }
  function fitGeometry(model,w,h) {
    const items=model.active,n=items.length;
    if(n>1024) fail('区域超过 1024 个，未进行不完整处理');
    const oldOverlaps=new Set();
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++) {
      const a=items[i],b=items[j];
      if(intersects(a.r,b.r)) {
        if(a.fixed && b.fixed || a.fixed && a.s.values.CENTER==='F80' || b.fixed && b.s.values.CENTER==='F80') {oldOverlaps.add(i+':'+j);continue;}
        if(Math.min(overlap(a.r,b.r,0),overlap(a.r,b.r,1))>3) fail(a.s.name+' 与 '+b.s.name+' 存在非取整误差的叠加，需确认分层');
      }
    }
    const seams=[],systems=[];
    for(let axis=0;axis<2;axis++) {
      const parent=Array.from({length:n*2},(_,i)=>i), locks=dict(), outer=dict(), vals=[],lower=dict(),upper=dict();
      const root=i=>{while(parent[i]!==i){parent[i]=parent[parent[i]];i=parent[i];}return i;};
      const union=(a,b)=>{parent[root(b)]=root(a);};
      const bound=(node,value,low)=>{const map=low?lower:upper;map[node]=own(map,node)?(low?Math.max(map[node],value):Math.min(map[node],value)):value;};
      const connect=(i,j)=>{
        const a=items[i],b=items[j];
        if(a.fixed && b.fixed)return;
        if(a.fixed)bound(2*j,end(a.r,axis),true);
        else if(b.fixed)bound(2*i+1,b.r[axis],false);
        else union(2*i+1,2*j);
      };
      items.forEach((k,i)=>{
        vals.push(k.r[axis],end(k.r,axis));
        if(k.fixed) {locks[2*i]=k.r[axis];locks[2*i+1]=end(k.r,axis);}
        else {
          // Exposed row/column ends meet this panel's boundary, including a
          // staggered row's two ends. Reserved surfaces still block expansion.
          const cross=1-axis;
          const blocked=side=>items.some((o,j)=>j!==i && overlap(axis?k.next:k.r,axis?o.next:o.r,cross)>0.001 &&
            (side===0?end(o.r,axis)<=k.r[axis]+3:o.r[axis]>=end(k.r,axis)-3));
          // Equal integer LIST cells may not divide an exposed panel edge.
          // Keep that remainder at the outside only; every internal seam remains shared.
          const multiple=k.list && (k.list.horizontal?axis===0:axis===1) ? k.list.count:1;
          if(!blocked(0)) {if(multiple>1)outer[2*i]={target:0,min:0,max:multiple-1};else locks[2*i]=0;}
          if(!blocked(1)) {if(multiple>1)outer[2*i+1]={target:axis?h:w,min:(axis?h:w)-multiple+1,max:axis?h:w};else locks[2*i+1]=axis?h:w;}
        }
      });
      // Preserve existing aligned row/column edges while solving all seams.
      for(let side=0;side<2;side++){
        const aligned=dict();items.forEach((k,i)=>{if(k.fixed)return;const node=2*i+side,v=vals[node]+'|'+(own(locks,node)?locks[node]:own(outer,node)?'list-outer':'free');if(own(aligned,v))union(node,aligned[v]);else aligned[v]=node;});
      }
      for(let i=0;i<n;i++) for(let j=0;j<n;j++) {
        if(i===j)continue; const a=items[i],b=items[j],cross=1-axis;
        if(b.r[axis]+b.r[axis+2]/2<=a.r[axis]+a.r[axis+2]/2)continue;
        const ar=axis?a.next:a.r,br=axis?b.next:b.r,span=overlap(ar,br,cross);
        if(span < Math.max(1,Math.min(ar[cross+2],br[cross+2])*.25))continue;
        const gap=b.r[axis]-end(a.r,axis);
        if(gap < -3)continue;
        const low=Math.max(ar[cross],br[cross]),high=Math.min(end(ar,cross),end(br,cross));
        const blocked=items.some((k,index)=>index!==i && index!==j && k.r[axis]>=end(a.r,axis)-3 && end(k.r,axis)<=b.r[axis]+3 && Math.min(end(axis?k.next:k.r,cross),high)-Math.max((axis?k.next:k.r)[cross],low)>0.001);
        if(blocked)continue;
        if(gap>Math.min(a.r[axis+2],b.r[axis+2])*.55) {
          if(!a.fixed && !b.fixed) fail(a.s.name+' / '+b.s.name+' 之间的留白较大，无法确定是否属于同一排布区域');
          continue;
        }
        if(a.fixed && b.fixed)continue;
        connect(i,j);if(!a.fixed&&!b.fixed)seams.push({i,j,axis});
      }
      const solve=()=>{
        const groups=dict();for(let i=0;i<vals.length;i++){const r=root(i);(groups[r]||(groups[r]=[])).push(i);}
        const resolved=dict();
        Object.keys(groups).forEach(id=>{
          const members=groups[id],fixed=Array.from(new Set(members.filter(i=>own(locks,i)).map(i=>locks[i])));
          if(fixed.length>1)fail('共享边界与面板固定边界冲突');
          const lows=members.filter(i=>own(lower,i)).map(i=>lower[i]),highs=members.filter(i=>own(upper,i)).map(i=>upper[i]);
          const exposed=members.filter(i=>own(outer,i)).map(i=>outer[i]);
          const low=Math.ceil(Math.max(0,...lows,...exposed.map(o=>o.min))),high=Math.floor(Math.min(axis?h:w,...highs,...exposed.map(o=>o.max)));
          if(low>high)fail('共享边界的保留区域相互冲突');
          const values=Array.from(new Set(members.map(i=>vals[i])));
          let value=fixed.length?fixed[0]:exposed.length?exposed[0].target:lows.length&&!highs.length?low:highs.length&&!lows.length?high:Math.round(values.reduce((s,v)=>s+v,0)/values.length);
          if(fixed.length&&(value<low||value>high))fail('外沿与保留区域边界冲突');
          value=Math.max(low,Math.min(high,value));
          resolved[id]={value,low:fixed.length?value:low,high:fixed.length?value:high};
        });
        fitListIntegers(items,axis,root,resolved);
        Object.keys(groups).forEach(id=>groups[id].forEach(i=>{const k=items[Math.floor(i/2)],value=resolved[id].value;if(i%2)k.next[axis+2]=value;else k.next[axis]=value;}));
        items.forEach(k=>{k.next[axis+2]-=k.next[axis];});
      };
      systems.push({parent,lower,upper,solve,connect});solve();
    }
    // A LIST ending slightly above/below a neighbouring row creates a corner
    // constraint. Resolve it with the same shared edges, never by overlaying keys.
    for(let attempt=0;attempt<n*2;attempt++){
      let conflict=null;
      for(let i=0;i<n&&!conflict;i++)for(let j=i+1;j<n;j++)if(!oldOverlaps.has(i+':'+j)&&intersects(items[i].next,items[j].next)){conflict=[i,j];break;}
      if(!conflict)break;
      const [i,j]=conflict,a=items[i],b=items[j],options=[];
      for(let axis=0;axis<2;axis++){
        if(end(a.r,axis)<=b.r[axis]+3)options.push({axis,i,j,amount:overlap(a.next,b.next,axis)});
        else if(end(b.r,axis)<=a.r[axis]+3)options.push({axis,i:j,j:i,amount:overlap(a.next,b.next,axis)});
      }
      options.sort((a,b)=>a.amount-b.amount);let resolved=false;
      for(const option of options){
        const sys=systems[option.axis],parent=sys.parent.slice(),low=Object.assign({},sys.lower),high=Object.assign({},sys.upper);
        try{
          sys.connect(option.i,option.j);sys.solve();
          if(intersects(a.next,b.next)||items.some(k=>k.next[2]<=0||k.next[3]<=0))fail('拐角不可合并');
          if(!items[option.i].fixed&&!items[option.j].fixed)seams.push(option);
          resolved=true;break;
        }catch(e){sys.parent.splice(0,sys.parent.length,...parent);Object.keys(sys.lower).forEach(k=>delete sys.lower[k]);Object.assign(sys.lower,low);Object.keys(sys.upper).forEach(k=>delete sys.upper[k]);Object.assign(sys.upper,high);sys.solve();}
      }
      if(!resolved)fail(a.s.name+' 与 '+b.s.name+' 的拐角无法无重叠贴合');
    }
    for(const k of items) {
      if(k.next[2]<=0 || k.next[3]<=0 || !contained(k.next,w,h)) fail(k.s.name+' 贴合后尺寸无效或越界');
      if(k.fixed && !eq(k.r,k.next)) fail(k.s.name+' 的保留区域发生移动');
      if(k.list) {
        const axis=k.list.horizontal?0:1;
        if(k.next[axis+2]%k.list.count!==0)fail(k.s.name+' 的单元格无法使用整数共边');
        const pad=k.list.pad;
        if(pad.length===4&&(pad[0]+pad[2]>=k.next[2]||pad[1]+pad[3]>=k.next[3]))fail(k.s.name+' 贴合后 PADDING 占满列表');
        for(const value of [k.next[axis],(axis?h:w)-end(k.next,axis)])if(value>0&&value<k.list.count)model.notes.push(k.s.name+' 等尺寸单元格的 '+value+' 像素余数位于面板外沿，列表内部和相邻区域共边');
      }
    }
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)if(!oldOverlaps.has(i+':'+j) && intersects(items[i].next,items[j].next)) fail(items[i].s.name+' 与 '+items[j].s.name+' 贴合后产生重叠');
    seams.forEach(s=>{if(end(items[s.i].next,s.axis)!==items[s.j].next[s.axis])fail('共享边界校验失败');});
    return seams.length;
  }
  // LIST stores a single CELL_SIZE, not independently sized cells. Solve its
  // divisibility on the same shared-edge groups so rounding cannot open a seam.
  function fitListIntegers(items,axis,root,groups) {
    const constraints=[],ids=new Set();
    items.forEach((k,i)=>{if(k.list && (k.list.horizontal?axis===0:axis===1) && k.list.count>1){
      const a=String(root(2*i)),b=String(root(2*i+1));constraints.push({a,b,n:k.list.count,name:k.s.name});ids.add(a);ids.add(b);
    }});
    if(!constraints.length)return;
    const ordered=items.map((k,i)=>({a:String(root(2*i)),b:String(root(2*i+1)),min:k.list&&(k.list.horizontal?axis===0:axis===1)?k.list.count:1}));
    const assigned=dict(),domain=dict();
    for(const id of ids){const g=groups[id];let low=g.low,high=g.high;
      ordered.forEach(c=>{if(c.a===id&&!ids.has(c.b))high=Math.min(high,groups[c.b].value-c.min);if(c.b===id&&!ids.has(c.a))low=Math.max(low,groups[c.a].value+c.min);});
      domain[id]=[];for(let value=low;value<=high;value++)domain[id].push(value);
      domain[id].sort((a,b)=>Math.abs(a-g.value)-Math.abs(b-g.value)||a-b);
    }
    const valid=(id,value)=>constraints.every(c=>c.a!==id&&c.b!==id||!own(assigned,c.a===id?c.b:c.a)||Math.abs(value-assigned[c.a===id?c.b:c.a])%c.n===0) && ordered.every(c=>{
      if(c.a===id&&own(assigned,c.b))return assigned[c.b]-value>=c.min;
      if(c.b===id&&own(assigned,c.a))return value-assigned[c.a]>=c.min;return true;
    });
    let visits=0;
    const search=()=>{
      if(Object.keys(assigned).length===ids.size)return true;
      if(++visits>20000)fail('LIST 共边约束过于复杂，保留此面板原配置');
      let chosen=null,choices=null;
      for(const id of ids)if(!own(assigned,id)){const available=domain[id].filter(v=>valid(id,v));if(!available.length)return false;if(choices===null||available.length<choices.length){chosen=id;choices=available;}}
      for(const value of choices){assigned[chosen]=value;if(search())return true;delete assigned[chosen];}return false;
    };
    if(!search())fail(constraints.map(c=>c.name).join('、')+' 的等尺寸单元格无法与固定区域使用整数共边');
    Object.keys(assigned).forEach(id=>{groups[id].value=assigned[id];});
  }
  function stateItems(model,sections,defaults) {
    const virtual=[];
    for(const item of model.all.filter(k=>k.kind!=='overlay')) {
      for(const field of Object.keys(item.s.values).filter(k=>/^STAT_STYLE\d*$/.test(k))) {
        const value=item.s.values[field],tokens=value.match(/S\d+_\d+/g)||[];
        if(tokens.length && !/^\s*S\d+(?:_\d+)?(?:\s*\|\s*S\d+(?:_\d+)?)*\s*$/.test(value))fail(item.s.name+' 的状态表达式无法确定');
        for(const token of Array.from(new Set(tokens))) {
          const name='TIP'+token.split('_')[1],tip=sections.find(s=>s.name===name)||defaults.find(s=>s.name===name);
          if(!tip)fail(item.s.name+' 的状态 '+token+' 缺少 '+name);
          if(item.list)for(const field of ['POS','CELL_SIZE','LIST_NUM','LIST_ORDER','PADDING'])if(tip.values[field] && tip.values[field]!==item.s.values[field])fail(item.s.name+' 的状态 '+token+' 使用不同 LIST 几何，保留此面板原配置');
          if(tip.values.VIEW_RECT && !eq(nums(tip.values.VIEW_RECT),item.r))fail(item.s.name+' 的状态 '+token+' 使用不同 VIEW，无法自动确定共用边界');
          const s={name:item.s.name+'/'+name,index:-virtual.length-1,values:Object.assign(dict(),tip.values)};
          const k={s,r:item.r,next:item.next,kind:'state',base:item,tip,field,token};virtual.push(k);
        }
      }
    }
    model.all.push(...virtual);return virtual;
  }
  // Reflow one explicit add/copy/delete operation. Native callers commit the
  // returned text once, so undo restores both the edit and its geometry.
  function reflow(input) {
    const text=String(input.after),mode=input.mode;
    if(mode==='off')return {text,changedKeys:0};
    if(!['row','grid'].includes(mode))fail('未知的自动排列方式');
    const defs=parse(input.defaults||'').sections,before=effective(parse(input.before||'').sections,defs),after=effective(parse(text).sections,defs);
    const panel=after.find(s=>s.name==='PANEL') || defs.find(s=>s.name==='PANEL'),size=nums(panel && panel.values.SIZE);
    if(size.length!==2 || size.some(v=>!Number.isInteger(v)||v<=0||v>32768))fail('自动排列需要有效的 PANEL.SIZE');
    const [w,h]=size,model=classify(before,w,h),oldKeys=model.active.filter(k=>k.kind==='key');
    if(after.filter(s=>/^KEY\d+$/.test(s.name)).length>1024)fail('KEY 超过 1024 个');
    const byName=dict();for(const s of after){if(own(byName,s.name)&&/^KEY\d+$/.test(s.name))fail('重复 KEY 无法自动排列');byName[s.name]=s;}
    const surviving=oldKeys.filter(k=>byName[k.s.name]).map(k=>({s:byName[k.s.name],r:k.r,next:k.r.slice()}));
    let added=null;
    if(input.addedKey && byName[input.addedKey]) {
      const s=byName[input.addedKey];
      if(['F53','F55','F80'].includes((s.values.CENTER||'').toUpperCase()) || !action(s.values))fail('特殊区域或背景层不能作为普通按键自动排列；可先关闭自动排列再复制');
      added={s,r:rect(s.values.VIEW_RECT,s.name),next:null};
    }
    const targets=surviving.concat(added?[added]:[]),changes=dict();
    if(!targets.length)return {text,changedKeys:0};
    const obstacles=model.active.filter(k=>k.kind!=='key' && byName[k.s.name]);
    const arrange=(keys,bounds,weights)=>{
      if(!keys.length)return;
      const sum=weights.reduce((a,b)=>a+b,0);let used=0,x=Math.round(bounds[0]);
      keys.forEach((k,i)=>{used+=weights[i];const right=Math.round(bounds[0]+bounds[2]*used/sum);k.next=[x,Math.round(bounds[1]),right-x,Math.round(end(bounds,1))-Math.round(bounds[1])];x=right;});
    };
    if(mode==='row' && oldKeys.length) {
      const rows=[];
      for(const k of oldKeys.slice().sort((a,b)=>a.r[1]-b.r[1]||a.r[0]-b.r[0])) {
        let row=rows.find(row=>Math.abs(row.y-k.r[1])<=2 && Math.abs(row.bottom-end(k.r,1))<=2);
        if(!row){row={y:k.r[1],bottom:end(k.r,1),old:[]};rows.push(row);}row.old.push(k);
      }
      const anchor=input.removedKey || input.anchorKey;
      const chosen=rows.find(row=>row.old.some(k=>k.s.name===anchor)) || rows[rows.length-1];
      if(input.removedKey && !oldKeys.some(k=>k.s.name===input.removedKey))return {text,changedKeys:0};
      const keys=chosen.old.map(k=>surviving.find(s=>s.s.name===k.s.name)).filter(Boolean);
      if(added){let index=keys.findIndex(k=>k.s.name===input.anchorKey);keys.splice(index<0?keys.length:index+1,0,added);}
      let left=Math.min(...chosen.old.map(k=>k.r[0])),right=Math.max(...chosen.old.map(k=>end(k.r,0)));
      // Extend only across empty side margins. LIST, symbol and handwriting
      // surfaces bound the row and are never flattened into ordinary keys.
      const blockers=obstacles.filter(k=>overlap(k.r,[left,chosen.y,right-left,chosen.bottom-chosen.y],1)>0);
      left=Math.max(0,...blockers.filter(k=>end(k.r,0)<=left+2).map(k=>end(k.r,0)));
      right=Math.min(w,...blockers.filter(k=>k.r[0]>=right-2).map(k=>k.r[0]));
      if(keys.length)arrange(keys,[left,chosen.y,right-left,chosen.bottom-chosen.y],keys.map(k=>k===added?((oldKeys.find(o=>o.s.name===input.anchorKey)||{r:[]}).r[2] || median(chosen.old.map(o=>o.r[2]))):k.r[2]));
      else {
        // Removing the final key in a row gives its vertical space to the
        // nearest matching row, without moving unrelated side columns.
        const neighbours=rows.filter(r=>r!==chosen && r.old.some(k=>byName[k.s.name]) && Math.abs(Math.min(...r.old.map(k=>k.r[0]))-Math.min(...chosen.old.map(k=>k.r[0])))<=2 && Math.abs(Math.max(...r.old.map(k=>end(k.r,0)))-Math.max(...chosen.old.map(k=>end(k.r,0))))<=2).sort((a,b)=>Math.abs(a.y-chosen.y)-Math.abs(b.y-chosen.y));
        const neighbour=neighbours[0];
        if(neighbour){const members=neighbour.old.map(k=>surviving.find(s=>s.s.name===k.s.name)).filter(Boolean),top=Math.min(neighbour.y,chosen.y),bottom=Math.max(neighbour.bottom,chosen.bottom);arrange(members,[left,top,right-left,bottom-top],members.map(k=>k.r[2]));}
      }
    } else {
      // Partition around reserved surfaces before placing the ordinary keys.
      // Every resulting rectangle is empty; no grid cell covers a symbol bar,
      // LIST or handwriting surface.
      let regions=[[0,0,w,h]];
      for(const obstacle of obstacles){const o=obstacle.r,next=[];for(const r of regions){
        if(!intersects(r,o)){next.push(r);continue;}
        const l=Math.max(r[0],o[0]),t=Math.max(r[1],o[1]),right=Math.min(end(r,0),end(o,0)),bottom=Math.min(end(r,1),end(o,1));
        for(const part of [[r[0],r[1],r[2],t-r[1]],[r[0],bottom,r[2],end(r,1)-bottom],[r[0],t,l-r[0],bottom-t],[right,t,end(r,0)-right,bottom-t]])if(part[2]>=1&&part[3]>=1)next.push(part);
      }regions=next;}
      if(!regions.length)fail('面板没有可排列普通按键的空间');
      // Thin decorative gaps are not keyboard rows. Prefer actual existing
      // key regions when a special surface splits the panel.
      if(oldKeys.length){const used=regions.filter(r=>oldKeys.some(k=>intersects(k.r,r)));if(used.length)regions=used;}
      regions.sort((a,b)=>a[1]-b[1]||a[0]-b[0]);
      const total=regions.reduce((s,r)=>s+area(r),0),counts=regions.map(r=>Math.floor(targets.length*area(r)/total));
      const ranked=regions.map((r,i)=>({i,remainder:targets.length*area(r)/total-counts[i]})).sort((a,b)=>b.remainder-a.remainder);
      for(let i=0,left=targets.length-counts.reduce((a,b)=>a+b,0);i<left;i++)counts[ranked[i%ranked.length].i]++;
      const ordered=surviving.slice().sort((a,b)=>a.r[1]-b.r[1]||a.r[0]-b.r[0]);
      if(added){const at=ordered.findIndex(k=>k.s.name===input.anchorKey);ordered.splice(at<0?ordered.length:at+1,0,added);}
      const aspect=oldKeys.length?median(oldKeys.map(k=>k.r[2]/k.r[3])):1;let offset=0;
      regions.forEach((r,i)=>{const n=counts[i];if(!n)return;const columns=Math.max(1,Math.min(n,Math.round(Math.sqrt(n*r[2]/r[3]/Math.max(aspect,.1))))),rows=Math.ceil(n/columns);let used=0;
        for(let row=0;row<rows;row++){const count=Math.floor(n/rows)+(row<n%rows?1:0),top=Math.round(r[1]+r[3]*row/rows),bottom=Math.round(r[1]+r[3]*(row+1)/rows);arrange(ordered.slice(offset+used,offset+used+count),[r[0],top,r[2],bottom-top],Array(count).fill(1));used+=count;}offset+=n;
      });
    }
    for(const k of targets) {
      if(!k.next || k.next[2]<=0 || k.next[3]<=0 || !contained(k.next,w,h))fail('自动排列后的按键尺寸无效');
      if(obstacles.some(o=>intersects(k.next,o.r)))fail('自动排列会覆盖保留区域，请改用另一种排列方式');
    }
    for(let i=0;i<targets.length;i++)for(let j=i+1;j<targets.length;j++)if(intersects(targets[i].next,targets[j].next))fail('原行存在交叠，无法自动排列');
    const transform=(value,k)=>{const r=nums(value);if(r.length!==4)fail(k.s.name+' 的触摸或状态区域无效');if(r[2]===0&&r[3]===0)return value;return boxText([Math.round(k.next[0]+(r[0]-k.r[0])*k.next[2]/k.r[2]),Math.round(k.next[1]+(r[1]-k.r[1])*k.next[3]/k.r[3]),Math.max(1,Math.round(r[2]*k.next[2]/k.r[2])),Math.max(1,Math.round(r[3]*k.next[3]/k.r[3]))]);};
    let tipID=Math.max(0,Number(panel && panel.values.TIP_NUM)||0,...after.concat(defs).filter(s=>/^TIP\d+$/.test(s.name)).map(s=>Number(s.name.slice(3))));const tips=[];
    for(const k of targets)if(k===added || !eq(k.r,k.next)) {
      const values=changes[k.s.index]={VIEW_RECT:boxText(k.next)};
      if(own(k.s.values,'TOUCH_RECT'))values.TOUCH_RECT=transform(k.s.values.TOUCH_RECT,k);
      for(const field of Object.keys(k.s.values).filter(f=>/^STAT_STYLE\d*$/.test(f)))for(const token of new Set(k.s.values[field].match(/S\d+_\d+/g)||[])) {
        const name='TIP'+token.split('_')[1],tip=after.find(s=>s.name===name)||defs.find(s=>s.name===name);
        if(!tip)fail('状态配置缺少 '+name);
        if(!tip.values.VIEW_RECT&&!tip.values.TOUCH_RECT)continue;
        const copy=Object.assign(dict(),tip.values),id=++tipID;
        if(copy.VIEW_RECT)copy.VIEW_RECT=transform(copy.VIEW_RECT,k);if(copy.TOUCH_RECT)copy.TOUCH_RECT=transform(copy.TOUCH_RECT,k);
        values[field]=(values[field]||k.s.values[field]).replace(new RegExp('\\b'+token+'\\b','g'),token.split('_')[0]+'_'+id);tips.push({name:'TIP'+id,values:copy});
      }
    }
    if(tips.length){const at=after.findIndex(s=>s.name==='PANEL');if(at<0)fail('状态自动排列需要本地 PANEL 段');(changes[at]||(changes[at]=dict())).TIP_NUM=String(tipID);}
    let updated=patch(text,changes);const nl=parse(text).nl;
    for(const tip of tips)updated+=nl+'['+tip.name+']'+nl+Object.keys(tip.values).map(k=>k+'='+tip.values[k]).join(nl)+nl;
    return {text:updated,changedKeys:targets.filter(k=>k===added||!eq(k.r,k.next)).length};
  }
  function run(input) {
    if(input.operation==='reflow')return reflow(input);
    const files=dict(), originals=dict(), index=dict(), reports=[];
    Object.keys(input.files||{}).sort().forEach(path=>{const p=normalized(path);if(own(index,p.toLowerCase()))fail('存在大小写冲突路径：'+p);index[p.toLowerCase()]=p;files[p]=String(input.files[path]);originals[p]=files[p];});
    (input.inventory||[]).forEach(path=>{const p=normalized(path);if(!own(index,p.toLowerCase()))index[p.toLowerCase()]=p;});
    const lookup=p=>index[p.toLowerCase()];
    if(input.operation==='zeroPositionTypes') {
      const edits=[],reports=[];
      for(const path of Object.keys(files).filter(p=>/\.(ini|cnd|pop|css|til)$/i.test(p))) {
        const changes=dict();let fields=0,invalid=[];
        parse(files[path]).sections.forEach((section,i)=>{
          if(!own(section.values,'POS_TYPE'))return;
          const value=section.values.POS_TYPE,values=nums(value);
          if(!values.length) {invalid.push(section.name);return;}
          const zero=value.split(',').map(part=>part.replace(/\S+/g,'0')).join(',');
          if(value!==zero){changes[i]={POS_TYPE:zero};fields++;}
        });
        if(invalid.length)reports.push({path,status:'uncertain',reason:'POS_TYPE 含非数值或空项：'+invalid.join('、')+'；整个文件保留原样'});
        else if(fields) {edits.push({path,text:patch(files[path],changes)});reports.push({path,status:'processed',reason:'已归零 '+fields+' 个 POS_TYPE 字段，英文逗号数量与分隔顺序保留'});}
        else reports.push({path,status:'unchanged',reason:'没有 POS_TYPE 字段，或数值已经全部为 0'});
      }
      for(const item of input.unreadable||[])reports.push({path:item.path,status:'uncertain',reason:item.reason||'无法无损读取'});
      return {version:1,summary:{processed:reports.filter(r=>r.status==='processed').length,unchanged:reports.filter(r=>r.status==='unchanged').length,uncertain:reports.filter(r=>r.status==='uncertain').length,files:edits.length},reports,edits};
    }
    function defaultsFor(path) {for(const p of parents(path)){const hit=lookup(join(p,'gen.ini'));if(hit && hit!==path)return hit;}return null;}
    function appendSection(path,name,values) {
      const p=parse(files[path]);let result=files[path];if(!result.endsWith(p.nl))result+=p.nl;
      result+=p.nl+'['+name+']'+p.nl+Object.keys(values).map(k=>k+'='+values[k]).join(p.nl)+p.nl;files[path]=result;
    }
    const candidates=Object.keys(files).filter(p=>/\.(ini|cnd|pop)$/i.test(p));
    const defaultsUsed=new Set(candidates.map(defaultsFor).filter(Boolean));
    for(const path of candidates) {
      const before=Object.assign(dict(),files),report={path,status:'unchanged',reason:'',keys:0,lists:0,changedKeys:0,changedLists:0,touches:0,notes:[]};
      try {
        const local=parse(files[path]).sections, def=defaultsFor(path);
        if(def && !own(files,def))fail('继承配置无法无损读取：'+def);
        const defs=def?parse(files[def]).sections:[],sections=effective(local,defs);
        const keys=sections.filter(s=>/^KEY\d+$/.test(s.name)),lists=sections.filter(s=>/^LIST\d*$/.test(s.name));report.keys=keys.length;report.lists=lists.length;
        if(!keys.length&&!lists.length || defaultsUsed.has(path)&&!keys.length) {report.reason=sections.some(s=>/^(PANEL|LIST\d*|ICON\d+|CAND)$/.test(s.name))?'无独立 KEY / LIST 拼合区域；保留候选/图标/继承配置':'非布局 INI，未修改';reports.push(report);continue;}
        if(['appearanceConfig','appearanceConfig.json','appearanceConfig.txt'].some(n=>lookup(join(dir(path),n))))fail('此面板的布局由混合/二进制配置管理，仅修改 INI 无法确定实际 VIEW');
        if(defaultsUsed.has(path))fail('此文件作为共享继承配置使用，需在引用面板内展开修改');
        if(keys.length>1024)fail('KEY 段超过 1024 个');
        if(new Set(keys.map(s=>s.name)).size!==keys.length)fail('重复 KEY 段，无法确定运行时的实际键位');
        if(new Set(lists.map(s=>s.name)).size!==lists.length)fail('重复 LIST 段，无法确定运行时的实际列表');
        const panel=sections.find(s=>s.name==='PANEL') || defs.find(s=>s.name==='PANEL');let size=nums(panel && panel.values.SIZE);
        if(/\.cnd$/i.test(path)) {
          const localCandidate=sections.find(s=>s.name==='CAND');size=nums(localCandidate && localCandidate.values.SIZE);
          const references=defs.filter(s=>s.name==='CAND' && (s.values.LAYOUT_NAME||'').replace(/\.cnd$/i,'').toLowerCase()===base(path).replace(/\.cnd$/i,'').toLowerCase()).map(s=>nums(s.values.VIEW_RECT)).filter(r=>r.length===4);
          if(references.length){
            if(references.some(r=>r[2]!==references[0][2]||r[3]!==references[0][3]) || size.length===2&&!eq(size,references[0].slice(2)))fail('CND 列表被不同尺寸引用，无法确定共用坐标');size=references[0].slice(2);
          }else if(size.length!==2)fail('无法确定此 CND 列表的独立候选区尺寸');
        } else if(/\.pop$/i.test(path) && !local.some(s=>s.name==='PANEL'&&s.values.SIZE))fail('POP 列表缺少独立尺寸，保留原配置');
        if(size.length!==2 || size.some(v=>!Number.isInteger(v)||v<=0||v>32768))fail('缺少有效的本面板/继承 PANEL.SIZE');
        const model=classify(sections,size[0],size[1]),changes=dict();
        report.seams=fitGeometry(model,size[0],size[1]);
        for(const k of model.all)if(k.geometryOwner)k.next=k.geometryOwner.next.slice();
        for(const k of model.all.filter(k=>k.kind!=='overlay'))if(!eq(k.r,k.next)) {
          const v=changes[k.s.index]||(changes[k.s.index]=dict());
          if(k.list){v.POS=boxText(k.next.slice(0,2));v.CELL_SIZE=boxText([k.next[2]/(k.list.horizontal?k.list.count:1),k.next[3]/(k.list.horizontal?1:k.list.count)]);report.changedLists++;}
          else {v.VIEW_RECT=boxText(k.next);report.changedKeys++;}
          if(/^KEY\d+$/.test(k.s.name)) {
            const touch=k.s.values.TOUCH_RECT;
            if(touch && nums(touch).length!==4)fail(k.s.name+' 的 TOUCH_RECT 无效，无法保持触摸范围');
            if(!touch) {v.TOUCH_RECT=boxText(k.r);report.touches++;}
          }
        }
        const variants=stateItems(model,sections,defs);
        for(const item of variants)if(!eq(item.r,item.next)) {
          if(item.base.list){const v=dict();for(const field of ['POS','CELL_SIZE'])if(item.tip.values[field])v[field]=changes[item.base.s.index][field];if(Object.keys(v).length)changes[item.s.index]=v;}
          else if(item.tip.values.VIEW_RECT)changes[item.s.index]={VIEW_RECT:boxText(item.next)};
        }
        let tipID=Math.max(0,Number(panel && panel.values.TIP_NUM)||0,...sections.concat(defs).filter(s=>/^TIP\d+$/.test(s.name)).map(s=>Number(s.name.slice(3))));
        const extraTips=[];
        for(const item of variants)if(changes[item.s.index]) {
          const id=++tipID, fields=changes[item.base.s.index]||(changes[item.base.s.index]=dict());
          fields[item.field]=(fields[item.field]||item.base.s.values[item.field]).split('|').map(t=>t.trim()===item.token?item.token.split('_')[0]+'_'+id:t).join('|');
          extraTips.push({name:'TIP'+id,values:Object.assign(dict(),item.tip.values,changes[item.s.index])});delete changes[item.s.index];
        }
        if(extraTips.length) {
          const panelIndex=sections.findIndex(s=>s.name==='PANEL');if(panelIndex<0)fail('状态贴片需要本地 PANEL 段');
          (changes[panelIndex]||(changes[panelIndex]=dict())).TIP_NUM=String(tipID);
          report.notes.push('为状态切换保留独立 TIP，未改变状态与输入动作');
        }
        const declared=Number(panel && panel.values.KEY_NUM);
        if(Number.isFinite(declared) && declared!==keys.length)report.notes.push('声明 KEY_NUM='+declared+'，按实际 '+keys.length+' 个 KEY 段检查；保留编号和声明以免改变启用范围');
        if(Object.keys(changes).length)files[path]=patch(files[path],changes);
        extraTips.forEach(s=>appendSection(path,s.name,s.values));
        report.status=Object.keys(files).some(p=>files[p]!==before[p])?'processed':'unchanged';
        report.reason=report.status==='processed'?'已应用到包内配置：'+report.changedKeys+' 个 VIEW，'+report.changedLists+' 个 LIST，'+report.touches+' 个隐式按键触摸范围保持原值':'边界已贴合，未改变原布局';
        report.notes.push(...Array.from(new Set(model.notes)));report.size=size;report.defaults=def || '';
      } catch(e) {
        Object.keys(files).forEach(p=>{files[p]=before[p];});report.status='uncertain';report.reason=e.message || String(e);report.changedKeys=0;report.changedLists=0;report.touches=0;
      }
      reports.push(report);
    }
    for(const entry of input.unreadable||[])reports.push({path:entry.path,status:'uncertain',reason:entry.reason||'文件编码或格式无法确定'});
    const edits=Object.keys(files).filter(p=>files[p]!==originals[p]).map(path=>({path,text:files[path]}));
    const summary={processed:reports.filter(r=>r.status==='processed').length,unchanged:reports.filter(r=>r.status==='unchanged').length,uncertain:reports.filter(r=>r.status==='uncertain').length,files:edits.length};
    return {version:1,summary,reports,edits};
  }
  global.ViewFit={run,parse,patch};
  if(typeof module!=='undefined' && module.exports)module.exports=global.ViewFit;
})(typeof globalThis!=='undefined'?globalThis:this);
