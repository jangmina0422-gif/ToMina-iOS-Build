'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const V=require(['ViewFit.js','../app/src/main/assets/ViewFit.js','../Resources/ViewFit.js'].map(p=>path.resolve(__dirname,p)).find(p=>fs.existsSync(p)));
let count=0;const test=(name,body)=>{body();count++;console.log('PASS '+name)};
const key=(n,rect,extra='')=>`[KEY${n}]\nVIEW_RECT=${rect}\nCENTER=${n}\n${extra}\n`;
const panel=keys=>'[PANEL]\nSIZE=300,200\nKEY_NUM=4\n'+keys;
const original=panel(key(1,'0,0,150,100')+key(2,'150,0,150,100')+key(3,'0,100,150,100')+key(4,'150,100,150,100'));
const added=key(5,'10,10,100,100','TOUCH_RECT=10,10,100,100');
const run=(after,extra={})=>V.run({operation:'reflow',before:original,after,mode:'row',...extra});
const get=(text,name,field='VIEW_RECT')=>V.parse(text).sections.find(s=>s.name===name).values[field];
const boxes=text=>V.parse(text).sections.filter(s=>/^KEY\d+$/.test(s.name)).map(s=>get(text,s.name).split(',').map(Number));
test('adding to selected row closes seams and leaves other row untouched',()=>{
 const r=run(original+added,{addedKey:'KEY5',anchorKey:'KEY1'});
 assert.equal(get(r.text,'KEY1'),'0,0,100,100');assert.equal(get(r.text,'KEY5'),'100,0,100,100');assert.equal(get(r.text,'KEY2'),'200,0,100,100');assert.equal(get(r.text,'KEY3'),'0,100,150,100');
 assert.equal(get(r.text,'KEY5','TOUCH_RECT'),'100,0,100,100');
});
test('deleting a key fills only the original row before native renumbering',()=>{
 const after=panel(key(1,'0,0,150,100')+key(3,'0,100,150,100')+key(4,'150,100,150,100'));
 const r=run(after,{removedKey:'KEY2'});assert.equal(get(r.text,'KEY1'),'0,0,300,100');assert.equal(get(r.text,'KEY3'),'0,100,150,100');
});
test('off mode retains the explicit key edit exactly',()=>{const after=original+added;assert.equal(run(after,{mode:'off',addedKey:'KEY5'}).text,after)});
test('global grid has no gaps or overlaps and retains every action',()=>{
 const r=run(original+added,{mode:'grid',addedKey:'KEY5',anchorKey:'KEY1'}),rects=boxes(r.text);
 assert.equal(rects.reduce((sum,r)=>sum+r[2]*r[3],0),60000);
 rects.forEach(r=>assert.ok(r[0]>=0&&r[1]>=0&&r[0]+r[2]<=300&&r[1]+r[3]<=200));
 for(let i=0;i<rects.length;i++)for(let j=i+1;j<rects.length;j++){const a=rects[i],b=rects[j];assert.ok(Math.min(a[0]+a[2],b[0]+b[2])<=Math.max(a[0],b[0])||Math.min(a[1]+a[3],b[1]+b[3])<=Math.max(a[1],b[1]));}
 for(let n=1;n<=5;n++)assert.equal(get(r.text,'KEY'+n,'CENTER'),String(n));
});
test('explicit disabled touches remain disabled; inset touches follow resized key',()=>{
 const before=original.replace('CENTER=1','CENTER=1\nTOUCH_RECT=10,10,130,80').replace('CENTER=2','CENTER=2\nTOUCH_RECT=0,0,0,0');
 const r=run(before+added,{before,addedKey:'KEY5',anchorKey:'KEY1'});
 assert.equal(get(r.text,'KEY1','TOUCH_RECT'),'7,10,87,80');assert.equal(get(r.text,'KEY2','TOUCH_RECT'),'0,0,0,0');
});
test('grid protects a symbol surface and its background',()=>{
 const before=panel(key(1,'0,0,300,120').replace('CENTER=1\n','')+key(2,'0,0,300,120').replace('CENTER=2','CENTER=F55')+key(3,'0,120,150,80')+key(4,'150,120,150,80'));
 const r=run(before+added,{before,mode:'grid',addedKey:'KEY5'});
 assert.equal(get(r.text,'KEY1'),'0,0,300,120');assert.equal(get(r.text,'KEY2'),'0,0,300,120');for(const n of [3,4,5])assert.ok(Number(get(r.text,'KEY'+n).split(',')[1])>=120);
});
test('first key fills an empty panel',()=>{const before='[PANEL]\nSIZE=300,200\n',r=run(before+added,{before,addedKey:'KEY5'});assert.equal(get(r.text,'KEY5'),'0,0,300,200')});
test('removing the last key is a valid empty layout',()=>{const after='[PANEL]\nSIZE=300,200\n';assert.equal(run(after,{before:after+key(1,'0,0,300,200'),removedKey:'KEY1'}).text,after)});
test('removing the final key in one row expands its neighbouring row',()=>{
 const before=panel(key(1,'0,0,300,100')+key(2,'0,100,300,100'));const after=panel(key(1,'0,0,300,100'));
 assert.equal(get(run(after,{before,removedKey:'KEY2'}).text,'KEY1'),'0,0,300,200');
});
test('state geometry is copied and transformed without changing a shared TIP',()=>{
 const before=original.replace('CENTER=1','CENTER=1\nSTAT_STYLE=S7_1')+'[TIP1]\nVIEW_RECT=0,0,150,100\nCENTER=F22\n';
 const r=run(before+added,{before,addedKey:'KEY5',anchorKey:'KEY1'});
 assert.equal(get(r.text,'KEY1','STAT_STYLE'),'S7_2');assert.equal(get(r.text,'TIP1'),'0,0,150,100');assert.equal(get(r.text,'TIP2'),'0,0,100,100');assert.equal(get(r.text,'TIP2','CENTER'),'F22');
});
test('inherited panel size and key dimensions are supported',()=>{
 const before='[PANEL]\n[KEY1]\nCENTER=1\n',after=before+added;
 const r=run(after,{before,defaults:'[PANEL]\nSIZE=300,200\n[KEY1]\nVIEW_RECT=0,0,300,200\n',addedKey:'KEY5',anchorKey:'KEY1'});
 assert.equal(get(r.text,'KEY1'),'0,0,150,200');assert.equal(get(r.text,'KEY5'),'150,0,150,200');
});
test('failure is atomic and never silently drops a key',()=>{
 const after=original+added;assert.throws(()=>run(after,{mode:'invalid',addedKey:'KEY5'}));assert.equal(after,original+added);
});
console.log(count+' reflow test groups passed');
