import Foundation
import CryptoKit
import SwiftUI
import UIKit

enum PreviewDiagnostics {
    static func fingerprint(_ text:String)->String {
        SHA256.hash(data:Data(text.utf8)).prefix(6).map{String(format:"%02x",$0)}.joined()
    }
}

struct PreviewCheckReport: Identifiable {
    let id=UUID()
    let text:String
}

struct PreviewCheckView: View {
    @ObservedObject var store:SkinStore
    let report:String
    @Environment(\.dismiss) private var dismiss
    @State private var copied=false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading,spacing:18) {
                    Text(report).font(.system(size:14,design:.monospaced)).textSelection(.enabled)
                        .frame(maxWidth:.infinity,alignment:.leading).accessibilityIdentifier("preview.check.report")
                    if store.bda == nil {
                        Toggle("兼容绘制",isOn:$store.compatiblePreview).accessibilityIdentifier("preview.check.compatibility")
                        Text("切换绘制方式不会修改包内文件。关闭此页后可重新打开检查，查看最新绘制状态。")
                            .font(.system(size:13)).foregroundStyle(MinaTheme.muted)
                    }
                    Button(copied ? "已复制" : "复制检查") { UIPasteboard.general.string=report;copied=true }
                        .buttonStyle(MinaButtonStyle()).accessibilityIdentifier("preview.check.copy")
                    Button("重载预览") {
                        do {try store.reloadPreview();dismiss()} catch {store.error=error.localizedDescription;dismiss()}
                    }.buttonStyle(MinaButtonStyle()).accessibilityIdentifier("preview.check.reload")
                }.padding(20)
            }.background(MinaTheme.background).navigationTitle("预览检查").navigationBarTitleDisplayMode(.inline)
                .toolbar {ToolbarItem(placement:.confirmationAction){Button("关闭"){dismiss()}}}
        }.foregroundStyle(MinaTheme.ink).tint(MinaTheme.ink).preferredColorScheme(.light)
    }
}
