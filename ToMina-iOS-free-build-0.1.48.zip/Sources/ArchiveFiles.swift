import Foundation
import SwiftUI
import UIKit
import UniformTypeIdentifiers
import ImageIO

struct ArchiveEntry: Identifiable, Sendable {
    let url: URL
    let directory: Bool
    var id: URL { url }
}

struct ArchiveRename: Sendable {
    let original: URL
    let destination: URL
    func relocated(_ file: URL) -> URL {
        let path = file.standardizedFileURL.pathComponents
        let prefix = original.standardizedFileURL.pathComponents
        guard path.starts(with: prefix) else { return file }
        return path.dropFirst(prefix.count).reduce(destination) { $0.appendingPathComponent($1) }
    }
}

enum ArchiveFiles {
    static func directory(_ folder: URL, root: URL) throws -> URL {
        let base = root.resolvingSymlinksInPath().standardizedFileURL
        let resolved = folder.resolvingSymlinksInPath().standardizedFileURL
        guard resolved.pathComponents.starts(with: base.pathComponents),
              (try? resolved.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true else {
            throw SkinFailure(message: "包内文件夹不存在")
        }
        return resolved
    }
    static func entries(in folder: URL, root: URL) throws -> [ArchiveEntry] {
        let folder = try directory(folder, root: root)
        return try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey]).compactMap { url in
            let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { return nil }
            return ArchiveEntry(url: url, directory: values.isDirectory == true)
        }.sorted { a, b in
            if a.directory != b.directory { return a.directory }
            return a.url.lastPathComponent.localizedStandardCompare(b.url.lastPathComponent) == .orderedAscending
        }
    }
    private static func regularFile(_ file: URL, root: URL) throws -> URL {
        let base = try directory(root, root: root)
        let original = file.standardizedFileURL
        let resolved = original.resolvingSymlinksInPath().standardizedFileURL
        guard original.isFileURL, resolved != base,
              original.pathComponents.starts(with: root.standardizedFileURL.pathComponents),
              resolved.pathComponents.starts(with: base.pathComponents),
              (try? resolved.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true else {
            throw SkinFailure(message: "只能操作当前包内的普通文件")
        }
        var part = original
        while part.pathComponents.count > root.standardizedFileURL.pathComponents.count {
            guard (try part.resourceValues(forKeys: [.isSymbolicLinkKey])).isSymbolicLink != true else {
                throw SkinFailure(message: "不能操作链接文件")
            }
            part.deleteLastPathComponent()
        }
        return resolved
    }
    static func copyFile(_ file: URL, root: URL) throws -> URL {
        let source = try regularFile(file, root: root)
        var total = try source.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        if let iterator = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey]) {
            for case let entry as URL in iterator {
                let values = try entry.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
                if values.isRegularFile == true { total += values.fileSize ?? 0 }
            }
        }
        guard total <= 128 * 1024 * 1024 else { throw SkinFailure(message: "复制后压缩包超过 128 MB") }
        let parent = source.deletingLastPathComponent()
        let occupied = Set(try FileManager.default.contentsOfDirectory(at: parent, includingPropertiesForKeys: nil)
            .map { $0.lastPathComponent.precomposedStringWithCanonicalMapping.lowercased() })
        let ext = source.pathExtension
        var stem = ext.isEmpty ? source.lastPathComponent : source.deletingPathExtension().lastPathComponent
        // Reserve room for the suffix while preserving the extension.
        while (stem + " 副本 999999" + (ext.isEmpty ? "" : "." + ext)).utf8.count > 255 && !stem.isEmpty { stem.removeLast() }
        var number = 1, target: URL
        repeat {
            let name = stem + " 副本" + (number == 1 ? "" : " \(number)") + (ext.isEmpty ? "" : "." + ext)
            target = parent.appendingPathComponent(name); number += 1
        } while occupied.contains(target.lastPathComponent.precomposedStringWithCanonicalMapping.lowercased())
        do { try FileManager.default.copyItem(at: source, to: target) }
        catch { try? FileManager.default.removeItem(at: target); throw error }
        return target
    }
    static func removeFile(_ file: URL, root: URL) throws { _ = try removeFiles([file], root: root) }
    @discardableResult static func removeFiles(_ files: [URL], root: URL) throws -> [URL] {
        // Validate the entire selection before changing any file. Stage removed
        // files outside the package so a failed move can be rolled back.
        let sources = try Set(files.map { try regularFile($0, root: root) }).sorted { $0.path < $1.path }
        guard !sources.isEmpty else { return [] }
        let staging = FileManager.default.temporaryDirectory.appendingPathComponent("archive-delete-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: false)
        var moved: [(URL, URL)] = []
        do {
            for (index, source) in sources.enumerated() {
                let backup = staging.appendingPathComponent(String(index))
                try FileManager.default.moveItem(at: source, to: backup)
                moved.append((source, backup))
            }
        } catch {
            for (source, backup) in moved.reversed() { try FileManager.default.moveItem(at: backup, to: source) }
            try? FileManager.default.removeItem(at: staging)
            throw error
        }
        try? FileManager.default.removeItem(at: staging)
        return sources
    }
    static func validName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." && !name.contains("/") && !name.contains("\\") && !name.contains(":") && !name.contains("\0")
    }
    static func rename(_ entry: URL, to name: String, root: URL) throws -> ArchiveRename {
        let base = try directory(root, root: root)
        let source = entry.standardizedFileURL
        let resolved = source.resolvingSymlinksInPath().standardizedFileURL
        let values = try? source.resourceValues(forKeys: [.isSymbolicLinkKey, .isDirectoryKey, .isRegularFileKey])
        guard entry.isFileURL, source != base, source.pathComponents.starts(with: base.pathComponents),
              resolved.pathComponents == source.pathComponents, values?.isSymbolicLink != true,
              values?.isDirectory == true || values?.isRegularFile == true else {
            throw SkinFailure(message: "只能更名当前包内的文件或文件夹")
        }
        guard validName(name), !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              name.utf8.count <= 255, !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw SkinFailure(message: "名称无效，请保留单个文件名")
        }
        let parent = try directory(source.deletingLastPathComponent(), root: base)
        let destination = parent.appendingPathComponent(name, isDirectory: values?.isDirectory == true)
        let result = ArchiveRename(original: source, destination: destination)
        guard source.lastPathComponent != name else { return result }
        let siblings = try FileManager.default.contentsOfDirectory(at: parent, includingPropertiesForKeys: nil)
        guard !siblings.contains(where: {
            $0.lastPathComponent != source.lastPathComponent &&
            $0.lastPathComponent.precomposedStringWithCanonicalMapping.caseInsensitiveCompare(name.precomposedStringWithCanonicalMapping) == .orderedSame
        }) else { throw SkinFailure(message: "已有同名文件或文件夹") }
        // A temporary name makes changes of letter case reliable on both
        // case-sensitive and case-insensitive file providers.
        if source.lastPathComponent.caseInsensitiveCompare(name) == .orderedSame {
            let temporary = parent.appendingPathComponent(".rename-" + UUID().uuidString, isDirectory: values?.isDirectory == true)
            try FileManager.default.moveItem(at: source, to: temporary)
            do { try FileManager.default.moveItem(at: temporary, to: destination) }
            catch { try? FileManager.default.moveItem(at: temporary, to: source); throw error }
        } else { try FileManager.default.moveItem(at: source, to: destination) }
        return result
    }
    static func createFolder(_ name: String, in folder: URL, root: URL) throws {
        guard validName(name) else { throw SkinFailure(message: "文件夹名称无效") }
        let target = try directory(folder, root: root).appendingPathComponent(name, isDirectory: true)
        guard !FileManager.default.fileExists(atPath: target.path) else { throw SkinFailure(message: "已有同名文件或文件夹") }
        try FileManager.default.createDirectory(at: target, withIntermediateDirectories: false)
    }
}

struct StagedResource: Sendable {
    let url: URL
    let name: String
}
struct ResourceBatch: Sendable {
    var files: [StagedResource] = []
    var failures: [String] = []
    func discard() { for file in files { try? FileManager.default.removeItem(at: file.url.deletingLastPathComponent()) } }
}

enum ResourceImport {
    static let maximumFile = 32 * 1024 * 1024
    static let maximumBatch = 128 * 1024 * 1024
    static let maximumCount = 64

    // Provider URLs may be deleted immediately after their callback returns.
    // Always copy within that callback, then pass only our stable copy onward.
    static func stage(_ source: URL, name: String? = nil, coordinated: Bool = true) throws -> StagedResource {
        guard source.isFileURL else { throw SkinFailure(message: "共享内容没有可读取的文件") }
        let access = source.startAccessingSecurityScopedResource()
        defer { if access { source.stopAccessingSecurityScopedResource() } }
        var output: StagedResource?, failure: Error?
        let copy: (URL) -> Void = { url in
            do {
                let values = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
                guard values.isRegularFile == true, let size = values.fileSize, size <= maximumFile else {
                    throw SkinFailure(message: "只支持文件；单文件最多 32 MB")
                }
                let filename = name ?? url.lastPathComponent
                guard ArchiveFiles.validName(filename) else { throw SkinFailure(message: "文件名无效") }
                let folder = FileManager.default.temporaryDirectory.appendingPathComponent("resource-" + UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                let copy = folder.appendingPathComponent(filename)
                do { try FileManager.default.copyItem(at: url, to: copy); output = StagedResource(url: copy, name: filename) }
                catch { try? FileManager.default.removeItem(at: folder); throw error }
            } catch { failure = error }
        }
        // loadFileRepresentation already gives an accessible, coordinated
        // temporary file. Re-entering its File Provider coordinator can hang
        // the provider callback. Original Files URLs still need coordination.
        var coordinationError: NSError?
        if coordinated {
            NSFileCoordinator().coordinate(readingItemAt: source, options: .withoutChanges, error: &coordinationError, byAccessor: copy)
        } else { copy(source) }
        if let coordinationError { throw coordinationError }
        if let failure { throw failure }
        guard let output else { throw SkinFailure(message: "文件读取失败") }
        return output
    }
    static func stageURLs(_ urls: [URL]) -> ResourceBatch {
        var batch = ResourceBatch(), total = 0
        for url in urls.prefix(maximumCount) {
            do {
                let file = try stage(url)
                let size = try file.url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard total + size <= maximumBatch else {
                    try? FileManager.default.removeItem(at: file.url.deletingLastPathComponent())
                    throw SkinFailure(message: "一次导入最多 128 MB")
                }
                total += size; batch.files.append(file)
            } catch { batch.failures.append(url.lastPathComponent + "：" + error.localizedDescription) }
        }
        if urls.count > maximumCount { batch.failures.append("一次最多导入 64 个文件，其余文件请再次导入") }
        return batch
    }
    static func accepts(_ provider: NSItemProvider) -> Bool {
        provider.hasItemConformingToTypeIdentifier(UTType.item.identifier) || provider.canLoadObject(ofClass: UIImage.self)
    }
    private static func suggestedName(_ suggestion: String?, url: URL, type: String) -> String {
        let proposed = suggestion ?? url.lastPathComponent
        let base = ArchiveFiles.validName(proposed) ? proposed : url.lastPathComponent
        guard (base as NSString).pathExtension.isEmpty else { return base }
        let ext = UTType(type)?.preferredFilenameExtension ?? url.pathExtension
        return ext.isEmpty ? base : base + "." + ext
    }
    private static func fileURL(_ provider: NSItemProvider) async throws -> StagedResource {
        try await withCheckedThrowingContinuation { continuation in
            _ = provider.loadObject(ofClass: NSURL.self) { value, error in
                do {
                    if let error { throw error }
                    let url: URL?
                    if let value = value as? NSURL { url = value as URL }
                    else { url = nil }
                    guard let url, url.isFileURL else { throw SkinFailure(message: "拖入的内容不是本地文件") }
                    continuation.resume(returning: try stage(url))
                } catch { continuation.resume(throwing: error) }
            }
        }
    }
    private static func representation(_ provider: NSItemProvider, type: String) async throws -> StagedResource {
        let suggestion = provider.suggestedName
        return try await withCheckedThrowingContinuation { continuation in
            _ = provider.loadFileRepresentation(forTypeIdentifier: type) { url, error in
                do {
                    if let error { throw error }
                    guard let url else { throw SkinFailure(message: "分享内容没有文件数据") }
                    let file = try autoreleasepool { try stage(url, name: suggestedName(suggestion, url: url, type: type), coordinated: false) }
                    continuation.resume(returning: file)
                } catch { continuation.resume(throwing: error) }
            }
        }
    }
    private static func image(_ provider: NSItemProvider) async throws -> StagedResource {
        let suggestion = provider.suggestedName
        return try await withCheckedThrowingContinuation { continuation in
            _ = provider.loadObject(ofClass: UIImage.self) { value, error in
                do {
                    if let error { throw error }
                    guard let image = value as? UIImage else { throw SkinFailure(message: "图片无法读取") }
                    let width = image.size.width * image.scale, height = image.size.height * image.scale
                    guard safeImageObject(width: width, height: height) else {
                        throw SkinFailure(message: "拖拽图片像素过大，请先从 Procreate 导出为 PNG 文件再导入")
                    }
                    let proposed = suggestion ?? "绘图"
                    let base = ArchiveFiles.validName(proposed) ? (proposed as NSString).deletingPathExtension : "绘图"
                    let name = base + ".png"
                    let folder = FileManager.default.temporaryDirectory.appendingPathComponent("resource-" + UUID().uuidString, isDirectory: true)
                    try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                    let file = folder.appendingPathComponent(name)
                    // Bound decoded memory before PNG encoding. The original
                    // file representation above is kept byte for byte.
                    do {
                        try autoreleasepool {
                            guard let pixels = image.cgImage, safeImageObject(width: CGFloat(pixels.width), height: CGFloat(pixels.height)),
                                  let writer = CGImageDestinationCreateWithURL(file as CFURL, UTType.png.identifier as CFString, 1, nil) else {
                                throw SkinFailure(message: "共享图片无法写入 PNG，请导出图片文件后导入")
                            }
                            CGImageDestinationAddImage(writer, pixels, [kCGImagePropertyOrientation: imageOrientation(image.imageOrientation)] as CFDictionary)
                            guard CGImageDestinationFinalize(writer), (try file.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? maximumFile + 1) <= maximumFile else {
                                throw SkinFailure(message: "图片无法读取或超过 32 MB")
                            }
                        }
                    }
                    catch { try? FileManager.default.removeItem(at: folder); throw error }
                    continuation.resume(returning: StagedResource(url: file, name: name))
                } catch { continuation.resume(throwing: error) }
            }
        }
    }
    static func safeImageObject(width: CGFloat, height: CGFloat) -> Bool {
        width.isFinite && height.isFinite && width > 0 && height > 0 && width * height <= 16 * 1024 * 1024
    }
    private static func imageOrientation(_ orientation: UIImage.Orientation) -> Int {
        switch orientation {
        case .up: return 1
        case .upMirrored: return 2
        case .down: return 3
        case .downMirrored: return 4
        case .leftMirrored: return 5
        case .right: return 6
        case .rightMirrored: return 7
        case .left: return 8
        @unknown default: return 1
        }
    }
    static func stageProvider(_ provider: NSItemProvider) async throws -> StagedResource {
        var lastError: Error = SkinFailure(message: "该共享内容没有文件或图片")
        // Prefer the sender's original representation, including Procreate/PSD,
        // over a preview thumbnail. Image-only providers fall back to full PNG.
        for type in provider.registeredTypeIdentifiers where type != UTType.fileURL.identifier && type != UTType.url.identifier && type != "com.apple.uikit.image" {
            do {
                let file = try await representation(provider, type: type)
                // UIKit's object archive is not an image file. Some providers
                // advertise it alongside export formats; accept only a readable
                // image representation, then fall back to the UIImage object.
                if UTType(type)?.conforms(to: .image) == true {
                    guard let source = CGImageSourceCreateWithURL(file.url as CFURL, nil), CGImageSourceGetCount(source) > 0 else {
                        try? FileManager.default.removeItem(at: file.url.deletingLastPathComponent())
                        throw SkinFailure(message: "共享图片不是可读取的图片文件")
                    }
                }
                return file
            } catch { lastError = error }
        }
        if provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier), provider.canLoadObject(ofClass: NSURL.self) {
            do { return try await fileURL(provider) } catch { lastError = error }
        }
        if provider.canLoadObject(ofClass: UIImage.self) { return try await image(provider) }
        throw lastError
    }
    static func stageProviders(_ providers: [NSItemProvider]) async -> ResourceBatch {
        var batch = ResourceBatch(), total = 0
        for provider in providers.prefix(maximumCount) {
            do {
                let file = try await stageProvider(provider)
                let size = try file.url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard total + size <= maximumBatch else {
                    try? FileManager.default.removeItem(at: file.url.deletingLastPathComponent())
                    throw SkinFailure(message: "一次导入最多 128 MB")
                }
                total += size; batch.files.append(file)
            } catch { batch.failures.append((provider.suggestedName ?? "共享文件") + "：" + error.localizedDescription) }
        }
        if providers.count > maximumCount { batch.failures.append("一次最多导入 64 个文件，其余文件请再次拖入") }
        return batch
    }
    enum ConflictPolicy { case replace, keepBoth }
    static func insert(_ batch: [StagedResource], into folder: URL, root: URL, policy: ConflictPolicy) throws -> [URL] {
        let folder = try ArchiveFiles.directory(folder, root: root)
        var targets = [URL](), reserved = Set<String>(), total = 0
        let existing = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil)
        var occupied = Set(existing.map { $0.lastPathComponent.lowercased() })
        for resource in batch {
            guard ArchiveFiles.validName(resource.name) else { throw SkinFailure(message: "文件名无效") }
            let size = try resource.url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? maximumFile + 1
            guard size <= maximumFile, total + size <= maximumBatch else { throw SkinFailure(message: "导入文件超出大小限制") }
            total += size
            var name = resource.name
            if policy == .keepBoth {
                let ext = (name as NSString).pathExtension, base = (name as NSString).deletingPathExtension
                var index = 2
                while occupied.contains(name.lowercased()) {
                    name = base + " (\(index))" + (ext.isEmpty ? "" : "." + ext); index += 1
                }
            } else {
                // Match an existing spelling even on a case-sensitive volume.
                name = existing.first { $0.lastPathComponent.lowercased() == name.lowercased() }?.lastPathComponent ?? name
                guard !reserved.contains(name.lowercased()) else { throw SkinFailure(message: "同一批文件有重复名称，请选择保留两份") }
            }
            occupied.insert(name.lowercased()); reserved.insert(name.lowercased())
            let target = folder.appendingPathComponent(name)
            let resolved = target.resolvingSymlinksInPath().standardizedFileURL
            guard resolved.deletingLastPathComponent() == folder else { throw SkinFailure(message: "目标文件路径无效") }
            if FileManager.default.fileExists(atPath: target.path), (try target.resourceValues(forKeys: [.isRegularFileKey])).isRegularFile != true {
                throw SkinFailure(message: "不能用文件覆盖文件夹：" + name)
            }
            targets.append(target)
        }
        // Stage replacements before touching the working archive; rollback all
        // written entries if an individual write fails midway through the batch.
        if let iterator=FileManager.default.enumerator(at:root,includingPropertiesForKeys:[.isRegularFileKey,.fileSizeKey]) {
            var resulting=total,count=0
            let replacements=Set(targets)
            for case let file as URL in iterator {
                count += 1
                let values=try file.resourceValues(forKeys:[.isRegularFileKey,.fileSizeKey])
                if values.isRegularFile == true,!replacements.contains(file){resulting += values.fileSize ?? 0}
            }
            guard resulting<=maximumBatch,count+targets.filter({!FileManager.default.fileExists(atPath:$0.path)}).count<=6000 else {
                throw SkinFailure(message:"加入后压缩包超过 128 MB 或 6000 个条目")
            }
        }
        let rollback = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: rollback, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: rollback) }
        var prior = [URL: URL](), written = [URL]()
        do {
            for (index, target) in targets.enumerated() {
                if FileManager.default.fileExists(atPath: target.path) {
                    let copy = rollback.appendingPathComponent(String(index))
                    try FileManager.default.copyItem(at: target, to: copy); prior[target] = copy
                }
                let data = try Data(contentsOf: batch[index].url, options: .mappedIfSafe)
                try data.write(to: target, options: .atomic); written.append(target)
            }
        } catch {
            for target in written.reversed() {
                if let copy = prior[target] { try? Data(contentsOf: copy).write(to: target, options: .atomic) }
                else { try? FileManager.default.removeItem(at: target) }
            }
            throw error
        }
        return targets
    }
}

@MainActor struct SkinResourcePicker: UIViewControllerRepresentable {
    let completion: (Result<[URL], Error>) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = Self.controller()
        picker.delegate = context.coordinator; return picker
    }
    static func controller() -> UIDocumentPickerViewController {
        let picker=SkinDocumentPicker.controller(contentTypes:[.item],asCopy:true)
        picker.allowsMultipleSelection=true;picker.shouldShowFileExtensions=true;return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    @MainActor final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let completion: (Result<[URL], Error>) -> Void
        private var completed = false
        init(_ completion: @escaping (Result<[URL], Error>) -> Void) { self.completion = completion }
        private func finish(_ result: Result<[URL], Error>) { guard !completed else { return }; completed = true; completion(result) }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard !urls.isEmpty, urls.allSatisfy(\.isFileURL) else { finish(.failure(SkinFailure(message: "系统未返回可读取的文件"))); return }
            finish(.success(urls))
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { finish(.success([])) }
    }
}
