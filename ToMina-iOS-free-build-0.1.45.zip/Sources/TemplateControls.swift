import SwiftUI
import UIKit

struct TemplateParameterEditor: View {
    @ObservedObject var store:SkinStore
    let id:String
    let key:String
    let floating:Bool
    @Environment(\.dismiss) private var dismiss
    @State private var values:[String:String]=[:]
    @State private var originalFields:Set<String>=[]
    @State private var template:AnimationCatalog.Template?
    @State private var failure=""
    private func value(_ field:String)->Binding<String>{Binding(get:{values[field] ?? ""},set:{values[field]=$0})}
    var body:some View {
        NavigationStack {
            Form {
                if let template {
                    Section {
                        Text("ANIM"+id+" · "+template.title)
                        Text("配置已写入包内。修改数值后保存；全零模板可能暂时不可见。按键动效可通过绑定和触发设置调用此编号。")
                            .font(.caption).foregroundStyle(MinaTheme.muted)
                    }
                    ForEach(template.fields.filter{originalFields.contains($0.key) || (template.id=="particle" && $0.key=="TYPR")}) { field in
                        Section {
                            if field.fixed {LabeledContent(field.key+"（固定）",value:values[field.key] ?? field.value)}
                            else {
                                TextField(field.key,text:value(field.key))
                                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                                    .accessibilityIdentifier("template.field."+field.key)
                                if template.id=="color",["FROM","TO"].contains(field.key) {
                                    ColorPicker("选择 "+field.key+" 颜色",selection:color(field.key),supportsOpacity:true)
                                        .accessibilityIdentifier("template.color."+field.key)
                                }
                            }
                        } header:{Text(field.key)} footer:{Text(field.hint).font(.caption)}
                    }
                }
                if !failure.isEmpty{Text(failure).foregroundStyle(.red).accessibilityIdentifier("template.error")}
            }.navigationTitle("编辑 ANIM"+id).toolbar {
                ToolbarItem(placement:.cancellationAction){Button("关闭"){dismiss()}}
                ToolbarItem(placement:.confirmationAction){Button("保存参数"){
                    do{try store.editTemplateParameters(id,values:values,key:key,floating:floating);dismiss()}
                    catch{failure=error.localizedDescription}
                }.accessibilityIdentifier("template.save").disabled(template==nil)}
            }
        }.preferredColorScheme(.light).tint(.black).onAppear {
            values=store.renderer.timeline.definitions[id] ?? [:]
            originalFields=Set(values.keys);template=AnimationCatalog.matching(values)
            if template?.id=="particle",values["TYPR"]==nil{values["TYPR"]=values["TYPE"] ?? "0"}
            if template==nil{failure="此动效请在源码中编辑。"}
        }
    }
    private func color(_ field:String)->Binding<Color> {
        Binding(get:{
            let text=(values[field] ?? "000000").replacingOccurrences(of:"#",with:"").replacingOccurrences(of:"0x",with:"",options:.caseInsensitive)
            let n=UInt64(text,radix:16) ?? 0
            return Color(.sRGB,red:Double((n>>16)&255)/255,green:Double((n>>8)&255)/255,blue:Double(n&255)/255,opacity:text.count>6 ? Double((n>>24)&255)/255:1)
        },set:{color in
            var r:CGFloat=0,g:CGFloat=0,b:CGFloat=0,a:CGFloat=0
            guard UIColor(color).getRed(&r,green:&g,blue:&b,alpha:&a) else{return}
            let alpha=Int((a*255).rounded()),rgb=(Int((r*255).rounded())<<16)|(Int((g*255).rounded())<<8)|Int((b*255).rounded())
            let old=(values[field] ?? "").replacingOccurrences(of:"#",with:"").replacingOccurrences(of:"0x",with:"",options:.caseInsensitive)
            values[field]=alpha<255 || old.count==8 ? String(format:"%08X",(alpha<<24)|rgb):String(format:"%06X",rgb)
        })
    }
}

struct SourceFieldControl: View {
    @ObservedObject var store:SkinStore
    let selected:String
    let inserted:(String)->Void
    @State private var showing=false
    @State private var pending:String?
    var body:some View {
        Button("添加字段"){showing=true}.buttonStyle(MinaButtonStyle()).accessibilityIdentifier("source.addField")
            .sheet(isPresented:$showing,onDismiss:{if let pending{inserted(pending);self.pending=nil}}){
                SourceFieldEditor(store:store,selected:selected){pending=$0}
            }
    }
}

struct SourceFieldEditor: View {
    @ObservedObject var store:SkinStore
    let selected:String
    let inserted:(String)->Void
    @Environment(\.dismiss) private var dismiss
    @State private var target=""
    @State private var field=""
    @State private var failure=""
    private var css:Bool{store.current?.pathExtension.lowercased()=="css"}
    private var fields:[String]{css ? AnimationCatalog.cssFields:AnimationCatalog.keyFields}
    private var names:[String]{SkinConfiguration.parse(store.text).filter{$0.name.range(of:css ? "^STYLE[0-9]+$":"^KEY[0-9]+$",options:.regularExpression) != nil}.map(\.name)}
    var body:some View {
        NavigationStack {
            Form {
                Picker(css ? "STYLE":"KEY",selection:$target){
                    if css{Text("新增 STYLE").tag("")}
                    ForEach(names,id:\.self){Text($0).tag($0)}
                }.accessibilityIdentifier("source.section")
                Picker("字段",selection:$field){ForEach(fields,id:\.self){Text($0+"=").tag($0)}}
                    .accessibilityIdentifier("source.field")
                Text(css ? "选择已有 STYLE，或按最大编号续写新 STYLE。添加后编辑等号右侧数值。":"字段添加到所选 KEY 的最后一行，随后编辑等号右侧数值。")
                    .font(.caption).foregroundStyle(MinaTheme.muted)
                Text("已存在的字段会定位到原值，不重复添加。").font(.caption).foregroundStyle(MinaTheme.muted)
                if !failure.isEmpty{Text(failure).foregroundStyle(.red)}
            }.navigationTitle("添加字段").toolbar {
                ToolbarItem(placement:.cancellationAction){Button("取消"){dismiss()}}
                ToolbarItem(placement:.confirmationAction){Button("添加并编辑"){
                    do{let result=try store.insertSourceField(section:target,field:field,newStyle:css && target.isEmpty);inserted(result.section);dismiss()}
                    catch{failure=error.localizedDescription}
                }.disabled(field.isEmpty || (!css && target.isEmpty)).accessibilityIdentifier("source.insert")}
            }
        }.preferredColorScheme(.light).tint(.black).onAppear {
            target=names.contains(selected) ? selected:(css ? "":names.first ?? "");field=fields.first ?? ""
        }
    }
}
