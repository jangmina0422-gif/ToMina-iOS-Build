import Foundation

// The animation editor contains a selection of blocks, not the complete file.
// Keep loaded blocks in their source files and append new definitions separately.
enum AnimationSourceEdits {
    static func id(_ name: String) -> String? {
        guard name.range(of: "^ANIM[0-9]+$", options: .regularExpression) != nil else { return nil }
        let digits = name.dropFirst(4).drop(while: { $0 == "0" })
        return digits.isEmpty ? "0" : String(digits)
    }

    static func validate(_ text: String, expected: Set<String>, occupied: Set<String>,
                         parsed: [Section]? = nil) throws -> [Section] {
        var hasHeader = false
        for raw in text.components(separatedBy: .newlines) {
            let line = raw.replacingOccurrences(of: "\u{FEFF}", with: "").trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix(";") || line.hasPrefix("//") || line.hasPrefix("#") { continue }
            if let name = SkinConfiguration.header(line), id(name) != nil { hasHeader = true }
            else if line.hasPrefix("[") || !hasHeader {
                throw AnimationEditError.invalid("动效代码只支持 [ANIM数字] 段，请检查：" + String(line.prefix(60)))
            }
        }
        let sections = parsed ?? SkinConfiguration.parse(text)
        var seen = Set<String>()
        for section in sections {
            guard let number = id(section.name) else {
                throw AnimationEditError.invalid("不支持的动效段：[\(section.name)]")
            }
            guard seen.insert(number).inserted else {
                throw AnimationEditError.invalid("[ANIM\(number)] 编号重复，请为新增动效使用不同编号")
            }
        }
        let names = Set(sections.map(\.name))
        if let missing = expected.subtracting(names).sorted().first {
            throw AnimationEditError.invalid("原有 [\(missing)] 不能删除或更名；可以在后面新增 ANIM 段")
        }
        let used = Set(occupied.compactMap { id("ANIM" + $0) })
        for section in sections where !expected.contains(section.name) {
            if let number = id(section.name), used.contains(number) {
                throw AnimationEditError.invalid("[\(section.name)] 已存在于动画文件中，请换一个新编号")
            }
        }
        return sections
    }

    private static func range(_ lines: [String], _ name: String) -> Range<Int>? {
        var start: Int?
        for (index, line) in lines.enumerated() {
            guard let header = SkinConfiguration.header(line) else { continue }
            if let start { return start..<index }
            if header == name { start = index }
        }
        return start.map { $0..<lines.count }
    }

    static func merge(_ original: String, draft: String, names: [String], existing: Set<String>) throws -> String {
        let newline = original.contains("\r\n") ? "\r\n" : "\n"
        var lines = original.replacingOccurrences(of: "\r\n", with: "\n").components(separatedBy: "\n")
        let replacements = draft.replacingOccurrences(of: "\r\n", with: "\n").components(separatedBy: "\n")
        for name in names {
            guard let replacement = range(replacements, name) else {
                throw AnimationEditError.invalid("未找到 [\(name)] 的编辑内容")
            }
            var block = Array(replacements[replacement])
            while block.last?.trimmingCharacters(in: .whitespaces).isEmpty == true { block.removeLast() }
            block.append("")
            if existing.contains(name) {
                guard let location = range(lines, name) else {
                    throw AnimationEditError.invalid("原文件中的 [\(name)] 已发生变化，请重新打开")
                }
                lines.replaceSubrange(location, with: block)
            } else {
                guard range(lines, name) == nil else {
                    throw AnimationEditError.invalid("原文件已包含 [\(name)]，未覆盖原动效")
                }
                lines.append(contentsOf: block)
            }
        }
        var result = lines.joined(separator: newline)
        if names.contains(where: { !existing.contains($0) }) {
            let count = SkinConfiguration.parse(result).filter { id($0.name) != nil }.count
            if SkinConfiguration.parse(result).contains(where: { $0.name == "GLOBAL" }) {
                result = try AnimationEdits.set(result, section: "GLOBAL", field: "ANIM_NUM", value: String(max(count,Int(SkinConfiguration.parse(original).first{$0.name=="GLOBAL"}?.values["ANIM_NUM"] ?? "0") ?? 0)))
            } else {
                result = "[GLOBAL]" + newline + "ANIM_NUM=\(count)" + newline + newline + result
            }
        }
        return result
    }
}
