import Foundation

enum TemplateEdits {
 struct Edit {let text:String;let section:String;let caret:Int}
 static func next(_ text:String,prefix:String,occupied:[String]=[])throws->Int {
  let ids=SkinConfiguration.parse(text).filter{$0.name.range(of:"^"+prefix+"[0-9]+$",options:.regularExpression) != nil}.compactMap{Int($0.name.dropFirst(prefix.count))}+occupied.compactMap(Int.init)
  let maxID=ids.max() ?? 0
  guard maxID<Int(Int32.max) else{throw AnimationEditError.invalid("编号已超出范围")}
  return maxID+1
 }
 static func newline(_ text:String)->String{text.contains("\r\n") ? "\r\n":"\n"}
 static func append(_ text:String,block:String)->String{let nl=newline(text);return text+(text.hasSuffix(nl) ? nl:nl+nl)+block.replacingOccurrences(of:"\n",with:nl)+nl}
 static func count(_ text:String,prefix:String,field:String,floor:Int=0)throws->String {
  let sections=SkinConfiguration.parse(text),global=sections.first{$0.name=="GLOBAL"}
  let count=sections.filter{$0.name.range(of:"^"+prefix+"[0-9]+$",options:.regularExpression) != nil}.count
  let value=String(max(floor,max(count,Int(global?.values[field] ?? "0") ?? 0)))
  if global != nil{return try AnimationEdits.set(text,section:"GLOBAL",field:field,value:value)}
  let nl=newline(text);return "[GLOBAL]"+nl+field+"="+value+nl+text
 }
 static func animation(_ original:String?,template:String,occupied:[String]=[])throws->Edit {
  var text=original ?? "[GLOBAL]\nANIM_NUM=422\n"
  let name="ANIM\(try next(text,prefix:"ANIM",occupied:occupied))"
  var block="["+name+"]"
  for field in AnimationCatalog.get(template).fields {block += "\n"+field.key+"="+field.value;if field.key=="TYPR"{block += "\nTYPE="+field.value}}
  text=try count(append(text,block:block),prefix:"ANIM",field:"ANIM_NUM",floor:original==nil ? 422:0)
  return Edit(text:text,section:name,caret:(text as NSString).length)
 }
 static func event(_ original:String?)throws->String {
  if let original,SkinConfiguration.parse(original).contains(where:{$0.name.range(of:"^EVENT[0-9]+$",options:.regularExpression) != nil && $0.values["NAME"]?.uppercased()=="IDLE"}){return original}
  let text=original ?? "[GLOBAL]\nEVENT_NUM=1\n"
  let block="[EVENT\(try next(text,prefix:"EVENT"))]\nNAME=IDLE\nIDLE_TIME=422"
  return try count(append(text,block:block),prefix:"EVENT",field:"EVENT_NUM",floor:1)
 }
 static func insert(_ original:String,section:String,field:String,newStyle:Bool=false)throws->Edit {
  var text=original,name=section
  let css=newStyle || section.range(of:"^STYLE[0-9]+$",options:.regularExpression) != nil
  guard (css ? AnimationCatalog.cssFields:AnimationCatalog.keyFields).contains(field) else{throw AnimationEditError.invalid("不支持的字段")}
  if newStyle {
   name="STYLE\(try next(text,prefix:"STYLE"))"
   text=try count(append(text,block:"["+name+"]\n"+field+"="),prefix:"STYLE",field:"STYLE_NUM")
  }else{
   guard section.range(of:css ? "^STYLE[0-9]+$":"^KEY[0-9]+$",options:.regularExpression) != nil,let range=range(text,section),let item=SkinConfiguration.parse(text).first(where:{$0.name==section}) else{throw AnimationEditError.invalid("请先选择 KEY 或 STYLE")}
   if item.values[field]==nil {
    let nl=newline(text);var lines=text.replacingOccurrences(of:"\r\n",with:"\n").components(separatedBy:"\n")
    var end=range.upperBound
    while end>range.lowerBound+1 && lines[end-1].trimmingCharacters(in:.whitespaces).isEmpty{end-=1}
    lines.insert(field+"=",at:end);text=lines.joined(separator:nl)
   }
  }
  return Edit(text:text,section:name,caret:caret(text,section:name,field:field))
 }
 static func range(_ text:String,_ name:String)->Range<Int>? {
  let lines=text.replacingOccurrences(of:"\r\n",with:"\n").components(separatedBy:"\n");var start:Int?
  for (i,line) in lines.enumerated(){if let header=SkinConfiguration.header(line){if let start{return start..<i};if header==name{start=i}}}
  return start.map{$0..<lines.count}
 }
 static func caret(_ text:String,section:String,field:String)->Int {
  guard let range=range(text,section) else{return (text as NSString).length}
  let nl=newline(text);var offset=0
  for (i,line) in text.components(separatedBy:nl).enumerated(){
   if range.contains(i),let equal=line.firstIndex(of:"="),line[..<equal].trimmingCharacters(in:.whitespaces).uppercased()==field{return offset+(String(line[...equal]) as NSString).length}
   offset += (line as NSString).length+(nl as NSString).length
  }
  return (text as NSString).length
 }
 static func parameters(_ original:String,section:String,values:[String:String])throws->String {
  guard let s=SkinConfiguration.parse(original).first(where:{$0.name==section}),let template=AnimationCatalog.matching(s.values) else{throw AnimationEditError.invalid("此动效请在源码中编辑")}
  var next=original
  for field in template.fields {
   guard s.values[field.key] != nil || (template.id=="particle" && field.key=="TYPR") else{continue}
   let value=(field.fixed ? s.values[field.key] ?? field.value:values[field.key] ?? s.values[field.key] ?? field.value).trimmingCharacters(in:.whitespaces)
   if template.id=="color",["FROM","TO"].contains(field.key),value.range(of:"^(#|0x)?([0-9a-fA-F]{6}|[0-9a-fA-F]{8})$",options:.caseInsensitive)==nil{throw AnimationEditError.invalid("颜色须为 6 或 8 位十六进制")}
   next=try AnimationEdits.set(next,section:section,field:field.key,value:value)
   if template.id=="particle" && field.key=="TYPR"{next=try AnimationEdits.set(next,section:section,field:"TYPE",value:value)}
  }
  return next
 }
}
