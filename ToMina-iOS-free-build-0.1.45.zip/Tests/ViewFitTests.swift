import XCTest
import ZIPFoundation
@testable import ToMina

final class ViewFitTests: XCTestCase {
    let text="[PANEL]\nSIZE=200,100\nKEY_NUM=2\n[KEY1]\nVIEW_RECT=0,0,98,100\nCENTER=文字\nUP=F12\nHOLD=F72\n[KEY2]\nVIEW_RECT=102,0,98,100\nCENTER=F38\n"
    func folder() throws -> URL {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
        return root
    }
    func testJavaScriptCoreMatchesNodeFixtureResults() throws {
        for name in ["plain","atlas","inset","list"] {
            let file=try XCTUnwrap(Bundle(for:Self.self).url(forResource:name,withExtension:"json",subdirectory:"Fixtures/ViewFit"))
            let fixture=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:file)) as? [String:Any])
            let input=try XCTUnwrap(fixture["input"] as? [String:Any]), expected=try XCTUnwrap(fixture["expected"] as? [String:Any])
            let actual=try GlobalViewFit.evaluate(input)
            XCTAssertEqual(try JSONSerialization.data(withJSONObject:actual,options:.sortedKeys),try JSONSerialization.data(withJSONObject:expected,options:.sortedKeys))
        }
    }
    func testNativeFitPreservesEveryResourceByteAndIgnoresMissingPictures() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=root.appendingPathComponent("custom.ini")
        try (text+"[TIP1]\nFORE_STYLE=1\n").write(to:file,atomically:true,encoding:.utf8)
        let resources=["default.css":Data("[STYLE1]\nNM_IMG=missing,9\n".utf8),"broken.til":Data([0xff,0x00,0xfe]),"picture.png":Data([1,2,3,4,5])]
        for (name,bytes) in resources {try bytes.write(to:root.appendingPathComponent(name))}
        let result=try GlobalViewFit.run(root:root)
        XCTAssertEqual(result.changedFiles,1);XCTAssertFalse(result.report.contains("无法确定 · 保留原文件\ncustom.ini"))
        XCTAssertTrue(try String(contentsOf:file,encoding:.utf8).contains("VIEW_RECT=0,0,100,100"))
        for (name,bytes) in resources {XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent(name)),bytes)}
        XCTAssertFalse(FileManager.default.fileExists(atPath:root.appendingPathComponent("missing.png").path))
    }
    func testNativeWritesPreserveBOMEncodingActionsAndTouch() throws {
        for (encoding,bom) in [(String.Encoding.utf8,Data()),(.utf8,Data([0xef,0xbb,0xbf])),(.utf16LittleEndian,Data([0xff,0xfe])),(.utf16BigEndian,Data([0xfe,0xff])),(SkinConfiguration.gb,Data())] {
            let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
            let file=root.appendingPathComponent("any-language.ini"), original=bom+text.data(using:encoding)!
            try original.write(to:file)
            let report=try GlobalViewFit.run(root:root)
            XCTAssertEqual(report.changedFiles,1)
            let decoded=try GlobalViewFit.decode(Data(contentsOf:file))
            XCTAssertEqual(decoded.bom,bom);XCTAssertEqual(decoded.encoding,encoding)
            XCTAssertTrue(decoded.text.contains("TOUCH_RECT=0,0,98,100"))
            XCTAssertTrue(decoded.text.contains("VIEW_RECT=0,0,100,100"))
            XCTAssertTrue(decoded.text.contains("CENTER=文字\nUP=F12\nHOLD=F72"))
            XCTAssertEqual(try GlobalViewFit.run(root:root).changedFiles,0)
        }
    }
    func testConcurrentModificationRejectsEveryWrite() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let a=root.appendingPathComponent("a.ini"),b=root.appendingPathComponent("b.ini"),bytes=Data(text.utf8)
        try bytes.write(to:a);try bytes.write(to:b)
        let original=try GlobalViewFit.decode(bytes)
        try Data("changed externally".utf8).write(to:b)
        XCTAssertThrowsError(try GlobalViewFit.apply([["path":"a.ini","text":"new a"],["path":"b.ini","text":"new b"]],root:root,snapshot:["a.ini":original,"b.ini":original]))
        XCTAssertEqual(try Data(contentsOf:a),bytes)
        XCTAssertEqual(try String(contentsOf:b,encoding:.utf8),"changed externally")
    }
    func testNativePositionZeroPreservesCommasAndOtherFields() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=root.appendingPathComponent("candidate.cnd")
        let original="[ICON1]\r\nPOS_TYPE=7,3,46\r\nCENTER=F22\r\nVIEW_RECT=1,2,3,4\r\n"
        try original.write(to:file,atomically:true,encoding:.utf8)
        XCTAssertEqual(try GlobalViewFit.run(root:root,operation:"zeroPositionTypes").changedFiles,1)
        XCTAssertEqual(try String(contentsOf:file,encoding:.utf8),original.replacingOccurrences(of:"7,3,46",with:"0,0,0"))
        XCTAssertEqual(try GlobalViewFit.run(root:root,operation:"zeroPositionTypes").changedFiles,0)
    }
    func testWriteThatDoesNotReachDiskCannotReportSuccess() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=root.appendingPathComponent("a.ini"),bytes=Data(text.utf8),saved=try GlobalViewFit.decode(Data(text.utf8))
        try bytes.write(to:file)
        XCTAssertThrowsError(try GlobalViewFit.apply([["path":"a.ini","text":text.replacingOccurrences(of:"98,100",with:"100,100")]],root:root,snapshot:["a.ini":saved],write:{_,_ in}))
        XCTAssertEqual(try Data(contentsOf:file),bytes)
    }
    func testChangedInheritedDefaultsRejectEntireTransaction() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=root.appendingPathComponent("a.ini"),gen=root.appendingPathComponent("gen.ini"),bytes=Data(text.utf8),defaults=Data("[PANEL]\nSIZE=200,100".utf8)
        try bytes.write(to:file);try defaults.write(to:gen)
        let snapshots=["a.ini":try GlobalViewFit.decode(bytes),"gen.ini":try GlobalViewFit.decode(defaults)]
        try Data("[PANEL]\nSIZE=400,200".utf8).write(to:gen)
        XCTAssertThrowsError(try GlobalViewFit.apply([["path":"a.ini","text":text+"\n"]],root:root,snapshot:snapshots))
        XCTAssertEqual(try Data(contentsOf:file),bytes)
    }
    @MainActor func testInsetPanelSourceReloadAndVerifiedCoordinateProof() async throws {
        let fm=FileManager.default,base=try folder();defer{try? fm.removeItem(at:base)}
        let source=base.appendingPathComponent("skin");try fm.createDirectory(at:source,withIntermediateDirectories:true)
        let inset="[PANEL]\nSIZE=200,100\n[KEY1]\nVIEW_RECT=12,8,76,84\nCENTER=A\n[KEY2]\nVIEW_RECT=112,8,76,84\nCENTER=B\n"
        try inset.write(to:source.appendingPathComponent("custom.ini"),atomically:true,encoding:.utf8)
        let archive=base.appendingPathComponent("inset.bds");try fm.zipItem(at:source,to:archive,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(archive);let root=try XCTUnwrap(store.root);defer{try? fm.removeItem(at:root)}
        let revision=store.sourceDraft.revision;try await store.fitGlobalViews()
        XCTAssertGreaterThan(store.sourceDraft.revision,revision)
        XCTAssertTrue(store.text.contains("VIEW_RECT=0,0,100,100"));XCTAssertFalse(store.text.contains("VIEW_RECT=12,8,76,84"))
        XCTAssertTrue(store.viewFitReport.contains("已写入并重新读取校验 1"));XCTAssertTrue(store.viewFitReport.contains("12,8,76,84 → 0,0,100,100"))
        XCTAssertEqual(store.keys.first(where:{$0.name=="KEY1"})?.rect,CGRect(x:0,y:0,width:100,height:100))
        try store.openViewFitSource();XCTAssertTrue(store.text.contains("VIEW_RECT=0,0,100,100"))
        let out=try store.export();defer{try? fm.removeItem(at:out.deletingLastPathComponent())}
        let reopened=try OriginalSkinDocument.unpack(out);defer{try? fm.removeItem(at:reopened)}
        XCTAssertTrue(try String(contentsOf:reopened.appendingPathComponent("custom.ini"),encoding:.utf8).contains("VIEW_RECT=0,0,100,100"))
    }
    func testUnsafeResultsAndSymlinksCannotWriteOutsideRoot() throws {
        let root=try folder(),outside=try folder();defer{try? FileManager.default.removeItem(at:root);try? FileManager.default.removeItem(at:outside)}
        let file=outside.appendingPathComponent("protected.ini");try Data(text.utf8).write(to:file)
        try FileManager.default.createSymbolicLink(at:root.appendingPathComponent("link.ini"),withDestinationURL:file)
        XCTAssertThrowsError(try GlobalViewFit.child("../escape.ini",root:root))
        XCTAssertThrowsError(try GlobalViewFit.child("link.ini",root:root))
        let result=try GlobalViewFit.run(root:root);XCTAssertEqual(result.changedFiles,0)
        XCTAssertEqual(try String(contentsOf:file,encoding:.utf8),text)
    }
    @MainActor func testListFitSourceGuidesAndExportUseSameGeometry() async throws {
        let fm=FileManager.default,base=try folder();defer{try? fm.removeItem(at:base)}
        let input=base.appendingPathComponent("input");try fm.createDirectory(at:input,withIntermediateDirectories:true)
        let config="[PANEL]\nSIZE=200,100\n[LIST]\nPOS=8,6\nCELL_SIZE=36,22\nLIST_NUM=4\nPADDING=2,1,2,1\nNAMES=甲 乙\nVALUES=a b\n[KEY1]\nVIEW_RECT=52,6,140,88\nCENTER=F38\n"
        try config.write(to:input.appendingPathComponent("custom.ini"),atomically:true,encoding:.utf8)
        let archive=base.appendingPathComponent("list.bds");try fm.zipItem(at:input,to:archive,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(archive);let root=try XCTUnwrap(store.root);defer{try? fm.removeItem(at:root)}
        try await store.fitGlobalViews()
        XCTAssertTrue(store.text.contains("POS=0,0"));XCTAssertTrue(store.text.contains("CELL_SIZE=48,25"));XCTAssertTrue(store.text.contains("VALUES=a b"))
        XCTAssertTrue(store.viewFitReport.contains("CELL_SIZE：36,22 → 48,25"))
        let regions=PreviewGuides.regions(store),list=try XCTUnwrap(regions.first{$0.name=="LIST"}),key=try XCTUnwrap(regions.first{$0.name=="KEY1"})
        XCTAssertEqual(list.rect,CGRect(x:0,y:0,width:48,height:100));XCTAssertEqual(list.rect.maxX,key.rect.minX)
        let cells=regions.filter{$0.name.hasPrefix("LIST/")};XCTAssertEqual(cells.count,4)
        for i in 0..<4 {XCTAssertEqual(cells[i].rect,CGRect(x:0,y:CGFloat(i*25),width:48,height:25))}
        let guide=try PreviewGuides.export(store);defer{try? fm.removeItem(at:guide.deletingLastPathComponent())};XCTAssertGreaterThan(try Data(contentsOf:guide).count,100)
        let exported=try store.export();defer{try? fm.removeItem(at:exported.deletingLastPathComponent())}
        let reopened=try OriginalSkinDocument.unpack(exported);defer{try? fm.removeItem(at:reopened)}
        let saved=try String(contentsOf:reopened.appendingPathComponent("custom.ini"),encoding:.utf8)
        XCTAssertEqual(saved,store.text);XCTAssertEqual(try GlobalViewFit.run(root:reopened).changedFiles,0)
    }
    @MainActor func testListOnlyPanelIncludesOuterAndEachCellGuide() async throws {
        let fm=FileManager.default,base=try folder();defer{try? fm.removeItem(at:base)}
        let input=base.appendingPathComponent("input");try fm.createDirectory(at:input,withIntermediateDirectories:true)
        try "[PANEL]\nSIZE=200,100\n[LIST7]\nPOS=8,8\nCELL_SIZE=46,84\nLIST_NUM=4\nLIST_ORDER=1\nPADDING=0\n".write(to:input.appendingPathComponent("list.ini"),atomically:true,encoding:.utf8)
        let archive=base.appendingPathComponent("list-only.bds");try fm.zipItem(at:input,to:archive,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(archive);let root=try XCTUnwrap(store.root);defer{try? fm.removeItem(at:root)}
        try await store.fitGlobalViews();XCTAssertTrue(store.text.contains("CELL_SIZE=50,100"))
        let regions=PreviewGuides.regions(store);XCTAssertEqual(regions.map{$0.name},["LIST7","LIST7/1","LIST7/2","LIST7/3","LIST7/4"])
        XCTAssertEqual(regions.last?.rect,CGRect(x:150,y:0,width:50,height:100))
    }
    @MainActor func testCandidateListGuideUsesCandidateCoordinates() async throws {
        let fm=FileManager.default,base=try folder();defer{try? fm.removeItem(at:base)}
        let input=base.appendingPathComponent("input");try fm.createDirectory(at:input,withIntermediateDirectories:true)
        try "[PANEL]\nSIZE=200,100\n[CAND]\nLAYOUT_NAME=bar\nVIEW_RECT=0,0,200,40\n[KEY1]\nVIEW_RECT=0,0,200,100\nCENTER=a\n".write(to:input.appendingPathComponent("main.ini"),atomically:true,encoding:.utf8)
        try "[CAND]\nSIZE=200,40\n[LIST1]\nPOS=0,0\nCELL_SIZE=50,40\nLIST_NUM=4\nLIST_ORDER=1\nPADDING=0\nNAMES=a b c d\n".write(to:input.appendingPathComponent("bar.cnd"),atomically:true,encoding:.utf8)
        let archive=base.appendingPathComponent("candidate.bds");try fm.zipItem(at:input,to:archive,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(archive);let root=try XCTUnwrap(store.root);defer{try? fm.removeItem(at:root)}
        try store.open(root.appendingPathComponent("main.ini"))
        let regions=PreviewGuides.regions(store)
        XCTAssertEqual(regions.first{$0.name=="CAND/LIST1"}?.rect,CGRect(x:0,y:-40,width:200,height:40))
        XCTAssertEqual(regions.filter{$0.name.hasPrefix("CAND/LIST1/")}.count,4)
        XCTAssertEqual(regions.last{$0.name=="CAND/LIST1/4"}?.rect,CGRect(x:150,y:-40,width:50,height:40))
    }
    @MainActor func testPreviewCurrentDraftAndExportReopenShareAllPanelEdits() async throws {
        let fm=FileManager.default,base=try folder();defer{try? fm.removeItem(at:base)}
        let source=base.appendingPathComponent("input"),port=source.appendingPathComponent("port"),dark=source.appendingPathComponent("dark/land")
        try fm.createDirectory(at:port,withIntermediateDirectories:true);try fm.createDirectory(at:dark,withIntermediateDirectories:true)
        try text.write(to:port.appendingPathComponent("arbitrary.ini"),atomically:true,encoding:.utf8)
        try text.write(to:dark.appendingPathComponent("extra-symbols.ini"),atomically:true,encoding:.utf8)
        let archive=base.appendingPathComponent("global.bds");try fm.zipItem(at:source,to:archive,shouldKeepParent:false)
        let original=try Data(contentsOf:archive),store=SkinStore();await store.openArchive(archive)
        let root=try XCTUnwrap(store.root);defer{try? fm.removeItem(at:root)}
        try store.open(root.appendingPathComponent("port/arbitrary.ini"));store.text += "\n; latest draft\n"
        try await store.fitGlobalViews()
        XCTAssertTrue(store.text.contains("latest draft"));XCTAssertTrue(store.text.contains("VIEW_RECT=0,0,100,100"))
        XCTAssertEqual(store.keys.first(where:{$0.name=="KEY1"})?.rect.width,100)
        let exported=try store.export();defer{try? fm.removeItem(at:exported.deletingLastPathComponent())}
        let reopened=try OriginalSkinDocument.unpack(exported);defer{try? fm.removeItem(at:reopened)}
        for name in ["port/arbitrary.ini","dark/land/extra-symbols.ini"] {
            let saved=try String(contentsOf:reopened.appendingPathComponent(name),encoding:.utf8)
            XCTAssertTrue(saved.contains("VIEW_RECT=0,0,100,100"));XCTAssertTrue(saved.contains("TOUCH_RECT=102,0,98,100"))
        }
        XCTAssertEqual(try Data(contentsOf:archive),original)
    }
}
