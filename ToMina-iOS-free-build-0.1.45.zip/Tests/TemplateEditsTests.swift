import XCTest
import UIKit
import ZIPFoundation
@testable import ToMina

final class TemplateEditsTests:XCTestCase {
    func testAllTemplatesDefaultsAndSparseAppend()throws {
        let before="; 保留 🎨\r\n[GLOBAL]\r\nANIM_NUM=422\r\nOTHER=keep\r\n[ANIM002]\r\nTYPE=1\r\nTO=25\r\n"
        for template in AnimationCatalog.all {
            let edit=try TemplateEdits.animation(before,template:template.id,occupied:["19"])
            XCTAssertEqual(edit.section,"ANIM20");XCTAssertTrue(edit.text.hasPrefix(before))
            let section=try XCTUnwrap(SkinConfiguration.parse(edit.text).first{$0.name=="ANIM20"})
            for (field,value) in section.values where !["TYPE","CATEGORY","REPEAT_CNT"].contains(field){XCTAssertNotNil(value.range(of:"^0+(,0+)*$",options:.regularExpression),field)}
        }
        let edit=try TemplateEdits.animation(nil,template:"rotate3d")
        XCTAssertEqual(edit.section,"ANIM1");XCTAssertTrue(edit.text.contains("ANIM_NUM=422"))
        XCTAssertTrue(edit.text.contains("FROM=0,0,0"));XCTAssertTrue(edit.text.contains("PIVOT=0,0"))
        let merged=try AnimationSourceEdits.merge(edit.text,draft:"[ANIM2]\nTYPE=0\n",names:["ANIM2"],existing:[])
        XCTAssertTrue(merged.contains("ANIM_NUM=422"))
    }
    func testColorValidationFixedTypeAndParticleAliases()throws {
        let color=try TemplateEdits.animation(nil,template:"color").text
        let next=try TemplateEdits.parameters(color,section:"ANIM1",values:["FROM":"80ff00ff","TYPE":"1"])
        XCTAssertTrue(next.contains("FROM=80ff00ff"));XCTAssertTrue(next.contains("TYPE=6"))
        XCTAssertThrowsError(try TemplateEdits.parameters(color,section:"ANIM1",values:["TO":"z12345"]))
        XCTAssertThrowsError(try TemplateEdits.parameters(color,section:"ANIM1",values:["DURATION":"1\n[ANIM9]"]))
        let particle=try TemplateEdits.animation(nil,template:"particle").text
        let p=try TemplateEdits.parameters(particle,section:"ANIM1",values:["TYPR":"1"])
        for line in ["TYPE=1","TYPR=1","CATEGORY=3","REPEAT_CNT=inf","EMIT_REGION=0,0,0,0","LIFE=0,0"]{XCTAssertTrue(p.contains(line),line)}
    }
    func testEventCreationPreservesExistingEvents()throws {
        let event=try TemplateEdits.event(nil)
        XCTAssertTrue(event.contains("EVENT_NUM=1\n\n[EVENT1]\nNAME=IDLE\nIDLE_TIME=422"))
        XCTAssertEqual(try TemplateEdits.event(event),event)
        let occupied="[EVENT1]\r\nNAME=PRESS\r\nCUSTOM=keep\r\n"
        let next=try TemplateEdits.event(occupied)
        XCTAssertTrue(next.contains(occupied));XCTAssertTrue(next.contains("[EVENT2]"))
        let idle="[EVENT9]\nNAME=IDLE\nIDLE_TIME=250\n"
        XCTAssertEqual(try TemplateEdits.event(idle),idle)
    }
    func testSourceInsertionIsAtSectionEndAndDoesNotBlankExistingValues()throws {
        let before="; 🎨\r\n[KEY1]\r\nCENTER=a\r\nHOLD=b\r\n\r\n[KEY2]\r\nCENTER=c\r\n"
        let result=try TemplateEdits.insert(before,section:"KEY1",field:"SOUND_STYLE")
        XCTAssertTrue(result.text.contains("HOLD=b\r\nSOUND_STYLE=\r\n\r\n[KEY2]"))
        XCTAssertTrue((result.text as NSString).substring(to:result.caret).hasSuffix("SOUND_STYLE="))
        let filled=result.text.replacingOccurrences(of:"SOUND_STYLE=",with:"SOUND_STYLE=42")
        XCTAssertEqual(try TemplateEdits.insert(filled,section:"KEY1",field:"SOUND_STYLE").text,filled)
        let css=try TemplateEdits.insert("[STYLE003]\nNM_IMG=keep,1\n[STYLE9]\nPRESS_ANIM=6\n",section:"",field:"EVENT1",newStyle:true)
        XCTAssertEqual(css.section,"STYLE10");XCTAssertTrue(css.text.contains("NM_IMG=keep,1"));XCTAssertTrue(css.text.contains("PRESS_ANIM=6"))
    }
    @MainActor private func fixture()async throws->(SkinStore,URL) {
        let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let root=folder.appendingPathComponent("skin"),res=root.appendingPathComponent("port/res")
        try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        try "[PANEL]\nSIZE=240,120\nKEY_NUM=1\n[KEY1]\nVIEW_RECT=0,0,120,80\nCENTER=q\nBACK_STYLE=1\n".write(to:root.appendingPathComponent("port/py_26.ini"),atomically:true,encoding:.utf8)
        try "[STYLE1]\nNM_IMG=art,1\n[STYLE9]\nPRESS_ANIM=7\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try "[IMG1]\nSOURCE_RECT=0,0,16,16\n".write(to:res.appendingPathComponent("art.til"),atomically:true,encoding:.utf8)
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let image=UIGraphicsImageRenderer(size:CGSize(width:16,height:16),format:format).image{ctx in UIColor.red.setFill();ctx.fill(CGRect(x:0,y:0,width:16,height:16))}
        try XCTUnwrap(image.pngData()).write(to:res.appendingPathComponent("art.png"))
        let archive=folder.appendingPathComponent("templates.bds");try FileManager.default.zipItem(at:root,to:archive,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(archive);XCTAssertNil(store.error)
        return (store,folder)
    }
    @MainActor func testStoreCreatesFilesEditsParametersAndExportsSameSourceWithoutTouchingImages()async throws {
        let (store,folder)=try await fixture()
        defer{store.finishAnimationEditing();if let root=store.root{try? FileManager.default.removeItem(at:root)};try? FileManager.default.removeItem(at:folder)}
        let root=try XCTUnwrap(store.root),layout=try XCTUnwrap(store.current),css=try XCTUnwrap(store.renderer.styleFile)
        let originalLayout=try Data(contentsOf:layout),originalCSS=try Data(contentsOf:css),res=css.deletingLastPathComponent()
        let imageBefore=try Data(contentsOf:res.appendingPathComponent("art.png")),tileBefore=try Data(contentsOf:res.appendingPathComponent("art.til"))
        let first=try store.addAnimationTemplate("color")
        XCTAssertEqual(first,"1");XCTAssertTrue(store.animationText.contains("[ANIM1]"));XCTAssertTrue(store.animationText.contains("FROM=000000"))
        try store.editTemplateParameters(first,values:["FROM":"112233","TO":"80ABCDEF","DURATION":"300"],key:"",floating:false)
        XCTAssertTrue(store.animationText.contains("TO=80ABCDEF"))
        let second=try store.addAnimationTemplate("particle")
        XCTAssertEqual(second,"2");XCTAssertTrue(store.animationText.contains("[ANIM2]"));XCTAssertEqual(store.renderer.floatingChoice,"2")
        let anim=try XCTUnwrap(store.renderer.animationFiles[first]);XCTAssertEqual(anim,res.appendingPathComponent("anim.ini"))
        XCTAssertTrue(try String(contentsOf:anim,encoding:.utf8).contains("ANIM_NUM=422"))
        let event=res.appendingPathComponent("event.ini");XCTAssertTrue(try String(contentsOf:event,encoding:.utf8).contains("IDLE_TIME=422"))
        XCTAssertEqual(try Data(contentsOf:layout),originalLayout);XCTAssertEqual(try Data(contentsOf:css),originalCSS)
        let exported=try store.export(),reopen=folder.appendingPathComponent("reopened")
        defer{try? FileManager.default.removeItem(at:exported.deletingLastPathComponent())}
        try FileManager.default.unzipItem(at:exported,to:reopen)
        let exportedRes=reopen.appendingPathComponent("port/res")
        XCTAssertEqual(try Data(contentsOf:exportedRes.appendingPathComponent("anim.ini")),try Data(contentsOf:anim))
        XCTAssertEqual(try Data(contentsOf:exportedRes.appendingPathComponent("art.png")),imageBefore)
        XCTAssertEqual(try Data(contentsOf:exportedRes.appendingPathComponent("art.til")),tileBefore)
        try store.open(anim);XCTAssertTrue(store.text.contains("TO=80ABCDEF"));XCTAssertTrue(store.text.contains("[ANIM2]"))
        XCTAssertTrue(root.path.count>0)
    }
    @MainActor func testStoreSourceFieldInsertionAndExistingEventAreSaved()async throws {
        let (store,folder)=try await fixture()
        defer{store.finishSourceEditing();if let root=store.root{try? FileManager.default.removeItem(at:root)};try? FileManager.default.removeItem(at:folder)}
        let layout=try XCTUnwrap(store.current),css=try XCTUnwrap(store.renderer.styleFile)
        let field=try store.insertSourceField(section:"KEY1",field:"BACK_ANIM_STYLE")
        XCTAssertEqual(store.sourceDraft.requestedSelection?.location,field.caret)
        XCTAssertTrue(try String(contentsOf:layout,encoding:.utf8).contains("BACK_ANIM_STYLE="))
        try store.open(css);let style=try store.insertSourceField(section:"",field:"PANEL_ACG_SHOW_SOUND_PATH",newStyle:true)
        XCTAssertEqual(style.section,"STYLE10");XCTAssertTrue(store.text.contains("NM_IMG=art,1"))
        XCTAssertTrue(try String(contentsOf:css,encoding:.utf8).contains("PANEL_ACG_SHOW_SOUND_PATH="))
    }
}
