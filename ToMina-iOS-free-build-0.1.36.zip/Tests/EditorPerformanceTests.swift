import XCTest
import SwiftUI
import UIKit
import Combine
import ZIPFoundation
@testable import ToMina

final class EditorPerformanceTests: XCTestCase {
    @MainActor private func fixture(large: Bool = false) async throws -> (SkinStore, URL) {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let skin = folder.appendingPathComponent("skin"), res = skin.appendingPathComponent("port/res")
        try FileManager.default.createDirectory(at: res, withIntermediateDirectories: true)
        let layout = "[PANEL]\nSIZE=240,120\nKEY_NUM=1\n[KEY1]\nVIEW_RECT=0,0,120,80\nCENTER=q\nBACK_STYLE=1\nANIM_STYLE=2\n" + (large ? String(repeating: "; unchanged large document content 0123456789\n", count: 18000) : "")
        try layout.write(to: skin.appendingPathComponent("port/py_26.ini"), atomically: true, encoding: .utf8)
        try "[STYLE1]\nNM_IMG=art,1\n[STYLE2]\nPRESS_ANIM=1\n".write(to: res.appendingPathComponent("default.css"), atomically: true, encoding: .utf8)
        try "[IMG1]\nSOURCE_RECT=0,0,16,16\n".write(to: res.appendingPathComponent("art.til"), atomically: true, encoding: .utf8)
        try "[ANIM1]\nTYPE=4\nFROM=100,100\nTO=85,85\nDURATION=180\nREPEAT_CNT=1\n".write(to: res.appendingPathComponent("anim.ini"), atomically: true, encoding: .utf8)
        let format = UIGraphicsImageRendererFormat(); format.scale = 1
        let image = UIGraphicsImageRenderer(size: CGSize(width: 32,height: 16),format: format).image { ctx in
            UIColor.red.setFill(); ctx.fill(CGRect(x: 0,y: 0,width: 16,height: 16))
            UIColor.blue.setFill(); ctx.fill(CGRect(x: 16,y: 0,width: 16,height: 16))
        }
        try XCTUnwrap(image.pngData()).write(to: res.appendingPathComponent("art.png"))
        let archive = folder.appendingPathComponent("original.bds")
        try FileManager.default.zipItem(at: skin,to: archive,shouldKeepParent: false)
        let store = SkinStore(); await store.openArchive(archive); XCTAssertNil(store.error)
        return (store,folder)
    }
    @MainActor private func cleanup(_ store: SkinStore, _ folder: URL) {
        store.finishSourceEditing(); store.finishAnimationEditing()
        if let root = store.root { try? FileManager.default.removeItem(at: root) }
        try? FileManager.default.removeItem(at: folder)
    }
    @MainActor func testLargeTypingBurstDoesNotWriteParseOrPublishEachCharacter() async throws {
        let (store,folder) = try await fixture(large: true); defer { cleanup(store,folder) }
        let file = try XCTUnwrap(store.current), original = try Data(contentsOf: file), initial = store.text
        let revision = store.sourceDraft.revision, previews = store.editorPreviewCount
        var publications = 0
        let observer = store.objectWillChange.sink { publications += 1 }; defer { observer.cancel() }
        let start = Date()
        for index in 0..<80 {
            let next = initial.replacingOccurrences(of: "SIZE=240,120",with: "SIZE=240,\(200+index)") + "\n; edit \(index)"
            XCTAssertTrue(store.editSource(next))
        }
        let seconds = Date().timeIntervalSince(start)
        XCTAssertEqual(publications,0); XCTAssertEqual(store.sourceDraft.revision,revision)
        XCTAssertEqual(store.editorPreviewCount,previews); XCTAssertEqual(try Data(contentsOf: file),original)
        XCTAssertLessThan(seconds,1.0,"Keystrokes still do expensive synchronous work")
        try await Task.sleep(for: .milliseconds(750))
        XCTAssertEqual(store.editorPreviewCount,previews+1); XCTAssertTrue(store.editorParseWasBackground)
        XCTAssertEqual(store.panel.height,279); XCTAssertEqual(store.parsedText.first?.values["SIZE"],"240,279")
        XCTAssertEqual(try Data(contentsOf: file),original)
        store.finishSourceEditing(); XCTAssertEqual(try String(contentsOf: file,encoding: .utf8),store.text)
        store.history(redo: false); XCTAssertEqual(store.text,initial)
        store.history(redo: true); XCTAssertTrue(store.text.hasSuffix("; edit 79"))
        print("EDITOR_TYPING: \(original.count) bytes, 80 edits, seconds=\(seconds), perKeystrokeWrites=0, perKeystrokePublishes=0, previewPasses=1, parseOffMain=true")
    }
    @MainActor func testSaveAndFileSwitchFlushLatestDraftAndCancelStalePreview() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        let file = try XCTUnwrap(store.current), original = store.text
        let next = original.replacingOccurrences(of: "SIZE=240,120",with: "SIZE=320,160")
        _ = store.editSource(next)
        try await store.saveSession(EditorViewState(),recordFile: folder.appendingPathComponent("record.json"))
        XCTAssertEqual(store.panel,CGSize(width:320,height:160))
        let unpacked = try OriginalSkinDocument.unpack(folder.appendingPathComponent("original.bds"))
        defer { try? FileManager.default.removeItem(at: unpacked) }
        XCTAssertEqual(try String(contentsOf: unpacked.appendingPathComponent("port/py_26.ini"),encoding: .utf8),next)
        _ = store.editSource(next + "\n; final draft")
        let css = try XCTUnwrap(store.files.first { $0.lastPathComponent == "default.css" })
        try store.open(css)
        XCTAssertTrue(try String(contentsOf: file,encoding: .utf8).hasSuffix("; final draft"))
        let currentText = store.text
        try await Task.sleep(for: .milliseconds(550))
        XCTAssertEqual(store.current,css); XCTAssertEqual(store.text,currentText)
        XCTAssertEqual(store.panel,CGSize(width:320,height:160))
        XCTAssertFalse(store.canUndo)
    }
    @MainActor func testParameterDraftUsesAllCharactersAndUndoKeepsWholeBurst() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        let before = store.text
        for value in ["9","90","900,","900,5","900,50","900,500"] {
            store.editParameter(section: "PANEL",key: "SIZE",value: value)
        }
        store.finishSourceEditing()
        XCTAssertEqual(store.panel,CGSize(width:900,height:500))
        XCTAssertEqual(store.parsedText.first?.values["SIZE"],"900,500")
        store.history(redo: false); XCTAssertEqual(store.text,before)
    }
    @MainActor func testCompositionKeepsDraftWithoutParsingUntilCommitted() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        let initial = store.text, previews = store.editorPreviewCount
        _ = store.editSource(initial + "\n; 中",composing: true)
        _ = store.editSource(initial + "\n; 中文",composing: true)
        try await Task.sleep(for: .milliseconds(450))
        XCTAssertEqual(store.editorPreviewCount,previews)
        _ = store.editSource(store.text,composing: false)
        try await Task.sleep(for: .milliseconds(550))
        XCTAssertEqual(store.editorPreviewCount,previews+1)
        store.finishSourceEditing()
        XCTAssertTrue(try String(contentsOf: XCTUnwrap(store.current),encoding: .utf8).hasSuffix("; 中文"))
    }
    @MainActor func testAnimationEditingCoalescesAndFlushesBeforeSwitching() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        store.loadAnimationSource("KEY1")
        let initial = store.animationText, previews = store.editorPreviewCount
        let file = try XCTUnwrap(store.files.first { $0.lastPathComponent == "anim.ini" })
        for value in 200..<250 { _ = store.editAnimationSource(initial.replacingOccurrences(of: "DURATION=180",with: "DURATION=\(value)")) }
        XCTAssertEqual(store.editorPreviewCount,previews)
        XCTAssertTrue(try String(contentsOf: file,encoding: .utf8).contains("DURATION=180"))
        try await Task.sleep(for: .milliseconds(550))
        XCTAssertEqual(store.renderer.timeline.definitions["1"]?["DURATION"],"249")
        XCTAssertEqual(store.editorPreviewCount,previews+1)
        _ = store.editAnimationSource(initial.replacingOccurrences(of: "DURATION=180",with: "DURATION=350"))
        try store.open(file)
        XCTAssertTrue(store.text.contains("DURATION=350"))
        try await Task.sleep(for: .milliseconds(550))
        XCTAssertTrue(store.text.contains("DURATION=350"))
    }
    @MainActor func testAppendedAnimationGroupWritesAnimINIAndOriginalArchive() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        store.loadAnimationSource("KEY1")
        let file = try XCTUnwrap(store.files.first { $0.lastPathComponent == "anim.ini" })
        let css = try XCTUnwrap(store.renderer.styleFile), cssBefore = try Data(contentsOf:css)
        let initial = store.animationText
        let children = (20...23).map { "[ANIM\($0)]\nTYPE=4\nFROM=100,100\nTO=120,120\nDURATION=250\n" }.joined(separator:"\n")
        _ = store.editAnimationSource(initial + "\nBUILD_NUM=2\nBUILD_LIST=18,19\n\n[ANIM18]\nTYPE=4\nDURATION=250\n\n[ANIM19]\nBUILD_NUM=4\nBUILD_LIST=20,21,22,23\n\n" + children)
        XCTAssertTrue(store.saveAnimationSource(),store.error ?? "")
        XCTAssertNil(store.error)
        let written = try String(contentsOf:file,encoding:.utf8)
        XCTAssertTrue(written.contains("ANIM_NUM=7"))
        for number in [1,18,19,20,21,22,23] {
            XCTAssertEqual(SkinConfiguration.parse(written).filter { $0.name == "ANIM\(number)" }.count,1)
            XCTAssertEqual(store.renderer.animationFiles[String(number)],file)
        }
        XCTAssertEqual(try Data(contentsOf:css),cssBefore)
        store.loadAnimationSource("KEY1")
        XCTAssertEqual(Set(SkinConfiguration.parse(store.animationText).map(\.name)),Set([1,18,19,20,21,22,23].map { "ANIM\($0)" }))
        _ = store.editAnimationSource(store.animationText.replacingOccurrences(of:"DURATION=250",with:"DURATION=300"))
        XCTAssertTrue(store.saveAnimationSource(),store.error ?? "")
        try await store.saveSession(EditorViewState(),recordFile:folder.appendingPathComponent("record.json"))
        let unpacked = try OriginalSkinDocument.unpack(folder.appendingPathComponent("original.bds"))
        defer { try? FileManager.default.removeItem(at:unpacked) }
        let saved = try String(contentsOf:unpacked.appendingPathComponent("port/res/anim.ini"),encoding:.utf8)
        XCTAssertTrue(saved.contains("[ANIM23]")); XCTAssertTrue(saved.contains("ANIM_NUM=7"))
        XCTAssertTrue(saved.contains("DURATION=300")); XCTAssertFalse(saved.contains("DURATION=250"))
    }
    @MainActor func testNewAnimationPreviewCanBeRemovedBeforeSavingWithoutDiskWrites() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        store.loadAnimationSource("KEY1")
        let initial = store.animationText, file = try XCTUnwrap(store.renderer.animationFiles["1"])
        let original = try Data(contentsOf:file)
        _ = store.editAnimationSource(initial + "\nBUILD_LIST=18\n\n[ANIM18]\nTYPE=4\nDURATION=250\n")
        try await Task.sleep(for:.milliseconds(550))
        XCTAssertEqual(store.renderer.timeline.definitions["18"]?["DURATION"],"250")
        XCTAssertEqual(store.renderer.animationFiles["18"],file)
        XCTAssertEqual(try Data(contentsOf:file),original)
        _ = store.editAnimationSource(initial)
        try await Task.sleep(for:.milliseconds(550))
        XCTAssertNil(store.renderer.timeline.definitions["18"])
        XCTAssertNil(store.renderer.animationFiles["18"])
        XCTAssertNil(store.renderer.timeline.definitions["1"]?["BUILD_LIST"])
        XCTAssertEqual(try Data(contentsOf:file),original)
        // Save after a live preview must not mistake its own new ID for a collision.
        _ = store.editAnimationSource(initial + "\n\n[ANIM18]\nTYPE=4\nDURATION=250\n")
        try await Task.sleep(for:.milliseconds(550))
        XCTAssertTrue(store.saveAnimationSource(),store.error ?? "")
        XCTAssertTrue(try String(contentsOf:file,encoding:.utf8).contains("[ANIM18]"))
    }
    @MainActor func testDuplicateAndMissingOriginalAnimationKeepDraftAndFileIntact() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        store.loadAnimationSource("KEY1")
        let initial=store.animationText,file=try XCTUnwrap(store.renderer.animationFiles["1"])
        let original=try Data(contentsOf:file)
        for (draft,message) in [(initial+"\n[ANIM1]\nTYPE=2\n","编号重复"),("[ANIM18]\nTYPE=4\n","原有 [ANIM1]")] {
            _ = store.editAnimationSource(draft)
            XCTAssertFalse(store.saveAnimationSource())
            XCTAssertTrue(store.error?.contains(message) == true,store.error ?? "")
            XCTAssertEqual(store.animationText,draft)
            XCTAssertEqual(try Data(contentsOf:file),original)
        }
        store.animationText=initial;store.error=nil
    }
    @MainActor func testNewAnimationCannotOverwriteUnloadedDefinition() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        let file=try XCTUnwrap(store.renderer.animationFiles["1"])
        let extra=try String(contentsOf:file,encoding:.utf8)+"\n[ANIM9]\nTYPE=3\nDURATION=900\n"
        try extra.write(to:file,atomically:true,encoding:.utf8);store.rescan();store.loadAnimationSource("KEY1")
        let initial=store.animationText
        XCTAssertFalse(initial.contains("ANIM9"))
        _ = store.editAnimationSource(initial+"\n[ANIM9]\nTYPE=4\nDURATION=250\n")
        XCTAssertFalse(store.saveAnimationSource())
        XCTAssertTrue(store.error?.contains("[ANIM9] 已存在") == true)
        XCTAssertEqual(try String(contentsOf:file,encoding:.utf8),extra)
        store.animationText=initial;store.error=nil
    }
    @MainActor func testNewDefinitionsFromEmptyAnimationSelectionUseAnimINI() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        let file=try XCTUnwrap(store.renderer.animationFiles["1"]),layout=try XCTUnwrap(store.current)
        let layoutBefore=try Data(contentsOf:layout)
        store.loadAnimationSource("");XCTAssertEqual(store.animationText,"")
        _ = store.editAnimationSource("[ANIM2]\nTYPE=4\nDURATION=250\n")
        XCTAssertTrue(store.saveAnimationSource(),store.error ?? "")
        let written=try String(contentsOf:file,encoding:.utf8)
        XCTAssertTrue(written.contains("[ANIM1]"));XCTAssertTrue(written.contains("[ANIM2]"))
        XCTAssertTrue(written.contains("ANIM_NUM=2"))
        XCTAssertEqual(try Data(contentsOf:layout),layoutBefore)
    }
    @MainActor func testAnimationBlocksKeepSourceFilesAndAppendToPrimaryFile() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        let primary=try XCTUnwrap(store.renderer.animationFiles["1"])
        let secondary=primary.deletingLastPathComponent().appendingPathComponent("secondary.anim")
        let first=try String(contentsOf:primary,encoding:.utf8)+"BUILD_LIST=2\n"
        try first.write(to:primary,atomically:true,encoding:.utf8)
        try "[GLOBAL]\nANIM_NUM=1\n[ANIM2]\nTYPE=4\nDURATION=300\n".write(to:secondary,atomically:true,encoding:.utf8)
        store.rescan();store.loadAnimationSource("KEY1")
        XCTAssertTrue(store.animationText.contains("[ANIM2]"))
        _ = store.editAnimationSource(store.animationText.replacingOccurrences(of:"DURATION=300",with:"DURATION=400")+"\n[ANIM3]\nTYPE=2\nDURATION=100\n")
        XCTAssertTrue(store.saveAnimationSource(),store.error ?? "")
        let primaryText=try String(contentsOf:primary,encoding:.utf8),secondaryText=try String(contentsOf:secondary,encoding:.utf8)
        XCTAssertTrue(primaryText.contains("[ANIM3]"));XCTAssertFalse(primaryText.contains("[ANIM2]"))
        XCTAssertTrue(primaryText.contains("ANIM_NUM=2"))
        XCTAssertTrue(secondaryText.contains("DURATION=400"));XCTAssertFalse(secondaryText.contains("[ANIM3]"))
        XCTAssertTrue(secondaryText.contains("ANIM_NUM=1"))
    }
    func testAnimationSourceValidationRejectsIncompleteHeadersAndNumericAliases() throws {
        for draft in ["[ANIM1]\nTYPE=4\n[ANIM", "[ANIM1]\n[STYLE2]\n", "[ANIM1]\n[ANIM01]\n", "TYPE=4\n[ANIM1]\n"] {
            XCTAssertThrowsError(try AnimationSourceEdits.validate(draft,expected:["ANIM1"],occupied:["1"]))
        }
        XCTAssertNoThrow(try AnimationSourceEdits.validate("[anim1]\nTYPE=4\n[ANIM18] ; extra\nTYPE=2\n",expected:["ANIM1"],occupied:["1"]))
    }
    func testAnimationSourceMergePreservesCRLFAndUneditedSections() throws {
        let original="; original\r\n[GLOBAL]\r\nANIM_NUM=2\r\nOTHER=keep\r\n[ANIM1]\r\nTYPE=4\r\n[ANIM9]\r\nTYPE=2\r\n; preserve\r\n[EXTRA]\r\nVALUE=unchanged\r\n"
        let result=try AnimationSourceEdits.merge(original,draft:"[ANIM1]\nTYPE=3\n\n[anim18] ; added\nTYPE=4\n",names:["ANIM1","ANIM18"],existing:["ANIM1"])
        XCTAssertTrue(result.contains("ANIM_NUM=3\r\nOTHER=keep"))
        XCTAssertTrue(result.contains("[ANIM9]\r\nTYPE=2\r\n; preserve\r\n[EXTRA]\r\nVALUE=unchanged\r\n"))
        XCTAssertTrue(result.contains("[anim18] ; added\r\nTYPE=4\r\n"))
        XCTAssertFalse(result.replacingOccurrences(of:"\r\n",with:"").contains("\n"))
    }
    @MainActor func testTextPreviewReusesPixelsAndResourceReplacementInvalidatesThem() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        let file = try XCTUnwrap(store.files.first { $0.lastPathComponent == "art.png" })
        let image = try XCTUnwrap(store.renderer.imageCache.image(file))
        let piece = try XCTUnwrap(store.renderer.imageCache.crop(image,rect:CGRect(x:0,y:0,width:16,height:16)))
        for height in [130,140,150] {
            _ = store.editSource(store.text.replacingOccurrences(of: store.parsedText.first?.values["SIZE"] ?? "240,120",with:"240,\(height)"))
            store.finishSourceEditing()
            XCTAssertTrue(try XCTUnwrap(store.renderer.imageCache.image(file)) === image)
            XCTAssertTrue(try XCTUnwrap(store.renderer.imageCache.crop(image,rect:CGRect(x:0,y:0,width:16,height:16))) === piece)
        }
        XCTAssertEqual(store.renderer.imageCache.decodeCount,1)
        let tile = try XCTUnwrap(store.files.first { $0.lastPathComponent == "art.til" })
        try store.open(tile)
        let atlas = try XCTUnwrap(store.renderer.imageCache.image(file))
        _ = store.editSource(store.text.replacingOccurrences(of:"0,0,16,16",with:"16,0,16,16"))
        store.finishSourceEditing()
        XCTAssertTrue(try XCTUnwrap(store.renderer.imageCache.image(file)) === atlas)
        var key = try XCTUnwrap(store.keys.first); key.caption = ""
        let view = Canvas { context,_ in
            var layer = context; store.renderer.key(key,pressed:false,context:&layer)
        }.frame(width:120,height:80)
        let painter = ImageRenderer(content:view);painter.scale=1
        let rendered = try XCTUnwrap(painter.cgImage)
        let center = try XCTUnwrap(rendered.cropping(to:CGRect(x:60,y:40,width:1,height:1)))
        var bytes=[UInt8](repeating:0,count:4)
        try bytes.withUnsafeMutableBytes { buffer in
            let context=try XCTUnwrap(CGContext(data:buffer.baseAddress,width:1,height:1,bitsPerComponent:8,bytesPerRow:4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue))
            context.draw(center,in:CGRect(x:0,y:0,width:1,height:1))
        }
        XCTAssertEqual(Array(bytes.prefix(3)),[0,0,255],"TIL metadata used the old crop")
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let replacement=UIGraphicsImageRenderer(size:CGSize(width:32,height:16),format:format).image { ctx in UIColor.green.setFill();ctx.fill(CGRect(x:0,y:0,width:32,height:16)) }
        try XCTUnwrap(replacement.pngData()).write(to:file)
        store.rescan()
        XCTAssertFalse(try XCTUnwrap(store.renderer.imageCache.image(file)) === image)
        XCTAssertFalse(try XCTUnwrap(store.renderer.imageCache.image(file)) === atlas)
    }
    @MainActor func testNativeEditorKeepsSelectionDuringPreviewRefresh() async throws {
        let (store,folder) = try await fixture(); defer { cleanup(store,folder) }
        func editor() -> DraftTextEditor {
            DraftTextEditor(draft:store.sourceDraft,focused:.constant(false),edit:{store.editSource($0,composing:$1)},finish:store.finishSourceEditing)
        }
        let host=UIHostingController(rootView:editor()),window=UIWindow(frame:CGRect(x:0,y:0,width:360,height:480))
        window.rootViewController=host;window.makeKeyAndVisible();defer{window.isHidden=true}
        host.view.layoutIfNeeded()
        func input(_ view:UIView)->UITextView? {
            if let input=view as? UITextView{return input}
            return view.subviews.lazy.compactMap{input($0)}.first
        }
        let textView=try XCTUnwrap(input(host.view))
        let next=store.text+"\n; caret stays here"
        textView.text=next;textView.selectedRange=NSRange(location:(next as NSString).length-3,length:0)
        textView.delegate?.textViewDidChange?(textView)
        let selection=textView.selectedRange
        try await Task.sleep(for:.milliseconds(550))
        host.rootView=editor();host.view.layoutIfNeeded()
        XCTAssertEqual(textView.text,next);XCTAssertEqual(textView.selectedRange,selection)
        XCTAssertEqual(store.text,next);XCTAssertEqual(store.editorPreviewCount,1)
    }
}
