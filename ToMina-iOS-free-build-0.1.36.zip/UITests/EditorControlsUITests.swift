import XCTest

final class EditorControlsUITests: XCTestCase {
    override func setUpWithError() throws { continueAfterFailure = false }

    private func openApp() -> XCUIApplication {
        XCUIDevice.shared.orientation = .portrait
        let app = XCUIApplication()
        app.launchArguments = ["--editor-controls-fixture"]
        app.launch()
        XCTAssertTrue(app.buttons["包内文件夹：controls.bds"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.staticTexts["app.version"].exists)
        return app
    }
    private func edit(_ file: String, in app: XCUIApplication, folder: String? = nil) {
        app.buttons["包内文件夹：controls.bds"].tap()
        if let folder { app.buttons[folder].tap() }
        let row = app.buttons[file]
        XCTAssertTrue(row.waitForExistence(timeout: 5))
        row.tap()
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout: 5))
    }
    private func assertNextToPanel(_ app: XCUIApplication, action: String) {
        let panel = app.buttons["editor.panel"], source = app.buttons[action]
        XCTAssertTrue(panel.isHittable); XCTAssertTrue(source.isHittable)
        XCTAssertEqual(source.frame.midY, panel.frame.midY, accuracy: 1)
        XCTAssertGreaterThanOrEqual(source.frame.minX, panel.frame.maxX)
        XCTAssertLessThanOrEqual(source.frame.minX - panel.frame.maxX, 8)
    }
    private func cleanup(_ app: XCUIApplication) {
        XCTAssertFalse(app.buttons["editor.cssCleanup"].isHittable)
        app.buttons["editor.operations"].tap()
        let button = app.buttons["editor.cssCleanup"]
        XCTAssertTrue(button.waitForExistence(timeout: 5)); XCTAssertTrue(button.isHittable)
        XCTAssertEqual(app.buttons.matching(identifier: "editor.cssCleanup").count, 1)
        proof(app, name: "CSS-cleanup-in-edit-menu")
        button.tap()
    }
    private func proof(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways
        add(attachment)
    }
    func testINIEditorHasOneVisibleExitAndCanReturn() {
        let app = openApp(); edit("py_26.ini", in: app, folder: "port")
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertEqual(app.buttons.matching(identifier: "editor.exit").count, 1)
        XCTAssertFalse(app.buttons["editor.cssCleanup"].isHittable)
        proof(app, name: "INI-editor-exit-next-to-panel")
        app.buttons["editor.exit"].tap()
        XCTAssertTrue(app.buttons["editor.open"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.textViews.firstMatch.exists)
        assertNextToPanel(app, action: "editor.open")
        app.buttons["editor.open"].tap()
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout: 5))
    }
    func testCSSCleanupMenuClearsUnusedBodyKeepsHeaderAndUndoRestoresIt() {
        let app = openApp(); edit("styles.css", in: app)
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]"))
        proof(app, name: "CSS-editor-adjacent-actions")
        cleanup(app)
        XCTAssertTrue(app.staticTexts["已清空 1 个未调用样式的内容，标题保留，可撤销"].waitForExistence(timeout: 5))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]\n[STYLE3]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("STYLE_NUM=3\n"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE1]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE3]"))
        proof(app, name: "CSS-cleanup-keeps-STYLE-headers")
        app.buttons["editor.operations"].tap(); app.buttons["撤销"].tap()
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]\nNM_COLOR=FF000000"))
    }
    func testCSSCleanupCanBeOpenedFromINIMenu() {
        let app = openApp(); edit("py_26.ini", in: app, folder: "port")
        cleanup(app)
        XCTAssertTrue(app.staticTexts["已清空 1 个未调用样式的内容，标题保留，可撤销"].waitForExistence(timeout: 5))
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE1]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE3]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]\n[STYLE3]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("STYLE_NUM=3\n"))
    }
    func testEditorActionsRemainHittableWithKeyboardAndLandscape() {
        let app = openApp(); edit("styles.css", in: app)
        app.textViews.firstMatch.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertTrue(app.buttons["editor.operations"].isHittable)
        XCUIDevice.shared.orientation = .landscapeLeft
        XCTAssertTrue(app.buttons["editor.exit"].waitForExistence(timeout: 5))
        assertNextToPanel(app, action: "editor.exit")
        XCTAssertTrue(app.buttons["editor.operations"].isHittable)
        proof(app, name: "Editor-actions-keyboard-landscape")
        app.buttons["editor.exit"].tap()
        XCTAssertTrue(app.buttons["editor.open"].waitForExistence(timeout: 5))
    }
    func testFloatingButtonsHaveEqualFramesIncludingMenuAndPauseState() {
        let app = openApp()
        XCTAssertTrue(app.buttons["漂浮预览"].isHittable)
        app.buttons["漂浮预览"].tap()
        let ids = ["animation.replay", "animation.pause", "animation.selector", "animation.images", "animation.log"]
        for id in ids {
            let button = app.buttons[id]
            XCTAssertTrue(button.waitForExistence(timeout: 5)); XCTAssertTrue(button.isHittable)
            XCTAssertEqual(button.frame.width, 88, accuracy: 1)
            XCTAssertEqual(button.frame.height, 32, accuracy: 1)
        }
        proof(app, name: "Floating-controls-equal-size")
        app.buttons["animation.pause"].tap()
        XCTAssertEqual(app.buttons["animation.pause"].label, "继续")
        XCTAssertEqual(app.buttons["animation.pause"].frame.width, 88, accuracy: 1)
        XCTAssertEqual(app.buttons["animation.pause"].frame.height, 32, accuracy: 1)
        app.buttons["animation.pause"].tap()
        app.buttons["animation.selector"].tap()
        let panelBinding = app.buttons["animation.panelBinding"]
        XCTAssertTrue(panelBinding.waitForExistence(timeout: 5))
        XCTAssertTrue(panelBinding.isHittable)
        panelBinding.tap()
        XCTAssertEqual(app.buttons["animation.selector"].frame.width, 88, accuracy: 1)
        XCTAssertEqual(app.buttons["animation.selector"].frame.height, 32, accuracy: 1)
    }
    func testAnimationEditorAppendsNewBlockAndPersistsItInAnimINI() {
        let app = openApp()
        app.buttons["漂浮预览"].tap()
        let editor = app.textViews.firstMatch
        XCTAssertTrue(editor.waitForExistence(timeout:5))
        XCTAssertTrue((editor.value as? String ?? "").contains("[ANIM1]"))
        // The fixture has a short document. Tapping below its text puts the
        // caret at the end, just as a user appending an animation would do.
        editor.coordinate(withNormalizedOffset:CGVector(dx:0.8,dy:0.85)).tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout:5))
        editor.typeText("\n\n[ANIM18]\nTYPE=4\nDURATION=250\n")
        XCTAssertTrue((editor.value as? String ?? "").contains("[ANIM18]"))
        app.buttons["退出漂浮"].tap()
        XCTAssertFalse(app.alerts.firstMatch.exists)
        edit("anim.ini",in:app)
        let source = app.textViews.firstMatch.value as? String ?? ""
        XCTAssertTrue(source.contains("[ANIM1]"))
        XCTAssertTrue(source.contains("[ANIM18]"))
        XCTAssertTrue(source.contains("ANIM_NUM=2"))
        XCTAssertTrue(source.contains("DURATION=250"))
        proof(app,name:"Added-ANIM18-saved-in-anim-ini")
    }
}
