import SwiftUI
import UniformTypeIdentifiers

struct FileInspector:View {
    let file:URL
    let editable:Bool
    var transferChanged:(Bool)->Void = { _ in }
    let changed:()->Void
    @Environment(\.dismiss) private var dismiss
    @State private var data=Data()
    @State private var page=0
    @State private var hex=""
    @State private var error=""
    @State private var replace=false
    @State private var columns="1"
    @State private var rows="1"
    @State private var tiles=false
    @State private var rawMode=false
    @State private var rawReplace=false
    @State private var savedHex=""
    @State private var single=false
    @State private var sourceRect=""
    @State private var innerRect=""
    private let pageSize=1024
    var body:some View {
        NavigationStack {
            VStack(alignment:.leading,spacing:10) {
                if !rawMode,let image=UIImage(data:data) {
                    Image(uiImage:image).resizable().scaledToFit().frame(maxHeight:360)
                    Text("\(image.cgImage?.width ?? 0) × \(image.cgImage?.height ?? 0)").foregroundStyle(.black)
                    HStack {
                        Button("替换图片"){transferChanged(true);replace=true}.disabled(!editable)
                        Button("等分切片"){tiles=true}.disabled(!editable)
                        Button("单个切片"){sourceRect="0,0,\(image.cgImage?.width ?? 0),\(image.cgImage?.height ?? 0)";single=true}.disabled(!editable)
                        Button("字节编辑"){rawMode=true}
                    }.buttonStyle(MinaButtonStyle())
                } else {
                    HStack {
                        Button("上一页"){if saveIfNeeded(){page=max(0,page-1);loadPage()}}.disabled(page==0)
                        Text("\(page+1) / \(max(1,(data.count+pageSize-1)/pageSize))")
                        Button("下一页"){if saveIfNeeded(){page+=1;loadPage()}}.disabled((page+1)*pageSize>=data.count)
                    }.buttonStyle(MinaButtonStyle())
                    TextEditor(text:$hex).disabled(!editable).font(.system(size:13,design:.monospaced)).foregroundStyle(.black).scrollContentBackground(.hidden).background(.white)
                    MinaFlow {
                        Button("保存本页十六进制"){_ = savePage()}.disabled(!editable)
                        Button("替换原文件"){transferChanged(true);rawReplace=true}.disabled(!editable)
                        if UIImage(data:data) != nil{Button("图片预览"){if saveIfNeeded(){rawMode=false}}}
                    }.buttonStyle(MinaButtonStyle())
                }
                if !error.isEmpty{Text(error).font(.caption).foregroundStyle(.black)}
                Spacer(minLength:0)
            }.padding().background(MinaTheme.background).navigationTitle(file.lastPathComponent)
                .toolbar{Button("关闭"){if saveIfNeeded(){dismiss()}}}
        }.interactiveDismissDisabled(hex != savedHex).preferredColorScheme(.light).onAppear{do{data=try Data(contentsOf:file);loadPage()}catch{self.error=error.localizedDescription}}
        .sheet(isPresented:$replace, onDismiss:{transferChanged(false)}){
            SkinDocumentPicker(contentTypes:[.image],asCopy:true){result in
            replace=false;defer{transferChanged(false)}
            do{
                guard let url=try result.get() else{return}
                let access=url.startAccessingSecurityScopedResource();defer{if access{url.stopAccessingSecurityScopedResource()}}
                let bytes=try Data(contentsOf:url)
                guard bytes.count<=32*1024*1024,let image=UIImage(data:bytes) else{throw SkinFailure(message:"图片无法解码或超过 32 MB")}
                let ext=file.pathExtension.lowercased()
                let output:Data
                if ext=="png"{guard let d=image.pngData() else{throw SkinFailure(message:"PNG 转换失败")};output=d}
                else if ["jpg","jpeg"].contains(ext){guard let d=image.jpegData(compressionQuality:1) else{throw SkinFailure(message:"JPEG 转换失败")};output=d}
                else{guard url.pathExtension.lowercased()==ext else{throw SkinFailure(message:"此格式替换图片须与原格式一致")};output=bytes}
                try output.write(to:file,options:.atomic);data=output;page=0;loadPage();changed()
            }catch{self.error=error.localizedDescription}
            }.interactiveDismissDisabled()
        }
        .sheet(isPresented:$rawReplace, onDismiss:{transferChanged(false)}){
            SkinDocumentPicker(contentTypes:[.item],asCopy:true){result in
            rawReplace=false;defer{transferChanged(false)}
            do{
                guard let url=try result.get() else{return}
                let access=url.startAccessingSecurityScopedResource();defer{if access{url.stopAccessingSecurityScopedResource()}}
                let bytes=try Data(contentsOf:url);guard bytes.count<=32*1024*1024 else{throw SkinFailure(message:"文件超过 32 MB")}
                try bytes.write(to:file,options:.atomic);data=bytes;page=0;loadPage();changed();error="已替换"
            }catch{self.error=error.localizedDescription}
            }.interactiveDismissDisabled()
        }
        .alert("单个切片",isPresented:$single){
            TextField("SOURCE_RECT",text:$sourceRect);TextField("INNER_RECT（可留空）",text:$innerRect)
            Button("生成"){createSingle()};Button("取消",role:.cancel){}
        }message:{Text("坐标按整张图片像素填写：x,y,宽,高。")}
        .alert("等分切片",isPresented:$tiles){
            TextField("列数",text:$columns);TextField("行数",text:$rows)
            Button("生成"){createTiles()};Button("取消",role:.cancel){}
        }message:{Text("按原图像素等分，不覆盖已有 TIL。")}
    }
    private func loadPage(){let start=min(data.count,page*pageSize),end=min(data.count,start+pageSize);hex=data[start..<end].enumerated().map{($0.offset>0 && $0.offset%16==0 ? "\n":"")+String(format:"%02X ",$0.element)}.joined();savedHex=hex}
    private func saveIfNeeded()->Bool{hex==savedHex || savePage()}
    private func savePage()->Bool{
        guard editable else{return hex==savedHex}
        let tokens=hex.components(separatedBy:.whitespacesAndNewlines).filter{!$0.isEmpty}
        let bytes=tokens.compactMap{UInt8($0,radix:16)},start=page*pageSize,end=min(data.count,start+pageSize)
        guard tokens.allSatisfy({$0.count==2}),bytes.count==tokens.count,bytes.count==end-start else{error="请使用两位十六进制字节，并保留本页字节数量";return false}
        do{var next=data;next.replaceSubrange(start..<end,with:bytes);try next.write(to:file,options:.atomic);data=next;savedHex=hex;changed();error="已保存";return true}catch{self.error=error.localizedDescription;return false}
    }
    private func createSingle(){
        guard let image=UIImage(data:data)?.cgImage else{return}
        do{try writeTiles(TileEdits.single(source:sourceRect,inner:innerRect,width:image.width,height:image.height))}catch{self.error=error.localizedDescription}
    }
    private func writeTiles(_ text:String)throws{
        let target=file.deletingPathExtension().appendingPathExtension("til")
        guard !FileManager.default.fileExists(atPath:target.path) else{throw SkinFailure(message:"已有同名 TIL，请在文件列表编辑")}
        try Data(text.utf8).write(to:target,options:.atomic);changed();error="已生成 TIL"
    }
    private func createTiles(){
        guard let c=Int(columns),let r=Int(rows),(1...100).contains(c),(1...100).contains(r),c*r<=10000,let image=UIImage(data:data)?.cgImage,image.width%c==0,image.height%r==0 else{error="列数、行数需在 1–100，且能整除原图像素";return}
        let file=file.deletingPathExtension().appendingPathExtension("til")
        guard !FileManager.default.fileExists(atPath:file.path) else{error="已有同名 TIL，请在文件列表编辑";return}
        let w=image.width/c,h=image.height/r
        let text="[GLOBAL]\nIMG_NUM=\(r*c)\n\n"+(0..<r*c).map{"[IMG\($0+1)]\nSOURCE_RECT=\(($0%c)*w),\(($0/c)*h),\(w),\(h)\n"}.joined(separator:"\n")
        do{try Data(text.utf8).write(to:file,options:.atomic);changed();error="已生成 \(r*c) 个切片"}catch{self.error=error.localizedDescription}
    }
}
