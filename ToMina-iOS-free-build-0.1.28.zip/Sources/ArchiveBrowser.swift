import SwiftUI
import UniformTypeIdentifiers

struct ArchiveBrowser: View {
    @ObservedObject var store: SkinStore
    @Binding var relativeDirectory: String
    let openFile: (URL) -> Void
    let chooseFiles: (URL) -> Void
    let dropped: ([NSItemProvider], URL) -> Bool
    let close: () -> Void
    @State private var search = ""
    @State private var entries: [ArchiveEntry] = []
    @State private var newFolder = false
    @State private var folderName = ""
    @State private var error: String?
    @State private var targeted = false
    private var folder: URL? { store.root?.appendingPathComponent(relativeDirectory, isDirectory: true) }
    private var rows: [ArchiveEntry] {
        if search.isEmpty { return entries }
        let folders = entries.filter { $0.directory && store.relative($0.url).localizedCaseInsensitiveContains(search) }
        return folders + store.files.filter { store.relative($0).localizedCaseInsensitiveContains(search) }.map { ArchiveEntry(url: $0, directory: false) }
    }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    if !relativeDirectory.isEmpty {
                        Button { relativeDirectory = (relativeDirectory as NSString).deletingLastPathComponent } label: { Label("上一级", systemImage: "arrow.up") }
                    }
                    Text(relativeDirectory.isEmpty ? store.filename : store.filename + "/" + relativeDirectory).font(.caption).lineLimit(2)
                    Spacer()
                }.padding(12).foregroundStyle(MinaTheme.ink)
                List(rows) { entry in
                    Button {
                        if entry.directory { relativeDirectory = store.relative(entry.url); search = "" }
                        else { openFile(entry.url) }
                    } label: {
                        Label {
                            Text(search.isEmpty ? entry.url.lastPathComponent : store.relative(entry.url)).foregroundStyle(MinaTheme.ink)
                        } icon: {
                            Image(systemName: entry.directory ? "folder" : "doc").foregroundStyle(MinaTheme.muted)
                        }
                    }
                }.listStyle(.plain)
                Text("可拖入多个文件或图片，导入到当前文件夹").font(.caption).foregroundStyle(MinaTheme.muted).padding(12)
            }.background(MinaTheme.background).contentShape(Rectangle())
                .overlay { if targeted { RoundedRectangle(cornerRadius: 12).stroke(MinaTheme.ink, lineWidth: 2).padding(4).allowsHitTesting(false) } }
                .onDrop(of: [UTType.item.identifier], isTargeted: $targeted) { providers in
                    guard let folder else { return false }; return dropped(providers, folder)
                }
                .searchable(text: $search, prompt: "搜索包内文件")
                .navigationTitle("包内文件夹")
                .toolbar {
                    ToolbarItemGroup(placement: .topBarTrailing) {
                        Button { folderName = ""; newFolder = true } label: { Image(systemName: "folder.badge.plus") }.accessibilityLabel("新建文件夹").disabled(store.busy)
                        Button("导入文件") { if let folder { chooseFiles(folder) } }.disabled(store.busy)
                        Button("关闭", action: close)
                    }
                }
                .task(id: (store.root?.path ?? "") + "/" + relativeDirectory + ":" + String(store.fileRevision)) {
                    guard let root = store.root, let folder else { entries = []; return }
                    do { entries = try await Task.detached { try ArchiveFiles.entries(in: folder, root: root) }.value }
                    catch { entries = []; self.error = error.localizedDescription }
                }
                .alert("新建文件夹", isPresented: $newFolder) {
                    TextField("文件夹名称", text: $folderName)
                    Button("创建") {
                        guard let root = store.root, let folder else { return }
                        do { try ArchiveFiles.createFolder(folderName, in: folder, root: root); store.rescan() }
                        catch { self.error = error.localizedDescription }
                    }
                    Button("取消", role: .cancel) {}
                }
                .alert("提示", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                    Button("确定") { error = nil }
                } message: { Text(error ?? "") }
        }.preferredColorScheme(.light)
    }
}
