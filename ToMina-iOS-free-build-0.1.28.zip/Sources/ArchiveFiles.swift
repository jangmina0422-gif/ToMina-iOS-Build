import Foundation
import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct ArchiveEntry: Identifiable, Sendable {
    let url: URL
    let directory: Bool
    var id: URL { url }
}

enum ArchiveFiles {
    static func directory(_ folder: URL, root: URL) throws -> URL {
        let base = root.resolvingSymlinksInPath().standardizedFileURL
        let resolved = folder.resolvingSymlinksInPath().standardizedFileURL
        guard resolved.pathComponents.starts(with: base.pathComponents),
              (try? resolved.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true else {
            throw SkinFailure(message: "包内文件夹不存在")
        }
        return resolved
    }
    static func entries(in folder: URL, root: URL) throws -> [ArchiveEntry] {
        let folder = try directory(folder, root: root)
        return try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey]).compactMap { url in
            let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { return nil }
            return ArchiveEntry(url: url, directory: values.isDirectory == true)
        }.sorted { a, b in
            if a.directory != b.directory { return a.directory }
            return a.url.lastPathComponent.localizedStandardCompare(b.url.lastPathComponent) == .orderedAscending
        }
    }
    static func validName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." && !name.contains("/") && !name.contains("\\") && !name.contains(":") && !name.contains("\0")
    }
    static func createFolder(_ name: String, in folder: URL, root: URL) throws {
        guard validName(name) else { throw SkinFailure(message: "文件夹名称无效") }
        let target = try directory(folder, root: root).appendingPathComponent(name, isDirectory: true)
        guard !FileManager.default.fileExists(atPath: target.path) else { throw SkinFailure(message: "已有同名文件或文件夹") }
        try FileManager.default.createDirectory(at: target, withIntermediateDirectories: false)
    }
}

struct StagedResource: Sendable {
    let url: URL
    let name: String
}
struct ResourceBatch: Sendable {
    var files: [StagedResource] = []
    var failures: [String] = []
    func discard() { for file in files { try? FileManager.default.removeItem(at: file.url.deletingLastPathComponent()) } }
}

enum ResourceImport {
    static let maximumFile = 32 * 1024 * 1024
    static let maximumBatch = 128 * 1024 * 1024
    static let maximumCount = 64

    // Provider URLs may be deleted immediately after their callback returns.
    // Always copy within that callback, then pass only our stable copy onward.
    static func stage(_ source: URL, name: String? = nil) throws -> StagedResource {
        guard source.isFileURL else { throw SkinFailure(message: "共享内容没有可读取的文件") }
        let access = source.startAccessingSecurityScopedResource()
        defer { if access { source.stopAccessingSecurityScopedResource() } }
        var output: StagedResource?, failure: Error?
        let coordinator = NSFileCoordinator()
        var coordinationError: NSError?
        coordinator.coordinate(readingItemAt: source, options: .withoutChanges, error: &coordinationError) { url in
            do {
                let values = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
                guard values.isRegularFile == true, let size = values.fileSize, size <= maximumFile else {
                    throw SkinFailure(message: "只支持文件；单文件最多 32 MB")
                }
                let filename = name ?? url.lastPathComponent
                guard ArchiveFiles.validName(filename) else { throw SkinFailure(message: "文件名无效") }
                let folder = FileManager.default.temporaryDirectory.appendingPathComponent("resource-" + UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                let copy = folder.appendingPathComponent(filename)
                do { try FileManager.default.copyItem(at: url, to: copy); output = StagedResource(url: copy, name: filename) }
                catch { try? FileManager.default.removeItem(at: folder); throw error }
            } catch { failure = error }
        }
        if let coordinationError { throw coordinationError }
        if let failure { throw failure }
        guard let output else { throw SkinFailure(message: "文件读取失败") }
        return output
    }
    static func stageURLs(_ urls: [URL]) -> ResourceBatch {
        var batch = ResourceBatch(), total = 0
        for url in urls.prefix(maximumCount) {
            do {
                let file = try stage(url)
                let size = try file.url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard total + size <= maximumBatch else {
                    try? FileManager.default.removeItem(at: file.url.deletingLastPathComponent())
                    throw SkinFailure(message: "一次导入最多 128 MB")
                }
                total += size; batch.files.append(file)
            } catch { batch.failures.append(url.lastPathComponent + "：" + error.localizedDescription) }
        }
        if urls.count > maximumCount { batch.failures.append("一次最多导入 64 个文件，其余文件请再次导入") }
        return batch
    }
    static func accepts(_ provider: NSItemProvider) -> Bool {
        provider.hasItemConformingToTypeIdentifier(UTType.item.identifier) || provider.canLoadObject(ofClass: UIImage.self)
    }
    private static func suggestedName(_ provider: NSItemProvider, url: URL, type: String) -> String {
        let proposed = provider.suggestedName ?? url.lastPathComponent
        let base = ArchiveFiles.validName(proposed) ? proposed : url.lastPathComponent
        guard (base as NSString).pathExtension.isEmpty else { return base }
        let ext = UTType(type)?.preferredFilenameExtension ?? url.pathExtension
        return ext.isEmpty ? base : base + "." + ext
    }
    private static func fileURL(_ provider: NSItemProvider) async throws -> StagedResource {
        try await withCheckedThrowingContinuation { continuation in
            _ = provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { value, error in
                do {
                    if let error { throw error }
                    let url: URL?
                    if let value = value as? URL { url = value }
                    else if let data = value as? Data { url = URL(dataRepresentation: data, relativeTo: nil) }
                    else { url = nil }
                    guard let url, url.isFileURL else { throw SkinFailure(message: "拖入的内容不是本地文件") }
                    continuation.resume(returning: try stage(url))
                } catch { continuation.resume(throwing: error) }
            }
        }
    }
    private static func representation(_ provider: NSItemProvider, type: String) async throws -> StagedResource {
        try await withCheckedThrowingContinuation { continuation in
            _ = provider.loadFileRepresentation(forTypeIdentifier: type) { url, error in
                do {
                    if let error { throw error }
                    guard let url else { throw SkinFailure(message: "分享内容没有文件数据") }
                    continuation.resume(returning: try stage(url, name: suggestedName(provider, url: url, type: type)))
                } catch { continuation.resume(throwing: error) }
            }
        }
    }
    private static func image(_ provider: NSItemProvider) async throws -> StagedResource {
        try await withCheckedThrowingContinuation { continuation in
            _ = provider.loadObject(ofClass: UIImage.self) { value, error in
                do {
                    if let error { throw error }
                    guard let image = value as? UIImage, let data = image.pngData(), data.count <= maximumFile else {
                        throw SkinFailure(message: "图片无法读取或超过 32 MB")
                    }
                    let proposed = provider.suggestedName ?? "绘图"
                    let base = ArchiveFiles.validName(proposed) ? (proposed as NSString).deletingPathExtension : "绘图"
                    let name = base + ".png"
                    let folder = FileManager.default.temporaryDirectory.appendingPathComponent("resource-" + UUID().uuidString, isDirectory: true)
                    try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                    let file = folder.appendingPathComponent(name)
                    do { try data.write(to: file, options: .atomic) }
                    catch { try? FileManager.default.removeItem(at: folder); throw error }
                    continuation.resume(returning: StagedResource(url: file, name: name))
                } catch { continuation.resume(throwing: error) }
            }
        }
    }
    static func stageProvider(_ provider: NSItemProvider) async throws -> StagedResource {
        var lastError: Error = SkinFailure(message: "该共享内容没有文件或图片")
        if provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) {
            do { return try await fileURL(provider) } catch { lastError = error }
        }
        // Prefer the sender's original representation, including Procreate/PSD,
        // over a preview thumbnail. Image-only providers fall back to full PNG.
        for type in provider.registeredTypeIdentifiers where type != UTType.fileURL.identifier && type != UTType.url.identifier {
            do { return try await representation(provider, type: type) } catch { lastError = error }
        }
        if provider.canLoadObject(ofClass: UIImage.self) { return try await image(provider) }
        throw lastError
    }
    static func stageProviders(_ providers: [NSItemProvider]) async -> ResourceBatch {
        var batch = ResourceBatch(), total = 0
        for provider in providers.prefix(maximumCount) {
            do {
                let file = try await stageProvider(provider)
                let size = try file.url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard total + size <= maximumBatch else {
                    try? FileManager.default.removeItem(at: file.url.deletingLastPathComponent())
                    throw SkinFailure(message: "一次导入最多 128 MB")
                }
                total += size; batch.files.append(file)
            } catch { batch.failures.append((provider.suggestedName ?? "共享文件") + "：" + error.localizedDescription) }
        }
        if providers.count > maximumCount { batch.failures.append("一次最多导入 64 个文件，其余文件请再次拖入") }
        return batch
    }
    enum ConflictPolicy { case replace, keepBoth }
    static func insert(_ batch: [StagedResource], into folder: URL, root: URL, policy: ConflictPolicy) throws -> [URL] {
        let folder = try ArchiveFiles.directory(folder, root: root)
        var targets = [URL](), reserved = Set<String>(), total = 0
        let existing = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil)
        var occupied = Set(existing.map { $0.lastPathComponent.lowercased() })
        for resource in batch {
            guard ArchiveFiles.validName(resource.name) else { throw SkinFailure(message: "文件名无效") }
            let size = try resource.url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? maximumFile + 1
            guard size <= maximumFile, total + size <= maximumBatch else { throw SkinFailure(message: "导入文件超出大小限制") }
            total += size
            var name = resource.name
            if policy == .keepBoth {
                let ext = (name as NSString).pathExtension, base = (name as NSString).deletingPathExtension
                var index = 2
                while occupied.contains(name.lowercased()) {
                    name = base + " (\(index))" + (ext.isEmpty ? "" : "." + ext); index += 1
                }
            } else {
                // Match an existing spelling even on a case-sensitive volume.
                name = existing.first { $0.lastPathComponent.lowercased() == name.lowercased() }?.lastPathComponent ?? name
                guard !reserved.contains(name.lowercased()) else { throw SkinFailure(message: "同一批文件有重复名称，请选择保留两份") }
            }
            occupied.insert(name.lowercased()); reserved.insert(name.lowercased())
            let target = folder.appendingPathComponent(name)
            let resolved = target.resolvingSymlinksInPath().standardizedFileURL
            guard resolved.deletingLastPathComponent() == folder else { throw SkinFailure(message: "目标文件路径无效") }
            if FileManager.default.fileExists(atPath: target.path), (try target.resourceValues(forKeys: [.isRegularFileKey])).isRegularFile != true {
                throw SkinFailure(message: "不能用文件覆盖文件夹：" + name)
            }
            targets.append(target)
        }
        // Stage replacements before touching the working archive; rollback all
        // written entries if an individual write fails midway through the batch.
        if let iterator=FileManager.default.enumerator(at:root,includingPropertiesForKeys:[.isRegularFileKey,.fileSizeKey]) {
            var resulting=total,count=0
            let replacements=Set(targets)
            for case let file as URL in iterator {
                count += 1
                let values=try file.resourceValues(forKeys:[.isRegularFileKey,.fileSizeKey])
                if values.isRegularFile == true,!replacements.contains(file){resulting += values.fileSize ?? 0}
            }
            guard resulting<=maximumBatch,count+targets.filter({!FileManager.default.fileExists(atPath:$0.path)}).count<=6000 else {
                throw SkinFailure(message:"加入后压缩包超过 128 MB 或 6000 个条目")
            }
        }
        let rollback = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: rollback, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: rollback) }
        var prior = [URL: URL](), written = [URL]()
        do {
            for (index, target) in targets.enumerated() {
                if FileManager.default.fileExists(atPath: target.path) {
                    let copy = rollback.appendingPathComponent(String(index))
                    try FileManager.default.copyItem(at: target, to: copy); prior[target] = copy
                }
                let data = try Data(contentsOf: batch[index].url, options: .mappedIfSafe)
                try data.write(to: target, options: .atomic); written.append(target)
            }
        } catch {
            for target in written.reversed() {
                if let copy = prior[target] { try? Data(contentsOf: copy).write(to: target, options: .atomic) }
                else { try? FileManager.default.removeItem(at: target) }
            }
            throw error
        }
        return targets
    }
}

@MainActor struct SkinResourcePicker: UIViewControllerRepresentable {
    let completion: (Result<[URL], Error>) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = Self.controller()
        picker.delegate = context.coordinator; return picker
    }
    static func controller() -> UIDocumentPickerViewController {
        let picker=SkinDocumentPicker.controller(contentTypes:[.item],asCopy:true)
        picker.allowsMultipleSelection=true;picker.shouldShowFileExtensions=true;return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    @MainActor final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let completion: (Result<[URL], Error>) -> Void
        private var completed = false
        init(_ completion: @escaping (Result<[URL], Error>) -> Void) { self.completion = completion }
        private func finish(_ result: Result<[URL], Error>) { guard !completed else { return }; completed = true; completion(result) }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard !urls.isEmpty, urls.allSatisfy(\.isFileURL) else { finish(.failure(SkinFailure(message: "系统未返回可读取的文件"))); return }
            finish(.success(urls))
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { finish(.success([])) }
    }
}
