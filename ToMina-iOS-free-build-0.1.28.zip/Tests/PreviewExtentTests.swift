import XCTest
import SwiftUI
import UIKit
@testable import ToMina

final class PreviewExtentTests:XCTestCase {
    @MainActor private func scene()throws->(BdaPreviewEngine,URL) {
        let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let data=UIGraphicsImageRenderer(size:CGSize(width:160,height:90),format:format).image{context in
            UIColor.red.setFill();context.fill(CGRect(x:0,y:0,width:160,height:90))
        }.pngData()!
        let file=folder.appendingPathComponent("decoration.png");try data.write(to:file)
        let engine=BdaPreviewEngine(root:folder,files:[file]);engine.panelID="test"
        engine.images=["1":["normalImage":["resource":["resourceID":"decoration.png"]]]]
        engine.colors=["2":["normalColor":"#0000FF"],"3":["normalColor":"#00FF00"]]
        let candidate=BdaPreviewEngine.Item(id:"CAND",kind:"cand",data:["backStyle":["type":"1","key":"2"]],rect:CGRect(x:-30,y:-30,width:170,height:20))
        let key=BdaPreviewEngine.Item(id:"KEY1",kind:"keys",data:["foreStyles":[["key":"1"]],"foreStyleOffsets":[["x":1,"y":0]]],rect:CGRect(x:10,y:10,width:20,height:20))
        let bottom=BdaPreviewEngine.Item(id:"DECOR",kind:"images",data:["backStyle":["type":"1","key":"3"]],rect:CGRect(x:145,y:95,width:15,height:15))
        var hidden=BdaPreviewEngine.Item(id:"HIDDEN",kind:"images",data:[:],rect:CGRect(x:-900,y:-900,width:2000,height:2000));hidden.visible=false
        engine.panels["test"] = .init(id:"test",data:[:],size:CGSize(width:100,height:80),items:[candidate,key,bottom,hidden])
        return(engine,folder)
    }
    @MainActor private func render(_ engine:BdaPreviewEngine,cached:Bool)->CGImage {
        let bounds=engine.previewBounds
        let view=Canvas{context,_ in
            context.translateBy(x:-bounds.minX,y:-bounds.minY)
            engine.draw(context:&context,time:0,pressed:false,debug:false,scale:1,rasterScale:cached ? 1:nil)
        }.frame(width:bounds.width,height:bounds.height)
        let image=ImageRenderer(content:view);image.scale=1;return image.cgImage!
    }
    private func rgb(_ image:CGImage,_ x:Int,_ y:Int)throws->[UInt8] {
        var bytes=[UInt8](repeating:0,count:image.width*image.height*4)
        let context=try XCTUnwrap(CGContext(data:&bytes,width:image.width,height:image.height,bitsPerComponent:8,bytesPerRow:image.width*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue))
        context.draw(image,in:CGRect(x:0,y:0,width:image.width,height:image.height))
        let offset=(y*image.width+x)*4;return Array(bytes[offset..<offset+3])
    }
    @MainActor func testFullSceneIncludesCandidateOutsideItemsAndNaturalForeground()throws {
        let (engine,folder)=try scene();defer{try? FileManager.default.removeItem(at:folder)}
        XCTAssertEqual(engine.previewBounds,CGRect(x:-40,y:-30,width:200,height:140))
        let direct=render(engine,cached:false),cached=render(engine,cached:true)
        for (x,y,color) in [(40,2,[UInt8(0),0,255]),(10,30,[UInt8(255),0,0]),(190,135,[UInt8(0),255,0])] {
            XCTAssertEqual(try rgb(direct,x,y),color);XCTAssertEqual(try rgb(cached,x,y),color)
        }
        let paints=engine.rasterCache.staticCommandCount
        for _ in 0..<20{_=render(engine,cached:true)}
        XCTAssertEqual(engine.rasterCache.staticCommandCount,paints)
    }
    @MainActor func testLiveSceneExtentsAndChosenAnimationRefreshBounds()throws {
        let (engine,folder)=try scene();defer{try? FileManager.default.removeItem(at:folder)}
        _=engine.previewBounds
        var panel=try XCTUnwrap(engine.panel)
        panel.items[2].rect=CGRect(x:300,y:160,width:20,height:20);engine.panels["test"]=panel
        XCTAssertEqual(engine.previewBounds.maxX,320);XCTAssertEqual(engine.previewBounds.maxY,180)
        engine.animations=[.init(id:"outside",frames:[],durations:[],rect:CGRect(x:-80,y:-100,width:40,height:40))]
        engine.animationChoice="outside"
        XCTAssertEqual(engine.previewBounds.minX,-80);XCTAssertEqual(engine.previewBounds.minY,-100)
        engine.animationChoice=""
        XCTAssertEqual(engine.previewBounds.minX,-40);XCTAssertEqual(engine.previewBounds.minY,-30)
    }
    @MainActor func testCompleteSceneFitsPhoneAndSplitWindowsAtOriginalSizeLimits()throws {
        let (engine,folder)=try scene();defer{try? FileManager.default.removeItem(at:folder)}
        let bounds=engine.previewBounds
        for (width,height,tablet) in [(CGFloat(390),CGFloat(800),false),(400,900,true),(680,900,true),(1000,900,true)] {
            let previewHeight=PreviewSizing.height(available:CGSize(width:width,height:height),tablet:tablet)
            let scale=min((width-16)/bounds.width,(previewHeight-16)/bounds.height)
            XCTAssertLessThanOrEqual(bounds.width*scale,width-16)
            XCTAssertLessThanOrEqual(bounds.height*scale,previewHeight-16)
            XCTAssertGreaterThan(scale,0)
        }
    }
}
