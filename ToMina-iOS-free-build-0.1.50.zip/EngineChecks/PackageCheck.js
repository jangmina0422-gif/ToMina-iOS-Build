/* Read-only package diagnostics. Native collectors supply bounded text, image
 * metadata and decoded Config objects. No rule writes or repairs a skin. */
(function(root){
'use strict';
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o||{},k), dict=()=>Object.create(null);
const base=p=>p.slice(p.lastIndexOf('/')+1), dir=p=>p.includes('/')?p.slice(0,p.lastIndexOf('/')):'', stem=p=>p.replace(/\.[^/.]+$/,'');
const join=(a,b)=>a?a+'/'+b:b, lower=s=>String(s).toLowerCase();
const numbers=s=>{if(typeof s!=='string'||!s.trim())return null;const a=s.split(',').map(x=>x.trim());return a.every(x=>/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(x)&&Number.isFinite(Number(x)))?a.map(Number):null;};
const ids=s=>String(s||'').split(',').map(x=>x.trim()).filter(x=>x&&x!=='-1'&&x!=='0');
function run(input){
 const files=(input.files||[]).slice().sort((a,b)=>a.path.localeCompare(b.path)),index=dict(),byBase=dict(),parsed=dict(),counts={error:0,warning:0,info:0},buckets={error:[],warning:[],info:[]},seen=new Set();
 let configs=0,images=0,nativeFiles=0,skipped=0;
 function add(severity,path,line,section,field,code,message,suggestion){
  const key=[path,line,section,field,code,message].join('|');if(seen.has(key))return;seen.add(key);counts[severity]++;
  if(buckets[severity].length<1000)buckets[severity].push({severity,path,line:line||0,section:section||'',field:field||'',code,message,suggestion:suggestion||''});
 }
 function issue(level,f,s,k,code,message,suggestion){add(level,f.path,s?(s.lines[k]||s.line):0,s?s.name:'',k,code,message,suggestion);}
 for(const f of files){
  const key=lower(f.path);if(index[key])add('error',f.path,0,'','','path.collision','文件路径仅大小写不同：'+index[key].path,'统一路径命名，避免不同系统读取不同资源。');else index[key]=f;
  for(const name of new Set([lower(base(f.path)),lower(stem(base(f.path)))])){(byBase[name]||(byBase[name]=[])).push(f);}
  if(f.problem){add('error',f.path,0,'','','file.read',f.problem,'核对原文件，重新导入完整资源。');skipped++;}
  if(f.limited){add('info',f.path,0,'','','coverage.skip',f.limited,'此文件没有完成内容检查，需要单独核对。');skipped++;}
  if(f.size===0)add('warning',f.path,0,'','','file.empty','文件内容为空','确认是否为有意保留的占位文件。');
  if(f.image)images++;
  if(typeof f.text==='string'&&/\.(ini|css|til|cnd|pop|anim|ani)$/i.test(f.path)){parsed[key]=parse(f);configs++;}
  else if(typeof f.text==='string'&&/\.json$/i.test(f.path)){configs++;try{JSON.parse(f.text);}catch(e){add('error',f.path,0,'','','json.syntax','JSON 格式错误：'+String(e.message).slice(0,180),'检查引号、逗号和括号。');}}
  if(own(f,'native'))nativeFiles++;
  if(f.unknown>0)add('info',f.path,0,'','','native.unknown','存在 '+f.unknown+' 个未识别的二进制字段','这些字段不判为错误，也未完成语义检查。');
 }
 function parse(f){
  let section=null;const result=[],names=dict();
  f.text.replace(/^\uFEFF/,'').split(/\r\n|\n|\r/).forEach((raw,i)=>{
   const t=raw.trim();if(!t||/^(;|#|\/\/)/.test(t))return;
   const m=t.match(/^\[([^\]]+)\]\s*(?:(?:;|\/\/).*)?$/);
   if(m){const name=m[1].trim().toUpperCase();section={name,line:i+1,v:dict(),lines:dict()};result.push(section);
    if(names[name]&&name!=='CAND')issue('error',f,section,'','syntax.duplicateSection','重复配置段 ['+name+']','检查是否复制后忘记改编号。');names[name]=true;return;}
   if(t.startsWith('[')){add('error',f.path,i+1,'','','syntax.header','配置段标题不完整','使用 [KEY1] 这样的完整方括号标题。');section=null;return;}
   const equal=t.indexOf('=');if(equal<1){add('warning',f.path,i+1,section?section.name:'','','syntax.line','无法识别为 字段=值 的配置行','如为说明文字，请在前面加 ;。');return;}
   const k=t.slice(0,equal).trim().toUpperCase(),v=t.slice(equal+1).replace(/ \/\/.*$/,'').trim();
   if(!section){add('warning',f.path,i+1,'',k,'syntax.orphan','字段没有所属配置段','检查前面的段标题是否缺失。');return;}
   if(own(section.v,k))add('warning',f.path,i+1,section.name,k,'syntax.duplicateField','字段重复，后一个值会覆盖前一个值','保留所需的唯一设置。');
   section.v[k]=v;section.lines[k]=i+1;
  });return result;
 }
 function ancestors(path){const out=[];let d=dir(path);while(true){out.push(d);if(!d)break;d=dir(d);}return out;}
 function score(path,context){let n=0;while(n<path.length&&n<context.length&&lower(path[n])===lower(context[n]))n++;for(const token of ['dark','light','port','land']){const a=('/'+lower(path)).includes('/'+token+'/'),b=('/'+lower(context)).includes('/'+token+'/');if(a)n+=b?1000:-1000;}return n;}
 const resourceCache=dict();
 function resolve(reference,context,extensions){
  const name=String(reference||'').trim().replace(/\\/g,'/').replace(/^\.\//,'');if(!name||name.startsWith('/')||/[:\0]/.test(name)||name.split('/').includes('..'))return null;
  const cache=context+'|'+name+'|'+(extensions||[]).join(',');if(own(resourceCache,cache))return resourceCache[cache];
  const candidates=name.includes('/')?[name]:[];for(const d of ancestors(context))candidates.push(join(d,name),join(d,'res/'+name));
  for(const p of candidates){if(index[lower(p)])return resourceCache[cache]=index[lower(p)];for(const ext of extensions||[])if(index[lower(p+'.'+ext)])return resourceCache[cache]=index[lower(p+'.'+ext)];}
  const fallback=(byBase[lower(base(name))]||[]).filter(f=>!extensions||extensions.includes(lower(base(f.path).split('.').pop()))).slice().sort((a,b)=>score(b.path,context)-score(a.path,context)||a.path.localeCompare(b.path));
  return resourceCache[cache]=fallback[0]||null;
 }
 function referenced(f,s,k,ref,ext){
  if(!ref)return null;const normalized=ref.replace(/\\/g,'/');
  if(normalized.startsWith('/')||/[:\0]/.test(normalized)||normalized.split('/').includes('..')){issue('error',f,s,k,'reference.unsafe','资源路径超出底包或使用绝对路径：'+ref,'使用底包内的相对路径。');return null;}
  const result=resolve(ref,f.path,ext);if(!result)issue('error',f,s,k,'reference.missing','找不到引用文件：'+ref,'补回资源或修正文件名、目录与扩展名。');return result;
 }
 function nearest(path,name){for(const d of ancestors(path)){const f=index[lower(join(d,name))];if(f)return f;}return null;}
 function sections(file){return file?parsed[lower(file.path)]||[]:[];}
 function effective(f){
  const local=sections(f),gen=nearest(f.path,'gen.ini'),defs=gen&&gen.path!==f.path?sections(gen):[],used=dict();
  const result=local.map(s=>{const n=used[s.name]||0;used[s.name]=n+1;const d=defs.filter(x=>x.name===s.name)[n];return {...s,v:Object.assign(dict(),d?d.v:{},s.v)};});
  if(!used.PANEL){const p=defs.find(x=>x.name==='PANEL');if(p)result.unshift({...p,line:0,lines:dict(),inherited:true});}
  // A repeated CAND is legal; inherit matching names or positional defaults.
  const cands=defs.filter(s=>s.name==='CAND');let n=0;for(const s of result)if(s.name==='CAND'){const d=cands.find(x=>x.v.LAYOUT_NAME&&x.v.LAYOUT_NAME===s.v.LAYOUT_NAME)||cands[n++];if(d)s.v=Object.assign(dict(),d.v,s.v);}
  return result;
 }
 const definitionCache=dict();
 function definitions(context,prefix){const key=dir(context)+'|'+prefix;if(definitionCache[key])return definitionCache[key];const out=dict();
  const order=files.filter(f=>parsed[lower(f.path)]).slice().sort((a,b)=>score(a.path,context)-score(b.path,context)||b.path.localeCompare(a.path));
  for(const f of order)for(const s of sections(f))if(s.name.match(new RegExp('^'+prefix+'[0-9]+$')))out[s.name.slice(prefix.length)]={f,s};return definitionCache[key]=out;
 }
 const imageExt=['png','webp','jpg','jpeg','gif','apng','bmp'];
 for(const f of files){const local=sections(f);if(!local.length)continue;const ss=effective(f),panel=ss.find(s=>s.name==='PANEL'),panelSize=panel?numbers(panel.v.SIZE):null;
  const css=nearest(f.path,'res/default.css'),styles=sections(css),styleIDs=new Set(styles.filter(s=>/^STYLE\d+$/.test(s.name)).map(s=>s.name.slice(5)));
  const offsets=definitions(f.path,'OFFSET'),anim=definitions(f.path,'ANIM'),keyIDs=new Set(ss.filter(s=>/^KEY\d+$/.test(s.name)).map(s=>s.name.slice(3)));
  for(const s of ss){if(s.inherited)continue;const v=s.v;
   for(const k of Object.keys(v)){
    const val=v[k],localField=own(s.lines,k);if(!localField&&s.name!=='CAND')continue;
    if(val.includes('，')&&(/RECT$|STYLE$/.test(k)||['SIZE','POS','CELL_SIZE','PADDING','BUILD_LIST'].includes(k)))issue('error',f,s,k,'number.comma','使用了中文逗号','将数字分隔符改为英文逗号。');
    if(['VIEW_RECT','TOUCH_RECT','SOURCE_RECT','INNER_RECT','SIZE','POS','CELL_SIZE','PADDING'].includes(k)&&val!==''){
     const expected=/RECT$/.test(k)||k==='PADDING'?4:2,a=numbers(val);
     if(k==='TOUCH_RECT'&&a&&a.length===4&&a.every(x=>x===0))continue;
     if(k==='PADDING'&&!/^LIST\d*$|^CAND$/.test(s.name)&&a&&[1,2,4].includes(a.length))continue;
     if(!a||a.length!==expected)issue('error',f,s,k,'number.shape','应为 '+expected+' 个有限数字，用英文逗号分隔','检查数字数量，不能使用 NaN 或 Infinity。');
     else if((/RECT$/.test(k)&&(a[2]<=0||a[3]<=0))||(['SIZE','CELL_SIZE'].includes(k)&&a.some(x=>x<=0)))issue('warning',f,s,k,'geometry.empty','宽或高不为正数，可能无法显示','若不是有意隐藏，请填写正宽度、正高度。');
    }
    if(/^(KEY|ICON|TIP|OFFSET|STYLE|IMG|ANIM)_NUM$/.test(k)&&localField){const prefix=k.slice(0,-4),matches=local.filter(x=>new RegExp('^'+prefix+'[0-9]+$').test(x.name)),actual=matches.length,maxID=matches.reduce((m,x)=>Math.max(m,Number(x.name.slice(prefix.length))),0),capacity=['STYLE','OFFSET','IMG','ANIM'].includes(prefix)&&Number(val)===maxID;if(!/^\d+$/.test(val)||Number(val)!==actual&&!capacity)issue('warning',f,s,k,'count.mismatch','声明数量 '+val+'，本文件实际 '+actual,'核对编号和数量；继承数量请结合底包规则确认。');}
    if(['BACK_STYLE','FORE_STYLE','CELL_STYLE','BAR_STYLE','NML_BACK_STYLE','SEL_BACK_STYLE','NML_FONT_STYLE','SEL_FONT_STYLE','FIRST_FORE','ANIM_STYLE','BACK_ANIM_STYLE','FORE_ANIM_STYLE'].includes(k)){
     const nativeStyle=k.includes('ANIM_STYLE'),available=nativeStyle?files.some(x=>/^appearanceConfig(?:\.json)?$/i.test(base(x.path))):false;
     if(!available)for(const id of ids(val))if(/^\d+$/.test(id)&&!styleIDs.has(id))issue(css?'error':'warning',f,s,k,'style.missing','未找到 STYLE'+id+(css?'（'+css.path+'）':'，当前目录及上层未找到 res/default.css'),'核对样式编号及方向/主题对应的样式表。');
    }
    if(['NM_IMG','HL_IMG'].includes(k)&&val){const a=val.split(',').map(x=>x.trim());if(a.length===2){const name=stem(a[0]),til=referenced(f,s,k,name+'.til');referenced(f,s,k,name,imageExt);if(til&&!sections(til).some(x=>x.name==='IMG'+a[1]))issue('error',f,s,k,'tile.missing','切片文件中没有 IMG'+a[1]+'：'+til.path,'修正切片编号或补齐 IMG 段。');}else referenced(f,s,k,val,imageExt);}
    if(k==='LAYOUT_NAME'&&val){const ext=s.name==='CAND'?'cnd':s.name==='HINT'?'pop':s.name==='MORE'?'ini':'';referenced(f,s,k,/\.[^/.]+$/.test(val)||!ext?val:val+'.'+ext,ext?undefined:['ini','cnd','pop']);}
    if(k==='SYM_LAYOUT'&&val)referenced(f,s,k,/\.ini$/i.test(val)?val:val+'.ini');
    if(k==='ANIM_PATH'&&val)referenced(f,s,k,val,imageExt);
    if((k==='FONT_FILE'||k==='FONT_NAME'&&/\.(ttf|otf|ttc)$/i.test(val))&&val)referenced(f,s,k,val);
    if(['SHOW_ANIM','HIDE_ANIM','PRESS_ANIM','RELEASE_ANIM','BUILD_LIST'].includes(k))for(const id of ids(val))if(/^\d+$/.test(id)&&!anim[id])issue('error',f,s,k,'animation.missing','未找到 ANIM'+id,'检查动画编号与 BUILD_LIST 引用。');
    if(k==='POS_TYPE')for(const id of ids(val))if(/^\d+$/.test(id)&&!offsets[id])issue('warning',f,s,k,'offset.missing','未找到 OFFSET'+id,'检查偏移编号，或确认该编号是否由输入法内置提供。');
    if(/^ANIM\d+$/.test(s.name)&&['DURATION','DELAY','REPEAT_CNT','LIFE','TOTAL_NUMBER'].includes(k)&&val){const a=numbers(val);if(!a||a.length!==1)issue('error',f,s,k,'animation.number','动画参数应为有限数字','检查动画时长、延迟和数量。');else if(a[0]<0&&k!=='REPEAT_CNT')issue('warning',f,s,k,'animation.negative','动画参数为负数','确认是否填写错误。');}
   }
   if(/^KEY\d+$/.test(s.name)&&v.BROTHER_ID&&!['0','-1'].includes(v.BROTHER_ID)&&!keyIDs.has(v.BROTHER_ID))issue('error',f,s,'BROTHER_ID','key.brother','关联 KEY'+v.BROTHER_ID+' 不存在','检查删除或改号后的按键关联。');
   const rect=numbers(v.VIEW_RECT);if(/^KEY\d+$/.test(s.name)&&rect&&rect.length===4&&rect[2]>0&&rect[3]>0&&panelSize&&panelSize.length===2&&(rect[0]+rect[2]<=0||rect[1]+rect[3]<=0||rect[0]>=panelSize[0]||rect[1]>=panelSize[1]))issue('warning',f,s,'VIEW_RECT','geometry.outside','按键完全位于面板范围之外','检查坐标、横竖屏尺寸；如为隐藏按键可保留。');
   if(/^LIST\d*$/.test(s.name)&&lower(base(f.path))!=='gen.ini'){const cell=numbers(v.CELL_SIZE),pos=numbers(v.POS),padding=numbers(v.PADDING||'0,0,0,0'),n=Number(v.LIST_NUM);
    if(!cell||cell.length!==2||cell.some(x=>x<=0))issue('warning',f,s,'CELL_SIZE','list.cell','列表没有有效的单元格尺寸','补齐本面板或 gen.ini 的 CELL_SIZE。');
    if(!pos||pos.length!==2)issue('warning',f,s,'POS','list.position','列表没有有效位置','补齐 POS=x,y。');
    if(!Number.isInteger(n)||n<1||n>10000)issue('warning',f,s,'LIST_NUM','list.count','列表数量应为 1–10000','核对 LIST_NUM。');
    if(cell&&cell.length===2&&padding&&padding.length===4&&n>0){const w=cell[0]*(v.LIST_ORDER==='1'?n:1),h=cell[1]*(v.LIST_ORDER==='1'?1:n);if(padding[0]+padding[2]>=w||padding[1]+padding[3]>=h)issue('warning',f,s,'PADDING','list.padding','内边距占满或超出列表区域','减小 PADDING 或调整列表尺寸。');}
   }
   const outer=numbers(v.SOURCE_RECT),inner=numbers(v.INNER_RECT);if(outer&&outer.length===4){
    if(inner&&inner.length===4&&(inner[0]<outer[0]||inner[1]<outer[1]||inner[0]+inner[2]>outer[0]+outer[2]||inner[1]+inner[3]>outer[1]+outer[3]))issue('warning',f,s,'INNER_RECT','tile.inner','九宫格内部区域超出 SOURCE_RECT','核对整张素材坐标。');
    if(/\.til$/i.test(f.path)){const image=resolve(stem(base(f.path)),f.path,imageExt);if(!image)issue('error',f,s,'SOURCE_RECT','tile.image','切片对应的图片不存在','补回与 TIL 同名的图片。');else if(image.image&&(outer[0]<0||outer[1]<0||outer[0]+outer[2]>image.image[0]||outer[1]+outer[3]>image.image[1]))issue('error',f,s,'SOURCE_RECT','tile.bounds','切片超出图片 '+image.image.join(' × ')+' 的范围','按实际图片尺寸修正 SOURCE_RECT。');}
   }
  }
  // Detect cycles per source context, without conflating dark/light definitions.
  const active=new Set(),done=new Set();function visit(id,depth){if(done.has(id)||!anim[id])return;if(active.has(id)){const x=anim[id];issue('error',x.f,x.s,'BUILD_LIST','animation.cycle','组合动画存在循环引用：ANIM'+id,'删除形成循环的 BUILD_LIST 引用。');return;}if(depth>64){const x=anim[id];issue('info',x.f,x.s,'BUILD_LIST','coverage.depth','组合动画超过 64 层，未继续检查','简化动画层级并单独验证。');return;}active.add(id);for(const child of ids(anim[id].s.v.BUILD_LIST))visit(child,depth+1);active.delete(id);done.add(id);}
  for(const s of local)if(/^ANIM\d+$/.test(s.name))visit(s.name.slice(4),0);
 }
 // Typed Config checks use decoded field names; unknown protobuf fields are
 // explicitly reported above rather than guessed from arbitrary byte strings.
 for(const f of files)if(own(f,'native')){let budget=0;function walk(o,at,depth){if(!o||typeof o!=='object')return;if(++budget>100000||depth>64){if(budget===100001||depth===65)add('info',f.path,0,at,'','coverage.nativeLimit','原生配置超过检查层级或节点数量限制','其余内容需单独检查。');return;}
   if(typeof o.resourceID==='string'&&o.resourceID)referenced(f,{name:at,line:0,lines:{}},'resourceID',o.resourceID,imageExt);
   for(const k of Object.keys(o)){const v=o[k],path=at?at+'.'+k:k;if(['width','height'].includes(k)&&typeof v==='number'&&(!Number.isFinite(v)||v<0))add('warning',f.path,0,at,k,'native.size','原生布局尺寸为负数或非有限值','核对对应面板或按键尺寸。');if(k==='duration'&&typeof v==='number'&&v<0)add('warning',f.path,0,at,k,'native.duration','原生动画时长为负数','核对动画时长。');if(v&&typeof v==='object')walk(v,path,depth+1);}
  }walk(f.native,'',0);}
 if(files.length===0)add('error','',0,'','','package.empty','底包中没有可检查的文件','先导入完整底包。');
 else if(configs===0&&nativeFiles===0)add('info','',0,'','','package.noConfig','未找到可识别的布局配置','核对导入内容；其他文件只检查存在性和大小。');
 const issues=[...buckets.error,...buckets.warning,...buckets.info].slice(0,1000),total=counts.error+counts.warning+counts.info,omitted=total-issues.length;
 const summary={files:files.length,configs,images,nativeFiles,skipped,...counts,total,omitted};
 const lines=['底包检查','扫描 '+files.length+' 个文件 · 文本配置 '+configs+' · 图片 '+images+' · 原生配置 '+nativeFiles,'错误 '+counts.error+' · 警告 '+counts.warning+' · 未确认/提示 '+counts.info,skipped?'有 '+skipped+' 个文件未完成内容检查。':'已完成本次可识别内容的检查。','检查只读取文件，不修复、不导出底包。','范围：配置语法、数量、几何、列表、样式/顶栏/图片/切片/字体/动画引用、动画循环、图片尺寸和原生 Config 结构。','图片只检查读取与尺寸，未逐帧渲染；未知字段、输入法版本行为和实际显示效果仍需实机验证。'];
 if(total===0)lines.push('本次规则范围内未发现问题，不代表不存在其他兼容性问题。');
 for(const x of issues){lines.push('\n['+({error:'错误',warning:'警告',info:'未确认/提示'}[x.severity])+'] '+x.path+(x.line?' · 第 '+x.line+' 行':'')+(x.section?' · ['+x.section+']':'')+(x.field?' '+x.field:''),x.message);if(x.suggestion)lines.push('建议：'+x.suggestion);}
 if(omitted)lines.push('\n另有 '+omitted+' 条未展示（保留前 1000 条，错误优先）。全部文件已遍历。');
 return {summary,issues,report:lines.join('\n')};
}
root.PackageCheck={run};if(typeof module==='object'&&module.exports)module.exports=root.PackageCheck;
})(typeof globalThis!=='undefined'?globalThis:this);
