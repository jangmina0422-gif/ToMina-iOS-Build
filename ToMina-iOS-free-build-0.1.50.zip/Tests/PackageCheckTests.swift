import XCTest
@testable import ToMina

final class PackageCheckTests:XCTestCase {
    func testSharedRulesInJavaScriptCore() throws {
        let file=try XCTUnwrap(Bundle(for:Self.self).url(forResource:"PackageCheckFixtures",withExtension:"json",subdirectory:"Fixtures"))
        let fixture=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:file)) as? [String:Any])
        for item in fixture["cases"] as? [[String:Any]] ?? [] {
            let result=try PackageCheck.evaluate(try XCTUnwrap(item["input"] as? [String:Any])),codes=Set(result.issues.map{$0.code})
            for code in item["present"] as? [String] ?? [] {XCTAssertTrue(codes.contains(code),"\(item["name"] ?? "") missing \(code)")}
            for code in item["absent"] as? [String] ?? [] {XCTAssertFalse(codes.contains(code),"\(item["name"] ?? "") unexpected \(code)")}
        }
    }
    func testCollectorIncludesUnopenedFilesAndDraftWithoutWrites() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try fm.createDirectory(at:root,withIntermediateDirectories:true);defer{try? fm.removeItem(at:root)}
        let a=root.appendingPathComponent("a.ini"),b=root.appendingPathComponent("b.ini")
        try Data("[PANEL]\nSIZE=100,100\n".utf8).write(to:a)
        try XCTUnwrap("[PANEL]\nSIZE=100,100\n[KEY1]\nVIEW_RECT=0,0,20,20\nCENTER=た".data(using:.utf16)).write(to:b)
        try Data([71,73,70]).write(to:root.appendingPathComponent("broken.gif"))
        try Data("{bad".utf8).write(to:root.appendingPathComponent("appearanceConfig.json"))
        try Data(repeating:65,count:2*1024*1024+1).write(to:root.appendingPathComponent("large.ini"))
        let before=try Dictionary(uniqueKeysWithValues:SingleGIFCompiler.files(root).map{($0,try Data(contentsOf:$0))})
        let result=try PackageCheck.scan(root,drafts:[a:"[PANEL]\nSIZE=bad\n"])
        XCTAssertEqual(result.summary.files,5)
        XCTAssertTrue(result.issues.contains{$0.path=="a.ini" && $0.code=="number.shape"})
        XCTAssertFalse(result.issues.contains{$0.path=="b.ini"})
        XCTAssertTrue(result.issues.contains{$0.path=="broken.gif" && $0.code=="file.read"})
        XCTAssertTrue(result.issues.contains{$0.path=="appearanceConfig.json" && $0.code=="file.read"})
        XCTAssertTrue(result.issues.contains{$0.path=="large.ini" && $0.code=="coverage.skip"})
        for (file,bytes) in before {XCTAssertEqual(try Data(contentsOf:file),bytes)}
    }
}
