import Foundation
import JavaScriptCore
import ImageIO

enum PackageCheck {
    struct Issue: Codable, Identifiable, Sendable {
        let severity:String, path:String, line:Int, section:String, field:String, code:String, message:String, suggestion:String
        var id:String { [severity,path,String(line),section,field,code,message].joined(separator:"|") }
    }
    struct Summary: Codable, Sendable { let files:Int, configs:Int, images:Int, nativeFiles:Int, skipped:Int, error:Int, warning:Int, info:Int, total:Int, omitted:Int }
    struct Result: Codable, Sendable { let summary:Summary, issues:[Issue], report:String }
    static func collect(_ root:URL,drafts:[URL:String]=[:]) throws -> [String:Any] {
        guard let walk=FileManager.default.enumerator(at:root,includingPropertiesForKeys:[.isRegularFileKey,.isSymbolicLinkKey,.fileSizeKey]) else { throw SkinFailure(message:"无法读取底包") }
        var files:[URL]=[]
        for case let url as URL in walk { let v=try url.resourceValues(forKeys:[.isRegularFileKey,.isSymbolicLinkKey]);if v.isSymbolicLink==true || v.isRegularFile==true { guard files.count<6000 else { throw SkinFailure(message:"工程文件超过 6000 个，请分包检查") };files.append(url) } }
        var entries:[[String:Any]]=[],total=0
        for file in files.sorted(by:{$0.path<$1.path}) {
            let path=SkinConfiguration.relative(file,root:root),name=file.lastPathComponent.lowercased(),v=try file.resourceValues(forKeys:[.fileSizeKey,.isSymbolicLinkKey])
            var entry:[String:Any]=["path":path,"size":v.fileSize ?? 0]
            defer { entries.append(entry) }
            guard v.isSymbolicLink != true,file.resolvingSymlinksInPath().pathComponents.starts(with:root.resolvingSymlinksInPath().pathComponents) else { entry["limited"]="链接指向的内容未读取";continue }
            let native=name.range(of:"^(appearance|layout|animation|scene|sound)config(?:_[^.]+)?(?:\\.json)?$",options:.regularExpression) != nil
            let text=["ini","css","til","cnd","pop","anim","ani","json"].contains(file.pathExtension.lowercased())
            let image=["png","jpg","jpeg","webp","gif","apng","bmp"].contains(file.pathExtension.lowercased())
            do {
                if native || text {
                    let length=drafts[file]?.utf8.count ?? v.fileSize ?? 0
                    guard length<=2*1024*1024,total+length<=24*1024*1024 else { entry["limited"]="配置超过单文件 2 MB 或总配置 24 MB 的检查限制";continue };total+=length
                    let data=try drafts[file].map{Data($0.utf8)} ?? Data(contentsOf:file)
                    if native {
                        if name.hasSuffix(".json") { entry["native"]=try JSONSerialization.jsonObject(with:data) }
                        else {
                            let prefix=["appearance","layout","animation","scene","sound"].first{name.hasPrefix($0+"config")} ?? "layout"
                            let canonical=file.deletingLastPathComponent().appendingPathComponent(prefix+"Config")
                            let bytes=try BinaryPlaintext.decode(canonical,data:data,includeInspection:false)
                            let decoded=try JSONSerialization.jsonObject(with:bytes) as? [String:Any] ?? [:]
                            entry["native"]=decoded["decoded"] ?? decoded["data"] ?? [:]
                            entry["unknown"]=decoded["unknownFields"] ?? 0
                            if decoded["format"] as? String != "JSON",decoded["recognizedFields"] as? Int == 0 { entry["limited"]="原生配置结构可读取，但没有识别到可检查的字段" }
                        }
                    } else { entry["text"]=try drafts[file] ?? GlobalViewFit.decode(data).text }
                } else if image {
                    if name.hasSuffix(".gif") {
                        guard (v.fileSize ?? 0)<=32*1024*1024 else { entry["limited"]="GIF 超过 32 MB，未检查完整数据";continue }
                        let size=try SingleGIFCompiler.dimensions(Data(contentsOf:file));entry["image"]=[size.0,size.1]
                    } else if let source=CGImageSourceCreateWithURL(file as CFURL,[kCGImageSourceShouldCache:false] as CFDictionary),let properties=CGImageSourceCopyPropertiesAtIndex(source,0,nil) as? [CFString:Any],let width=properties[kCGImagePropertyPixelWidth] as? NSNumber,let height=properties[kCGImagePropertyPixelHeight] as? NSNumber,width.intValue>0,height.intValue>0 {
                        entry["image"]=[width.intValue,height.intValue]
                    } else if name.hasSuffix(".webp") { entry["limited"]="当前解码器无法识别此 WebP，请单独核对图片" }
                    else { throw SkinFailure(message:"无法读取有效图片尺寸，图片可能损坏或格式与后缀不符") }
                }
            } catch { entry["problem"]=error.localizedDescription }
        }
        return ["files":entries]
    }
    static func evaluate(_ input:[String:Any]) throws -> Result {
        guard let url=Bundle.main.url(forResource:"PackageCheck",withExtension:"js"),let context=JSContext() else { throw SkinFailure(message:"底包检查组件缺失") }
        context.evaluateScript(try String(contentsOf:url,encoding:.utf8))
        guard context.exception==nil else { throw SkinFailure(message:"底包检查组件加载失败") }
        let data=try JSONSerialization.data(withJSONObject:input,options:[.sortedKeys])
        context.setObject(String(decoding:data,as:UTF8.self),forKeyedSubscript:"packageCheckInput" as NSString)
        let value=context.evaluateScript("JSON.stringify(PackageCheck.run(JSON.parse(packageCheckInput)))")
        guard context.exception==nil,let text=value?.toString(),let bytes=text.data(using:.utf8) else { throw SkinFailure(message:context.exception?.toString() ?? "底包检查没有返回结果") }
        return try JSONDecoder().decode(Result.self,from:bytes)
    }
    static func scan(_ root:URL,drafts:[URL:String]=[:]) throws -> Result { try evaluate(collect(root,drafts:drafts)) }
}
