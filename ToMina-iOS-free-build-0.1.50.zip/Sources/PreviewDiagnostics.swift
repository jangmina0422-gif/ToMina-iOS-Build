import Foundation
import CryptoKit
import SwiftUI
import UIKit

enum PreviewDiagnostics {
    static func fingerprint(_ text:String)->String {
        SHA256.hash(data:Data(text.utf8)).prefix(6).map{String(format:"%02x",$0)}.joined()
    }
}
