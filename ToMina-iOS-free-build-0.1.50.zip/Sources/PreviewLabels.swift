import Foundation

// Preview captions only; original platform actions remain untouched.
enum PreviewLabels {
    static let functions:[String:String] = [
        "F1":"符号",
        "F3":"切换键盘",
        "F4":"返回",
        "F5":"软键盘",
        "F6":"数字",
        "F7":"表情",
        "F8":"收起",
        "F9":"更多候选",
        "F10":"大小写",
        "F11":"大写锁定",
        "F12":"网络面板",
        "F13":"换皮肤",
        "F14":"输入方式",
        "F15":"中文",
        "F16":"英文",
        "F17":"拨号",
        "F21":"菜单",
        "F22":"候选上翻",
        "F23":"候选下翻",
        "F24":"中文输入方式",
        "F25":"字母/联想",
        "F26":"单字/全部",
        "F27":"锁定符号",
        "F28":"英文排序",
        "F29":"候选上页",
        "F30":"候选下页",
        "F31":"Logo 菜单",
        "F32":"预备列表",
        "F36":"退格",
        "F37":"删除",
        "F38":"空格",
        "F39":"回车",
        "F40":"清除输入码",
        "F41":"Tab",
        "F42":"Home",
        "F43":"End",
        "F44":"剪切",
        "F45":"复制",
        "F46":"粘贴",
        "F47":"全选",
        "F48":"清空",
        "F49":"光标上移",
        "F50":"光标下移",
        "F51":"光标左移",
        "F52":"光标右移",
        "F53":"手写",
        "F54":"结束联想",
        "F55":"候选区域",
        "F56":"遮罩",
        "F61":"选字",
        "F62":"其他输入法",
        "F63":"选择输入法",
        "F64":"确认/关闭",
        "F65":"Win",
        "F66":"恢复",
        "F67":"撤销",
        "F68":"搜索",
        "F69":"短信",
        "F70":"应用功能",
        "F71":"表情符号",
        "F72":"语音",
        "F73":"多媒体",
        "F74":"颜文字",
        "F75":"换行",
        "F76":"剪贴板",
        "F77":"短语/筛选",
        "F78":"手写标志",
        "F79":"语音控制",
        "F80":"语音区域",
        "F81":"速成/仓颉",
        "F82":"搜索卡片",
        "F83":"快速编辑",
        "F84":"输入方式",
        "F85":"切换语种",
        "F86":"游戏键盘",
        "F87":"游戏和谐语料",
        "F88":"游戏语料",
        "F89":"快捷符号",
        "F90":"符号面板",
        "F91":"更多符号",
        "F92":"关闭联想",
        "F93":"长按符号",
        "F94":"空格左滑",
        "F95":"空格右滑",
        "F96":"悬浮键盘",
        "F97":"通知中心",
        "F99":"快速编辑"
    ]
    static let panels:[String:String] = [
        "cj":"仓颉",
        "zy":"注音",
        "ja":"日文",
        "ko":"韩文",
        "py_26":"拼音 26 键",
        "py_9":"拼音 9 键",
        "en_26":"英文 26 键",
        "en_9":"英文 9 键",
        "bh":"笔画",
        "hw_full":"全屏手写",
        "hw_grid":"手写",
        "num_9":"数字",
        "dial":"拨号",
        "email":"邮箱",
        "net":"网络",
        "symbol":"符号",
        "voice":"语音",
        "message_num":"短信数字",
        "def_26":"默认 26 键",
        "def_9":"默认 9 键",
        "sel_ch":"中文候选",
        "sel_en":"英文候选"
    ]
    static func function(_ action:String)->Bool { action.trimmingCharacters(in:.whitespacesAndNewlines).range(of:"^F[0-9]+$",options:[.regularExpression,.caseInsensitive]) != nil }
    static func caption(_ action:String)->String {let code=action.trimmingCharacters(in:.whitespacesAndNewlines).uppercased();return function(action) ? functions[code] ?? "未知功能 "+code:action}
    static func isJapanese(_ name:String)->Bool { let stem=(name as NSString).deletingPathExtension.lowercased();return stem=="ja" || stem.hasPrefix("ja_") }
    static func iniOverride(_ values:[String:String],panel:String)->String? {
        guard isJapanese(panel),values["SHOW"] != nil || values["CENTER"] != nil else{return nil}
        return keyCaption(values)
    }
    static func keyCaption(_ values:[String:String],fallback:String="")->String { caption(values["SHOW"] ?? values["CENTER"] ?? values["KEY"] ?? fallback) }
    static func panel(_ name:String)->String {
        let stem=(name as NSString).deletingPathExtension.lowercased()
        if stem=="ja" { return "日文 · 平假名" };if stem=="ja_shifts" { return "日文 · 片假名" }
        if let title=panels[stem]{return title}
        for key in ["cj","ja","ko","zy"] where stem.hasPrefix(key+"_") {return (panels[key] ?? key)+" · "+(stem.hasSuffix("_shifts") ? "大写":String(stem.dropFirst(key.count+1)))}
        return stem
    }
}
