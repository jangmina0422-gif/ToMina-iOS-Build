import XCTest
import UIKit
@testable import ToMina
final class SourceLineTests:XCTestCase {
    func testLogicalLinesUseUTF16AndKeepTrailingEmptyLine() {
        var lines=SourceLineIndex();lines.update("");XCTAssertEqual(lines.count,1)
        lines.update("a\r\nた😀\n\nlast\r")
        XCTAssertEqual(lines.starts,[0,3,7,8,13]);XCTAssertEqual(lines.line(at:3),2)
        XCTAssertEqual(lines.line(at:6),2);XCTAssertEqual(lines.line(at:7),3)
        XCTAssertEqual(lines.line(at:13),5);XCTAssertEqual(lines.line(at:0),1)
        lines.update(String(repeating:"q",count:500)+"\nend")
        XCTAssertEqual(lines.count,2);XCTAssertEqual(lines.line(at:400),1)
    }
    @MainActor func testGutterKeepsSourceAndTracksSelectionAfterResize() throws {
        let view=SourceTextView(frame:CGRect(x:0,y:0,width:280,height:240))
        let text="[KEY1]\nSHOW=た\n"+String(repeating:"; long source line ",count:30)+"\n"
        view.text=text;view.font = .systemFont(ofSize:14);view.refreshLineNumbers(rebuild:true)
        view.selectedRange=NSRange(location:(text as NSString).length,length:0)
        view.layoutIfNeeded();XCTAssertEqual(view.sourceLines.count,4)
        XCTAssertEqual(view.sourceLines.line(at:view.selectedRange.location),4)
        view.frame.size.width=160;view.layoutIfNeeded();XCTAssertEqual(view.sourceLines.count,4)
        XCTAssertEqual(view.text,text);XCTAssertGreaterThan(view.textContainerInset.left,30)
        let label=try XCTUnwrap(view.subviews.compactMap{$0 as? UILabel}.first)
        XCTAssertTrue(label.text?.contains("第 4 行 / 共 4 行")==true)
        let renderer=UIGraphicsImageRenderer(bounds:view.bounds)
        _=renderer.image{view.layer.render(in:$0.cgContext)}
        XCTAssertEqual(view.text,text)
    }
    @MainActor func testKeyboardOnlyChangesEditorScrollInsets() {
        let window=UIWindow(frame:CGRect(x:0,y:0,width:400,height:800)),controller=UIViewController()
        window.rootViewController=controller;window.makeKeyAndVisible();defer{window.isHidden=true}
        let view=SourceTextView(frame:CGRect(x:20,y:220,width:360,height:500));controller.view.addSubview(view)
        view.text=String(repeating:"line\n",count:200);view.refreshLineNumbers(rebuild:true);view.layoutIfNeeded()
        let before=view.frame,text=view.text
        let rectangle=window.convert(CGRect(x:0,y:view.frame.maxY-180,width:window.bounds.width,height:800),to:window.screen.coordinateSpace)
        NotificationCenter.default.post(name:UIResponder.keyboardWillChangeFrameNotification,object:nil,userInfo:[UIResponder.keyboardFrameEndUserInfoKey:NSValue(cgRect:rectangle)])
        XCTAssertEqual(view.frame,before);XCTAssertEqual(view.keyboardOcclusion,180,accuracy:1);XCTAssertEqual(view.contentInset.bottom,180,accuracy:1);XCTAssertEqual(view.text,text)
        NotificationCenter.default.post(name:UIResponder.keyboardWillHideNotification,object:nil)
        XCTAssertEqual(view.frame,before);XCTAssertEqual(view.contentInset.bottom,0);XCTAssertEqual(view.text,text)
    }

}
