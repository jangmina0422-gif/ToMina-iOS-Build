import XCTest
import SwiftUI
import UIKit
import ImageIO
import UniformTypeIdentifiers
@testable import ToMina

final class PreviewPerformanceTests: XCTestCase {
    func testCompactWindowSizingKeepsRoomForEditing() {
        XCTAssertEqual(PreviewSizing.height(available:CGSize(width:400,height:900),tablet:true),232)
        XCTAssertEqual(PreviewSizing.height(available:CGSize(width:680,height:900),tablet:true),264)
        XCTAssertEqual(PreviewSizing.height(available:CGSize(width:1000,height:900),tablet:true),320)
        XCTAssertEqual(PreviewSizing.height(available:CGSize(width:390,height:800),tablet:false),264)
        XCTAssertEqual(PreviewSizing.height(available:CGSize(width:600,height:400),tablet:true),180)
        XCTAssertEqual(PreviewSizing.height(available:CGSize(width:400,height:260),tablet:true),64)
        let panel=CGSize(width:1080,height:760) // includes the top candidate bar
        for width in [CGFloat(400),680] {
            let height=PreviewSizing.height(available:CGSize(width:width,height:900),tablet:true)
            let scale=min((width-16)/panel.width,(height-16)/panel.height)
            XCTAssertLessThanOrEqual(panel.width*scale,width-16)
            XCTAssertLessThanOrEqual(panel.height*scale,height-16)
            XCTAssertGreaterThan(scale,0)
        }
    }
    @MainActor private func png(_ color:UIColor,size:CGSize=CGSize(width:64,height:32))->Data {
        let format=UIGraphicsImageRendererFormat();format.scale=1
        return UIGraphicsImageRenderer(size:size,format:format).image{canvas in
            color.setFill();canvas.fill(CGRect(origin:.zero,size:size))
        }.pngData()!
    }
    @MainActor func testDecodedFramesAndCropsAreReusedAndInvalidated() throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        defer{try? FileManager.default.removeItem(at:directory)}
        let file=directory.appendingPathComponent("atlas.png"),cache=PreviewImageCache()
        try png(.red).write(to:file)
        let original=try XCTUnwrap(cache.image(file))
        let rect=CGRect(x:0,y:0,width:32,height:32),piece=try XCTUnwrap(cache.crop(original,rect:rect))
        let start=Date()
        for _ in 0..<1000 {
            XCTAssertTrue(try XCTUnwrap(cache.image(file)) === original)
            XCTAssertTrue(try XCTUnwrap(cache.crop(original,rect:rect)) === piece)
        }
        XCTAssertEqual(cache.decodeCount,1);XCTAssertEqual(cache.cropCount,1)
        print("PREVIEW_CACHE: 1000 reads/crops, one decode and one crop; seconds=\(Date().timeIntervalSince(start))")
        try png(.blue).write(to:file);cache.clear()
        let replacement=try XCTUnwrap(cache.image(file))
        XCTAssertFalse(replacement === original)
        XCTAssertEqual(cache.decodeCount,1);XCTAssertEqual(cache.cropCount,0)
        XCTAssertEqual(try rgb(replacement,x:16,y:16),[0,0,255])
    }
    @MainActor func testAnimatedImageFramesKeepTheirTimingAndIdentity() throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        defer{try? FileManager.default.removeItem(at:directory)}
        let file=directory.appendingPathComponent("frames.gif"),cache=PreviewImageCache()
        let destination=try XCTUnwrap(CGImageDestinationCreateWithURL(file as CFURL,UTType.gif.identifier as CFString,2,nil))
        for color in [UIColor.red,.blue] {
            let raw=try XCTUnwrap(UIImage(data:png(color))?.cgImage)
            CGImageDestinationAddImage(destination,raw,[kCGImagePropertyGIFDictionary:[kCGImagePropertyGIFDelayTime:0.1]] as CFDictionary)
        }
        XCTAssertTrue(CGImageDestinationFinalize(destination));XCTAssertTrue(cache.animated(file))
        XCTAssertEqual(cache.loopIndex(file,time:0.05),0);XCTAssertEqual(cache.loopIndex(file,time:0.15),1)
        XCTAssertEqual(cache.loopIndex(file,time:0.25),0)
        let red=try XCTUnwrap(cache.image(file,index:0)),blue=try XCTUnwrap(cache.image(file,index:1))
        XCTAssertEqual(try rgb(red,x:16,y:16),[255,0,0]);XCTAssertEqual(try rgb(blue,x:16,y:16),[0,0,255])
        XCTAssertTrue(try XCTUnwrap(cache.image(file,index:0)) === red);XCTAssertEqual(cache.decodeCount,2)
    }
    @MainActor func testIniTapCompletionParticlesAndLiveTileEdits() throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString),res=directory.appendingPathComponent("res")
        try FileManager.default.createDirectory(at:res,withIntermediateDirectories:true)
        defer{try? FileManager.default.removeItem(at:directory)}
        let config=directory.appendingPathComponent("py_26.ini"),css=res.appendingPathComponent("default.css"),tile=res.appendingPathComponent("atlas.til"),image=res.appendingPathComponent("atlas.png")
        let text="[PANEL]\nSIZE=160,80\nANIM_STYLE=3\n[KEY1]\nVIEW_RECT=16,16,32,32\nBACK_STYLE=1\nFORE_ANIM_STYLE=2\n"
        let definitions="[STYLE1]\nNM_IMG=atlas,1\n[STYLE2]\nPRESS_ANIM=20\n[STYLE3]\nSHOW_ANIM=10\n[ANIM10]\nCATEGORY=3\nEMIT_TYPE=1\nTOTAL_NUMBER=32\nPARTICLE_IMAGE=1\nLIFE=800\nDELAY=200\nREPEAT_CNT=1\n[ANIM20]\nBUILD_LIST=21,22\nDELAY=100\nREPEAT_CNT=1\n[ANIM21]\nTYPE=2\nFROM=0,0\nTO=0,-40\nDURATION=250\nANIM_PATH=res/atlas.png\n[ANIM22]\nTYPE=4\nFROM=60,60\nTO=80,80\nDURATION=250\n"
        try text.write(to:config,atomically:true,encoding:.utf8);try definitions.write(to:css,atomically:true,encoding:.utf8)
        try "[IMG1]\nSOURCE_RECT=0,0,32,32\n".write(to:tile,atomically:true,encoding:.utf8)
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let atlas=UIGraphicsImageRenderer(size:CGSize(width:64,height:32),format:format).image{canvas in
            UIColor.red.setFill();canvas.fill(CGRect(x:0,y:0,width:32,height:32))
            UIColor.blue.setFill();canvas.fill(CGRect(x:32,y:0,width:32,height:32))
        }
        try XCTUnwrap(atlas.pngData()).write(to:image)
        let renderer=IniSkinRenderer(),files=[config,css,tile,image]
        renderer.configure(root:directory,config:config,files:files,text:text)
        XCTAssertEqual(renderer.refreshPlan(mode:"",ios:true),.idle)
        renderer.animationEnabled=true;renderer.trigger("KEY1")
        let plan=renderer.refreshPlan(mode:"key",ios:true),deadline=try XCTUnwrap(plan.deadline)
        XCTAssertEqual(deadline.timeIntervalSince(renderer.animationStart),0.35,accuracy:0.0001)
        XCTAssertTrue(plan.active(at:renderer.animationStart.addingTimeInterval(0.3)))
        XCTAssertFalse(plan.active(at:deadline));XCTAssertTrue(renderer.timeline.sample("20",300).running)
        XCTAssertFalse(renderer.timeline.sample("20",350).running)
        renderer.animationEnabled=false;renderer.restartFloating()
        let floating=renderer.refreshPlan(mode:"floating",ios:true)
        XCTAssertEqual(try XCTUnwrap(floating.deadline).timeIntervalSince(renderer.floatingStart),1,accuracy:0.0001)
        renderer.floatingPausedAt=renderer.floatingStart.addingTimeInterval(0.4)
        XCTAssertEqual(renderer.refreshPlan(mode:"floating",ios:true),.idle)
        let key=KeyShape(id:0,name:"KEY1",rect:CGRect(x:16,y:16,width:32,height:32),caption:"q")
        func render(floating:Bool) throws -> CGImage {
            let canvas=Canvas{context,_ in
                renderer.key(key,pressed:false,context:&context)
                if floating{renderer.floating(size:CGSize(width:160,height:80),ios:true,context:&context)}
            }.frame(width:160,height:80)
            let output=ImageRenderer(content:canvas);output.scale=1
            return try XCTUnwrap(output.uiImage?.cgImage)
        }
        XCTAssertEqual(try rgb(render(floating:false),x:32,y:32),[255,0,0])
        let start=Date()
        for _ in 0..<60{_ = try render(floating:true)}
        XCTAssertEqual(renderer.imageCache.decodeCount,1);XCTAssertEqual(renderer.imageCache.cropCount,1)
        XCTAssertEqual(renderer.tileReadCount,1)
        print("PREVIEW_PARTICLES: 60 renders with 32 particles; one atlas decode/crop/parse; seconds=\(Date().timeIntervalSince(start))")
        renderer.configure(root:directory,config:config,files:files,text:text,overrides:[tile:"[IMG1]\nSOURCE_RECT=32,0,32,32\n"])
        XCTAssertEqual(try rgb(render(floating:false),x:32,y:32),[0,0,255],"Live tile edits used stale cached pixels")
    }
    @MainActor func testBdaStaticPreviewSleepsAndTapReplaysFully() throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        defer{try? FileManager.default.removeItem(at:directory)}
        let file=directory.appendingPathComponent("atlas.png");try png(.red).write(to:file)
        let engine=BdaPreviewEngine(root:directory,files:[file]),epoch=Date()
        let item=BdaPreviewEngine.Item(id:"KEY1",kind:"keys",data:["backStyle":["key":1]],rect:CGRect(x:0,y:0,width:64,height:32))
        engine.panelID="test";engine.panels["test"] = .init(id:"test",data:[:],size:CGSize(width:64,height:32),items:[item])
        engine.images=["1":["normalImage":["resource":["resourceID":"atlas.png"]]]]
        XCTAssertEqual(engine.refreshPlan(epoch:epoch),.idle)
        let original=try XCTUnwrap(engine.image("atlas.png",time:0))
        for _ in 0..<60{XCTAssertTrue(try XCTUnwrap(engine.image("atlas.png",time:1)) === original)}
        XCTAssertEqual(engine.imageCache.decodeCount,1)
        engine.animations=[.init(id:"tap",frames:["atlas.png","atlas.png"],durations:[100,100],target:["KEY1"],event:"PRESS")]
        XCTAssertEqual(engine.refreshPlan(epoch:epoch),.idle)
        engine.triggerKey("KEY1",at:epoch)
        let tap=engine.refreshPlan(epoch:epoch)
        XCTAssertTrue(tap.active(at:epoch.addingTimeInterval(0.15)));XCTAssertFalse(tap.active(at:epoch.addingTimeInterval(0.2)))
        XCTAssertNotNil(engine.tapTime(engine.animations[0],"KEY1",at:epoch.addingTimeInterval(0.15)))
        XCTAssertNil(engine.tapTime(engine.animations[0],"KEY1",at:epoch.addingTimeInterval(0.2)))
        engine.triggerKey("KEY1",at:epoch.addingTimeInterval(1))
        XCTAssertTrue(engine.refreshPlan(epoch:epoch).active(at:epoch.addingTimeInterval(1.15)),"Second tap did not restart")
        engine.animations[0].event="";engine.animations[0].loop=true
        XCTAssertTrue(engine.refreshPlan(epoch:epoch).continuous)
    }
    private func rgb(_ image:CGImage,x:Int,y:Int) throws -> [UInt8] {
        let crop=try XCTUnwrap(image.cropping(to:CGRect(x:x,y:y,width:1,height:1)))
        var bytes=[UInt8](repeating:0,count:4)
        try bytes.withUnsafeMutableBytes{buffer in
            let context=try XCTUnwrap(CGContext(data:buffer.baseAddress,width:1,height:1,bitsPerComponent:8,bytesPerRow:4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue))
            context.draw(crop,in:CGRect(x:0,y:0,width:1,height:1))
        }
        return Array(bytes.prefix(3))
    }
}
