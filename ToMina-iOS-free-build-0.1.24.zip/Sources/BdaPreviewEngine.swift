import Foundation
import SwiftUI
import ImageIO
import CoreText
import AVFoundation

@MainActor final class BdaPreviewEngine {
    struct Item {
        var id:String; var kind:String; var data:[String:Any]
        var rect:CGRect?; var source="explicit"; var confidence:Double=1
        var visible=true
    }
    struct Panel {
        var id:String;var data:[String:Any];var size:CGSize;var items:[Item]
    }
    let root:URL;let files:[URL]
    private var drafts:[URL:Data]=[:]
    var config:URL?
    var panels:[String:Panel]=[:]
    var panelID="py_26"
    var images:[String:Any]=[:],texts:[String:Any]=[:],colors:[String:Any]=[:]
    var notes:[String]=[], statuses:[String]=[]
    var missing=Set<String>()
    var mode="",type=""
    struct Animation {var id:String;var frames:[String];var durations:[Double];var loop=false;var repeats=1.0;var target:[String]=[];var event="";var background=false;var rect:CGRect?;var kind="frames"}
    var animations:[Animation]=[],animationChoice=""
    private var tapKey=""
    private var tapStarted=Date()
    func triggerKey(_ key:String,at date:Date=Date()) { tapKey=key;tapStarted=date }
    func tapTime(_ animation:Animation,_ key:String,at date:Date=Date())->TimeInterval? {
        guard tapKey==key,animation.target.contains(key),!animation.event.isEmpty,!animation.frames.isEmpty else{return nil}
        let elapsed=date.timeIntervalSince(tapStarted)
        let duration=animation.durations.reduce(0,+)/1000
        return elapsed>=0 && elapsed<duration ? elapsed:nil
    }
    private var videos:[URL:AVAssetImageGenerator]=[:]
    let imageCache = PreviewImageCache()
    private var resolvedImages:[String:URL]=[:]
    private var unresolvedImages=Set<String>()
    private var fontNames:[URL:String]=[:]
    var panel:Panel? { panels[panelID] }
    var size:CGSize { panel?.size ?? CGSize(width:1,height:1) }
    var minY:CGFloat { min(0,panel?.items.compactMap{$0.rect?.minY}.min() ?? 0) }
    init(root:URL,files:[URL]) { self.root=root;self.files=files }
    static func object(_ value:Any?) -> [String:Any] { value as? [String:Any] ?? [:] }
    static func number(_ value:Any?,_ fallback:CGFloat=0) -> CGFloat {
        let d=(value as? NSNumber)?.doubleValue ?? Double(value as? String ?? "") ?? Double(fallback)
        return d.isFinite ? CGFloat(d):fallback
    }
    static func string(_ value:Any?) -> String { value.map{String(describing:$0)} ?? "" }
    static func entries(_ value:Any?) -> [String:Any] {
        if let map=value as? [String:Any] { return map }
        var out:[String:Any]=[:]
        for (index,item) in (value as? [[String:Any]] ?? []).enumerated() { out[string(item["name"] ?? item["id"] ?? "item_\(index)")]=item }
        return out
    }
    static func merge(_ base:[String:Any],_ preferred:[String:Any]) -> [String:Any] {
        var out=base
        for (key,value) in preferred {
            if let child=value as? [String:Any],let old=out[key] as? [String:Any] { out[key]=merge(old,child) } else { out[key]=value }
        }
        return out
    }
    static func rect(_ value:Any?) -> CGRect? {
        let d=object(value)
        for key in ["viewRect","frame","bounds","rect","layoutRect"] { if let v=d[key],let r=directRect(v) { return r } }
        return directRect(value)
    }
    private static func directRect(_ value:Any?) -> CGRect? {
        if let a=value as? [Any],a.count==4 { let r=CGRect(x:number(a[0]),y:number(a[1]),width:number(a[2]),height:number(a[3]));return r.width>0 && r.height>0 ? r:nil }
        let d=object(value)
        var origin=object(d["original"] ?? d["origin"] ?? d["position"]),size=object(d["size"])
        if origin.isEmpty { origin=d };if size.isEmpty { size=d }
        let r=CGRect(x:number(origin["x"] ?? d["left"]),y:number(origin["y"] ?? d["top"]),width:number(size["width"] ?? size["w"]),height:number(size["height"] ?? size["h"]))
        return r.width>0 && r.height>0 ? r:nil
    }
    private func rank(_ file:URL,_ color:String,_ orientation:String) -> Int {
        let parts=file.path.lowercased().components(separatedBy:"/")
        var value=0
        if parts.contains(color) { value += 100 } else if parts.contains(color=="dark" ? "light":"dark") { value -= 25 }
        if parts.contains(orientation) { value += 60 } else if parts.contains(orientation=="port" ? "land":"port") { value -= 40 }
        if let config,file.deletingLastPathComponent()==config.deletingLastPathComponent() { value += 250 }
        return value
    }
    private func read(_ kind:String,_ color:String,_ orientation:String) -> [String:Any] {
        let candidates=files.filter { let name=$0.lastPathComponent.lowercased();return name==kind.lowercased() || name==kind.lowercased()+".json" }.sorted {
            let a=rank($0,color,orientation),b=rank($1,color,orientation)
            if a != b { return a>b };return $0.pathExtension=="json" && $1.pathExtension != "json"
        }
        if candidates.isEmpty { statuses.append(kind+"：不存在");return [:] }
        var result:[String:Any]=[:],selected:URL?
        for file in candidates {
            if let selected,file.deletingLastPathComponent() != selected.deletingLastPathComponent() { continue }
            do {
                let data=try drafts[file] ?? Data(contentsOf:file)
                guard data.count<=32*1024*1024 else { throw SkinFailure(message:"配置过大") }
                let value:[String:Any]
                if let json=try? JSONSerialization.jsonObject(with:data) as? [String:Any] { value=json;type += type.contains("JSON") ? "":" JSON" }
                else {
                    let decoded=try JSONSerialization.jsonObject(with:BinaryPlaintext.decode(file,data:data)) as? [String:Any] ?? [:]
                    value=Self.object(decoded["decoded"]);type += type.contains("Binary") ? "":" Binary"
                    if Self.number(decoded["unknownFields"])>0 { notes.append(kind+"：包含未映射字段") }
                }
                guard !value.isEmpty else { throw SkinFailure(message:"未识别可用字段") }
                result=Self.merge(value,result);selected=file
                if kind=="appearanceConfig",config==nil { config=file }
                statuses.append(kind+"：已读取 "+String(file.path.dropFirst(root.path.count+1)))
            } catch { statuses.append(kind+"：不支持 / "+error.localizedDescription) }
        }
        return result
    }
    func load(color:String,orientation:String,overrides:[URL:Data]=[:]) {
        drafts=overrides
        imageCache.clear();videos.removeAll();resolvedImages=[:];unresolvedImages=[]
        config=nil;panels=[:];notes=[];statuses=[];missing=[];type=""
        let appearance=read("appearanceConfig",color,orientation)
        let actualParts=config?.path.lowercased().components(separatedBy:"/") ?? []
        mode=(actualParts.contains("dark") ? "dark":"light")+" / "+(actualParts.contains("land") ? "land":"port")
        if mode != color+" / "+orientation { notes.append("请求模式不存在，已回退到 "+mode) }
        let layout=read("layoutConfig",color,orientation)
        let animation=read("animationConfig",color,orientation),scene=read("sceneConfig",color,orientation)
        loadAnimations(animation,scene)
        images=Self.entries(appearance["imageStyles"]);texts=Self.entries(appearance["textStyles"]);colors=Self.entries(appearance["colorStyles"])
        let ap=Self.entries(appearance["panels"]),lp=Self.entries(layout["panels"] ?? layout["panel"])
        let sceneSize=Self.object(scene["size"])
        let declaredWidth=Self.number(appearance["designWidth"] ?? layout["designWidth"])
        let width=declaredWidth>0 ? declaredWidth:Self.number(sceneSize["width"])
        let declaredHeight=Self.number(appearance["designHeight"] ?? layout["designHeight"])
        let height=declaredHeight>0 ? declaredHeight:Self.number(sceneSize["height"])
        for id in Set(ap.keys).union(lp.keys).sorted() {
            let a=Self.object(ap[id]),l=Self.object(lp[id]),d=Self.merge(l,a)
            let declared=Self.object(l["size"])
            var size=CGSize(width:Self.number(declared["width"] ?? d["designWidth"] ?? d["width"],width),height:Self.number(declared["height"] ?? d["designHeight"] ?? d["height"],height))
            var items:[Item]=[]
            for kind in ["keys","lists","images","textItems"] {
                for (name,value) in Self.entries(d[kind]).sorted(by:{$0.key.localizedStandardCompare($1.key) == .orderedAscending}) {
                    let data=Self.object(value);var r=Self.rect(data)
                    if r==nil,kind=="lists" {
                        let pos=Self.object(data["pos"]),cell=Self.object(data["cellSize"]),count=Self.number(data["listNum"] ?? data["count"])
                        let w=Self.number(cell["width"]),h=Self.number(cell["height"])*count
                        if w>0,h>0 { r=CGRect(x:Self.number(pos["x"]),y:Self.number(pos["y"]),width:w,height:h) }
                    }
                    let source=Self.rect(Self.entries(a[kind])[name]) != nil ? "explicit":"layoutConfig"
                    var item=Item(id:name,kind:kind,data:data,rect:r,source:source,confidence:source=="explicit" ? 1:0.9)
                    if name.range(of:"_S[0-9]+$",options:.regularExpression) != nil || (name=="KEY_" && data.count==1) || (data["isTip"] as? Bool)==true { item.visible=false }
                    items.append(item)
                }
            }
            for key in ["wholeBackStyle","backStyle"] where d[key] != nil { items.insert(Item(id:key,kind:"background",data:["backStyle":d[key]!]),at:0) }
            let cand=Self.object(d["cand"])
            if !cand.isEmpty { items.append(Item(id:"cand",kind:"cand",data:cand,rect:Self.rect(cand)))
                for (name,value) in Self.entries(cand["candKeys"]) { items.append(Item(id:name,kind:"candKey",data:Self.object(value),rect:Self.rect(value))) }
            }
            for key in ["input","more"] { let value=Self.object(d[key]);if !value.isEmpty { items.append(Item(id:key,kind:key,data:value,rect:Self.rect(value))) } }
            for item in items where item.kind=="background" {
                if let image=imageForReference(item.data["backStyle"],time:0) {
                    if size.width<=0 { size.width=CGFloat(image.width) }
                    if size.height<=0 { size.height=CGFloat(image.height)*size.width/CGFloat(image.width) }
                }
            }
            if size.width<=0 { size.width=items.compactMap{$0.rect?.maxX}.max() ?? 0 }
            if size.width<=0 {
                size.width=max(1,(items.compactMap{imageForReference($0.data["backStyle"],time:0)?.width}.max() ?? 1)*10).cg
                notes.append(id+"：宽度按资源推算")
            }
            if size.height<=0 { size.height=items.compactMap{$0.rect?.maxY}.max() ?? size.width*(orientation=="land" ? 0.36:0.6) }
            var panel=Panel(id:id,data:d,size:size,items:items)
            recover(&panel,layout:l)
            panels[id]=panel
        }
        if panels[panelID]==nil { panelID=panels["py_26"] != nil ? "py_26":(panels.keys.sorted().first ?? "") }
    }
    func resolve(_ name:String) -> URL? {
        let name=name.replacingOccurrences(of:"\\",with:"/").lowercased()
        guard !name.isEmpty,!name.hasPrefix("/"),!name.components(separatedBy:"/").contains(".."),!name.contains(":") else { return nil }
        if let cached=resolvedImages[name]{return cached};if unresolvedImages.contains(name){return nil}
        let context=config?.deletingLastPathComponent() ?? root
        for url in [root.appendingPathComponent(name),root.appendingPathComponent("res/"+name),context.appendingPathComponent(name),context.appendingPathComponent("res/"+name)] {
            if let f=files.first(where:{$0.path.lowercased()==url.path.lowercased()}) { resolvedImages[name]=f;return f }
        }
        let base=(name as NSString).lastPathComponent
        let candidates=files.filter{$0.lastPathComponent.lowercased()==base || $0.deletingPathExtension().lastPathComponent.lowercased()==base}
        let parts=context.path.lowercased().components(separatedBy:"/")
        let ranked=candidates.sorted { a,b in
            func score(_ file:URL)->Int { let p=file.path.lowercased().components(separatedBy:"/");return zip(parts,p).prefix(while:{$0.0==$0.1}).count*10 }
            return score(a)==score(b) ? a.path<b.path:score(a)>score(b)
        }
        if let file=ranked.first { resolvedImages[name]=file;return file };unresolvedImages.insert(name);missing.insert(name);return nil
    }
    func image(_ name:String,time:TimeInterval) -> CGImage? {
        guard let url=resolve(name) else { return nil }
        if ["mp4","mov","m4v"].contains(url.pathExtension.lowercased()) {
            if videos[url]==nil {let generator=AVAssetImageGenerator(asset:AVURLAsset(url:url));generator.appliesPreferredTrackTransform=true;generator.maximumSize=CGSize(width:2048,height:2048);videos[url]=generator}
            let seconds=max(0,min(time,86400)),frame=Int(seconds*30)
            return imageCache.frame(key:"video:"+url.path+":\(frame)") {
                try? videos[url]?.copyCGImage(at:CMTime(seconds:seconds,preferredTimescale:600),actualTime:nil)
            }
        }
        return imageCache.image(url,index:imageCache.loopIndex(url,time:time),maximum:4096)
    }
    func refreshPlan(epoch:Date)->PreviewRefreshPlan {
        guard let panel else{return .idle}
        var plan=PreviewRefreshPlan.idle,resources=Set<String>(),seenStyles=Set<String>()
        func collect(_ value:Any,_ depth:Int=0) {
            guard depth<16 else{return}
            if let dictionary=value as? [String:Any] {
                for name in ["resourceID","imagePath"] {
                    let resource=Self.string(dictionary[name]);if !resource.isEmpty{resources.insert(resource)}
                }
                let key=Self.string(dictionary["key"])
                if !key.isEmpty,seenStyles.insert(key).inserted,let style=images[key]{collect(style,depth+1)}
                for (name,child) in dictionary {
                    if ["wholeBackStyle","backStyle","candBarStyle","foreStyle","foreStyles","textStyle","cellBackStyle","cellForeStyle"].contains(name) {
                        for reference in (child as? [Any] ?? [child]) {
                            let key=Self.string(reference as? NSNumber)
                            if !key.isEmpty,seenStyles.insert(key).inserted,let style=images[key]{collect(style,depth+1)}
                        }
                    }
                    collect(child,depth+1)
                }
            } else if let array=value as? [Any] {for child in array{collect(child,depth+1)}}
        }
        let visible=Set(panel.items.filter{$0.visible}.map{$0.id})
        for item in panel.items where item.visible{collect(item.data)}
        for resource in resources {
            if let url=resolve(resource),imageCache.animated(url){plan.include(.repeating)}
        }
        for animation in animations where !animation.frames.isEmpty {
            if !animation.event.isEmpty,animation.target.contains(tapKey),visible.contains(tapKey) {
                let duration=animation.durations.reduce(0,+)/1000
                if duration>0 {plan.include(.until(tapStarted.addingTimeInterval(duration)))}
            }
            let automatic=animation.event.isEmpty && !animation.target.filter({visible.contains($0)}).isEmpty
            guard animation.id==animationChoice || automatic else{continue}
            let duration=animation.durations.reduce(0,+)*max(1,animation.repeats)/1000
            if animation.frames.count>1,duration>0 {
                plan.include(animation.loop ? .repeating:.until(epoch.addingTimeInterval(duration)))
            }
            for resource in animation.frames {
                if let url=resolve(resource),imageCache.animated(url){plan.include(.repeating)}
            }
        }
        return plan
    }

    private func imageForReference(_ ref:Any?,time:TimeInterval) -> CGImage? {
        let r=Self.object(ref),style=Self.object(images[Self.string(r["key"])])
        let resource=Self.object(Self.object(style["normalImage"])["resource"])
        return image(Self.string(resource["resourceID"]),time:time)
    }
    func animationReport() -> String {
        animations.map { a in
            let status=a.frames.isEmpty ? "未支持播放":"帧资源已识别"
            let resources=a.frames.map { resolve($0)==nil ? $0+"（缺失）":$0 }.joined(separator:", ")
            return "\(a.id) · \(a.kind) · \(status)\n绑定：\(a.target.joined(separator:", ")) · 事件：\(a.event)\n资源：\(resources)"
        }.joined(separator:"\n")
    }
    func log() -> String {
        let report=animationReport()
        let all=panels.values.flatMap{$0.items}.filter{$0.kind=="keys" && $0.visible}
        let explicit=all.filter{$0.source=="explicit"}.count
        let layout=all.filter{$0.source=="layoutConfig"}.count
        let inferred=all.filter{["semanticInference","fallback","panelRule"].contains($0.source)}.count
        var lines=["BDA 类型：\(type)","模式：\(mode)"]
        lines.append(contentsOf:statuses)
        lines.append(contentsOf:["Panels：\(panels.count)","Keys：\(all.count)","Explicit Position：\(explicit)","LayoutConfig Position：\(layout)","Inferred Position：\(inferred)"])
        lines.append(contentsOf:["Images：\(images.count)","Text：\(texts.count)","Missing Resources：\(missing.count)"])
        lines.append(contentsOf:notes)
        lines.append("Animations：\(animations.count)")
        lines.append(report)
        return lines.joined(separator:"\n")
    }
}
private extension Int { var cg:CGFloat { CGFloat(self) } }

extension BdaPreviewEngine {
    private func color(_ value:Any?,fallback:Color = .clear)->Color {
        let text=Self.string(value)
        var integer:UInt64?
        if text.hasPrefix("#") { integer=UInt64(text.dropFirst(),radix:16);if text.count==7,let n=integer { integer=n|0xff000000 } }
        else if let n=value as? NSNumber { integer=n.uint64Value }
        else { integer=UInt64(text) }
        guard let n=integer else{return fallback}
        return Color(.sRGB,red:Double((n>>16)&255)/255,green:Double((n>>8)&255)/255,blue:Double(n&255)/255,opacity:Double((n>>24)&255)/255)
    }
    private func font(_ spec:[String:Any],size:CGFloat)->Font {
        let requested=Self.string(spec["fontName"] ?? Self.object(spec["resource"])["resourceID"])
        let file=requested.isEmpty ? files.first(where:{["ttf","otf","ttc"].contains($0.pathExtension.lowercased())}):resolve(requested)
        guard let file else{return .system(size:size)}
        if fontNames[file]==nil {
            CTFontManagerRegisterFontsForURL(file as CFURL,.process,nil)
            if let descriptors=CTFontManagerCreateFontDescriptorsFromURL(file as CFURL) as? [CTFontDescriptor],let descriptor=descriptors.first { fontNames[file]=CTFontCopyPostScriptName(CTFontCreateWithFontDescriptor(descriptor,size,nil)) as String }
        }
        return fontNames[file].map{Font.custom($0,fixedSize:size)} ?? .system(size:size)
    }
    private func drawImage(_ image:CGImage,rect:CGRect,spec:[String:Any],natural:Bool,context:inout GraphicsContext) {
        let width=CGFloat(image.width),height=CGFloat(image.height)
        guard rect.width>0,rect.height>0 else{return}
        if let inner=Self.rect(spec["innerRect"]),CGRect(x:0,y:0,width:width,height:height).contains(inner) {
            let left=inner.minX,right=width-inner.maxX,top=inner.minY,bottom=height-inner.maxY
            let fx=min(1,rect.width/max(1,left+right)),fy=min(1,rect.height/max(1,top+bottom))
            let xs=[CGFloat(0),left,inner.maxX,width],ys=[CGFloat(0),top,inner.maxY,height]
            let xd=[rect.minX,rect.minX+left*fx,rect.maxX-right*fx,rect.maxX],yd=[rect.minY,rect.minY+top*fy,rect.maxY-bottom*fy,rect.maxY]
            for y in 0..<3 { for x in 0..<3 {
                let src=CGRect(x:xs[x],y:ys[y],width:xs[x+1]-xs[x],height:ys[y+1]-ys[y]),dst=CGRect(x:xd[x],y:yd[y],width:xd[x+1]-xd[x],height:yd[y+1]-yd[y])
                if src.width>0,src.height>0,dst.width>0,dst.height>0,let crop=imageCache.crop(image,rect:src) { context.draw(Image(decorative:crop,scale:1),in:dst) }
            }}
        } else {
            let dest=natural ? CGRect(x:rect.midX-width/2,y:rect.midY-height/2,width:width,height:height):rect
            context.draw(Image(decorative:image,scale:1),in:dest)
        }
    }
    private func style(_ reference:Any?,rect:CGRect,natural:Bool=false,pressed:Bool,time:TimeInterval,fallback:String="",context:inout GraphicsContext) {
        let ref=Self.object(reference),key=Self.string(ref["key"] ?? (reference as? NSNumber))
        guard !key.isEmpty else{return}
        let type=Self.string(ref["type"])
        var spec=Self.object((type=="1" || type=="colorStyle") ? colors[key]:(type=="2" || type=="textStyle") ? texts[key]:images[key])
        if spec.isEmpty { spec=Self.object(colors[key] ?? texts[key]) }
        guard !spec.isEmpty else{return}
        var img=Self.object(spec[pressed ? "highlightImage":"normalImage"])
        if Self.object(img["resource"]).isEmpty { img=Self.object(spec["normalImage"]) }
        let resource=Self.string(Self.object(img["resource"])["resourceID"])
        if !resource.isEmpty,let image=image(resource,time:time) { drawImage(image,rect:rect,spec:img,natural:natural,context:&context);return }
        var info=Self.object(spec["fontInfo"])
        if info.isEmpty,spec["fontSize"] != nil || spec["contentText"] != nil { info=spec }
        if !info.isEmpty {
            let label=Self.string(info["contentText"]);let text=label.isEmpty ? fallback:label
            guard !text.isEmpty else{return}
            let size=max(1,min(500,Self.number(info["fontSize"],min(rect.width,rect.height)*0.45)))
            let offset=Self.object(info["scaledOffset"]),point=CGPoint(x:rect.midX+Self.number(offset["x"])*rect.width,y:rect.midY+Self.number(offset["y"])*rect.height)
            context.draw(Text(text).font(font(info,size:size)).foregroundColor(color(info[pressed ? "highlightColor":"normalColor"] ?? info["normalColor"],fallback:.black)),at:point)
        } else if resource.isEmpty,spec["normalColor"] != nil || spec["highlightColor"] != nil {
            let radius=max(0,Self.number(spec["cornerRadius"] ?? spec["radius"]))
            context.fill(Path(roundedRect:rect,cornerRadius:radius),with:.color(color(spec[pressed ? "highlightColor":"normalColor"] ?? spec["normalColor"])))
        }
    }
    private func draw(_ item:Item,time:TimeInterval,pressed:Bool,context:inout GraphicsContext) {
        guard item.visible,let rect=item.rect else{return}
        let d=item.data
        for name in ["wholeBackStyle","backStyle","candBarStyle"] { style(d[name],rect:rect,pressed:pressed,time:time,context:&context) }
        let foreground=d["foreStyles"] as? [Any] ?? [],offsets=d["foreStyleOffsets"] as? [Any] ?? []
        for (index,ref) in foreground.enumerated() {
            let offset=index<offsets.count ? Self.object(offsets[index]):[:]
            let target=rect.offsetBy(dx:Self.number(offset["x"])*rect.width,dy:Self.number(offset["y"])*rect.height)
            style(ref,rect:target,natural:true,pressed:pressed,time:time,fallback:Self.string(d["contentText"]),context:&context)
        }
        style(d["textStyle"],rect:rect,pressed:pressed,time:time,fallback:Self.string(d["contentText"]),context:&context)
        style(d["foreStyle"],rect:rect,natural:true,pressed:pressed,time:time,fallback:Self.string(d["contentText"]),context:&context)
        let resource=Self.string(d["imagePath"] ?? Self.object(d["resource"])["resourceID"])
        if !resource.isEmpty,let image=image(resource,time:time) { drawImage(image,rect:rect,spec:d,natural:false,context:&context) }
        if item.kind=="lists" {
            let count=min(10000,max(0,Int(Self.number(d["listNum"] ?? d["count"])))),pad=Self.object(d["padding"]),cell=Self.object(d["cellSize"])
            guard count>0 else{return}
            let h=Self.number(cell["height"],rect.height/CGFloat(count));guard h>0 else{return}
            var layer=context
            layer.clip(to:Path(CGRect(x:rect.minX+Self.number(pad["left"]),y:rect.minY+Self.number(pad["top"]),width:max(0,rect.width-Self.number(pad["left"])-Self.number(pad["right"])),height:max(0,rect.height-Self.number(pad["top"])-Self.number(pad["bottom"])))))
            let names=d["names"] as? [Any] ?? []
            for i in 0..<count {
                let frame=CGRect(x:rect.minX,y:rect.minY+CGFloat(i)*h,width:rect.width,height:h)
                style(d["cellBackStyle"],rect:frame,pressed:pressed,time:time,context:&layer)
                style(d["cellForeStyle"],rect:frame,pressed:pressed,time:time,fallback:i<names.count ? Self.string(names[i]):"",context:&layer)
            }
        }
    }
    func drawHybrid(_ data:[String:Any],rect:CGRect,pressed:Bool,context:inout GraphicsContext){draw(Item(id:"hybrid",kind:"key",data:data,rect:rect),time:0,pressed:pressed,context:&context)}
    func draw(context:inout GraphicsContext,time:TimeInterval,pressed:Bool,debug:Bool,scale:CGFloat,playing:Bool=true) {
        guard let panel else{return}
        for item in panel.items where item.kind=="background"{draw(item,time:time,pressed:pressed,context:&context)}
        for a in animations where a.background && a.id==animationChoice {drawAnimation(a,rect:CGRect(origin:.zero,size:panel.size),time:time,context:&context)}
        for item in panel.items where item.kind != "background" && item.visible {
            draw(item,time:time,pressed:pressed,context:&context)
            if item.kind=="keys",let rect=item.rect {for a in animations where a.target.contains(item.id) {
                if a.event.isEmpty {drawAnimation(a,rect:rect,time:time,context:&context)}
                else if let elapsed=tapTime(a,item.id) {drawAnimation(a,rect:rect,time:playing ? elapsed:0,context:&context)}
            }}
        }
        for a in animations where !a.background && a.id==animationChoice{drawAnimation(a,rect:CGRect(origin:.zero,size:panel.size),time:time,context:&context)}
        if debug { for item in panel.items where item.kind=="keys" && item.visible {
            guard let rect=item.rect else{continue}
            context.stroke(Path(rect),with:.color(item.source=="explicit" ? .green:.orange),lineWidth:1/max(0.01,scale))
        }}
    }
    private func drawAnimation(_ a:Animation,rect:CGRect,time:TimeInterval,context:inout GraphicsContext){
        guard !a.frames.isEmpty else{return}
        let duration=a.durations.reduce(0,+);guard duration>0 else{return}
        var index=a.frames.count-1
        if a.loop || time*1000<duration*max(1,a.repeats){var t=max(0,time*1000).truncatingRemainder(dividingBy:duration);index=0;while index<a.durations.count-1 && t>=a.durations[index]{t-=a.durations[index];index+=1}}
        if let image=image(a.frames[min(index,a.frames.count-1)],time:time){drawImage(image,rect:a.rect ?? rect,spec:[:],natural:!a.background && !a.target.isEmpty,context:&context)}
    }
    private func loadAnimations(_ root:[String:Any],_ scene:[String:Any]) {
        animations=[];tapKey=""
        for (id,value) in Self.entries(root["imageAnimation"]).sorted(by:{$0.key<$1.key}) {
            let d=Self.object(value);var frames:[String]=[],durations:[Double]=[]
            for item in d["imageItem"] as? [[String:Any]] ?? [] {let name=Self.string(Self.object(item["resource"])["resourceID"]);if !name.isEmpty{frames.append(name);durations.append(Double(max(16,Self.number(item["duration"],100))))}}
            if !frames.isEmpty{animations.append(Animation(id:id,frames:frames,durations:durations,loop:Self.number(d["loopForever"])==1,repeats:Double(Self.number(d["repeatCount"],1))))}
        }
        for (key,value) in Self.entries(root["animationMap"]) {let d=Self.object(value);for group in ["baseAnimation","isolationAnimation"]{for bind in d[group] as? [[String:Any]] ?? []{if let index=animations.firstIndex(where:{$0.id==Self.string(bind["key"])}){animations[index].target.append(key);animations[index].event=Self.string(bind["observerEvent"])}}}}
        for kind in ["alphaAnimation","scaleAnimation"] {
            for id in Self.entries(root[kind]).keys.sorted() {
                animations.append(Animation(id:id,frames:[],durations:[],kind:kind))
                notes.append("暂不执行变换动画："+kind+"/"+id)
            }
        }
        func scan(_ value:Any,_ path:String,_ depth:Int){
            guard depth<=24 else{return}
            if let d=value as? [String:Any] {
                let lower=path.lowercased(),name=Self.string(Self.object(d["resource"])["resourceID"])
                if !name.isEmpty && (lower.contains("back") || lower.contains("anim") || lower.contains("decorator")){animations.append(Animation(id:path,frames:[name],durations:[100],background:lower.contains("back"),rect:Self.rect(d)))}
                if let list=d["frames"] as? [Any] {
                    var frames:[String]=[],durations:[Double]=[]
                    for item in list{let f=Self.object(item),name=(item as? String) ?? Self.string(Self.object(f["resource"])["resourceID"]);if !name.isEmpty{frames.append(name);durations.append(Double(max(16,Self.number(f["duration"] ?? d["frameDuration"],100))))}}
                    if !frames.isEmpty{animations.append(Animation(id:path,frames:frames,durations:durations,background:lower.contains("back"),rect:Self.rect(d)))}
                }
                for (key,item) in d{scan(item,path+"/"+key,depth+1)}
            }else if let list=value as? [Any]{for (i,item) in list.enumerated(){scan(item,path+"/\(i)",depth+1)}}
        }
        scan(scene,"scene",0)
        if !root.isEmpty || !scene.isEmpty{notes.append("动画：支持图片与帧资源；未知触发和变换协议保持静态")}
    }
}

extension BdaPreviewEngine {
    private func token(_ item:Item) -> String {
        var raw=Self.string(item.data["function"] ?? item.data["action"] ?? item.data["keyType"] ?? item.data["text"] ?? item.data["label"] ?? item.data["contentText"])
        if raw.isEmpty {
            raw=item.id.replacingOccurrences(of:"_S[0-9]+$",with:"",options:.regularExpression).replacingOccurrences(of:"^KEY_?",with:"",options:.regularExpression)
        }
        func normal(_ value:String)->String {
            let text=value.trimmingCharacters(in:.whitespacesAndNewlines).lowercased()
            for (key,values) in ["delete":["f36","delete","backspace","del","删除","⌫"],"space":["f38","space","空格"],"enter":["f39","enter","return","回车","确认","↵"],"shift":["f11","shift","⇧"],"symbol":["f1","symbol","符","符号"],"number":["f6","123","number"],"language":["f16","language","中/英","中英","语言"]] { if values.contains(text) { return key } }
            return value==" " ? "space":text
        }
        let t=normal(raw)
        if ["delete","space","enter","shift","symbol","number","language"].contains(t) { return t }
        for ref in item.data["foreStyles"] as? [[String:Any]] ?? [] {
            let key=Self.string(ref["key"]),style=Self.object(texts[key] ?? images[key])
            let text=Self.string(style["contentText"] ?? Self.object(style["fontInfo"])["contentText"])
            if !text.isEmpty { return normal(text) }
        }
        return t
    }
    private func weight(_ item:Item)->CGFloat {
        let declared=Self.number(item.data["weight"] ?? item.data["ratio"])
        if declared>0 { return min(20,declared) }
        let t=token(item);var value:CGFloat=t=="space" ? 2.7:(["shift","delete"].contains(t) ? 1.4:1)
        if let image=imageForReference(item.data["backStyle"],time:0),image.height>0 { value=max(value,min(6,CGFloat(image.width)/CGFloat(image.height))) }
        return value
    }
    private func place(_ panel:inout Panel,rows:[[Int]],params:[String:Any],source:String,confidence:Double,topOverride:CGFloat?=nil) {
        guard !rows.isEmpty else{return}
        let pad=Self.object(params["padding"] ?? params["margin"]),region=Self.rect(params["region"]) ?? CGRect(origin:.zero,size:panel.size)
        let left=Self.number(pad["left"],panel.size.width*0.015),right=Self.number(pad["right"],panel.size.width*0.015)
        let top=topOverride ?? Self.number(pad["top"],panel.size.height*0.02),bottom=Self.number(pad["bottom"],panel.size.height*0.02)
        let gap=max(0,Self.number(params["spacing"] ?? params["gap"],panel.size.width*0.008)),vGap=max(0,Self.number(params["rowSpacing"],gap))
        let rowHeight=(region.height-top-bottom-vGap*CGFloat(rows.count-1))/CGFloat(rows.count)
        guard rowHeight>0 else{return}
        for (r,row) in rows.enumerated() where !row.isEmpty {
            let definitions=params["rows"] as? [Any] ?? [],rp=r<definitions.count ? Self.object(definitions[r]):[:]
            let indent=Self.number(rp["offset"] ?? rp["startOffset"] ?? rp["indent"],source=="semanticInference" && r==1 && row.count==9 ? panel.size.width*0.045:0)
            let available=region.width-left-right-indent*2-gap*CGFloat(row.count-1)
            let sum=row.reduce(CGFloat(0)){$0+weight(panel.items[$1])};guard sum>0,available>0 else{continue}
            var x=region.minX+left+indent
            for index in row {
                let item=panel.items[index],w=Self.number(item.data["keyWidth"],Self.number(params["keyWidth"],available*weight(item)/sum)),h=Self.number(item.data["keyHeight"],Self.number(params["keyHeight"],rowHeight))
                let column=Self.number(item.data["column"] ?? item.data["columnIndex"],-1),columns=Self.number(params["columns"] ?? params["columnCount"] ?? params["cols"])
                var frame=CGRect(x:x,y:region.minY+top+CGFloat(r)*(rowHeight+vGap),width:max(1,w),height:max(1,h))
                if column>=0,columns>0 {
                    let slot=(region.width-left-right-gap*(columns-1))/columns,span=max(1,Self.number(item.data["columnSpan"],1))
                    frame.origin.x=region.minX+left+column*(slot+gap);frame.size.width=slot*span+gap*(span-1)
                }
                if panel.items[index].rect==nil {
                    panel.items[index].rect=frame;panel.items[index].source=source;panel.items[index].confidence=confidence
                }
                x+=w+gap
            }
        }
    }
    private func recover(_ panel:inout Panel,layout:[String:Any]) {
        let active=panel.items.indices.filter{panel.items[$0].kind=="keys" && panel.items[$0].visible}.sorted {
            let a=Self.number(panel.items[$0].data["order"] ?? panel.items[$0].data["index"],CGFloat($0)),b=Self.number(panel.items[$1].data["order"] ?? panel.items[$1].data["index"],CGFloat($1))
            return a<b
        }
        for (params,source,confidence) in [(layout,"layoutConfig",0.9),(panel.data,"panelRule",0.85)] {
            let d=Self.merge(params,Self.object(params["grid"]))
            var rows:[[Int]]=[]
            if let definitions=d["rows"] as? [Any] {
                rows=definitions.map { value in
                    let entries=(value as? [Any]) ?? (Self.object(value)["keys"] as? [Any]) ?? (Self.object(value)["items"] as? [Any]) ?? []
                    return entries.compactMap { entry in let id=(entry as? String) ?? Self.string(Self.object(entry)["id"] ?? Self.object(entry)["key"] ?? Self.object(entry)["name"]);return active.first{panel.items[$0].id==id} }
                }
            }
            if rows.allSatisfy({$0.isEmpty}) {
                let columns=Int(Self.number(d["columns"] ?? d["columnCount"] ?? d["cols"]))
                var grouped:[Int:[Int]]=[:]
                for (i,index) in active.enumerated() {
                    let row=Int(Self.number(panel.items[index].data["row"] ?? panel.items[index].data["rowIndex"],columns>0 ? CGFloat(i/columns):-1))
                    if row>=0,row<100 { grouped[row,default:[]].append(index) }
                }
                if let maximum=grouped.keys.max() { rows=(0...maximum).map{grouped[$0] ?? []} }
            }
            if rows.contains(where:{!$0.isEmpty}) { place(&panel,rows:rows,params:d,source:source,confidence:confidence) }
        }
        var candidateHeight:CGFloat=0
        if let ci=panel.items.firstIndex(where:{$0.kind=="cand"}) {
            let cand=Self.object(layout["cand"]),height=Self.number(cand["mainCandHeight"])+Self.number(cand["secondCandHeight"])
            if height>0 { panel.items[ci].rect=CGRect(x:0,y:-height,width:panel.size.width,height:height) }
            else if panel.items[ci].rect==nil {
                let image=imageForReference(panel.items[ci].data["candBarStyle"],time:0)
                candidateHeight=min(panel.size.height*0.25,image.map{CGFloat($0.height)} ?? panel.size.height*0.14)
                panel.items[ci].rect=CGRect(x:0,y:0,width:panel.size.width,height:candidateHeight)
                panel.items[ci].source="semanticInference"
            } else { candidateHeight=max(0,panel.items[ci].rect?.maxY ?? 0) }
            for i in panel.items.indices where panel.items[i].kind=="candKey" && panel.items[i].rect==nil {
                let icon=Self.object(Self.entries(cand["icons"])[panel.items[i].id])
                let iconSize=Self.object(icon["size"]),pos=Self.object(icon["pos"])
                let w=Self.number(iconSize["width"]),iconHeight=Self.number(iconSize["height"])
                if height>0,w>0,iconHeight>0 {
                    let type=Self.string(icon["type"])
                    if type=="PersistTypeOnCand" || type=="2" { panel.items[i].visible=false;continue }
                    var x=Self.number(pos["x"]);if x<0{x+=panel.size.width}
                    panel.items[i].rect=CGRect(x:x,y:-height/2+Self.number(pos["y"]),width:w,height:iconHeight)
                    panel.items[i].source="layoutConfig";panel.items[i].confidence=0.9;continue
                }
                let id=panel.items[i].id.lowercased(),h=height>0 ? height:candidateHeight
                if id=="cand_f31" || id.contains("left") { panel.items[i].rect=CGRect(x:panel.size.width*0.02,y:height>0 ? -h:0,width:h,height:h) }
                if id=="cand_f8" || id.contains("right") { panel.items[i].rect=CGRect(x:panel.size.width-h-panel.size.width*0.02,y:height>0 ? -h:0,width:h,height:h) }
            }
        }
        if active.contains(where:{panel.items[$0].rect==nil}) {
            let kind=panel.id.lowercased(),tokens=Set(active.map{token(panel.items[$0])})
            let qwerty=kind.contains("26") || Set(["q","w","e","r","t","y"]).isSubset(of:tokens)
            let nine = !qwerty && (kind.contains("9") || kind.contains("num") || Set(["1","2","3","4","5","6","7","8","9"]).isSubset(of:tokens))
            var rows:[[Int]]=[],used=Set<Int>()
            if qwerty {
                for letters in ["qwertyuiop","asdfghjkl","zxcvbnm"] {
                    var row:[Int]=[]
                    for letter in letters { if let index=active.first(where:{!used.contains($0) && token(panel.items[$0])==String(letter)}) { row.append(index);used.insert(index) } }
                    rows.append(row)
                }
                for index in active where !used.contains(index) { let t=token(panel.items[index]);if t=="shift" { rows[2].insert(index,at:0);used.insert(index) };if t=="delete" { rows[2].append(index);used.insert(index) } }
                if rows.flatMap({$0}).count<10 {
                    let ordinary=active.filter{!used.contains($0) && !["shift","delete","space","enter","symbol","language"].contains(token(panel.items[$0]))}
                    if ordinary.count>=26 { for (i,index) in ordinary.prefix(26).enumerated() { rows[i<10 ? 0:(i<19 ? 1:2)].append(index);used.insert(index) } }
                }
            } else if nine {
                rows=[[],[],[]]
                for (i,group) in [["1","'"],["2","abc","b"],["3","def","e"],["4","ghi","h"],["5","jkl","k"],["6","mno","n"],["7","pqrs","q"],["8","tuv","u"],["9","wxyz","x"]].enumerated() {
                    if let index=active.first(where:{!used.contains($0) && group.contains(token(panel.items[$0]))}) { rows[i/3].append(index);used.insert(index) }
                }
            }
            let recognized = !used.isEmpty
            var rest=active.filter{!used.contains($0)}
            if recognized {
                let order=["symbol":0,"number":1,",":2,"，":2,"space":3,".":4,"。":4,"language":5,"enter":6,"delete":7]
                rest.sort{(order[token(panel.items[$0])] ?? 2)<(order[token(panel.items[$1])] ?? 2)}
            } else { rows=[] }
            let columns=recognized ? (nine ? 5:9):max(1,Int(ceil(sqrt(Double(rest.count)*2))))
            for offset in stride(from:0,to:rest.count,by:columns) { rows.append(Array(rest[offset..<min(rest.count,offset+columns)])) }
            place(&panel,rows:rows,params:[:],source:recognized ? "semanticInference":"fallback",confidence:recognized ? 0.7:0.4,topOverride:candidateHeight>0 ? candidateHeight+panel.size.height*0.02:nil)
            notes.append(panel.id+"：含推算布局，未写回原配置")
        }
        for i in panel.items.indices where panel.items[i].kind=="background" { panel.items[i].rect=CGRect(origin:.zero,size:panel.size) }
    }
}
