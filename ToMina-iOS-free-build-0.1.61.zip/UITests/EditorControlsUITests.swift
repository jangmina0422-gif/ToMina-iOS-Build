import XCTest
import UIKit

final class EditorControlsUITests: XCTestCase {
    func testHalfBdaToolExplainsOrdinaryBdsAndBdi() {
        for bdi in [false,true] {
            let app=XCUIApplication();app.launchArguments=["--editor-controls-fixture"]+(bdi ? ["--bdi-gif-tool-fixture"]:[]);app.launch()
            XCTAssertTrue(app.buttons["包内文件夹：controls."+(bdi ? "bdi":"bds")].waitForExistence(timeout:30))
            endSourceInput(app);app.buttons["⋮"].tap();app.buttons["工具箱"].tap()
            let button=app.buttons["tools.updateHalfBda"]
            XCTAssertTrue(button.waitForExistence(timeout:8));XCTAssertTrue(button.isEnabled)
            // The BDS fixture is plain INI; the BDI fixture carries appearanceConfig JSON plus its binary, so it is a real half-BDA.
            let availability=app.staticTexts["tools.halfBdaAvailability"].label
            XCTAssertTrue(bdi ? availability.contains("BDI"):availability.contains("INI"),availability)
            tapSettled(button)
            let notice=app.alerts["提示"],report=app.staticTexts["tools.halfBdaReport"]
            let answered=XCTNSPredicateExpectation(predicate:NSPredicate{_,_ in notice.exists || report.exists},object:nil)
            XCTAssertEqual(XCTWaiter.wait(for:[answered],timeout:15),.completed)
            let unneeded=notice.staticTexts.matching(NSPredicate(format:"label CONTAINS %@","无需更新半 BDA")).firstMatch.exists
            XCTAssertEqual(unneeded,!bdi)
            proof(app,name:bdi ? "Half-BDA-explains-INI-BDI":"Half-BDA-explains-INI-BDS")
            if notice.exists { notice.buttons["确定"].tap() };app.terminate()
        }
    }
    func testPackageCheckScansWholeProjectAndCopiesReport() {
        let app=openApp()
        endSourceInput(app); app.buttons["⋮"].tap();XCTAssertFalse(app.buttons["预览检查"].exists);app.buttons["工具箱"].tap()
        XCTAssertFalse(app.switches["显示 VIEW / LIST 边框"].exists)
        tapSettled(app.buttons["tools.packageCheck"])
        let start=app.buttons["packageCheck.start"];XCTAssertTrue(start.waitForExistence(timeout:10));tapSettled(start)
        let summary=app.staticTexts["packageCheck.summary"];XCTAssertTrue(summary.waitForExistence(timeout:30));XCTAssertTrue(summary.label.contains("文件 4"))
        tapSettled(app.buttons["packageCheck.copy"]);XCTAssertTrue(app.buttons["报告已复制"].exists)
        proof(app,name:"Package-check-report")
    }
    func testBDIGIFAppliesWithoutExportAndKeepsExtension() {
        XCUIDevice.shared.orientation = .portrait
        let app=XCUIApplication();app.launchArguments=["--editor-controls-fixture","--bdi-gif-tool-fixture","--single-gif-tool-fixture"];app.launch()
        XCTAssertTrue(app.buttons["包内文件夹：controls.bdi"].waitForExistence(timeout:30))
        endSourceInput(app); app.buttons["⋮"].tap();app.buttons["工具箱"].tap();tapSettled(app.buttons["tools.singleGIF"])
        XCTAssertTrue(app.navigationBars["GIF 动态背景"].waitForExistence(timeout:10))
        tapSettled(app.buttons["singleGIF.compile"])
        XCTAssertTrue(app.staticTexts["背景已应用，导出请使用菜单"].waitForExistence(timeout:30))
        XCTAssertTrue(app.buttons["包内文件夹：controls.bdi"].exists);XCTAssertFalse(app.buttons["Save"].exists)
        proof(app,name:"BDI-GIF-applied-without-export")
    }
    func testSingleGIFToolOpensAndRequiresBackgroundSelection() {
        let app=openApp()
        endSourceInput(app); app.buttons["⋮"].tap();app.buttons["工具箱"].tap()
        let tool=app.buttons["tools.singleGIF"]
        tapSettled(tool)
        let compile=app.buttons["singleGIF.compile"]
        XCTAssertTrue(compile.waitForExistence(timeout:10));XCTAssertFalse(compile.isEnabled)
        XCTAssertTrue(app.staticTexts["singleGIF.target"].label.contains("py_26.ini"))
        XCTAssertTrue(app.staticTexts["请先添加 GIF，添加后会自动选中。"].exists)
        XCTAssertFalse(app.staticTexts["竖屏默认背景"].exists)
        XCTAssertFalse(app.staticTexts["横屏默认背景"].exists)
        XCTAssertFalse(app.buttons["按面板设置"].exists)
        proof(app,name:"Single-GIF-toolbox-settings")
        app.buttons["singleGIF.add"].tap()
        let hint=app.alerts["GIF 建议尺寸"];XCTAssertTrue(hint.waitForExistence(timeout:5))
        XCTAssertTrue(hint.staticTexts.matching(NSPredicate(format:"label CONTAINS %@ AND label CONTAINS %@","py_26.ini","240 × 120")).firstMatch.exists)
        proof(app,name:"Single-GIF-current-INI-size-before-picker")
        hint.buttons["继续选择 GIF"].tap()
        let cancel=app.buttons.matching(NSPredicate(format:"label IN %@",["Cancel","取消"])).firstMatch
        XCTAssertTrue(cancel.waitForExistence(timeout:15));cancel.tap()
        XCTAssertTrue(compile.waitForExistence(timeout:10));XCTAssertFalse(compile.isEnabled)
    }
    func testSingleGIFAppliesToPreviewWithoutOpeningExport() {
        let app=openApp(singleGIF:true)
        endSourceInput(app); app.buttons["⋮"].tap();app.buttons["工具箱"].tap();tapSettled(app.buttons["tools.singleGIF"])
        let apply=app.buttons["singleGIF.compile"]
        XCTAssertTrue(apply.waitForExistence(timeout:10));XCTAssertTrue(apply.isEnabled);tapSettled(apply)
        XCTAssertTrue(app.staticTexts["背景已应用，导出请使用菜单"].waitForExistence(timeout:30))
        XCTAssertTrue(app.descendants(matching:.any)["editor.preview"].waitForExistence(timeout:10))
        XCTAssertFalse(app.buttons["Save"].exists)
        proof(app,name:"Single-GIF-applied-without-export")
    }
    func testSaveOpensSystemExportPanelAndToolsKeepLatestProject() {
        let app = openApp()
        app.buttons["保存"].tap()
        // Use the English system control; the Chinese app button remains in
        // the accessibility tree behind the sheet and is not proof of saving.
        let save = app.buttons["Save"]
        XCTAssertTrue(save.waitForExistence(timeout: 45))
        // Choose the provider location through Files itself. The directoryURL
        // hint on a fresh simulator can display an unresolved, read-only route.
        let local = app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "On My iPad")).firstMatch
        XCTAssertTrue(local.waitForExistence(timeout: 15)); local.tap()
        let documents = app.cells.containing(.staticText, identifier: "To.Mina").firstMatch
        XCTAssertTrue(documents.waitForExistence(timeout: 15)); documents.tap()
        let cancel = app.buttons.matching(NSPredicate(format: "label IN %@", ["Cancel", "取消"])).firstMatch
        XCTAssertTrue(cancel.waitForExistence(timeout: 10))
        proof(app, name: "System-save-panel-with-save-button")
        save.tap()
        if app.buttons["Replace"].waitForExistence(timeout: 3) { app.buttons["Replace"].tap() }
        XCTAssertTrue(app.staticTexts["已保存：controls.bds"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.buttons["⋮"].waitForExistence(timeout: 5)); endSourceInput(app); app.buttons["⋮"].tap()
        app.buttons["工具箱"].tap()
        let clear = app.buttons["清除缓存"]
        XCTAssertTrue(clear.waitForExistence(timeout: 5)); clear.tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "已保留最新项目")).firstMatch.waitForExistence(timeout: 10))
        proof(app, name: "Clear-history-cache-keep-latest")
        app.buttons["关闭"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["editor.preview"].exists)
        app.buttons["保存"].tap()
        XCTAssertTrue(save.waitForExistence(timeout: 30)); save.tap()
        let replace = app.buttons["Replace"]
        XCTAssertTrue(replace.waitForExistence(timeout: 10))
        proof(app, name: "System-same-name-replace-confirmation")
        replace.tap()
        XCTAssertTrue(app.staticTexts["已保存：controls.bds"].waitForExistence(timeout: 15))
        proof(app, name: "Saved-again-after-cache-cleanup")
    }
    func testGlobalViewFitToolReportAndBorderToggle() {
        let app = openApp()
        endSourceInput(app); app.buttons["⋮"].tap(); app.buttons["工具箱"].tap()
        let fit = app.buttons["VIEW 全局贴合"]
        XCTAssertTrue(fit.waitForExistence(timeout: 5)); fit.tap()
        let result = app.buttons["最近处理结果"]
        XCTAssertTrue(result.waitForExistence(timeout: 30)); result.tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "已处理")).firstMatch.waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["POS_TYPE 归零"].exists)
        app.buttons["POS_TYPE 归零"].tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "POS_TYPE 归零")).firstMatch.waitForExistence(timeout: 30))
        let borders = app.switches["显示 VIEW / LIST 边框"]
        XCTAssertTrue(borders.exists); borders.tap()
        proof(app, name: "Global-VIEW-tool-report-and-toggle")
        app.buttons["关闭"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["editor.preview"].waitForExistence(timeout: 5))
        proof(app, name: "Global-VIEW-borders-in-real-editor")
    }
    func testGlobalViewFitReplacesVisibleSourceAndOtherPanels() {
        let app=openApp(viewFit:true)
        assertSourceVisible(app)
        let before=app.textViews.firstMatch
        XCTAssertTrue(before.waitForExistence(timeout:5))
        XCTAssertTrue((before.value as? String ?? "").contains("VIEW_RECT=12,8,96,44"))
        proof(app,name:"VIEW-source-before-fitting")
        endSourceInput(app); app.buttons["⋮"].tap();app.buttons["工具箱"].tap()
        tapSettled(app.buttons["VIEW 全局贴合"])
        let show=app.buttons["查看修改源码"]
        XCTAssertTrue(show.waitForExistence(timeout:30));show.tap()
        let source=app.textViews.firstMatch
        XCTAssertTrue(source.waitForExistence(timeout:5))
        let refreshed=XCTNSPredicateExpectation(predicate:NSPredicate{_,_ in
            let value=source.value as? String ?? ""
            return value.contains("VIEW_RECT=0,0,120,60") && !value.contains("VIEW_RECT=12,8,96,44")
        },object:nil)
        XCTAssertEqual(XCTWaiter.wait(for:[refreshed],timeout:10),.completed)
        XCTAssertTrue((source.value as? String ?? "").contains("TOUCH_RECT=12,8,96,44"))
        proof(app,name:"VIEW-source-after-fitting-verified-in-real-editor")
        edit("other.ini",in:app)
        let other=app.textViews.firstMatch.value as? String ?? ""
        XCTAssertTrue(other.contains("CENTER=other"));XCTAssertTrue(other.contains("VIEW_RECT=0,0,120,60"))
        XCTAssertFalse(other.contains("VIEW_RECT=12,8,96,44"))
        proof(app,name:"VIEW-other-panel-source-after-fitting")
    }
    func testPortraitSourcePaneCompactsDetailsAboveEditor() {
        let app = combinedApp()
        let source = app.textViews.firstMatch
        let preview = app.descendants(matching: .any).matching(identifier: "editor.preview").firstMatch
        let ready = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            guard source.exists, preview.exists else { return false }
            let window = app.windows.firstMatch.frame, code = source.frame, canvas = preview.frame
            return window.height > window.width
                && code.minY >= canvas.maxY
                && code.minY - canvas.maxY < 120
                && code.height > window.height * 0.45
                && code.width > window.width * 0.90
                && window.maxY - code.maxY < 64
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [ready], timeout: 15), .completed)
        XCTAssertFalse(app.buttons["editor.operations"].exists)
        XCTAssertFalse(app.staticTexts["INI 样式预览"].exists)
        proof(app, name: "Portrait-source-expanded-with-compact-details")
    }
    func testLandscapeSourcePaneUsesHeightWithoutBlankDetailsBlock() {
        let app = combinedApp()
        let source = app.textViews.firstMatch
        XCTAssertTrue(source.waitForExistence(timeout: 10))
        let original = source.value as? String
        XCUIDevice.shared.orientation = .landscapeLeft
        let preview = app.descendants(matching: .any).matching(identifier: "editor.preview").firstMatch
        let ready = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            guard source.exists, preview.exists else { return false }
            let window = app.windows.firstMatch.frame, code = source.frame, canvas = preview.frame
            return window.width > window.height
                && code.minX > window.width * 0.5
                && code.minY - canvas.minY < 120
                && code.height > canvas.height * 0.75
                && code.width > window.width * 0.42
                && window.maxX - code.maxX < 32
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [ready], timeout: 15), .completed)
        XCTAssertEqual(source.value as? String, original)
        XCTAssertFalse(app.buttons["editor.operations"].exists)
        XCTAssertFalse(app.staticTexts["INI 样式预览"].exists)
        proof(app, name: "Landscape-source-expanded-with-compact-details")
    }
    func testLandscapeSearchAndMenuVersion() {
        let app = openApp()
        XCUIDevice.shared.orientation = .landscapeLeft
        let settled = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            let frame = app.windows.firstMatch.frame
            return frame.width > frame.height && app.buttons["editor.effects"].frame.minX > frame.width * 0.5
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [settled], timeout: 12), .completed)
        endSourceInput(app); openEditorTools(app)
        let search = app.buttons["editor.search"]
        XCTAssertTrue(search.waitForExistence(timeout: 5)); search.tap()
        let input = app.textFields["editor.searchQuery"]
        XCTAssertTrue(input.waitForExistence(timeout: 5)); input.tap(); input.typeText("KEY1")
        XCTAssertTrue(app.staticTexts["editor.searchResult"].waitForExistence(timeout: 5))
        XCTAssertNotEqual(app.staticTexts["editor.searchResult"].label, "未找到关键词")
        XCTAssertTrue(app.textViews.firstMatch.exists)
        XCTAssertGreaterThan(app.textViews.firstMatch.frame.minX, app.windows.firstMatch.frame.width * 0.5)
        XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "app.version").firstMatch.exists)
        proof(app, name: "Landscape-search-left-preview-right-editor")
        let source = app.textViews.firstMatch
        let original = source.value as? String ?? ""
        jumpToEnd(app)
        source.typeText("\n; SEARCH-EDIT")
        XCTAssertEqual(source.value as? String, original + "\n; SEARCH-EDIT")
        proof(app, name: "Search-keeps-caret-while-editing")
        if app.buttons["收起键盘"].exists { app.buttons["收起键盘"].tap() }
        endSourceInput(app); app.buttons["⋮"].tap()
        XCTAssertTrue(app.descendants(matching: .any).matching(NSPredicate(format: "label BEGINSWITH %@", "版本 0.1.61")).firstMatch.waitForExistence(timeout: 5))
        proof(app, name: "Version-only-in-menu")
    }
    func testListSourceAndRegionGuidesAfterGlobalFit() {
        let app=openApp(listFit:true)
        assertSourceVisible(app)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("CELL_SIZE=40,26"))
        proof(app,name:"LIST-before-fitting-source-and-preview")
        endSourceInput(app); app.buttons["⋮"].tap();app.buttons["工具箱"].tap();tapSettled(app.buttons["VIEW 全局贴合"])
        let show=app.buttons["查看修改源码"]
        XCTAssertTrue(show.waitForExistence(timeout:30));show.tap()
        let source=app.textViews.firstMatch
        XCTAssertTrue(source.waitForExistence(timeout:5))
        let updated=XCTNSPredicateExpectation(predicate:NSPredicate{_,_ in
            let value=source.value as? String ?? ""
            return value.contains("POS=0,0") && value.contains("CELL_SIZE=52,30") && value.contains("VIEW_RECT=52,0,188,60")
        },object:nil)
        XCTAssertEqual(XCTWaiter.wait(for:[updated],timeout:10),.completed)
        XCTAssertTrue((source.value as? String ?? "").contains("VALUES=a b c d"))
        proof(app,name:"LIST-after-fitting-source-and-cell-borders")
    }
    func testSourceLinePositionTracksEditingAndEndNavigation() {
        let app=openApp();assertSourceVisible(app)
        let source=app.textViews.firstMatch,position=app.staticTexts["source.linePosition"]
        XCTAssertTrue(source.waitForExistence(timeout:10));XCTAssertTrue(position.waitForExistence(timeout:10))
        let original=source.value as? String ?? "",count=original.components(separatedBy:"\n").count
        XCTAssertTrue(position.label.contains("共 \(count) 行"));jumpToEnd(app)
        XCTAssertTrue(position.label.contains("第 \(count) 行"));XCTAssertEqual(source.value as? String,original)
        source.typeText("\n; line-number-check")
        XCTAssertTrue(position.label.contains("第 \(count+1) 行 / 共 \(count+1) 行"))
        XCTAssertEqual(source.value as? String,original+"\n; line-number-check")
        proof(app,name:"Source-line-numbers-and-current-position")
    }
    private func jumpToEnd(_ app: XCUIApplication) {
        endSourceInput(app); openEditorTools(app)
        let jump = app.buttons["editor.jumpToEnd"]
        XCTAssertTrue(jump.waitForExistence(timeout: 5)); jump.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
    }
    func testJumpToLastLineOpensSourceAndPreservesLongDraft() {
        let app = openApp()
        jumpToEnd(app)
        assertSourceVisible(app)
        let source = app.textViews.firstMatch
        let initial = source.value as? String ?? ""
        source.typeText("; tail")
        XCTAssertEqual(source.value as? String, initial + "; tail")
        endSourceInput(app)
        edit("long.txt", in: app)
        jumpToEnd(app)
        let longText = source.value as? String ?? ""
        XCTAssertTrue(longText.hasSuffix("; END"))
        source.typeText("-FIRST")
        XCTAssertEqual(source.value as? String, longText + "-FIRST")
        XCUIDevice.shared.orientation = .landscapeLeft
        // XCUI can synthesize a tap using an intermediate rotation frame.
        // Wait for the actual action row to settle before opening its menu.
        endSourceInput(app)
        var previous = CGRect.null, stableFrames = 0
        let settled = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            let window = app.windows.firstMatch.frame
            let frame = app.buttons["editor.effects"].frame
            guard window.width > window.height, frame == previous else {
                previous = frame; stableFrames = 0; return false
            }
            stableFrames += 1
            return stableFrames >= 3
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [settled], timeout: 10), .completed)
        jumpToEnd(app)
        source.typeText("-SECOND")
        XCTAssertEqual(source.value as? String, longText + "-FIRST-SECOND")
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = "Jump-to-last-line-keyboard-landscape"; attachment.lifetime = .keepAlways; add(attachment)
        endSourceInput(app)
        assertSourceVisible(app)
        XCTAssertEqual(source.value as? String, longText + "-FIRST-SECOND")
    }
    func testJumpToLastLineKeepsAnimationEditorAndDraft() {
        // XCUI waits up to 60 seconds for each continuous preview/menu
        // animation to become idle even while the app remains interactive.
        executionTimeAllowance = 180
        let app = openApp()
        app.buttons["漂浮"].tap()
        app.buttons["animation.selector"].tap(); app.buttons["ANIM1"].tap()
        let source = app.textViews.firstMatch
        let initial = source.value as? String ?? ""
        XCTAssertTrue(initial.contains("[ANIM1]"))
        jumpToEnd(app)
        source.typeText("\n; animation tail")
        XCTAssertEqual(source.value as? String, initial + "\n; animation tail")
        jumpToEnd(app)
        source.typeText("-SECOND")
        XCTAssertEqual(source.value as? String, initial + "\n; animation tail-SECOND")
        XCTAssertTrue(app.buttons["漂浮"].exists)
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = "Jump-to-last-line-animation"; attachment.lifetime = .keepAlways; add(attachment)
    }
    override func setUpWithError() throws { continueAfterFailure = false }

    func testAddedColorTemplateHasPickerAndPersistsParameters() {
        let app=openApp()
        app.buttons["动效"].tap()
        let menu=app.buttons["animation.addTemplate"]
        XCTAssertTrue(menu.waitForExistence(timeout:5));menu.tap()
        app.buttons["template.add.color"].tap()
        let from=app.textFields["template.field.FROM"]
        XCTAssertTrue(from.waitForExistence(timeout:10));XCTAssertEqual(from.value as? String,"000000")
        XCTAssertTrue(app.descendants(matching:.any)["template.color.FROM"].exists)
        XCTAssertTrue(app.descendants(matching:.any)["template.color.TO"].exists)
        proof(app,name:"New-color-animation-hex-and-color-pickers")
        from.tap();from.typeText(String(repeating:XCUIKeyboardKey.delete.rawValue,count:8)+"112233")
        app.buttons["template.save"].tap()
        let source=app.textViews.firstMatch
        XCTAssertTrue(source.waitForExistence(timeout:5))
        XCTAssertTrue((source.value as? String ?? "").contains("FROM=112233"))
        XCTAssertTrue((source.value as? String ?? "").contains("TYPE=6"))
        proof(app,name:"Color-template-saved-in-animation-source")
    }
    func testAddedFloatingTemplateCreatesEventAndShowsSource() {
        let app=openApp();app.buttons["漂浮"].tap()
        let add=app.buttons["animation.addParticle"]
        XCTAssertTrue(add.waitForExistence(timeout:5));add.tap()
        XCTAssertTrue(app.textFields["template.field.TYPR"].waitForExistence(timeout:10))
        XCTAssertEqual(app.textFields["template.field.LIFE"].value as? String,"0,0")
        proof(app,name:"New-floating-template-parameters-and-help")
        app.buttons["template.save"].tap()
        let source=app.textViews.firstMatch
        XCTAssertTrue(source.waitForExistence(timeout:5))
        let text=source.value as? String ?? ""
        for line in ["CATEGORY=3","TYPE=0","TYPR=0","LIFE=0,0","REPEAT_CNT=inf","EMIT_REGION=0,0,0,0"]{XCTAssertTrue(text.contains(line),line)}
        proof(app,name:"Floating-template-in-package-source")
        edit("event.ini",in:app)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("IDLE_TIME=422"))
        proof(app,name:"Created-idle-event-in-same-folder")
    }
    func testAddKeyAndNewCSSStyleFieldsInSource() {
        let app=openApp();assertSourceVisible(app)
        openAddField(app)
        XCTAssertTrue(app.buttons["source.insert"].waitForExistence(timeout:5))
        proof(app,name:"KEY-field-insertion-options")
        app.buttons["source.insert"].tap()
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("BACK_ANIM_STYLE="))
        proof(app,name:"KEY-field-appended-to-source")
        edit("styles.css",in:app)
        openAddField(app);app.buttons["source.insert"].tap()
        let code=app.textViews.firstMatch.value as? String ?? ""
        XCTAssertTrue(code.contains("[STYLE4]"));XCTAssertTrue(code.contains("NM_IMG="))
        XCTAssertTrue(code.contains("NM_COLOR=FFFFFFFF"))
        proof(app,name:"New-CSS-style-field-in-source")
    }
    private func tapSettled(_ button: XCUIElement) {
        XCTAssertTrue(button.waitForExistence(timeout: 8))
        var previous = CGRect.null
        var stableSince = Date()
        let settled = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            guard button.exists, button.isEnabled, button.isHittable else {
                previous = .null; stableSince = Date(); return false
            }
            let frame = button.frame
            if frame != previous {
                previous = frame; stableSince = Date(); return false
            }
            return Date().timeIntervalSince(stableSince) >= 0.6
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [settled], timeout: 8), .completed)
        button.tap()
    }
    func testHandwritingAreaClosesOuterGapsAndKeepsOverlay() {
        let app=openApp(handwritingFit:true)
        assertSourceVisible(app)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("VIEW_RECT=8,8,164,72"))
        proof(app,name:"Handwriting-before-fit")
        endSourceInput(app); app.buttons["⋮"].tap();app.buttons["工具箱"].tap();tapSettled(app.buttons["VIEW 全局贴合"])
        let show=app.buttons["查看修改源码"]
        XCTAssertTrue(show.waitForExistence(timeout:30));show.tap()
        let source=app.textViews.firstMatch
        let updated=XCTNSPredicateExpectation(predicate:NSPredicate{_,_ in
            let text=source.value as? String ?? ""
            return text.contains("VIEW_RECT=0,0,176,84") && text.contains("TOUCH_RECT=8,8,164,72")
        },object:nil)
        XCTAssertEqual(XCTWaiter.wait(for:[updated],timeout:10),.completed)
        XCTAssertTrue((source.value as? String ?? "").contains("VIEW_RECT=12,62,30,14"))
        proof(app,name:"Handwriting-after-fit-source-and-preview")
    }
    private func openApp(viewFit:Bool=false,listFit:Bool=false,handwritingFit:Bool=false,singleGIF:Bool=false) -> XCUIApplication {
        XCUIDevice.shared.orientation = .portrait
        let app = XCUIApplication()
        app.launchArguments = ["--editor-controls-fixture"]
        if viewFit {app.launchArguments.append("--view-fit-fixture")}
        if listFit {app.launchArguments.append("--list-fit-fixture")}
        if handwritingFit {app.launchArguments.append("--handwriting-fit-fixture")}
        if singleGIF {app.launchArguments.append("--single-gif-tool-fixture")}
        app.launch()
        XCTAssertTrue(app.buttons["包内文件夹：controls.bds"].waitForExistence(timeout: 15))
        XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "app.version").firstMatch.exists)
        return app
    }
    private func edit(_ file: String, in app: XCUIApplication, folder: String? = nil) {
        endSourceInput(app)
        app.buttons["包内文件夹：controls.bds"].tap()
        if let folder { app.buttons[folder].tap() }
        let row = app.buttons[file]
        XCTAssertTrue(row.waitForExistence(timeout: 5))
        row.tap()
        assertSourceVisible(app)
    }
    private func assertSourceVisible(_ app: XCUIApplication) {
        XCTAssertTrue(app.textViews.firstMatch.waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["editor.open"].exists)
        XCTAssertFalse(app.buttons["editor.exit"].exists)
        XCTAssertFalse(app.buttons["editor.panel"].exists)
    }
    private func endSourceInput(_ app: XCUIApplication) {
        if app.keyboards.firstMatch.exists {
            let done=app.buttons["source.keyboardDone"]
            if done.exists { done.tap() }
            else if app.buttons["收起键盘"].exists { app.buttons["收起键盘"].tap() }
        }
    }
    private func openAddField(_ app: XCUIApplication) {
        endSourceInput(app)
        XCTAssertFalse(app.buttons["source.addField"].isHittable)
        openEditorTools(app)
        let insert=app.buttons["source.addField"]
        XCTAssertTrue(insert.waitForExistence(timeout:5));insert.tap()
    }
    private func openEditorTools(_ app:XCUIApplication) {
        endSourceInput(app);app.buttons["⋮"].tap();app.buttons["工具箱"].tap()
        let group=app.buttons["源码与按键"]
        XCTAssertTrue(group.waitForExistence(timeout:8));tapSettled(group)
    }
    private func cleanup(_ app: XCUIApplication) {
        endSourceInput(app);app.buttons["⋮"].tap();app.buttons["工具箱"].tap()
        let button=app.buttons["tools.cssCleanup"]
        XCTAssertEqual(app.buttons.matching(identifier:"tools.cssCleanup").count,1)
        tapSettled(button)
    }
    private func proof(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways
        add(attachment)
    }
    func testSourceOpensDirectlyAndPlaintextLivesInToolbox() {
        let app = openApp(); edit("py_26.ini", in: app, folder: "port")
        assertSourceVisible(app)
        XCTAssertFalse(app.buttons["source.addField"].isHittable)
        app.buttons["⋮"].tap()
        XCTAssertFalse(app.buttons["生成明文副本"].exists)
        app.buttons["工具箱"].tap()
        let plaintext=app.buttons["tools.plaintext"]
        XCTAssertTrue(plaintext.waitForExistence(timeout:5));XCTAssertTrue(plaintext.isEnabled)
        proof(app,name:"Plaintext-copy-in-toolbox")
        plaintext.tap()
        let result=app.alerts["提示"]
        XCTAssertTrue(result.waitForExistence(timeout:10))
        XCTAssertTrue(result.staticTexts.matching(NSPredicate(format:"label CONTAINS %@","已生成 0 份明文副本")).firstMatch.exists)
        result.buttons["确定"].tap();assertSourceVisible(app)
    }
    func testCSSCleanupMenuClearsUnusedBodyKeepsHeaderAndUndoRestoresIt() {
        let app = openApp(); edit("styles.css", in: app)
        assertSourceVisible(app)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]"))
        proof(app, name: "CSS-editor-adjacent-actions")
        cleanup(app)
        XCTAssertTrue(app.staticTexts["已清空 1 个未调用样式的内容，标题保留，可撤销"].waitForExistence(timeout: 5))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]\n[STYLE3]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("STYLE_NUM=3\n"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE1]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE3]"))
        proof(app, name: "CSS-cleanup-keeps-STYLE-headers")
        endSourceInput(app); openEditorTools(app); app.buttons["撤销"].tap()
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]\nNM_COLOR=FF000000"))
    }
    func testCSSCleanupFromToolboxClosesSheetKeepsStylesAndSupportsUndo() {
        let app = openApp()
        app.buttons["⋮"].tap(); app.buttons["工具箱"].tap()
        let cleanup = app.buttons["tools.cssCleanup"]
        XCTAssertTrue(cleanup.waitForExistence(timeout: 5))
        XCTAssertTrue(cleanup.isEnabled)
        cleanup.tap()
        XCTAssertTrue(app.staticTexts["已清空 1 个未调用样式的内容，标题保留，可撤销"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.buttons["tools.cssCleanup"].exists)
        let source = app.textViews.firstMatch
        XCTAssertTrue(source.waitForExistence(timeout: 5))
        let cleaned = source.value as? String ?? ""
        XCTAssertTrue(cleaned.contains("[STYLE2]\n[STYLE3]"))
        XCTAssertTrue(cleaned.contains("STYLE_NUM=3\n"))
        XCTAssertTrue(cleaned.contains("[STYLE1]\nNM_COLOR=FFFFFFFF"))
        XCTAssertTrue(cleaned.contains("[STYLE3]\nNM_COLOR=FF000000"))
        proof(app, name: "CSS-cleanup-from-toolbox")
        openEditorTools(app); app.buttons["撤销"].tap()
        XCTAssertTrue((source.value as? String ?? "").contains("[STYLE2]\nNM_COLOR=FF000000"))
    }
    func testToolboxCleanupWithMultipleCSSWaitsForSelectionAndCanCancel() {
        let app = XCUIApplication()
        app.launchArguments = ["--editor-controls-fixture", "--multiple-css-fixture"]
        app.launch()
        XCTAssertTrue(app.buttons["包内文件夹：controls.bds"].waitForExistence(timeout: 30))
        let source = app.textViews.firstMatch
        XCTAssertTrue(source.waitForExistence(timeout: 5))
        let original = source.value as? String
        app.buttons["⋮"].tap(); app.buttons["工具箱"].tap()
        tapSettled(app.buttons["tools.cssCleanup"])
        XCTAssertTrue(app.buttons["extra.css"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["styles.css"].waitForExistence(timeout: 10))
        let cancel = app.buttons["取消"]
        if cancel.exists { cancel.tap() }
        else { app.coordinate(withNormalizedOffset: CGVector(dx: 0.01, dy: 0.5)).tap() }
        let dismissed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            !app.buttons["extra.css"].exists
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [dismissed], timeout: 5), .completed)
        XCTAssertEqual(source.value as? String, original)
        app.buttons["⋮"].tap(); app.buttons["工具箱"].tap()
        tapSettled(app.buttons["tools.cssCleanup"])
        let choice = app.buttons["extra.css"]
        XCTAssertTrue(choice.waitForExistence(timeout: 5)); choice.tap()
        XCTAssertTrue(app.staticTexts["已清空 1 个未调用样式的内容，标题保留，可撤销"].waitForExistence(timeout: 10))
        XCTAssertEqual(source.value as? String, "[STYLE99]\n")
        openEditorTools(app); app.buttons["撤销"].tap()
        XCTAssertTrue((source.value as? String ?? "").contains("NM_COLOR=FF123456"))
    }
    func testCSSCleanupCanBeOpenedFromINIMenu() {
        let app = openApp(); edit("py_26.ini", in: app, folder: "port")
        cleanup(app)
        XCTAssertTrue(app.staticTexts["已清空 1 个未调用样式的内容，标题保留，可撤销"].waitForExistence(timeout: 5))
        assertSourceVisible(app)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE1]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE3]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[STYLE2]\n[STYLE3]"))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("STYLE_NUM=3\n"))
    }
    func testPreviewAndSourceFramesStayFixedAcrossKeyboardAndRotation() {
        let app=combinedApp(),source=app.textViews.firstMatch
        let preview=app.descendants(matching:.any)["editor.preview"]
        var expected=source.value as? String ?? ""
        for orientation in [UIDeviceOrientation.portrait,.landscapeLeft] {
            endSourceInput(app);XCUIDevice.shared.orientation=orientation
            let settled=XCTNSPredicateExpectation(predicate:NSPredicate{_,_ in
                let frame=app.windows.firstMatch.frame
                return orientation == .portrait ? frame.height>frame.width:frame.width>frame.height
            },object:nil)
            XCTAssertEqual(XCTWaiter.wait(for:[settled],timeout:12),.completed)
            let canvas=preview.frame,code=source.frame
            jumpToEnd(app)
            let stable=XCTNSPredicateExpectation(predicate:NSPredicate{_,_ in
                let p=preview.frame,e=source.frame
                return abs(p.minX-canvas.minX)<2 && abs(p.minY-canvas.minY)<2 && abs(p.width-canvas.width)<2 && abs(p.height-canvas.height)<2 && abs(e.minY-code.minY)<2 && abs(e.height-code.height)<2
            },object:nil)
            XCTAssertEqual(XCTWaiter.wait(for:[stable],timeout:12),.completed)
            source.typeText("\n; fixed-keyboard-draft");expected += "\n; fixed-keyboard-draft"
            XCTAssertEqual(source.value as? String,expected)
            XCTAssertTrue(app.buttons["⋮"].isHittable);XCTAssertTrue(app.buttons["保存"].isHittable)
            XCTAssertFalse(app.buttons["编辑操作"].exists)
            proof(app,name:orientation == .portrait ? "Portrait-fixed-preview-with-keyboard":"Landscape-fixed-preview-with-keyboard")
            endSourceInput(app);XCTAssertEqual(source.value as? String,expected)
            XCTAssertEqual(preview.frame.minY,canvas.minY,accuracy:2);XCTAssertEqual(preview.frame.height,canvas.height,accuracy:2)
        }
    }
    func testModesMoveToHeaderAndToolboxHasOneCleanup() {
        let app=openApp(),effects=app.buttons["editor.effects"],floating=app.buttons["editor.floating"],menu=app.buttons["⋮"]
        XCTAssertTrue(effects.waitForExistence(timeout:10));XCTAssertEqual(effects.label,"动效");XCTAssertEqual(floating.label,"漂浮")
        XCTAssertLessThan(effects.frame.maxX,floating.frame.minX);XCTAssertLessThan(floating.frame.maxX,menu.frame.minX)
        XCTAssertEqual(effects.frame.midY,menu.frame.midY,accuracy:2)
        XCTAssertFalse(app.buttons["编辑操作"].exists)
        openEditorTools(app)
        for name in ["添加字段","文本搜索","跳到最后一行","撤销","重做","检查当前文件","批量 / 对齐","候选栏","添加按键","复制按键","删除按键"]{XCTAssertEqual(app.buttons.matching(NSPredicate(format:"label == %@",name)).count,1,name)}
        XCTAssertEqual(app.buttons.matching(identifier:"tools.cssCleanup").count,1)
        proof(app,name:"Toolbox-consolidated-editor-actions")
    }
    func testArchiveFolderActionsHaveSpacingAndStayInsideSheet() {
        let app=openApp();app.buttons["包内文件夹：controls.bds"].tap()
        let ids=["archive.newFolder","archive.importFiles","archive.selectFiles"]
        let first=app.buttons[ids[0]];XCTAssertTrue(first.waitForExistence(timeout:10))
        for i in ids.indices {
            let a=app.buttons[ids[i]];XCTAssertTrue(a.isHittable)
            for j in ids.indices where j>i {
                let x=a.frame,y=app.buttons[ids[j]].frame
                XCTAssertFalse(x.intersects(y));XCTAssertTrue(x.maxX+6<=y.minX || y.maxX+6<=x.minX || x.maxY+6<=y.minY || y.maxY+6<=x.minY)
            }
        }
        app.buttons["archive.selectFiles"].tap();XCTAssertTrue(app.buttons["archive.selectAll"].isHittable);XCTAssertTrue(app.buttons["archive.cancelSelection"].isHittable)
        XCTAssertFalse(app.buttons["archive.selectAll"].frame.intersects(app.buttons["archive.cancelSelection"].frame))
        proof(app,name:"Archive-folder-actions-with-gaps");app.buttons["archive.close"].tap()
    }
    func testFloatingButtonsHaveEqualFramesIncludingMenuAndPauseState() {
        let app = openApp()
        XCTAssertTrue(app.buttons["漂浮"].isHittable)
        app.buttons["漂浮"].tap()
        let ids = ["animation.replay", "animation.pause", "animation.selector", "animation.images", "animation.log"]
        for id in ids {
            let button = app.buttons[id]
            XCTAssertTrue(button.waitForExistence(timeout: 5)); XCTAssertTrue(button.isHittable)
            XCTAssertEqual(button.frame.width, 88, accuracy: 1)
            XCTAssertEqual(button.frame.height, 32, accuracy: 1)
        }
        proof(app, name: "Floating-controls-equal-size")
        app.buttons["animation.pause"].tap()
        XCTAssertEqual(app.buttons["animation.pause"].label, "继续")
        XCTAssertEqual(app.buttons["animation.pause"].frame.width, 88, accuracy: 1)
        XCTAssertEqual(app.buttons["animation.pause"].frame.height, 32, accuracy: 1)
        app.buttons["animation.pause"].tap()
        app.buttons["animation.selector"].tap()
        let panelBinding = app.buttons["animation.panelBinding"]
        XCTAssertTrue(panelBinding.waitForExistence(timeout: 5))
        XCTAssertTrue(panelBinding.isHittable)
        panelBinding.tap()
        XCTAssertEqual(app.buttons["animation.selector"].frame.width, 88, accuracy: 1)
        XCTAssertEqual(app.buttons["animation.selector"].frame.height, 32, accuracy: 1)
    }
    func testAnimationEditorAppendsNewBlockAndPersistsItInAnimINI() {
        let app = openApp()
        app.buttons["漂浮"].tap()
        app.buttons["animation.selector"].tap()
        app.buttons["ANIM1"].tap()
        let editor = app.textViews.firstMatch
        XCTAssertTrue(editor.waitForExistence(timeout:5))
        XCTAssertTrue((editor.value as? String ?? "").contains("[ANIM1]"))
        // The fixture has a short document. Tapping below its text puts the
        // caret at the end, just as a user appending an animation would do.
        editor.coordinate(withNormalizedOffset:CGVector(dx:0.8,dy:0.85)).tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout:5))
        editor.typeText("\n\n[ANIM18]\nTYPE=4\nDURATION=250\n")
        XCTAssertTrue((editor.value as? String ?? "").contains("[ANIM18]"))
        app.buttons["漂浮"].tap()
        XCTAssertFalse(app.alerts.firstMatch.exists)
        edit("anim.ini",in:app)
        let source = app.textViews.firstMatch.value as? String ?? ""
        XCTAssertTrue(source.contains("[ANIM1]"))
        XCTAssertTrue(source.contains("[ANIM18]"))
        XCTAssertTrue(source.contains("ANIM_NUM=2"))
        XCTAssertTrue(source.contains("DURATION=250"))
        proof(app,name:"Added-ANIM18-saved-in-anim-ini")
    }
    private func combinedApp(narrow:Bool=false)->XCUIApplication {
        XCUIDevice.shared.orientation = .portrait
        let app=XCUIApplication()
        app.launchArguments=["--combined-preview-fixture"] + (narrow ? ["--narrow-preview-fixture"] : [])
        app.launch()
        XCTAssertTrue(app.buttons["包内文件夹：combined.bds"].waitForExistence(timeout:15))
        return app
    }
    func testArchiveFileCopyAndConfirmedBatchDeletion() {
        let app = openApp()
        endSourceInput(app)
        app.buttons["包内文件夹：controls.bds"].tap()
        let original = app.buttons["styles.css"]
        XCTAssertTrue(original.waitForExistence(timeout: 5))
        original.press(forDuration: 1)
        app.buttons["复制文件"].tap()
        let first = app.buttons["styles 副本.css"]
        XCTAssertTrue(first.waitForExistence(timeout: 5))
        original.press(forDuration: 1)
        app.buttons["复制文件"].tap()
        let second = app.buttons["styles 副本 2.css"]
        XCTAssertTrue(second.waitForExistence(timeout: 5))
        proof(app, name: "Archive-copies-preserve-original")
        app.buttons["多选"].tap(); first.tap(); second.tap()
        XCTAssertTrue(app.staticTexts["已选 2 个文件"].exists)
        app.buttons["archive.deleteSelected"].tap()
        XCTAssertTrue(app.alerts.firstMatch.waitForExistence(timeout: 5))
        app.alerts.firstMatch.buttons["取消"].tap()
        XCTAssertTrue(first.exists); XCTAssertTrue(second.exists); XCTAssertTrue(original.exists)
        app.buttons["archive.deleteSelected"].tap()
        proof(app, name: "Archive-batch-delete-confirmation")
        app.alerts.firstMatch.buttons["删除"].tap()
        XCTAssertTrue(app.staticTexts["已删除 2 个文件"].waitForExistence(timeout: 5))
        XCTAssertFalse(first.exists); XCTAssertFalse(second.exists)
        XCTAssertTrue(original.exists); XCTAssertTrue(app.buttons["port"].exists)
        proof(app, name: "Archive-batch-delete-keeps-unselected-files")
    }
    private func preview(_ app:XCUIApplication)->XCUIElement {
        app.descendants(matching:.any).matching(identifier:"editor.preview").firstMatch
    }
    private func screenPoint(_ app:XCUIApplication,_ x:CGFloat,_ y:CGFloat)->CGPoint {
        let r=preview(app).frame,scale=min((r.width-16)/1080,(r.height-16)/760)
        return CGPoint(x:r.midX-1080*scale/2+x*scale,y:r.midY-760*scale/2+(y+120)*scale)
    }
    private func tapScene(_ app:XCUIApplication,_ x:CGFloat,_ y:CGFloat) {
        let point=screenPoint(app,x,y)
        app.coordinate(withNormalizedOffset:.zero).withOffset(CGVector(dx:point.x,dy:point.y)).tap()
    }
    private func assertCompletePreview(_ app:XCUIApplication,name:String) {
        let canvas=preview(app)
        XCTAssertTrue(canvas.waitForExistence(timeout:5))
        XCTAssertEqual(canvas.label,"顶栏与键盘预览")
        XCTAssertEqual(canvas.value as? String,"py_26 · cand1.cnd")
        // Capture the physical screen. Application screenshots can retain a
        // portrait crop immediately after rotation on the iPad simulator.
        let screenshot=XCUIScreen.main.screenshot(),raw=screenshot.image
        let attachment=XCTAttachment(screenshot:screenshot);attachment.name=name;attachment.lifetime = .keepAlways;add(attachment)
        // XCUIScreenshot may carry landscape orientation in UIImage metadata.
        // Draw through UIImage before comparing against screen coordinates.
        let format=UIGraphicsImageRendererFormat();format.scale=raw.scale
        let image=UIGraphicsImageRenderer(size:raw.size,format:format).image { _ in raw.draw(in:CGRect(origin:.zero,size:raw.size)) }
        print("PREVIEW_SCREEN: \(name), app=\(app.frame), canvas=\(canvas.frame), raw=\(raw.size), orientation=\(raw.imageOrientation.rawValue), normalized=\(image.size)")
        guard let cg=image.cgImage else { XCTFail("No preview screenshot");return }
        var bytes=[UInt8](repeating:0,count:cg.width*cg.height*4)
        guard let ctx=CGContext(data:&bytes,width:cg.width,height:cg.height,bitsPerComponent:8,bytesPerRow:cg.width*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else { XCTFail("Cannot read screenshot");return }
        ctx.draw(cg,in:CGRect(x:0,y:0,width:cg.width,height:cg.height))
        let pixelScale=CGFloat(cg.width)/image.size.width
        for (point,expected) in [(screenPoint(app,540,-105),[160,96,64]),(screenPoint(app,20,620),[64,128,192])] {
            XCTAssertTrue(canvas.frame.contains(point))
            let x=Int(point.x*pixelScale),y=Int(point.y*pixelScale)
            guard x>=0,y>=0,x<cg.width,y<cg.height else { XCTFail("Preview cropped");continue }
            let offset=(y*cg.width+x)*4
            for channel in 0..<3 { XCTAssertEqual(Double(bytes[offset+channel]),Double(expected[channel]),accuracy:8,"Missing top bar or bottom keyboard pixels") }
        }
    }
    func testTopBarAndKeyboardRemainVisibleThroughAnimationAndBarEditing() {
        let app=combinedApp()
        assertCompletePreview(app,name:"Combined-top-bar-and-keyboard")
        app.buttons["动效"].tap();tapScene(app,54,80)
        XCTAssertTrue(app.buttons["动效"].waitForExistence(timeout:5))
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[ANIM1]"))
        assertCompletePreview(app,name:"Combined-preview-during-animation-editing")
        tapScene(app,540,-60)
        assertSourceVisible(app)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[CAND]"))
        XCTAssertFalse((app.textViews.firstMatch.value as? String ?? "").contains("[KEY1]"))
        assertCompletePreview(app,name:"Combined-preview-while-editing-CND")
        tapScene(app,54,80)
        XCTAssertTrue((app.textViews.firstMatch.value as? String ?? "").contains("[KEY1]"))
        XCUIDevice.shared.orientation = .landscapeLeft
        assertCompletePreview(app,name:"Combined-preview-landscape")
    }
    func testNarrowPreviewAndSoftwareKeyboardKeepTopBarAndBottomRowVisible() {
        let app=combinedApp(narrow:true)
        XCTAssertEqual(preview(app).frame.width,375,accuracy:1)
        assertCompletePreview(app,name:"Combined-preview-375-point-width")
        // A drag at fit size must not displace/crop the top of the skin.
        let canvas=preview(app)
        canvas.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:0.5)).press(forDuration:0.1,thenDragTo:canvas.coordinate(withNormalizedOffset:CGVector(dx:0.7,dy:0.2)))
        assertCompletePreview(app,name:"Combined-preview-after-drag-at-fit")
        assertSourceVisible(app);app.textViews.firstMatch.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout:5))
        assertCompletePreview(app,name:"Combined-preview-with-software-keyboard")
    }
}
