import Foundation

enum TileEdits {
    static func single(source:String,inner:String,width:Int,height:Int)throws->String {
        func rect(_ value:String)throws->[Double] {
            let fields=value.split(separator:",",omittingEmptySubsequences:false)
            let values=fields.compactMap{Double($0.trimmingCharacters(in:.whitespaces))}
            guard values.count==4,fields.count==4,values.allSatisfy({$0.isFinite}),values[2]>0,values[3]>0 else{throw AnimationEditError.invalid("矩形应为 x,y,正宽,正高")}
            return values
        }
        func format(_ values:[Double])->String {values.map{String(format:"%g",locale:Locale(identifier:"en_US_POSIX"),$0)}.joined(separator:",")}
        let r=try rect(source)
        guard r[0]>=0,r[1]>=0,r[0]+r[2]<=Double(width),r[1]+r[3]<=Double(height) else{throw AnimationEditError.invalid("切片超出图片范围")}
        var text="[GLOBAL]\nIMG_NUM=1\n\n[IMG1]\nSOURCE_RECT="+format(r)+"\n"
        if !inner.trimmingCharacters(in:.whitespaces).isEmpty {
            let i=try rect(inner)
            guard i[0]>=r[0],i[1]>=r[1],i[0]+i[2]<=r[0]+r[2],i[1]+i[3]<=r[1]+r[3] else{throw AnimationEditError.invalid("INNER_RECT 超出 SOURCE_RECT，坐标相对于整张图片")}
            text+="INNER_RECT="+format(i)+"\n"
        }
        return text
    }
}
