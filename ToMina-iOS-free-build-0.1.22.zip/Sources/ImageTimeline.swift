import Foundation
import ImageIO

struct ImageTimeline {
    let source:CGImageSource
    let delays:[Double]
    var duration:Double{delays.reduce(0,+)}
    init?(_ file:URL) {
        guard let source=CGImageSourceCreateWithURL(file as CFURL,nil) else{return nil}
        let count=CGImageSourceGetCount(source);guard count>0,count<=512 else{return nil}
        guard (0..<count).allSatisfy({index in
            let properties=CGImageSourceCopyPropertiesAtIndex(source,index,nil) as? [String:Any] ?? [:]
            let w=(properties[kCGImagePropertyPixelWidth as String] as? NSNumber)?.int64Value ?? 0,h=(properties[kCGImagePropertyPixelHeight as String] as? NSNumber)?.int64Value ?? 0
            return w>0 && h>0 && w<=8_000_000/max(1,h)
        }) else{return nil}
        self.source=source
        delays=(0..<count).map {index in
            let properties=CGImageSourceCopyPropertiesAtIndex(source,index,nil) as? [String:Any] ?? [:]
            let gif=properties[kCGImagePropertyGIFDictionary as String] as? [String:Any] ?? [:]
            let png=properties[kCGImagePropertyPNGDictionary as String] as? [String:Any] ?? [:]
            let delay=(gif[kCGImagePropertyGIFUnclampedDelayTime as String] ?? gif[kCGImagePropertyGIFDelayTime as String] ?? png[kCGImagePropertyAPNGUnclampedDelayTime as String] ?? png[kCGImagePropertyAPNGDelayTime as String]) as? NSNumber
            return max(1,(delay?.doubleValue ?? 0.1)*1000)
        }
    }
    func index(time:Double,duration:Double)->Int {
        let total=self.duration,target=min(max(0,total-1),max(0,time)*total/max(1,duration))
        var end:Double=0
        for (index,delay) in delays.enumerated(){end+=delay;if target<end{return index}}
        return max(0,delays.count-1)
    }
}
