import Foundation
import SwiftUI
import UIKit

struct ViewRegion {let name:String;let rect:CGRect}

@MainActor enum PreviewGuides {
    static func regions(_ store:SkinStore)->[ViewRegion] {
        if let bda=store.bda {return (bda.panel?.items ?? []).compactMap {item in
            guard item.visible,let rect=BdaPreviewEngine.rect(item.data),rect.width>0,rect.height>0 else{return nil}
            return ViewRegion(name:item.id,rect:rect)
        }}
        var result:[ViewRegion]=[]
        func append(_ section:Section,_ prefix:String="",_ dy:CGFloat=0) {
            let r=SkinConfiguration.numbers(section.values["VIEW_RECT"])
            if r.count==4,r[2]>0,r[3]>0 {result.append(ViewRegion(name:prefix+section.name,rect:CGRect(x:r[0],y:CGFloat(r[1])+dy,width:r[2],height:r[3])))}
        }
        for key in store.keys where store.renderer.effectiveSections.indices.contains(key.id){append(store.renderer.effectiveSections[key.id])}
        if store.renderer.candidateFile != nil {
            let size=store.renderer.candidateSize
            result.append(ViewRegion(name:"CAND",rect:CGRect(x:0,y:-size.height,width:size.width,height:size.height)))
            for section in store.renderer.candidateSections where section.name.hasPrefix("ICON") && store.renderer.visible(section) {append(section,"CAND/",-size.height)}
        }
        return result
    }
    static let blue=Color(red:52/255,green:120/255,blue:191/255)
    static func bounds(_ panel:CGSize,_ regions:[ViewRegion])->CGRect {regions.reduce(CGRect(origin:.zero,size:panel)){$0.union($1.rect)}}
    static func draw(_ regions:[ViewRegion],scale:CGFloat,context:inout GraphicsContext) {
        for region in regions {context.stroke(Path(region.rect),with:.color(blue),lineWidth:1.5/max(0.000001,scale))}
    }
    static func export(_ store:SkinStore)throws->URL {
        guard store.saveAnimationSource() else{throw SkinFailure(message:"请先保存动效编辑")}
        try store.save()
        let regions=regions(store),bounds=bounds(store.panel,regions)
        guard !regions.isEmpty else{throw SkinFailure(message:"当前面板没有可确认的 VIEW 坐标")}
        let size=CGSize(width:ceil(bounds.width),height:ceil(bounds.height))
        guard size.width>0,size.height>0,size.width<=8192,size.height<=8192,size.width*size.height<=16000000 else{throw SkinFailure(message:"辅助线图片尺寸超过限制")}
        let format=UIGraphicsImageRendererFormat();format.scale=1;format.opaque=false
        let image=UIGraphicsImageRenderer(size:size,format:format).image {drawing in
            let c=drawing.cgContext;c.translateBy(x:-bounds.minX,y:-bounds.minY)
            let color=UIColor(red:52/255,green:120/255,blue:191/255,alpha:1)
            c.setStrokeColor(color.cgColor);c.setLineWidth(1.5)
            for region in regions {c.stroke(region.rect);(region.name as NSString).draw(at:CGPoint(x:region.rect.minX+3,y:region.rect.minY+3),withAttributes:[.font:UIFont.systemFont(ofSize:16),.foregroundColor:color])}
        }
        guard let data=image.pngData() else{throw SkinFailure(message:"辅助线导出失败")}
        let name=store.previewPanelName
        let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString,isDirectory:true)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        let file=folder.appendingPathComponent(name+"-VIEW辅助线.png");try data.write(to:file,options:.atomic);return file
    }
}
