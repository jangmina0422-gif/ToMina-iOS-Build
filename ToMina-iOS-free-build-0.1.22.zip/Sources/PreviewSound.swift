import Foundation
import AVFoundation

@MainActor enum PreviewSoundBinding {
    static func reference(key:Section?,panel:Section?,styles:[String:Section])->String {
        let direct=(key?.values["PRESS_SOUND_PATH"] ?? "").trimmingCharacters(in:.whitespacesAndNewlines)
        if !direct.isEmpty{return direct}
        var id=(key?.values["SOUND_STYLE"] ?? "").trimmingCharacters(in:.whitespacesAndNewlines)
        if id.isEmpty{id=(panel?.values["SOUND_STYLE"] ?? "").trimmingCharacters(in:.whitespacesAndNewlines)}
        return (styles["STYLE"+id]?.values["PRESS_SOUND_PATH"] ?? "").trimmingCharacters(in:.whitespacesAndNewlines)
    }
    static func platformPath(_ reference:String,extension ext:String="aiff")->String {
        let value=reference.trimmingCharacters(in:.whitespacesAndNewlines).replacingOccurrences(of:"\\",with:"/")
        guard !value.isEmpty else{return ""}
        let suffix=(value as NSString).pathExtension.lowercased()
        guard suffix.isEmpty || ["ogg","aif","aiff"].contains(suffix) else{return ""}
        return (suffix.isEmpty ? value:(value as NSString).deletingPathExtension)+"."+ext
    }
    static func resolve(_ reference:String,root:URL,config:URL?,files:[URL])->URL? {
        let path=platformPath(reference)
        guard !path.isEmpty,let file=SkinConfiguration.resolve(path,root:root,config:config ?? root.appendingPathComponent("sound.ini"),files:files),file.pathExtension.lowercased()=="aiff" else{return nil}
        return file
    }
}

@MainActor final class PreviewSound {
    var enabled=false {didSet{if !enabled{stop()}}}
    private var clips:[String:Data]=[:]
    private var players:[AVAudioPlayer]=[]
    private(set) var playedCount=0
    private(set) var lastFile:URL?
    private(set) var lastError:String?
    func clear(){stop();clips.removeAll()}
    private func stop(){players.forEach{$0.stop()};players.removeAll()}
    @discardableResult func press(_ requested:URL?)->Bool {
        guard enabled else{return false}
        let fallback=Bundle.main.url(forResource:"key-click",withExtension:"aiff")
        guard let file=requested ?? fallback else{lastError="未找到按键音效";return false}
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback,mode:.default,options:[.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
            let stamp=(try? file.resourceValues(forKeys:[.contentModificationDateKey,.fileSizeKey]))
            let cacheKey=file.path+":"+String(stamp?.contentModificationDate?.timeIntervalSince1970 ?? 0)+":"+String(stamp?.fileSize ?? 0)
            let data:Data
            if let cached=clips[cacheKey]{data=cached}else{data=try Data(contentsOf:file);if clips.count>=48{clips.removeAll()};clips[cacheKey]=data}
            players.removeAll{!$0.isPlaying}
            if players.count>=12{players.removeFirst().stop()}
            let player=try AVAudioPlayer(data:data);player.numberOfLoops=0;player.volume=1;player.prepareToPlay()
            guard player.play() else{lastError="音效未能播放";return false}
            players.append(player);playedCount+=1;lastFile=file;lastError=nil;return true
        }catch{if requested != nil{return press(nil)};lastError=error.localizedDescription;return false}
    }
}
