import Foundation
import CryptoKit

enum Credentials {
    static func readHashes(_ data: Data?) -> Set<String> {
        guard let data,
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              object["version"] as? Int == 1,
              let hashes = object["hashes"] as? [String],
              !hashes.isEmpty,
              hashes.allSatisfy({ $0.range(of: "^[0-9a-f]{64}$", options: .regularExpression) != nil }) else { return [] }
        return Set(hashes)
    }
    static let hashes = readHashes(Bundle.main.url(forResource: "Credentials", withExtension: "json").flatMap { try? Data(contentsOf: $0) })
    static func matches(_ account: String, _ password: String) -> Bool {
        let data = Data((account + "\0" + password).utf8)
        let hash = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        return hashes.contains(hash)
    }
}
