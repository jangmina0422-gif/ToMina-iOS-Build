import Foundation
import ZIPFoundation

struct EditorViewState: Codable, Equatable, Sendable {
    var selected = "", selection: [String] = []
    var editing = false, multi = false, touch = false, view = false, pressed = false
    var parameter = "VIEW_RECT", effect = "", event = "PRESS_ANIM"
    var zoom: Double = 1, panX: Double = 0, panY: Double = 0
    var color = "light", orientation = "port", panel = "py_26", animation = ""
    var playing = true, debug = false, hasCandidates = false, floatingPaused = false
    var candidate = "", floating = ""
}
struct EditorResumeRecord: Codable, Sendable {
    var version = 1
    var bookmark: Data
    var filename: String
    var current: String
    var preview: String
    var view: EditorViewState
}

enum OriginalSkinDocument {
    static var sessionFile: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("editor-resume.json")
    }
    static func bookmark(_ url: URL) throws -> Data {
        try url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil)
    }
    static func resolve(_ data: Data) throws -> URL {
        var stale = false
        return try URL(resolvingBookmarkData: data, options: .withoutUI, relativeTo: nil, bookmarkDataIsStale: &stale)
    }
    static func unpack(_ url: URL) throws -> URL {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let coordinator = NSFileCoordinator(filePresenter: nil)
        var failure: NSError?, operationError: Error?, result: URL?
        coordinator.coordinate(readingItemAt: url, options: .withoutChanges, error: &failure) { source in
            do {
                guard ["bds", "bdi", "bda"].contains(source.pathExtension.lowercased()) else { throw SkinFailure(message: "请选择 BDS、BDI 或 BDA") }
                let archive = try Archive(url: source, accessMode: .read)
                var count = 0, total: UInt64 = 0, seen = Set<String>()
                for entry in archive {
                    count += 1; total += UInt64(entry.uncompressedSize)
                    let parts = entry.path.split(separator: "/")
                    guard count <= 6000, total <= 128*1024*1024, entry.uncompressedSize <= 32*1024*1024,
                          !entry.path.hasPrefix("/"), !entry.path.contains("\\"), !entry.path.contains(":"), !parts.contains(".."),
                          entry.type != .symlink, seen.insert(entry.path.lowercased()).inserted else {
                        throw SkinFailure(message: "压缩包路径不安全、重复或超过大小限制")
                    }
                }
                guard count > 0 else { throw SkinFailure(message: "空压缩包") }
                let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                let folder = docs.appendingPathComponent(UUID().uuidString, isDirectory: true)
                do { try FileManager.default.unzipItem(at: source, to: folder) }
                catch { try? FileManager.default.removeItem(at: folder); throw error }
                result = folder
            } catch { operationError = error }
        }
        if let failure { throw failure }; if let operationError { throw operationError }
        guard let result else { throw SkinFailure(message: "无法读取原皮肤文件，请重新选择原文件") }; return result
    }
    static func overwrite(root: URL, original: URL) throws {
        let ready = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".zip")
        defer { try? FileManager.default.removeItem(at: ready) }
        try FileManager.default.zipItem(at: root, to: ready, shouldKeepParent: false)
        let bytes = try Data(contentsOf: ready, options: .mappedIfSafe)
        guard bytes.count <= 128*1024*1024 else { throw SkinFailure(message: "文件超过保存大小限制") }
        let access = original.startAccessingSecurityScopedResource()
        defer { if access { original.stopAccessingSecurityScopedResource() } }
        let coordinator = NSFileCoordinator(filePresenter: nil)
        var failure: NSError?, operationError: Error?
        coordinator.coordinate(writingItemAt: original, options: .forReplacing, error: &failure) { destination in
            do {
                guard FileManager.default.fileExists(atPath: destination.path) else { throw SkinFailure(message: "原文件已移动或删除，请重新选择原文件") }
                let old = try Data(contentsOf: destination)
                do {
                    try bytes.write(to: destination, options: .atomic)
                    guard try Data(contentsOf: destination) == bytes else { throw SkinFailure(message: "原文件写入校验失败") }
                } catch {
                    do { try old.write(to: destination, options: .atomic) }
                    catch { throw SkinFailure(message: "保存失败，原文件未能恢复，请检查文件位置和写入权限") }
                    throw error
                }
            } catch { operationError = error }
        }
        if let failure { throw failure }; if let operationError { throw operationError }
    }
    static func path(_ relative: String, root: URL) throws -> URL? {
        if relative.isEmpty { return nil }
        let parts = relative.components(separatedBy: "/")
        guard !parts.contains(where: { $0.isEmpty || $0 == "." || $0 == ".." || $0.contains(":") || $0.contains("\\") }) else { throw SkinFailure(message: "保存的编辑路径无效") }
        let file = root.appendingPathComponent(relative).resolvingSymlinksInPath()
        guard file.pathComponents.starts(with: root.resolvingSymlinksInPath().pathComponents), FileManager.default.fileExists(atPath: file.path) else { throw SkinFailure(message: "原文件中已没有 " + relative) }
        return file
    }
    static func write(_ record: EditorResumeRecord, at file: URL) throws {
        let data = try JSONEncoder().encode(record)
        try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
        try data.write(to: file, options: .atomic)
    }
}
