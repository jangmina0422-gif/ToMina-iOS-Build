import Foundation
import CryptoKit
import UIKit
import ZIPFoundation

enum SystemMigration {
    typealias F = BinaryPlaintext.Field
    static func allFiles(_ root: URL) -> [URL] {
        (FileManager.default.enumerator(at:root,includingPropertiesForKeys:[.isRegularFileKey])?.allObjects as? [URL] ?? []).filter { (try? $0.resourceValues(forKeys:[.isRegularFileKey]).isRegularFile) == true }
    }
    static func hash(_ data: Data) -> String { SHA256.hash(data:data).map{String(format:"%02x",$0)}.joined() }
    static func object(_ value: Any?) -> [String:Any] { value as? [String:Any] ?? [:] }
    static func string(_ value: Any?) -> String { value.map{String(describing:$0)} ?? "" }
    static func config(_ files: [URL], _ mode: String) throws -> URL {
        let found = files.filter{$0.lastPathComponent=="appearanceConfig" && $0.deletingLastPathComponent().lastPathComponent==mode}
        guard found.count == 1 else { throw SkinFailure(message:"需要单套 \(mode)/appearanceConfig") }; return found[0]
    }
    static func decoded(_ url: URL) throws -> [String:Any] {
        let result = try JSONSerialization.jsonObject(with:BinaryPlaintext.decode(url)) as? [String:Any] ?? [:]
        let value = object(result["decoded"])
        guard !object(value["panels"]).isEmpty, !object(value["imageStyles"]).isEmpty else { throw SkinFailure(message:"外观协议不匹配") }
        return value
    }
    static func index(_ fields:[F], _ number:Int, _ key:String? = nil) throws -> Int {
        let found = fields.indices.filter { i in
            guard fields[i].number==number else { return false }
            guard let key else { return true }
            guard let k=fields[i].children?.first(where:{$0.number==1}) else { return false }
            return (k.text ?? String(k.bits)) == key
        }
        guard found.count == 1 else { throw SkinFailure(message:"映射字段不唯一或缺失：\(number) \(key ?? "")") }; return found[0]
    }
    static func patch(_ fields: inout [F], _ path:[(Int,String?)], _ change:(inout F)throws->Void) throws {
        guard let step=path.first else { return }
        let i=try index(fields,step.0,step.1)
        if path.count==1 { try change(&fields[i]); return }
        guard var children=fields[i].children else { throw SkinFailure(message:"子消息结构不匹配") }
        try patch(&children,Array(path.dropFirst()),change)
        fields[i].children=children; fields[i].bytes=Array(BinaryPlaintext.encode(children))
    }
    static func resource(_ files:[URL], _ id:String) throws -> URL {
        guard !id.isEmpty, !id.contains("/"), !id.contains("\\"), !id.contains(".."), !id.contains(":") else { throw SkinFailure(message:"资源名未验证") }
        let found=files.filter{$0.lastPathComponent==id || $0.lastPathComponent==id+".png"}
        guard let first=found.first else { throw SkinFailure(message:"缺少资源："+id) }
        let data=try Data(contentsOf:first)
        for f in found.dropFirst() { guard try Data(contentsOf:f)==data else { throw SkinFailure(message:"同名资源冲突："+id) } }
        return first
    }
    @MainActor static func convert(root:URL, files:[URL]) throws -> URL {
        let fm=FileManager.default
        var platforms=Set<String>()
        for file in files where file.lastPathComponent.lowercased()=="info.txt" {
            for line in (IniSkinRenderer.read(file) ?? "").components(separatedBy:.newlines) {
                let p=line.split(separator:"=",maxSplits:1).map{$0.trimmingCharacters(in:.whitespaces)}
                if p.count==2,p[0].lowercased()=="supportplatform" { platforms.insert(p[1].uppercased()) }
            }
        }
        guard platforms.count==1,let platform=platforms.first,["I","A"].contains(platform) else { throw SkinFailure(message:"无法自动确定源包平台") }
        let target=root.deletingLastPathComponent().appendingPathComponent(UUID().uuidString)
        if platform=="I" {
            throw SkinFailure(message:"BDI → BDS 暂未验证目标安卓基准、原生按键功能与导入协议；已保留源包，不能只改目录和 SupportPlatform 导出伪转换包。")
        }
        guard files.contains(where:{$0.pathExtension.lowercased()=="ini"}) else { throw SkinFailure(message:"当前迁移需要 R1 INI 布局") }
        let source=try decoded(config(files,"port")), panels=object(source["panels"]), texts=object(source["textStyles"])
        var lightness:[Double]=[]
        for panel in ["py_26","en_26"] {
            for (key,item) in object(object(panels[panel])["keys"]) where key.hasPrefix("KEY_") && key.count==5 {
                let styles=(object(item)["foreStyles"] as? [[String:Any]] ?? []).filter{($0["type"] as? NSNumber)?.intValue==2}.map{object(texts[string($0["key"])])}.sorted{ (($0["fontSize"] as? NSNumber)?.doubleValue ?? 0) > (($1["fontSize"] as? NSNumber)?.doubleValue ?? 0) }
                if let color=(styles.first?["normalColor"] as? NSNumber)?.uint64Value { lightness.append(0.2126*Double((color>>16)&255)+0.7152*Double((color>>8)&255)+0.0722*Double(color&255)) }
            }
        }
        lightness.sort(); let theme = !lightness.isEmpty && lightness[lightness.count/2]>160 ? "dark":"light"
        guard let archive=Bundle.main.url(forResource:theme,withExtension:"bdi") else { throw SkinFailure(message:"缺少已验证的 iOS 基准") }
        try fm.unzipItem(at:archive,to:target)
        do {
            let targetFiles=allFiles(target)
            let expected=theme=="light" ? ["ee2fa66b10dcfbaee068b83e34524c6d9de64bd4428ed1e848ee1b3280053195","67273a48293b0ce9364f48dc840aa67a1fcf3a29548b8b049a1792e64c857d6e"] : ["db82c921a36af257bded1c2a7c52afddae37f875fd0ef3cbafe9a488eec037ac","f81331daf023686f7104321dbd47c9c907d467bb96880f6458c2a2fec4253674"]
            var logs=["目标 iOS 13.3.17；静态候选，真机未验证。仅迁移匹配的普通字符键背景；其他保留基准。"], count=0
            for (modeIndex,mode) in ["port","land"].enumerated() {
                let sf=try config(files,mode),tf=try config(targetFiles,mode),original=try Data(contentsOf:tf)
                guard hash(original)==expected[modeIndex] else { throw SkinFailure(message:"iOS 基准校验失败") }
                let s=try decoded(sf),t=try decoded(tf),si=object(s["imageStyles"]),ti=object(t["imageStyles"])
                var budget=0,wire=try BinaryPlaintext.parse(Array(original),budget:&budget)
                guard BinaryPlaintext.encode(wire)==original else { throw SkinFailure(message:"二进制往返校验失败") }
                var next=ti.keys.compactMap(UInt64.init).max() ?? 0
                for (pn,panel) in object(t["panels"]) { for (kn,key) in object(object(panel)["keys"]) {
                    guard kn.hasPrefix("KEY_"),kn.dropFirst(4).unicodeScalars.count==1 else { continue }
                    do {
                        let sourceKey=object(object(object(object(s["panels"])[pn])["keys"])[kn])
                        let sb=object(sourceKey["backStyle"]),tb=object(object(key)["backStyle"])
                        guard ((sb["type"] as? NSNumber)?.intValue ?? 0) == 0,((tb["type"] as? NSNumber)?.intValue ?? 0) == 0,sb["key"] != nil,tb["key"] != nil else { continue }
                        let style=string(tb["key"]),sn=object(object(si[string(sb["key"])])["normalImage"]),tn=object(object(ti[style])["normalImage"])
                        let sr=object(sn["resource"]),tr=object(tn["resource"])
                        guard string(sr["type"])==string(tr["type"]) else { continue }
                        let imageFile=try resource(files,string(sr["resourceID"])),baselineImage=try resource(targetFiles,string(tr["resourceID"]))
                        let image=try Data(contentsOf:imageFile),oldImage=try Data(contentsOf:baselineImage)
                        if image==oldImage { continue }
                        guard image.starts(with:[137,80,78,71]),oldImage.starts(with:[137,80,78,71]),let a=UIImage(data:image)?.cgImage,let b=UIImage(data:oldImage)?.cgImage,a.width==b.width,a.height==b.height else { continue }
                        guard NSDictionary(dictionary:object(sn["innerRect"])).isEqual(to:object(tn["innerRect"])),NSDictionary(dictionary:object(sn["contentInset"])).isEqual(to:object(tn["contentInset"])) else { continue }
                        let resourceName="mina_static_"+hash(image); next += 1
                        var clone=[wire[try index(wire,1,style)]]
                        try patch(&clone,[(1,nil),(1,nil)]) { $0.bits=next }
                        try patch(&clone,[(1,nil),(2,nil),(1,nil),(1,nil),(2,nil)]) { $0.bytes=Array(resourceName.utf8);$0.text=resourceName;$0.children=nil }
                        var changedWire=wire
                        changedWire.append(clone[0])
                        try patch(&changedWire,[(4,pn),(2,nil),(3,kn),(2,nil),(1,nil),(2,nil)]) { f in guard f.wire==0 else { throw SkinFailure(message:"样式引用格式不匹配") };f.bits=next }
                        var restored=changedWire
                        restored.removeLast()
                        guard let originalID=UInt64(style) else { throw SkinFailure(message:"原样式编号无效") }
                        try patch(&restored,[(4,pn),(2,nil),(3,kn),(2,nil),(1,nil),(2,nil)]) { $0.bits=originalID }
                        guard BinaryPlaintext.encode(restored)==BinaryPlaintext.encode(wire) else { throw SkinFailure(message:"发现计划外配置变化") }
                        let resourceDir=tf.deletingLastPathComponent().deletingLastPathComponent().appendingPathComponent("res")
                        try fm.createDirectory(at:resourceDir,withIntermediateDirectories:true);try image.write(to:resourceDir.appendingPathComponent(resourceName+".png"))
                        wire=changedWire
                        count += 1
                    } catch { logs.append(mode+"/"+pn+"/"+kn+"：保留基准，"+error.localizedDescription) }
                }}
                try BinaryPlaintext.encode(wire).write(to:tf,options:.atomic)
            }
            logs.append("已迁移背景：\(count)。未迁移动画、前景、文字及功能键；原始目标 Info/Token 保留。")
            try logs.joined(separator:"\n").write(to:target.appendingPathComponent("migration-report.txt"),atomically:true,encoding:.utf8)
            return target
        } catch { try? fm.removeItem(at:target);throw error }
    }
}
