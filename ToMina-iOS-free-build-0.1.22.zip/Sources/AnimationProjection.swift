import Foundation

enum AnimationProjection {
    // Android Camera's default projection, around the supplied key pivot.
    // Camera rotates X, negative Y and Z, then projects from 576 source pixels.
    static func matrix(_ degrees:[Double],pivot:[Double])->[Double] {
        let x=degrees[0] * .pi/180,y=degrees[1] * .pi/180,z=degrees[2] * .pi/180
        let rx=[1.0,0,0,0,cos(x),-sin(x),0,sin(x),cos(x)]
        let ry=[cos(y),0,-sin(y),0,1,0,sin(y),0,cos(y)]
        let rz=[cos(z),-sin(z),0,sin(z),cos(z),0,0,0,1]
        func multiply(_ a:[Double],_ b:[Double])->[Double] {
            var result=Array(repeating:0.0,count:9)
            for row in 0..<3 {
                for column in 0..<3 {
                    var value=0.0
                    for index in 0..<3 {value += a[row*3+index]*b[index*3+column]}
                    result[row*3+column]=value
                }
            }
            return result
        }
        let m=multiply(multiply(rx,ry),rz),px=pivot[0],py=pivot[1]
        let g=m[6]/576,h = -m[7]/576
        let a=m[0]+px*g,b = -m[1]+px*h,d = -m[3]+py*g,e=m[4]+py*h
        return [a,b,px-a*px-b*py,d,e,py-d*px-e*py,g,h,1-g*px-h*py]
    }
}
