import Foundation

enum AnimationEditError:LocalizedError {
    case invalid(String)
    var errorDescription:String? {if case .invalid(let message)=self{return message};return nil}
}
enum AnimationEdits {
    static func set(_ text:String,section:String,field:String,value:String)throws->String {
        guard !value.contains("\n"),!value.contains("\r"),!section.isEmpty,!field.isEmpty else{throw AnimationEditError.invalid("参数格式无效")}
        let newline=text.contains("\r\n") ? "\r\n":"\n"
        var lines=text.replacingOccurrences(of:"\r\n",with:"\n").components(separatedBy:"\n")
        var start:Int?,end=lines.count
        for (i,line) in lines.enumerated() {
            let clean=line.replacingOccurrences(of:"\u{FEFF}",with:"").trimmingCharacters(in:.whitespaces)
            if clean.hasPrefix("["),let close=clean.firstIndex(of:"]") {
                if start != nil {end=i;break}
                if String(clean.dropFirst().prefix(upTo:close)).uppercased()==section.uppercased(){start=i}
            }
        }
        guard let start else{throw AnimationEditError.invalid("未找到 ["+section+"]")}
        let matches=((start+1)..<end).filter {i in
            let line=lines[i].trimmingCharacters(in:.whitespaces)
            guard !line.hasPrefix(";"),!line.hasPrefix("#"),!line.hasPrefix("//"),let equal=line.firstIndex(of:"=") else{return false}
            return line[..<equal].trimmingCharacters(in:.whitespaces).uppercased()==field.uppercased()
        }
        if let first=matches.first {
            let comment=lines[first].range(of:" //").map{String(lines[first][$0.lowerBound...])} ?? ""
            lines[first]=field+"="+value+comment
            for i in matches.dropFirst().reversed(){lines.remove(at:i)}
        }else{lines.insert(field+"="+value,at:end)}
        return lines.joined(separator:newline)
    }
    static func ids(_ value:String,allowMany:Bool=true)throws->String {
        let value=value.trimmingCharacters(in:.whitespacesAndNewlines)
        if value.isEmpty{return ""}
        let parts=value.components(separatedBy:",").map{$0.trimmingCharacters(in:.whitespaces)}
        guard (allowMany || parts.count==1),parts.allSatisfy({!$0.isEmpty && $0.allSatisfy{$0.isASCII && $0.isNumber}}) else{throw AnimationEditError.invalid("编号须为数字，多项用逗号分隔")}
        return parts.joined(separator:",")
    }
}
