import Foundation

enum SkinTools {
    static func color(_ input: String) throws -> String {
        let s = input.trimmingCharacters(in: .whitespacesAndNewlines)
        var n: UInt64?
        if s.hasPrefix("#") || s.lowercased().hasPrefix("0x") {
            let hex = s.hasPrefix("#") ? String(s.dropFirst()) : String(s.dropFirst(2))
            if hex.count == 6 || hex.count == 8 { n = UInt64(hex, radix: 16); if hex.count == 6, let value = n { n = value | 0xff000000 } }
        } else { n = UInt64(s) }
        guard let n, n <= 0xffffffff else { throw SkinFailure(message: "请输入 6/8 位十六进制颜色或 0～4294967295 的整数") }
        return String(format: "ARGB：#%08llX\nRGB：%06llX\n十进制：%llu\n透明度：%.1f%%", n, n & 0xffffff, n, Double((n >> 24) & 255)/255*100)
    }
    @MainActor static func scaledLayout(_ text: String, ratio: CGFloat, width: Int, candidate: Bool) -> String {
        var section = ""
        return text.components(separatedBy: "\n").map { raw in
            let line = raw.replacingOccurrences(of:"\u{FEFF}",with:"").trimmingCharacters(in: .whitespacesAndNewlines)
            if let name=SkinConfiguration.header(line){section=name;return raw}
            guard !line.hasPrefix(";"), !line.hasPrefix("#"), !line.hasPrefix("//"), let equal = raw.firstIndex(of: "=") else { return raw }
            let key = raw[..<equal].trimmingCharacters(in:.whitespaces).uppercased()
            let value=String(raw[raw.index(after:equal)...]),comment=value.range(of:" //")
            let numberText=comment.map{String(value[..<$0.lowerBound])} ?? value
            let values = SkinStore.numbers(numberText.trimmingCharacters(in:.whitespacesAndNewlines))
            guard !values.isEmpty else { return raw }
            var next = values
            if section == "PANEL", key == "SIZE", values.count == 2 { next = [CGFloat(width), values[1]*ratio] }
            else if section == "INPUT", key == "SIZE", values.count == 2 { next = [CGFloat(width),values[1]] }
            else if section == "CAND", key == "VIEW_RECT", !candidate, values.count == 4 { next = [0,0,CGFloat(width),values[3]] }
            else if candidate, ["POS","SIZE","FIX_SIZE","ICON_ON_SWITCH_SIZE","ICON_ON_SWITCH_POS"].contains(key), values.count == 2 { next = [values[0]*ratio,values[1]] }
            else if candidate, key == "PADDING", values.count == 4 { next = [values[0]*ratio,values[1],values[2]*ratio,values[3]] }
            else if ["VIEW_RECT","TOUCH_RECT","POS","SIZE","FIX_SIZE","CELL_SIZE","PADDING","CELL_W","ICON_ON_SWITCH_SIZE","ICON_ON_SWITCH_POS"].contains(key) { next = values.map { $0*ratio } }
            else { return raw }
            guard next.allSatisfy({abs($0) < 1e12}) else { return raw }
            let suffix=comment.map{String(value[$0.lowerBound...])} ?? (raw.hasSuffix("\r") ? "\r" : "")
            return String(raw[...equal]) + next.map { String(Int(floor($0+0.5))) }.joined(separator:",") + suffix
        }.joined(separator:"\n")
    }
    @MainActor static func landscape(root: URL, files: [URL], width: Int) throws -> URL {
        guard (1...16384).contains(width) else { throw SkinFailure(message:"宽度须在 1～16384 之间") }
        let target = root.deletingLastPathComponent().appendingPathComponent(UUID().uuidString)
        var outputs: [String: Data] = [:], ports = Set<String>()
        for file in files {
            let rel = String(file.path.dropFirst(root.path.count+1))
            outputs[rel] = try Data(contentsOf:file)
            let parts = rel.components(separatedBy:"/")
            if let i = parts.firstIndex(where:{$0.lowercased()=="port"}) { ports.insert(parts.prefix(i+1).joined(separator:"/") + "/") }
        }
        guard !ports.isEmpty else { throw SkinFailure(message:"未找到 port 目录") }
        func panelSize(_ file: URL) -> [CGFloat] {
            var cursor = file
            while cursor.path.hasPrefix(root.path + "/") {
                let text = IniSkinRenderer.read(cursor) ?? ""
                let size = SkinStore.numbers(SkinStore.parse(text).first(where:{$0.name=="PANEL"})?.values["SIZE"])
                if size.count == 2, size[0]>0, size[1]>0 { return size }
                let dir = cursor.deletingLastPathComponent()
                cursor = (cursor.lastPathComponent.lowercased()=="gen.ini" ? dir.deletingLastPathComponent() : dir).appendingPathComponent("gen.ini")
            }
            return []
        }
        for port in ports {
            let land = String(port.dropLast(5)) + "land/"
            let base = panelSize(root.appendingPathComponent(port+"gen.ini"))
            guard base.count == 2 else { throw SkinFailure(message:"缺少面板宽度："+port+"gen.ini") }
            for file in files {
                let rel = String(file.path.dropFirst(root.path.count+1))
                let fromPort = rel.hasPrefix(port)
                let landOnly = rel.hasPrefix(land) && outputs[port + rel.dropFirst(land.count)] == nil
                guard fromPort || landOnly else { continue }
                let dest = fromPort ? land + rel.dropFirst(port.count) : rel
                var data = try Data(contentsOf:file)
                let ext = file.pathExtension.lowercased()
                if ext == "ini" || (fromPort && ext == "cnd") {
                    guard var text = IniSkinRenderer.read(file) else { throw SkinFailure(message:"无法解码："+rel) }
                    let size = ext == "ini" ? panelSize(file) : base
                    guard size.count == 2 else { throw SkinFailure(message:"缺少面板宽度："+rel) }
                    if landOnly, let range = text.range(of:"[PANEL]",options:.caseInsensitive), SkinStore.parse(text).first(where:{$0.name=="PANEL"})?.values["SIZE"] == nil {
                        text.insert(contentsOf:"\nSIZE=\(size[0]),\(size[1])",at:range.upperBound)
                    }
                    data = Data(scaledLayout(text,ratio:CGFloat(width)/size[0],width:width,candidate:ext=="cnd").utf8)
                }
                outputs[dest] = data
            }
        }
        do {
            for (path,data) in outputs {
                let url = target.appendingPathComponent(path)
                try FileManager.default.createDirectory(at:url.deletingLastPathComponent(),withIntermediateDirectories:true)
                try data.write(to:url,options:.atomic)
            }
        } catch { try? FileManager.default.removeItem(at:target); throw error }
        return target
    }
}
