import Foundation
import CoreGraphics

@MainActor enum PanelMetrics {
    static func size(_ sections:[Section])->CGSize {
        if let panel=sections.first(where:{$0.name=="PANEL"}) {
            let values=SkinStore.numbers(panel.values["SIZE"])
            if values.count==2,values[0]>0,values[1]>0{return CGSize(width:values[0],height:values[1])}
        }
        var width:CGFloat=0,height:CGFloat=0
        for section in sections {
            let rect=SkinStore.numbers(section.values["VIEW_RECT"])
            if rect.count==4,rect[2]>0,rect[3]>0{width=max(width,rect[0]+rect[2]);height=max(height,rect[1]+rect[3])}
        }
        return CGSize(width:width>0 ? width:1080,height:height>0 ? height:642)
    }
    static func dimension(_ value:CGFloat)->String {
        value.rounded()==value ? String(format:"%.0f",Double(value)):String(format:"%.2f",Double(value)).replacingOccurrences(of:"0+$",with:"",options:.regularExpression).replacingOccurrences(of:"[.]$",with:"",options:.regularExpression)
    }
}
