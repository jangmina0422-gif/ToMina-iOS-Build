import Foundation
import CoreGraphics

enum IniGeometry {
    static func bounds(_ section:Section,panel:CGSize)->CGRect? {
        let s=section.values
        if section.name.range(of:"^(TIP|OFFSET|STYLE|IMG)[0-9]+$",options:.regularExpression) != nil{return nil}
        if section.name.range(of:"^LIST[0-9]*$",options:.regularExpression) != nil {
            let pos=SkinConfiguration.numbers(s["POS"]),cell=SkinConfiguration.numbers(s["CELL_SIZE"]),count=Int(s["LIST_NUM"] ?? "") ?? 0
            guard pos.count==2,cell.count==2,cell[0]>0,cell[1]>0,(1...10000).contains(count) else{return nil}
            let horizontal=s["LIST_ORDER"]=="1"
            return CGRect(x:pos[0],y:pos[1],width:cell[0]*Double(horizontal ? count:1),height:cell[1]*Double(horizontal ? 1:count))
        }
        let r=SkinConfiguration.numbers(s["VIEW_RECT"])
        if r.count==4,r[2]>0,r[3]>0{return CGRect(x:r[0],y:r[1],width:r[2],height:r[3])}
        if section.name.hasPrefix("ICON") {
            let pos=SkinConfiguration.numbers(s["POS"]),size=SkinConfiguration.numbers(s["SIZE"])
            if pos.count==2,size.count==2,size[0]>0,size[1]>0 {
                let anchor=max(1,min(9,Int(s["ANCHOR_TYPE"] ?? "1") ?? 1))-1
                return CGRect(x:pos[0]+Double(anchor%3)*Double(panel.width)/2,y:pos[1]+Double(anchor/3)*Double(panel.height)/2,width:size[0],height:size[1])
            }
        }
        return nil
    }
    static func cells(_ section:Section,bounds:CGRect)->[(cell:CGRect,content:CGRect)] {
        guard section.name.range(of:"^LIST[0-9]*$",options:.regularExpression) != nil else{return []}
        let s=section.values,cell=SkinConfiguration.numbers(s["CELL_SIZE"]),padding=SkinConfiguration.numbers(s["PADDING"] ?? "0,0,0,0"),count=Int(s["LIST_NUM"] ?? "") ?? 0
        guard cell.count==2,padding.count==4,(1...10000).contains(count) else{return []}
        let horizontal=s["LIST_ORDER"]=="1"
        let inside=CGRect(x:bounds.minX+padding[0],y:bounds.minY+padding[1],width:max(0,bounds.width-padding[0]-padding[2]),height:max(0,bounds.height-padding[1]-padding[3]))
        return (0..<count).map{i in
            let rect=CGRect(x:bounds.minX+(horizontal ? Double(i)*cell[0]:0),y:bounds.minY+(horizontal ? 0:Double(i)*cell[1]),width:cell[0],height:cell[1])
            return (rect,rect.intersection(inside))
        }
    }
}
