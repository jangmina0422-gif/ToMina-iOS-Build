/* Offline port of the supplied bds_compile.py single-GIF compiler.
 * Native code owns file access, GIF validation, hashing, templates and ZIP IO.
 * Input/output are JSON so Android WebView and iOS JavaScriptCore use one engine.
 */
(function(root){
'use strict';
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o||{},k);
const dict=()=>Object.create(null), pairs=o=>Object.keys(o||{}).map(k=>[k,o[k]]);
const has=v=>v!==undefined&&v!==null;
const truth=v=>Array.isArray(v)?v.length>0:(v&&typeof v==='object'?Object.keys(v).length>0:!!v);
const integer=v=>{const n=Number(v);if(!Number.isFinite(n))throw Error('无效整数：'+v);return Math.trunc(n);};
const number=v=>{const n=Number(v||0);if(!Number.isFinite(n))throw Error('无效数值：'+v);return n;};
const cat=(...xs)=>[].concat(...xs);
function utf8(s){const out=[];for(const c of String(s)){const n=c.codePointAt(0);if(n<128)out.push(n);else if(n<2048)out.push(192|(n>>6),128|(n&63));else if(n<65536)out.push(224|(n>>12),128|((n>>6)&63),128|(n&63));else out.push(240|(n>>18),128|((n>>12)&63),128|((n>>6)&63),128|(n&63));}return out;}
function varint(n){n=integer(n);let lo=n>>>0,hi=n<0?0xffffffff:Math.floor(n/4294967296)>>>0;const out=[];while(hi||lo>127){out.push((lo&127)|128);lo=((lo>>>7)|(hi<<25))>>>0;hi>>>=7;}out.push(lo);return out;}
const tag=(n,w)=>varint(n*8+w);
const pint=(n,v)=>has(v)?cat(tag(n,0),varint(v)):[];
const pbool=(n,v)=>has(v)?pint(n,v?1:0):[];
function pfloat(n,v){if(!has(v))return [];const a=new ArrayBuffer(4);new DataView(a).setFloat32(0,number(v),true);return cat(tag(n,5),Array.from(new Uint8Array(a)));}
const pmsg=(n,b)=>b&&b.length?cat(tag(n,2),varint(b.length),b):[];
const pstr=(n,s)=>{if(!has(s))return [];const b=utf8(s);return cat(tag(n,2),varint(b.length),b);};
const mapstr=(n,k,v)=>pmsg(n,cat(pstr(1,k),pmsg(2,v)));
const mapint=(n,k,v)=>pmsg(n,cat(pint(1,k),pmsg(2,v)));
const pos=(a=[])=>cat(pint(1,a[0]||0),pint(2,a[1]||0));
const size=pos;
const rect=a=>a&&a.length>=4?cat(pmsg(1,pos(a)),pmsg(2,size(a.slice(2,4)))):[];
const edge=a=>a&&a.length?cat(pfloat(1,a[0]||0),pfloat(2,a[1]||0),pfloat(3,a[3]||0),pfloat(4,a[2]||0)):[];
const offset=(x,y)=>cat(pfloat(1,x),pfloat(2,y));
const resource=(id,type=0)=>cat(pint(1,type),pstr(2,id));
const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function b64(bytes){let s='';for(let i=0;i<bytes.length;i+=3){const a=bytes[i],b=bytes[i+1]||0,c=bytes[i+2]||0;s+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}return s;}
function un64(s){const a=[];let value=0,bits=0;for(const c of String(s||'')){if(c==='=')break;const n=alphabet.indexOf(c);if(n<0)throw Error('无效模板编码');value=(value<<6)|n;bits+=6;if(bits>=8){bits-=8;a.push((value>>bits)&255);}}return a;}
function sections(text){const out=dict();let sec=null;for(const raw of String(text||'').replace(/\r/g,'').split('\n')){const s=raw.trim();if(!s||/^(;|#|\/\/|\/\*|\*)/.test(s))continue;const m=s.match(/^\[([^\]]+)\]/);if(m){sec=m[1].trim();if(!own(out,sec))out[sec]=dict();continue;}const at=s.indexOf('=');if(sec&&at>=0)out[sec][s.slice(0,at).trim()]=s.slice(at+1).trim();}return out;}
const csv=s=>String(s||'').split(',').map(x=>x.trim()).filter(Boolean);
const nums=(s,f=false)=>!has(s)?[]:String(s).trim().split(/\s*,\s*/).filter(x=>x!=='').map(x=>{const v=Number(x);return Number.isFinite(v)?(f?v:Math.trunc(v)):0;});
const merge=(a,b)=>Object.assign(dict(),a||{},b||{});
const stats=s=>String(s||'').split(/[|,]/).map(x=>x.match(/^\s*(S\d+)_([0-9]+)/)).filter(Boolean).map(m=>[m[1],Number(m[2])]);
function css(text){const out=dict();for(const [k,v] of pairs(sections(text))){const m=k.match(/^STYLE(\d+)$/i);if(m)out[Number(m[1])]=v;}return out;}
function canonical(center,index,used){let c=String(center||'').trim()||'IDX_'+index;if(/^[a-z]$/.test(c))c=c.toUpperCase();const base='KEY_'+c;let k=base,n=2;while(used.has(k))k=base+'_'+n++;used.add(k);return k;}
function keyLayout(d){let b=[];if(truth(d.viewRect))b=cat(b,pmsg(1,rect(d.viewRect)));if(truth(d.touchRect))b=cat(b,pmsg(2,rect(d.touchRect)));['up','down','left','right','hold','center','show','holdSym'].forEach((k,i)=>{if(has(d[k])&&d[k]!=='')b=cat(b,pstr(i+3,d[k]));});if(d.isTip)b=cat(b,pbool(11,true));for(const t of d.tips||[])b=cat(b,pstr(12,t));if(d.com)b=cat(b,pstr(13,d.com));if(d.holdFlag)b=cat(b,pstr(14,d.holdFlag));return cat(b,pint(15,d.barSymSel));}
function candIcon(d){let b=pint(1,d.type||0);if(truth(d.size))b=cat(b,pmsg(2,size(d.size)));if(d.key)b=cat(b,pstr(3,d.key));if(truth(d.pos))b=cat(b,pmsg(4,pos(d.pos)));if(d.isTip)b=cat(b,pbool(5,true));for(const t of d.tips||[])b=cat(b,pstr(6,t));return cat(b,pint(9,d.anchorType));}
function candLayout(d){let b=cat(pfloat(1,d.firstGap),pfloat(2,d.mainCandHeight),pfloat(3,d.secondCandHeight),pmsg(4,edge(d.padding)));for(const [k,v] of pairs(d.icons))b=cat(b,mapstr(5,k,candIcon(v)));return cat(b,pint(6,d.candType),pint(7,d.cellWidth));}
function listLayout(d){return cat(truth(d.cellSize)?pmsg(1,size(d.cellSize)):[],truth(d.pos)?pmsg(2,pos(d.pos)):[],pint(4,d.listNum),pstr(5,d.names),pstr(6,d.values),pmsg(7,edge(d.padding)),pint(8,d.listOrientation),pint(9,d.listType));}
const inputLayout=d=>cat(pmsg(1,edge(d.padding)),truth(d.pos)?pmsg(2,pos(d.pos)):[]);
const gridLayout=d=>cat(pint(1,d.cols),pint(2,d.rows),pmsg(3,rect(d.viewRect)));
function panelLayout(d){let b=[];for(const [k,v] of pairs(d.keys))b=cat(b,mapstr(2,k,keyLayout(v)));for(const [n,k,fn] of [[3,'list',listLayout],[4,'cand',candLayout],[5,'input',inputLayout],[6,'more',gridLayout]])if(truth(d[k]))b=cat(b,pmsg(n,fn(d[k])));if(truth(d.size))b=cat(b,pmsg(7,size(d.size)));return cat(b,pbool(8,d.candInternal));}
const layoutConfig=(name,panel,width)=>cat(pmsg(1,cat(pstr(1,name),pmsg(2,panelLayout(panel)))),pint(6,width));
function color(s,fallback=0xff000000){if(!s)return fallback;const t=String(s).trim().replace(/#/g,'');if(!/^(?:0x)?[0-9a-f]+$/i.test(t))return fallback;let v=parseInt(t,16);if(t.length<=6)v=(v|0xff000000)>>>0;return v>>>0;}
function styleKind(kv){if(!truth(kv))return 'image';if(own(kv,'NM_IMG')||own(kv,'HL_IMG'))return 'image';if(own(kv,'SHOW')||own(kv,'FONT_SIZE'))return 'text';if(own(kv,'NM_COLOR')||own(kv,'HL_COLOR'))return 'color';return 'image';}
function skinStyle(old,styles){if(!/^[+-]?\d+$/.test(String(old).trim()))return [];old=integer(old);return cat(pint(1,{image:0,color:1,text:2}[styleKind(styles[old]||{})]),pint(2,10000+old));}
const styleRef=(n,old,styles)=>String(old||'').trim()?pmsg(n,skinStyle(old,styles)):[];
const transparent=n=>pmsg(n,cat(pint(1,1),pint(2,2147483000)));
function keyAppearance(kv,offsets,view,styles){let b=kv.BACK_STYLE?styleRef(1,kv.BACK_STYLE,styles):[];const fores=csv(kv.FORE_STYLE),ptypes=csv(kv.POS_TYPE),w=view&&view.length>=4&&view[2]?view[2]:1,h=view&&view.length>=4&&view[3]?view[3]:1;fores.forEach((f,i)=>{b=cat(b,pmsg(2,skinStyle(f,styles)));const pt=i<ptypes.length&&/^-*\d+$/.test(ptypes[i])?integer(ptypes[i]):0;let dx=0,dy=0;if(pt&&offsets[pt]){const vals=nums(offsets[pt].POS);dx=vals[0]||0;dy=vals[1]||0;}b=cat(b,pmsg(3,offset(dx/w,dy/h)));});return b;}
function inputApp(s,styles,clear){return cat(clear?transparent(1):styleRef(1,s.BACK_STYLE,styles),styleRef(2,s.FORE_STYLE,styles));}
function gridApp(s,styles){return cat(styleRef(1,s.BACK_STYLE,styles),styleRef(2,s.FORE_STYLE,styles),styleRef(3,s.CELL_STYLE,styles));}
function switchApp(s,styles,clear){return cat(clear?cat(transparent(1),transparent(2)):cat(styleRef(1,s.NML_BACK_STYLE,styles),styleRef(2,s.SEL_BACK_STYLE,styles)),styleRef(3,s.NML_FONT_STYLE,styles),styleRef(4,s.SEL_FONT_STYLE,styles));}
function candApp(d,styles,clear){let b=clear?cat(...[1,2,3,6,8,11].map(transparent)):cat(styleRef(1,d.BACK_STYLE,styles),styleRef(3,d.CELL_STYLE,styles));b=cat(b,styleRef(4,d.FORE_STYLE,styles),styleRef(5,d.FIRST_FORE,styles));for(const k of ['SUB_CAND_FORE_STYLE','SUBCAND_FORE_STYLE','SUB_FORE_STYLE'])if(d[k]){b=cat(b,styleRef(7,d[k],styles));break;}if(truth(d._SWITCH))b=cat(b,pmsg(9,switchApp(d._SWITCH,styles,clear)));for(const [k,v] of pairs(d._ICONS))b=cat(b,mapstr(10,'CAND_'+(v.KEY||k),keyAppearance(v,{},null,styles)));return b;}
function panelApp(d,styles,clear){let b=[];for(const [k,v] of pairs(d._key_source))b=cat(b,mapstr(3,k,keyAppearance(v,d._offsets||{},nums(v.VIEW_RECT),styles)));if(truth(d._cand_app))b=cat(b,pmsg(4,candApp(d._cand_app,styles,clear)));if(truth(d._input_app))b=cat(b,pmsg(5,inputApp(d._input_app,styles,clear)));if(truth(d._more_app))b=cat(b,pmsg(6,gridApp(d._more_app,styles)));const p=d._panel_app||{};if(clear)b=cat(b,transparent(7),transparent(10));else if(p.BACK_STYLE)b=cat(b,styleRef(7,p.BACK_STYLE,styles),styleRef(10,p.BACK_STYLE,styles));if(has(p.NO_BLUR))b=cat(b,pbool(8,String(p.NO_BLUR).trim()!=='1'));return b;}
function textStyle(kv){const fs=nums(kv.FONT_SIZE);return cat(pint(3,fs.length?fs[0]:40),kv.NM_COLOR?pint(4,color(kv.NM_COLOR)):[],kv.HL_COLOR?pint(5,color(kv.HL_COLOR)):[],pstr(6,kv.SHOW));}
const colorStyle=kv=>cat(pint(1,color(kv.NM_COLOR,0xffffffff)),pint(2,color(kv.HL_COLOR||kv.NM_COLOR,0xffffffff)));
function imgRef(v){if(!v)return null;const p=String(v).split(',').map(x=>x.trim());if(p.length<2)return null;const i=/^[+-]?\d+$/.test(p[1])?integer(p[1]):1;return 'res_'+p[0]+'_'+i;}
function imageStyle(kv){const n=imgRef(kv.NM_IMG),h=imgRef(kv.HL_IMG)||n;return cat(n?pmsg(1,pmsg(1,resource(n))):[],h?pmsg(2,pmsg(1,resource(h))):[]);}
function styleOverrides(base,styles,used){let b=base;for(const sid of Array.from(used).sort((a,b)=>a-b)){const kv=styles[sid]||{},kind=styleKind(kv),ns=10000+sid;if(kind==='text')b=cat(b,mapint(2,ns,textStyle(kv)));else if(kind==='color')b=cat(b,mapint(3,ns,colorStyle(kv)));else if(truth(kv))b=cat(b,mapint(1,ns,imageStyle(kv)));}return b;}
const isolation=(key,condition)=>cat(pint(1,1),pstr(3,key),pint(4,3),condition?pstr(5,condition):[]);
const frame=id=>cat(pint(1,0),pbool(2,false),pmsg(3,resource(id,1)));
function animation(items,defs,width,existing){
 let b=[],binding=[];existing=existing||[];
 for(const f of wire(existing)){
  if(f.type===2&&f.id===1&&mapEntry(f).key==='PANEL'){binding=cat(binding,mapEntry(f).value);continue;}
  if(f.type===2&&f.id===8&&own(defs,mapEntry(f).key))continue;
  b=cat(b,f.raw);
 }
 binding=cat(...wire(binding).filter(f=>{
  if(f.id!==2||f.type!==2)return true;
  const fs=wire(f.data),key=fs.find(x=>x.id===3),condition=fs.find(x=>x.id===5);
  return !(key&&str(key.data).startsWith('bg_mnbg_')&&condition&&items.some(i=>i[1]===str(condition.data)));
 }).map(f=>f.raw));
 if(binding.length||items.length)b=cat(b,mapstr(1,'PANEL',cat(binding,...items.map(i=>pmsg(2,isolation(i[0],i[1]))))));
 for(const [k,v] of pairs(defs))b=cat(b,mapstr(8,k,frame(v)));
 if(!wire(existing).some(f=>f.id===12)&&width)b=cat(b,pint(12,width));
 return b;
}
function candidateSections(text){
 const result=[];let current=null;
 for(const raw of String(text||'').replace(/\r/g,'').split('\n')){
  const line=raw.trim();if(!line||/^(;|#|\/\/|\/\*|\*)/.test(line))continue;
  const header=line.match(/^\[([^\]]+)\]/);if(header){current=header[1].trim()==='CAND'?dict():null;if(current)result.push(current);continue;}
  const at=line.indexOf('=');if(current&&at>=0)current[line.slice(0,at).trim()]=line.slice(at+1).trim();
 }
 return result;
}
const candidateName=value=>String(value||'').trim().toLowerCase().replace(/\.cnd$/,'');
function selectedCandidate(files,ori,path,chosen){
 const defaults=candidateSections(files[ori+'/gen.ini']),local=path===ori+'/gen.ini'?defaults:candidateSections(files[path]),used=new Set(),merged=[];
 local.forEach((spec,index)=>{
  const name=candidateName(spec.LAYOUT_NAME);let at=defaults.findIndex((base,i)=>!used.has(i)&&name&&candidateName(base.LAYOUT_NAME)===name);
  if(at<0&&index<defaults.length&&!used.has(index))at=index;
  if(at>=0)used.add(at);merged.push(merge(at>=0?defaults[at]:{},spec));
 });
 defaults.forEach((spec,i)=>{if(!used.has(i))merged.push(spec);});
 const available=merged.filter(spec=>{const name=String(spec.LAYOUT_NAME||'').trim().replace(/\.cnd$/i,'')+'.cnd';return spec.LAYOUT_NAME&&(own(files,ori+'/'+name)||own(files,name));});
 return available.find(spec=>candidateName(spec.LAYOUT_NAME)===candidateName(chosen))||available[0]||merged[0]||dict();
}
function resolve(files,ori,gen,path,report,candidateChoice=''){
 const sec=sections(files[path]),merged=dict(),offsets=dict();for(const n of ['PANEL','INPUT','CAND','HINT','MORE','LIST'])merged[n]=merge(gen[n],sec[n]);for(const src of [gen,sec])for(const [n,kv] of pairs(src)){const m=n.match(/^OFFSET(\d+)$/i);if(m)offsets[Number(m[1])]=merge(kv);}
 merged.CAND=selectedCandidate(files,ori,path,candidateChoice);
 let ca=dict(),cl=dict();const csec=merged.CAND,layout=csec.LAYOUT_NAME;
 if(layout){const cs=sections(files[ori+'/'+layout.replace(/\.cnd$/i,'')+'.cnd']??files[layout.replace(/\.cnd$/i,'')+'.cnd']),main=merge(cs.CAND,csec),icons=dict(),ci=dict();for(const [n,kv] of pairs(cs))if(/^ICON\d+$/i.test(n)){const key=kv.KEY||n;ci[key]={type:integer(kv.PERSIST||0),size:nums(kv.SIZE),key:key,pos:nums(kv.POS),anchorType:integer(kv.ANCHOR_TYPE||0)};icons[n]=merge(kv);}cl={firstGap:number(main.FIRST_GAP),padding:nums(main.PADDING,true),icons:ci,candType:integer(main.TYPE||0),cellWidth:integer(main.CELL_W||0)};ca=merge(main);ca._SWITCH=merge(cs.SWITCH);ca._ICONS=icons;}
 const l=merged.LIST,ld=truth(l)?{cellSize:nums(l.CELL_SIZE),pos:nums(l.POS),listNum:integer(l.LIST_NUM||0),names:l.NAMES||'',values:l.VALUES||'',padding:nums(l.PADDING,true),listOrientation:integer(l.LIST_ORDER||0),listType:integer(l.TYPE||0)}:{};
 const mo=merged.MORE,gr=nums(mo.GRID),more={cols:gr[0]||0,rows:gr[1]||0};if(mo.VIEW_RECT)more.viewRect=nums(mo.VIEW_RECT);
 const used=new Set(),keys=dict(),source=dict(),keysecs=pairs(sec).filter(k=>/^KEY\d+$/i.test(k[0])).sort((a,b)=>Number(a[0].slice(3))-Number(b[0].slice(3)));
 const actions=kv=>({up:kv.UP,down:kv.DOWN,left:kv.LEFT,right:kv.RIGHT,hold:kv.HOLD,center:kv.CENTER,show:kv.SHOW,holdSym:kv.HOLDSYM||kv.HOLD_SYM});
 for(const [name,kv] of keysecs){const kid=canonical(kv.CENTER,Number(name.slice(3)),used),d=actions(kv);d.viewRect=nums(kv.VIEW_RECT);d.touchRect=nums(kv.TOUCH_RECT);d.tips=[];for(const [state,ti] of stats(kv.STAT_STYLE)){const ts=sec['TIP'+ti]||{};let tid=kid+'_'+state;if(own(keys,tid))tid+='_'+ti;const td=actions(ts);td.center=ts.CENTER||ts.KEY||kv.CENTER;td.isTip=true;keys[tid]=td;d.tips.push(tid);source[tid]=merge(ts);}keys[kid]=d;source[kid]=kv;}
 let ps=nums(merged.PANEL.SIZE);let cr=nums(merged.CAND.VIEW_RECT);const ins=nums(merged.INPUT.SIZE),name=path.split('/').pop();
 if(layout){
  const cs=sections(files[ori+'/'+layout.replace(/\.cnd$/i,'')+'.cnd']??files[layout.replace(/\.cnd$/i,'')+'.cnd']);
  if(cr.length!==4||cr[2]<=0||cr[3]<=0)cr=nums((cs.CAND||{}).VIEW_RECT);
  if(cr.length!==4||cr[2]<=0||cr[3]<=0){const sz=nums(merged.CAND.SIZE||(cs.CAND||{}).SIZE);if(sz.length===2)cr=[0,0,sz[0],sz[1]];}
  if(cr.length!==4||cr[2]<=0||cr[3]<=0){
   const styles=css(files[ori+'/res/default.css']??files['res/default.css']),style=styles[(cs.CAND||{}).BACK_STYLE]||{},ref=csv(style.NM_IMG);
   if(ref.length===2){const tile=ref[0].replace(/\.(png|webp|gif|jpe?g|til)$/i,'')+'.til',raw=files[ori+'/res/'+tile]??files['res/'+tile];cr=nums((sections(raw)['IMG'+ref[1]]||{}).SOURCE_RECT);}
  }
  if(cr.length===4&&cr[2]>0&&cr[3]>0)cl.mainCandHeight=cr[3];
 }if(ps.length<2||ps[0]<=0||ps[1]<=0){let mx=0,my=0;for(const [k,v] of pairs(keys)){const r=v.viewRect||[];if(r.length>=4){mx=Math.max(mx,r[0]+r[2]);my=Math.max(my,r[1]+r[3]);}}if(!mx&&cr.length>=4)mx=cr[2];ps=[mx,my];report.push(name+': PANEL SIZE missing; derived from key VIEW_RECT as '+ps[0]+'x'+ps[1]);}
 const known=new Set(['BACK_STYLE','FORE_STYLE','POS_TYPE','VIEW_RECT','TOUCH_RECT','UP','DOWN','LEFT','RIGHT','HOLD','CENTER','SHOW','HOLDSYM','HOLD_SYM','STAT_STYLE','INFO']);for(const [n,kv] of keysecs)for(const [k,v] of pairs(kv))if(!known.has(k))report.push(name+'/'+n+': unconverted key field '+k+'='+v);
 return {keys:keys,list:ld,cand:cl,input:{},more:more,size:ps,_offsets:offsets,_key_source:source,_panel_app:merged.PANEL,_input_app:merged.INPUT,_more_app:merged.MORE,_cand_app:ca,_cand_rect:cr,_input_size:ins,_cand_layout_name:layout||''};
}
function usedStyles(p){const used=new Set();const add=v=>csv(v).forEach(x=>{if(/^[+-]?\d+$/.test(x))used.add(integer(x));});for(const [k,v] of pairs(p._key_source)){add(v.BACK_STYLE);add(v.FORE_STYLE);}for(const n of ['_panel_app','_input_app','_more_app'])for(const [k,v] of pairs(p[n]))if(k.endsWith('STYLE')||['BACK_STYLE','FORE_STYLE','CELL_STYLE'].indexOf(k)>=0)add(v);const ca=p._cand_app||{};for(const [k,v] of pairs(ca))if(typeof v==='string'&&k.indexOf('STYLE')>=0)add(v);for(const [k,v] of pairs(ca._ICONS)){add(v.BACK_STYLE);add(v.FORE_STYLE);}return used;}
function background(bg,ori,name){const b=bg.backgrounds||bg;let v=b[ori+'/'+name]||b[name]||b[ori+'/gen']||b[ori+'/gen.ini']||b.gen||'';if(v&&typeof v==='object')v=v.gif||v.file||v.background||'';return String(v||'').trim();}
function panelPaths(files){return Object.keys(files).filter(p=>/^(port|land)\/[^/]+\.ini$/i.test(p)&&p.split('/').pop().toLowerCase()!=='gen.ini').sort();}
// Preserve native BDI protobuf fields byte-for-byte except the chosen background bindings.
function wire(bytes){
 const out=[];let p=0;const read=()=>{let n=0,m=1;for(let i=0;i<10;i++){if(p>=bytes.length)throw Error('原生配置数据不完整');const c=bytes[p++];n+=(c&127)*m;if(!(c&128))return n;m*=128;}throw Error('原生配置整数无效');};
 while(p<bytes.length){if(out.length>100000)throw Error('原生配置字段过多');const start=p,t=read(),id=Math.floor(t/8),type=t%8;let data=[],value=0;if(!id)throw Error('原生配置字段无效');if(type===0)value=read();else if(type===1||type===5){const n=type===1?8:4;data=bytes.slice(p,p+n);p+=n;}else if(type===2){const n=read();if(!Number.isSafeInteger(n)||n<0||n>bytes.length-p)throw Error('原生配置长度无效');data=bytes.slice(p,p+n);p+=n;}else throw Error('暂不支持此原生配置编码');if(p>bytes.length)throw Error('原生配置数据不完整');out.push({id,type,data,value,raw:bytes.slice(start,p)});}
 return out;
}
function str(bytes){let result='';for(let p=0;p<bytes.length;){let n=bytes[p++];if(n>=240){n=((n&7)<<18)|((bytes[p++]&63)<<12)|((bytes[p++]&63)<<6)|(bytes[p++]&63);}else if(n>=224){n=((n&15)<<12)|((bytes[p++]&63)<<6)|(bytes[p++]&63);}else if(n>=192)n=((n&31)<<6)|(bytes[p++]&63);result+=String.fromCodePoint(n);}return result;}
function mapEntry(f){const fs=wire(f.data),key=fs.find(x=>x.id===1),v=fs.find(x=>x.id===2&&x.type===2);return {key:key?(key.type===2?str(key.data):String(key.value)):'',value:v?v.data:[]};}
const omit=(fields,ids)=>cat(...fields.filter(f=>!ids.includes(f.id)).map(f=>f.raw));
function nativePanels(input){const paths=panelPaths(input.files||{});for(const ori of ['port','land']){const raw=(input.nativeAppearances||{})[ori];if(raw)for(const f of wire(un64(raw)))if(f.id===4&&f.type===2){const key=mapEntry(f).key;if(key&&!paths.includes(ori+'/'+key+'.ini'))paths.push(ori+'/'+key);}}return paths.sort();}
function nativeSummary(encoded){const fs=wire(un64(encoded)),design=fs.find(x=>x.id===6&&x.type===0);return {panels:fs.filter(f=>f.id===4&&f.type===2).map(f=>mapEntry(f).key),width:design?design.value:0};}
function clearNativeBackground(panel,clearID){
 const ref=cat(pint(1,1),pint(2,clearID)),clear=ids=>cat(...ids.map(id=>pmsg(id,ref)));
 let out=[];
 for(const f of wire(panel)){
  if([7,10].includes(f.id))continue;
  if(f.id===4&&f.type===2){
   let cand=[];for(const c of wire(f.data)){
    if([1,2,3,6,8,11].includes(c.id))continue;
    if(c.id===9&&c.type===2)cand=cat(cand,pmsg(9,cat(omit(wire(c.data),[1,2]),clear([1,2]))));
    else cand=cat(cand,c.raw);
   }
   out=cat(out,pmsg(4,cat(cand,clear([1,2,3,6,8,11]))));
  }else if(f.id===5&&f.type===2)out=cat(out,pmsg(5,cat(omit(wire(f.data),[1]),clear([1]))));
  else out=cat(out,f.raw);
 }
 return cat(out,clear([7,10]));
}
function nativeBackgrounds(input){
 const result=dict();
 for(const ori of ['port','land']){
  const fs=wire(un64((input.existingAnimations||{})[ori]||'')),defs=dict();
  for(const f of fs)if(f.id===8&&f.type===2){const m=mapEntry(f),res=wire(m.value).find(f=>f.id===3&&f.type===2),id=res&&wire(res.data).find(f=>f.id===2&&f.type===2);if(id&&/^mnbg_[0-9a-f]{16}$/.test(str(id.data)))defs[m.key]=str(id.data)+'.gif';}
  for(const f of fs)if(f.id===1&&f.type===2&&mapEntry(f).key==='PANEL')for(const b of wire(mapEntry(f).value))if(b.id===2&&b.type===2){
   const fields=wire(b.data),key=fields.find(x=>x.id===3&&x.type===2),condition=fields.find(x=>x.id===5&&x.type===2),match=condition&&str(condition.data).match(/^curPanelID == ([A-Za-z0-9_]+)$/);
   if(key&&match&&defs[str(key.data)]){const p=ori+'/'+match[1];result[own(input.files,p+'.ini')?p+'.ini':p]=defs[str(key.data)];}
  }
 }
 return result;
}
function compileBDI(input){
 const files=input.files||{},paths=nativePanels(input),writes=dict(),preview=dict(),used=new Set(),warnings=[];
 if(!paths.length)throw Error('没有找到 BDI 的 INI 或原生面板配置');
 if(paths.length>1024)throw Error('面板数量超过 1024');
 for(const ori of ['port','land']){
  const raw=(input.nativeAppearances||{})[ori];let fs=raw?wire(un64(raw)):[],styles=css(files[ori+'/res/default.css']??files['res/default.css']),selected=dict(),items=[],defs=dict();
  let app=fs.length?[]:[],gen=sections(files[ori+'/gen.ini']),width=0;
  for(const path of paths.filter(p=>p.startsWith(ori+'/'))){
   const name=path.slice(ori.length+1),stem=name.replace(/\.ini$/i,''),gif=background(input.backgrounds||{},ori,name);
   if(!gif)continue;const g=(input.gifs||{})[gif];if(!g||!/^mnbg_[0-9a-f]{16}$/.test(g.rid)||g.width<=0||g.height<=0)throw Error('请重新选择有效 GIF：'+gif);
   if(!/^[A-Za-z0-9_]+$/.test(stem))throw Error('面板标识不支持背景条件：'+stem);
   used.add(gif);preview[path]=g.rid+'.gif';selected[stem]=g;const key='bg_'+g.rid;defs[key]=g.rid;items.push([key,'curPanelID == '+stem]);
  }
  if(!items.length)continue;
  // An INI-based BDI can supply its own appearance without an Android template.
  if(!fs.length){let allUsed=new Set(),panels=[];for(const path of panelPaths(files).filter(p=>p.startsWith(ori+'/'))){const p=resolve(files,ori,gen,path,warnings,background(input.candidateChoices||{},ori,path.split('/').pop())),stem=path.split('/').pop().slice(0,-4);panels.push([stem,p]);width=Math.max(width,p.size[0]||0);for(const id of usedStyles(p))allUsed.add(id);}app=styleOverrides([],styles,allUsed);for(const [stem,p] of panels)app=cat(app,mapstr(4,stem,panelApp(p,styles,false)));app=cat(app,pint(6,width));fs=wire(app);}
  // Use an unused transparent colour ID and retain every key, candidate and unknown field.
  const occupied=new Set(fs.filter(f=>[1,2,3].includes(f.id)&&f.type===2).map(f=>mapEntry(f).key));let clearID=2147483000;while(occupied.has(String(clearID)))clearID--;
  app=[];const found=new Set();for(const f of fs){if(f.id===4&&f.type===2){const m=mapEntry(f);if(selected[m.key]){found.add(m.key);app=cat(app,mapstr(4,m.key,clearNativeBackground(m.value,clearID)));continue;}}app=cat(app,f.raw);}
  for(const name of Object.keys(selected))if(!found.has(name))throw Error('原生外观缺少面板 '+ori+'/'+name+'，未修改工程');
  app=cat(app,mapint(3,clearID,cat(pint(1,0),pint(2,0))));writes[ori+'/appearanceConfig']=b64(app);
  const existing=wire(un64((input.existingAnimations||{})[ori]||''));let anim=[],binding=[];
  for(const f of existing){if(f.type===2&&f.id===1&&mapEntry(f).key==='PANEL'){binding=cat(binding,mapEntry(f).value);continue;}if(f.type===2&&f.id===8&&own(defs,mapEntry(f).key))continue;anim=cat(anim,f.raw);}
  // Remove only earlier tool bindings for the selected panels, keeping all other effects.
  binding=cat(...wire(binding).filter(f=>{if(f.id!==2||f.type!==2)return true;const v=wire(f.data),key=v.find(x=>x.id===3),condition=v.find(x=>x.id===5);return !(key&&str(key.data).startsWith('bg_mnbg_')&&condition&&items.some(i=>i[1]===str(condition.data)));}).map(f=>f.raw));
  binding=cat(binding,...items.map(i=>pmsg(2,isolation(i[0],i[1]))));anim=cat(anim,mapstr(1,'PANEL',binding));for(const [k,v] of pairs(defs))anim=cat(anim,mapstr(8,k,frame(v)));writes[ori+'/animationConfig']=b64(anim);
 }
 if(!used.size)throw Error('请至少为一个面板选择 GIF');
 const old=merge(nativeBackgrounds(input),input.previewBackgrounds);for(const [path,gif] of pairs(old))if(!own(preview,path))preview[path]=gif;
 const report=['GIF 动态背景','BDI 面板：'+paths.length+'；GIF：'+used.size,'顶栏与键盘共用一张完整 GIF；已清除遮挡整幅动图的顶栏底色。','已保留原 Info / Token、面板布局、按键样式和其他动效。','GIF 原字节保留，未自动导出。','输入法的实际动效兼容性需在对应 iOS 版本中预览确认。'].concat(warnings).join('\n');
 writes['bds_compile_backgrounds.json']=b64(utf8(JSON.stringify(preview)));writes['bds_compile_report.txt']=b64(utf8(report));
 return {writes,report,panels:paths.length,usedGIFs:Array.from(used),warnings};
}
function compile(input){
 if(input.format==='bdi')return compileBDI(input);
 const files=input.files||{},writes=dict(),previewBackgrounds=merge(nativeBackgrounds(input),input.previewBackgrounds),warnings=[],usedGIFs=new Set(),paths=panelPaths(files),template=input.templates||{};
 if(!paths.length)throw Error('没有找到 port/ 或 land/ 中的 INI 面板，请先导入 BDS 皮肤。');
 if(paths.length>1024)throw Error('面板数量超过 1024，无法编译。');
 for(const ori of ['port','land']){
  const styles=css(files[ori+'/res/default.css']!==undefined?files[ori+'/res/default.css']:files['res/default.css']);
  const gen=sections(files[ori+'/gen.ini']),panels=[],allUsed=new Set(),items=[],defs=dict();let design=0;
  for(const path of paths.filter(p=>p.startsWith(ori+'/'))){const p=resolve(files,ori,gen,path,warnings,background(input.candidateChoices||{},ori,path.split('/').pop())),name=path.split('/').pop(),stem=name.slice(0,-4),gif=background(input.backgrounds||{},ori,name);p._bg_gif=gif||previewBackgrounds[path];panels.push([stem,p]);for(const sid of usedStyles(p))allUsed.add(sid);const ps=p.size||[0,0];design=Math.max(design,ps[0]||0);writes[ori+'/layoutConfig_'+stem]=b64(layoutConfig(stem,p,ps[0]||design||1080));if(gif){const g=(input.gifs||{})[gif];if(!/\.gif$/i.test(gif)||!g||!/^mnbg_[0-9a-f]{16}$/.test(g.rid)||g.width<=0||g.height<=0)throw Error('请重新选择有效 GIF：'+gif+'（'+path+'）');usedGIFs.add(gif);previewBackgrounds[path]=g.rid+'.gif';const fk='bg_'+g.rid;defs[fk]=g.rid;items.push([fk,'curPanelID == '+stem]);if(!/^[A-Za-z0-9_]+$/.test(stem))warnings.push('WARNING unusual INI stem in condition: '+stem);if(design&&g.width!==design)warnings.push('GIF width '+g.width+' != design width '+design+' for '+path+': '+gif);}}
  // The reference creates facade directories for both orientations, even if empty.
  let app=styleOverrides(un64(template[ori]||''),styles,allUsed);app=cat(app,mapint(3,2147483000,cat(pint(1,0),pint(2,0))));for(const [stem,p] of panels)app=cat(app,mapstr(4,stem,panelApp(p,styles,!!p._bg_gif)));writes[ori+'/appearanceConfig']=b64(app);if(items.length)writes[ori+'/animationConfig']=b64(animation(items,defs,design||1080,un64((input.existingAnimations||{})[ori]||'')));
 }
 if(!usedGIFs.size)throw Error('请至少为一个面板选择 GIF，或设置通用背景。');
 let info=files['Info.txt']||'';if(/^SkinType=/m.test(info))info=info.replace(/^SkinType=.*$/gm,'SkinType=2');else info+=(info&&!info.endsWith('\n')?'\n':'')+'SkinType=2\n';writes['Info.txt']=b64(utf8(info));
 const lines=['GIF 动态背景编译结果','面板：'+paths.length+'；GIF：'+usedGIFs.size,'','扫描面板：'].concat(paths,['','提示 / 未转换字段：'],warnings.length?warnings:['无'],'','顶栏与键盘共用一张完整 GIF；顶栏高度写入布局，背景绑定到同一个 PANEL 动画。','优先级：方向/面板.ini → 面板.ini → 方向/gen → 方向/gen.ini → gen。','GIF 原字节保留，不裁剪、不缩放；未覆盖原始 BDS。','使用所提供工具包的原生动画格式，目标为安卓百度输入法。');
 const report=lines.join('\n');writes['bds_compile_report.txt']=b64(utf8(report));writes['bds_compile_backgrounds.json']=b64(utf8(JSON.stringify(previewBackgrounds)));
 return {writes:writes,report:report,panels:paths.length,usedGIFs:Array.from(usedGIFs),warnings:warnings};
}
const api={compile:compile,panelPaths:panelPaths,nativePanels:nativePanels,nativeSummary:nativeSummary,background:background,sections:sections,_test:{varint:varint,b64:b64,un64:un64,resolve:resolve,layoutConfig:layoutConfig,panelApp:panelApp,styleOverrides:styleOverrides,animation:animation,wire:wire,mapEntry:mapEntry}};
if(typeof module!=='undefined'&&module.exports)module.exports=api;root.SingleGIF=api;
})(typeof globalThis!=='undefined'?globalThis:this);
