import Foundation
import CryptoKit
import JavaScriptCore
import ZIPFoundation

enum SingleGIFCompiler {
    struct GIF: Identifiable, Sendable {
        let name: String
        let bytes: Data
        let width: Int
        let height: Int
        let rid: String
        var id: String { name }
        init(name: String, bytes: Data) throws {
            let size = try SingleGIFCompiler.dimensions(bytes)
            self.name = name; self.bytes = bytes; width = size.0; height = size.1
            rid = "mnbg_" + SHA256.hash(data: bytes).prefix(8).map { String(format: "%02x", $0) }.joined()
        }
    }
    // Walk GIF blocks without decoding full-resolution animation frames.
    static func dimensions(_ data: Data) throws -> (Int, Int) {
        guard data.count >= 14, data.count <= 32 * 1024 * 1024 else { throw SkinFailure(message: "GIF 文件无效或超过 32 MB") }
        let b = [UInt8](data), magic = String(decoding: data.prefix(6), as: UTF8.self)
        guard magic == "GIF87a" || magic == "GIF89a" else { throw SkinFailure(message: "请选择有效的 GIF 文件") }
        func u16(_ p: Int) -> Int { Int(b[p]) | (Int(b[p+1]) << 8) }
        let w = u16(6), h = u16(8)
        guard w > 0, h > 0 else { throw SkinFailure(message: "GIF 尺寸无效") }
        var p = 13, frames = 0
        if b[10] & 128 != 0 { p += 3 * (1 << (Int(b[10] & 7) + 1)) }
        while p < b.count {
            let type = b[p]; p += 1
            if type == 59 && frames > 0 { return (w,h) }
            if type == 33 { guard p < b.count else { break }; p += 1 }
            else if type == 44 {
                guard p + 9 <= b.count, u16(p+4) > 0, u16(p+6) > 0 else { break }
                let packed = b[p+8]; p += 9
                if packed & 128 != 0 { p += 3 * (1 << (Int(packed & 7) + 1)) }
                guard p < b.count else { break }; p += 1; frames += 1
            } else { break }
            var ended = false
            while p < b.count {
                let n = Int(b[p]); p += 1
                if n == 0 { ended = true; break }
                guard n <= b.count - p else { break }; p += n
            }
            if !ended { break }
        }
        throw SkinFailure(message: "GIF 数据不完整，请重新选择文件")
    }
    static func files(_ root: URL) throws -> [URL] {
        guard let items = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey,.isSymbolicLinkKey,.fileSizeKey]) else { throw SkinFailure(message: "无法读取工程") }
        var result: [URL] = [], total = 0
        for case let url as URL in items {
            let v = try url.resourceValues(forKeys: [.isRegularFileKey,.isSymbolicLinkKey,.fileSizeKey])
            guard v.isSymbolicLink != true else { throw SkinFailure(message: "工程包含链接文件") }
            if v.isRegularFile == true {
                let size = v.fileSize ?? 0; total += size
                guard size <= 32 * 1024 * 1024, total <= 128 * 1024 * 1024, result.count < 6000 else { throw SkinFailure(message: "工程超过文件数量或 128 MB / 单文件 32 MB 限制") }
                result.append(url)
            }
        }
        return result.sorted { $0.path < $1.path }
    }
    static func packageRoot(_ project: URL) throws -> URL {
        let roots = Set(try files(project).filter { ($0.pathExtension.lowercased() == "ini" || $0.lastPathComponent == "appearanceConfig") && ["port","land"].contains($0.deletingLastPathComponent().lastPathComponent) }.map { $0.deletingLastPathComponent().deletingLastPathComponent() })
        guard roots.count == 1, let root = roots.first else { throw SkinFailure(message: "需要一个包含 port / land 面板的 BDS / BDI 工程") }
        return root
    }
    static func relative(_ file: URL, _ root: URL) -> String { file.pathComponents.dropFirst(root.pathComponents.count).joined(separator: "/") }
    static func panels(_ project: URL) throws -> [String] {
        let root = try packageRoot(project)
        var paths=try files(root).map { relative($0,root) }.filter { $0.range(of: "^(port|land)/[^/]+\\.ini$", options: [.regularExpression,.caseInsensitive]) != nil && URL(fileURLWithPath:$0).lastPathComponent.lowercased() != "gen.ini" }
        for ori in ["port","land"] {
            let file=root.appendingPathComponent(ori+"/appearanceConfig")
            if FileManager.default.fileExists(atPath:file.path) {
                let summary=try evaluate(["encoded":Data(contentsOf:file).base64EncodedString()],function:"nativeSummary")
                for name in summary["panels"] as? [String] ?? [] where !paths.contains(ori+"/"+name+".ini") {paths.append(ori+"/"+name)}
            }
        }
        return paths.sorted()
    }
    static func targetKey(project:URL,panel:URL?,nativePanel:String="") throws -> String {
        let root=try packageRoot(project)
        if let panel,panel.pathExtension.lowercased()=="ini" {
            let path=relative(panel,root)
            if path.range(of:"^(port|land)/gen[.]ini$",options:[.regularExpression,.caseInsensitive]) != nil { return String(path.dropLast(4)) }
            if try panels(project).contains(path) { return path }
        } else if let panel {
            let path=panel.deletingLastPathComponent().lastPathComponent+"/"+nativePanel
            if try panels(project).contains(path) { return path }
        }
        throw SkinFailure(message:"请先打开要设置背景的面板或 gen.ini。")
    }
    @MainActor static func sizeHint(project:URL,panel:URL?,candidateChoice:String="") throws -> String {
        guard let panel,panel.pathExtension.lowercased()=="ini" else {
            let root=try packageRoot(project)
            let orientation=panel?.deletingLastPathComponent().lastPathComponent == "land" ? "land":"port"
            let file=root.appendingPathComponent(orientation+"/appearanceConfig")
            if FileManager.default.fileExists(atPath:file.path) {
                let info=try evaluate(["encoded":Data(contentsOf:file).base64EncodedString()],function:"nativeSummary")
                let width=(info["width"] as? NSNumber)?.intValue ?? 0
                return "当前面板："+orientation+" 原生面板\n"+(width>0 ? "底包设计宽度：\(width) px\n":"")+"原生配置未声明完整尺寸，请按当前面板实际宽高准备 GIF。"
            }
            return "请先打开要设置背景的面板。"
        }
        let text=try GlobalViewFit.decode(Data(contentsOf:panel)).text
        let gen=panel.deletingLastPathComponent().appendingPathComponent("gen.ini")
        let defaults=gen != panel && FileManager.default.fileExists(atPath:gen.path) ? try GlobalViewFit.decode(Data(contentsOf:gen)).text:""
        let own=SkinConfiguration.parse(text),base=SkinConfiguration.parse(defaults)
        let value=own.first{$0.name=="PANEL"}?.values["SIZE"] ?? base.first{$0.name=="PANEL"}?.values["SIZE"] ?? ""
        func numbers(_ text:String) -> [Double] { let parts=text.split(separator:",",omittingEmptySubsequences:false);let values=parts.compactMap { Double($0.trimmingCharacters(in:.whitespacesAndNewlines)) };return values.count==parts.count ? values:[] }
        var size=numbers(value)
        let label="当前面板："+relative(panel,project)+"\n"
        if size.count != 2 || size.contains(where:{ !$0.isFinite || $0<=0 }) {
            var w=0.0,h=0.0
            for key in own { let rect=numbers(key.values["VIEW_RECT"] ?? "");if rect.count==4,rect.allSatisfy({$0.isFinite}),rect[2]>0,rect[3]>0 { w=max(w,rect[0]+rect[2]);h=max(h,rect[1]+rect[3]) } }
            guard w>0,h>0 else { return label+"未找到有效面板尺寸，请先检查 PANEL.SIZE。" };size=[w,h]
        }
        let renderer=IniSkinRenderer();renderer.candidateChoice=candidateChoice
        renderer.configure(root:project,config:panel,files:try files(project),text:text)
        let area=renderer.gifBackgroundBounds(panel:CGSize(width:size[0],height:size[1]))
        let detail=renderer.candidateFile == nil ? "":String(format:"（含顶栏）\n顶栏 %.0f + 键盘 %.0f px；使用一张完整 GIF。",ceil(renderer.candidateSize.height),ceil(size[1]))
        return label+String(format:"建议 GIF 尺寸：%.0f × %.0f px",ceil(area.width),ceil(area.height))+detail
    }
    static func safe(_ path: String, root: URL) throws -> URL {
        guard !path.isEmpty, !path.hasPrefix("/"), !path.contains("\\"), !path.contains(":"), !path.contains("\0"), !path.split(separator:"/").contains("..") else { throw SkinFailure(message: "无效的编译路径") }
        let target = root.appendingPathComponent(path).standardizedFileURL
        guard target.pathComponents.starts(with: root.standardizedFileURL.pathComponents), target != root else { throw SkinFailure(message: "编译路径超出工程") }
        return target
    }
    static func evaluate(_ input: [String:Any],function:String="compile") throws -> [String:Any] {
        guard let file = Bundle.main.url(forResource:"SingleGIF",withExtension:"js"), let context = JSContext() else { throw SkinFailure(message:"GIF 组件缺失") }
        context.evaluateScript(try String(contentsOf:file,encoding:.utf8))
        guard context.exception == nil else { throw SkinFailure(message:"GIF 组件加载失败") }
        let data = try JSONSerialization.data(withJSONObject:input,options:[.sortedKeys])
        context.setObject(String(decoding:data,as:UTF8.self),forKeyedSubscript:"compileInput" as NSString)
        let value = context.evaluateScript("JSON.stringify(SingleGIF.\(function)(JSON.parse(compileInput)"+(function=="nativeSummary" ? ".encoded":"")+"))")
        guard context.exception == nil, let json=value?.toString(), let result = try JSONSerialization.jsonObject(with:Data(json.utf8)) as? [String:Any] else { throw SkinFailure(message:context.exception?.toString() ?? "编译结果无效") }
        return result
    }
    struct Output: Sendable { let folder: URL; let report: String }
    static func apply(_ output:Output,to project:URL) throws {
        let fm=FileManager.default,backup=project.deletingLastPathComponent().appendingPathComponent(".gif-backup-"+UUID().uuidString)
        try fm.moveItem(at:project,to:backup)
        do { try fm.moveItem(at:output.folder,to:project) }
        catch {
            do { try fm.moveItem(at:backup,to:project) }
            catch { throw SkinFailure(message:"应用失败，原工程备份保留在："+backup.path) }
            throw error
        }
        try? fm.removeItem(at:backup)
        try? fm.removeItem(at:output.folder.deletingLastPathComponent())
    }
    static func nativeBackground(_ config:URL?,panel:String)->String {
        guard let config,let bytes=try? Data(contentsOf:config.deletingLastPathComponent().appendingPathComponent("animationConfig")),bytes.count<=32*1024*1024 else {return ""}
        var budget=0
        guard let fields=try? BinaryPlaintext.parse(Array(bytes),budget:&budget) else {return ""}
        func text(_ fields:[BinaryPlaintext.Field],_ id:Int)->String {fields.first{$0.number==id}?.text ?? ""}
        var key=""
        for entry in fields where entry.number==1 {
            let map=entry.children ?? [];guard text(map,1)=="PANEL" else {continue}
            for binding in map.first(where:{$0.number==2})?.children ?? [] where binding.number==2 {
                let value=binding.children ?? []
                if text(value,5)=="curPanelID == "+panel,text(value,3).hasPrefix("bg_mnbg_"){key=text(value,3)}
            }
        }
        guard !key.isEmpty else {return ""};var result=""
        for entry in fields where entry.number==8 {
            let map=entry.children ?? [];guard text(map,1)==key else {continue}
            let value=map.first{$0.number==2}?.children ?? [],resource=value.first{$0.number==3}?.children ?? []
            let id=text(resource,2)
            if id.range(of:"^mnbg_[0-9a-f]{16}$",options:.regularExpression) != nil {result=id+".gif"}
        }
        return result
    }
    static func background(_ config:URL?) -> String {
        guard let config,config.pathExtension.lowercased()=="ini" else { return "" }
        let nativeGIF=nativeBackground(config,panel:config.deletingPathExtension().lastPathComponent);if !nativeGIF.isEmpty{return nativeGIF}
        let root=config.deletingLastPathComponent().deletingLastPathComponent(),file=root.appendingPathComponent("bds_compile_backgrounds.json")
        guard let size=try? file.resourceValues(forKeys:[.fileSizeKey]).fileSize,size<=1024*1024,
              let data=try? Data(contentsOf:file),let map=try? JSONSerialization.jsonObject(with:data) as? [String:String],
              let name=map[relative(config,root)],name.range(of:"^mnbg_[0-9a-f]{16}\\.gif$",options:.regularExpression) != nil else { return "" }
        return name
    }
    static func compile(project: URL, name: String, backgrounds: [String:String], gifs: [GIF], templates override: [String:Any]? = nil,candidateChoices:[String:String]=[:]) throws -> Output {
        guard !(try panels(project)).isEmpty else { throw SkinFailure(message:"没有可编译的面板 INI") }
        let fm = FileManager.default, session = fm.temporaryDirectory.appendingPathComponent("single-gif-"+UUID().uuidString)
        try fm.createDirectory(at:session,withIntermediateDirectories:true)
        let copy = session.appendingPathComponent("package")
        do {
            _ = try files(project)
            try fm.copyItem(at:project,to:copy)
            let root = try packageRoot(copy)
            var texts:[String:String] = [:], animations:[String:String] = [:], appearances:[String:String] = [:], metadata:[String:Any] = [:], textSize = 0
            for file in try files(root) where ["ini","css","cnd","til"].contains(file.pathExtension.lowercased()) || file.lastPathComponent == "Info.txt" {
                let data = try Data(contentsOf:file); textSize += data.count
                guard data.count <= 2*1024*1024, textSize <= 24*1024*1024 else { throw SkinFailure(message:"配置文本超过大小限制") }
                texts[relative(file,root)] = try GlobalViewFit.decode(data).text
            }
            for ori in ["port","land"] {
                let app=root.appendingPathComponent(ori+"/appearanceConfig")
                if fm.fileExists(atPath:app.path) {appearances[ori]=try Data(contentsOf:app).base64EncodedString()}
                let file = root.appendingPathComponent(ori+"/animationConfig")
                if fm.fileExists(atPath:file.path) { animations[ori] = try Data(contentsOf:file).base64EncodedString() }
            }
            guard gifs.reduce(0,{$0+$1.bytes.count}) <= 128*1024*1024 else { throw SkinFailure(message:"所选 GIF 总量超过 128 MB") }
            for g in gifs { metadata[g.name] = ["rid":g.rid,"width":g.width,"height":g.height] }
            let templates:[String:Any]
            if name.lowercased().hasSuffix(".bdi") {templates=["port":"","land":"","resources":[:]]}
            else if let override { templates = override }
            else {
                guard let url = Bundle.main.url(forResource:"SingleGIFTemplates",withExtension:"json"), let value = try JSONSerialization.jsonObject(with:Data(contentsOf:url)) as? [String:Any] else { throw SkinFailure(message:"GIF 模板缺失") }
                templates = value
            }
            let result = try evaluate(["files":texts,"backgrounds":backgrounds,"candidateChoices":candidateChoices,"gifs":metadata,"templates":["port":templates["port"] as? String ?? "","land":templates["land"] as? String ?? ""],"existingAnimations":animations,"nativeAppearances":appearances,"format":name.lowercased().hasSuffix(".bdi") ? "bdi":"bds","previewBackgrounds":(try? JSONSerialization.jsonObject(with:Data(contentsOf:root.appendingPathComponent("bds_compile_backgrounds.json")))) as? [String:String] ?? [:]])
            func write(_ path:String,_ bytes:Data) throws { let target = try safe(path,root:root);try fm.createDirectory(at:target.deletingLastPathComponent(),withIntermediateDirectories:true);try bytes.write(to:target,options:.atomic) }
            guard let writes=result["writes"] as? [String:String], let used=result["usedGIFs"] as? [String] else { throw SkinFailure(message:"编译结果不完整") }
            for (path,encoded) in writes { guard let bytes=Data(base64Encoded:encoded) else { throw SkinFailure(message:"编译文件无效") };try write(path,bytes) }
            for ori in ["port","land"] {
                for (name,encoded) in templates["resources"] as? [String:String] ?? [:] {
                    let path=ori+"/res/"+name
                    if !fm.fileExists(atPath:try safe(path,root:root).path) { guard let bytes=Data(base64Encoded:encoded) else { throw SkinFailure(message:"模板图片无效") };try write(path,bytes) }
                }
            }
            for name in used { guard let g=gifs.first(where:{$0.name==name}) else { throw SkinFailure(message:"GIF 选择已失效") };try write("res/"+g.rid+".gif",g.bytes) }
            _ = try files(copy)
            return Output(folder:copy,report:result["report"] as? String ?? "编译完成")
        } catch { try? fm.removeItem(at:session);throw error }
    }
}
