import XCTest
import ZIPFoundation
@testable import ToMina

final class SingleGIFTests: XCTestCase {
    let pixel = Data(base64Encoded:"R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")!
    func fixture() throws -> [String:Any] {
        let url = try XCTUnwrap(Bundle(for:Self.self).url(forResource:"SingleGIFFixtures",withExtension:"json",subdirectory:"Fixtures"))
        return try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:url)) as? [String:Any])
    }
    func testJavaScriptCoreMatchesSharedExportFixtures() throws {
        let cases = try XCTUnwrap(fixture()["cases"] as? [[String:Any]])
        for item in cases {
            let input = try XCTUnwrap(item["input"] as? [String:Any])
            let result = try SingleGIFCompiler.evaluate(input)
            let actual = try XCTUnwrap(result["writes"] as? [String:String])
            let expected = try XCTUnwrap(item["expected"] as? [String:String])
            for (path,value) in expected { XCTAssertEqual(actual[path] ?? (input["existingAnimations"] as? [String:String])?[path.components(separatedBy:"/")[0]],value,"\(item["name"] ?? "") / \(path)") }
        }
    }
    func testGIFValidationPreservesBytesAndRejectsTruncation() throws {
        let gif = try SingleGIFCompiler.GIF(name:"pixel.gif",bytes:pixel)
        XCTAssertEqual(gif.width,1);XCTAssertEqual(gif.height,1);XCTAssertEqual(gif.bytes,pixel)
        XCTAssertEqual(gif.rid.count,21)
        XCTAssertThrowsError(try SingleGIFCompiler.GIF(name:"broken.gif",bytes:pixel.dropLast()))
        XCTAssertThrowsError(try SingleGIFCompiler.GIF(name:"text.gif",bytes:Data("not a gif".utf8)))
        var zero=pixel;zero[6]=0;zero[7]=0
        XCTAssertThrowsError(try SingleGIFCompiler.dimensions(zero))
    }
    func testWrappedCompileKeepsOriginalAndUsesDirectionalStyles() throws {
        let fm=FileManager.default,folder=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? fm.removeItem(at:folder) }
        let root=folder.appendingPathComponent("wrapped"),res=root.appendingPathComponent("port/res")
        try fm.createDirectory(at:res,withIntermediateDirectories:true)
        let ini="[PANEL]\nSIZE=100,100\n[KEY1]\nCENTER=q\nSHOW=た\nFORE_STYLE=701\nVIEW_RECT=0,0,100,100\n"
        let css="[STYLE701]\nSHOW=た\nFONT_SIZE=40\nNM_COLOR=000000\n"
        try ini.write(to:root.appendingPathComponent("port/ja.ini"),atomically:true,encoding:.utf8)
        try css.write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try Data([1,2,3,4]).write(to:root.appendingPathComponent("scene"))
        let original=try Dictionary(uniqueKeysWithValues:SingleGIFCompiler.files(folder).map { ($0.path,try Data(contentsOf:$0)) })
        let gif=try SingleGIFCompiler.GIF(name:"pixel.gif",bytes:pixel)
        let output=try SingleGIFCompiler.compile(project:folder,name:"kana.bds",backgrounds:["gen":"pixel.gif"],gifs:[gif],templates:["port":"","land":"","resources":["keep.png":Data([9]).base64EncodedString()]])
        defer { try? fm.removeItem(at:output.folder.deletingLastPathComponent()) }
        let compiled=output.folder.appendingPathComponent("wrapped")
        XCTAssertFalse(try SingleGIFCompiler.files(output.folder.deletingLastPathComponent()).contains {$0.pathExtension=="bds"})
        XCTAssertEqual(try Data(contentsOf:compiled.appendingPathComponent("port/ja.ini")),Data(ini.utf8))
        XCTAssertEqual(try Data(contentsOf:compiled.appendingPathComponent("scene")),Data([1,2,3,4]))
        XCTAssertEqual(try Data(contentsOf:compiled.appendingPathComponent("res/"+gif.rid+".gif")),pixel)
        XCTAssertTrue(try Data(contentsOf:compiled.appendingPathComponent("port/appearanceConfig")).range(of:Data("た".utf8)) != nil)
        XCTAssertTrue(fm.fileExists(atPath:compiled.appendingPathComponent("port/layoutConfig_ja").path))
        for (path,bytes) in original { XCTAssertEqual(try Data(contentsOf:URL(fileURLWithPath:path)),bytes) }
        try SingleGIFCompiler.apply(output,to:folder)
        XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("res/"+gif.rid+".gif")),pixel)
        XCTAssertEqual(SingleGIFCompiler.background(root.appendingPathComponent("port/ja.ini")),gif.rid+".gif")
        XCTAssertFalse(try SingleGIFCompiler.files(folder).contains {$0.pathExtension=="bds"})
        for (path,bytes) in original { XCTAssertEqual(try Data(contentsOf:URL(fileURLWithPath:path)),bytes) }

    }
    @MainActor func testSizeHintUsesCurrentINIIncludingGenAndInheritance() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString),port=root.appendingPathComponent("port")
        try fm.createDirectory(at:port,withIntermediateDirectories:true);defer{try? fm.removeItem(at:root)}
        let gen=port.appendingPathComponent("gen.ini"),ja=port.appendingPathComponent("ja.ini"),other=port.appendingPathComponent("other.ini")
        try "[PANEL]\nSIZE=240,120".write(to:gen,atomically:true,encoding:.utf8)
        try "[PANEL]\nSIZE=400,200".write(to:ja,atomically:true,encoding:.utf8)
        try "[PANEL]\nKEY_NUM=0".write(to:other,atomically:true,encoding:.utf8)
        XCTAssertEqual(try SingleGIFCompiler.sizeHint(project:root,panel:gen),"当前面板：port/gen.ini\n建议 GIF 尺寸：240 × 120 px")
        XCTAssertEqual(try SingleGIFCompiler.sizeHint(project:root,panel:ja),"当前面板：port/ja.ini\n建议 GIF 尺寸：400 × 200 px")
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:other).contains("240 × 120"))
    }
    func testApplyFailureRestoresCurrentProject() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try fm.createDirectory(at:root,withIntermediateDirectories:true);defer { try? fm.removeItem(at:root) }
        let marker=root.appendingPathComponent("original.txt");try Data("original".utf8).write(to:marker)
        let missing=root.deletingLastPathComponent().appendingPathComponent(UUID().uuidString)
        XCTAssertThrowsError(try SingleGIFCompiler.apply(.init(folder:missing,report:""),to:root))
        XCTAssertEqual(try Data(contentsOf:marker),Data("original".utf8))
    }
    func testMissingGIFFailsWithoutChangingInput() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? fm.removeItem(at:root) }
        try fm.createDirectory(at:root.appendingPathComponent("port"),withIntermediateDirectories:true)
        let file=root.appendingPathComponent("port/ja.ini"),original=Data("[PANEL]\nSIZE=10,10\n[KEY1]\nCENTER=た\nVIEW_RECT=0,0,10,10".utf8)
        try original.write(to:file)
        XCTAssertThrowsError(try SingleGIFCompiler.compile(project:root,name:"bad.bds",backgrounds:["gen":"missing.gif"],gifs:[],templates:["port":"","land":"","resources":[:]]))
        XCTAssertEqual(try SingleGIFCompiler.files(root),[file]);XCTAssertEqual(try Data(contentsOf:file),original)
        XCTAssertThrowsError(try SingleGIFCompiler.safe("../outside",root:root))
    }
    @MainActor func testKanaComesFromPackageShowAndCenterInBothOrientations() async throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? fm.removeItem(at:root) }
        for ori in ["port","land"] {
            let res=root.appendingPathComponent(ori+"/res")
            try fm.createDirectory(at:res,withIntermediateDirectories:true)
            for (name,label) in [("ja","た"),("ja_shifts","タ")] {
                try "[PANEL]\nSIZE=100,100\n[KEY1]\nVIEW_RECT=0,0,100,100\nSHOW=\(label)\nCENTER=q\nFORE_STYLE=701\n".write(to:root.appendingPathComponent(ori+"/"+name+".ini"),atomically:true,encoding:.utf8)
            }
            try "[STYLE701]\nFONT_SIZE=40\nNM_COLOR=000000\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        }
        let archive=root.deletingLastPathComponent().appendingPathComponent(UUID().uuidString+".bds")
        defer { try? fm.removeItem(at:archive) }
        try fm.zipItem(at:root,to:archive,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(archive)
        let project=try XCTUnwrap(store.root);defer { try? fm.removeItem(at:project) }
        for ori in ["port","land"] { for (name,label) in [("ja","た"),("ja_shifts","タ")] {
            try store.open(project.appendingPathComponent(ori+"/"+name+".ini"))
            XCTAssertEqual(store.keys.first(where:{$0.name=="KEY1"})?.caption,label)
        } }
        XCTAssertEqual(PreviewLabels.keyCaption(["CENTER":"て"]),"て")
        XCTAssertEqual(PreviewLabels.keyCaption(["CENTER":"q"]),"q")
        XCTAssertEqual(PreviewLabels.keyCaption(["SHOW":"","CENTER":"q"]),"")
        XCTAssertEqual(PreviewLabels.panel("ja_shifts.ini"),"日文 · 片假名")
    }
    @MainActor func testAutomaticScopeAndTopBarSizeUseTheCurrentINI() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer{try? fm.removeItem(at:root)}
        let port=root.appendingPathComponent("wrapped/port")
        try fm.createDirectory(at:port,withIntermediateDirectories:true)
        let gen=port.appendingPathComponent("gen.ini"),panel=port.appendingPathComponent("py_26.ini"),bar=port.appendingPathComponent("bar.cnd")
        try "[PANEL]\nSIZE=240,120\n[CAND]\nLAYOUT_NAME=bar.cnd\nVIEW_RECT=0,0,240,40\n".write(to:gen,atomically:true,encoding:.utf8)
        try "[PANEL]\n[KEY1]\nVIEW_RECT=0,0,100,100\nCENTER=q\n".write(to:panel,atomically:true,encoding:.utf8)
        try "[CAND]\nBACK_STYLE=1\n".write(to:bar,atomically:true,encoding:.utf8)
        XCTAssertEqual(try SingleGIFCompiler.targetKey(project:root,panel:gen),"port/gen")
        XCTAssertEqual(try SingleGIFCompiler.targetKey(project:root,panel:panel),"port/py_26.ini")
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:gen).contains("240 × 160"))
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:panel).contains("240 × 160"))
        let base=try String(contentsOf:gen,encoding:.utf8)
        try (base+"[CAND]\nLAYOUT_NAME=second\nVIEW_RECT=0,0,240,64\n").write(to:gen,atomically:true,encoding:.utf8)
        try "[CAND]\n".write(to:port.appendingPathComponent("second.cnd"),atomically:true,encoding:.utf8)
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:panel).contains("240 × 160"))
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:panel,candidateChoice:"second").contains("240 × 184"))

    }

}
