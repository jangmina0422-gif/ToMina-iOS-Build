# To.Mina 0.1.53（build54）

工具箱新增“更新半bda”。基于公开的 0.1.52 构建，保留 GIF 和顶栏修复。

To.Mina iOS 0.1.52 build53. Public build sources with synthetic test resources. GIF backgrounds cover the top bar and keyboard. Uses the current panel automatically.
