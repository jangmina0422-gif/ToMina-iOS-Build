import UIKit
import SwiftUI

final class SourceLineGutter:UIView {
    weak var editor:SourceTextView?
    override func draw(_ rect:CGRect) {
        guard let editor else{return}
        UIColor(white:0.96,alpha:1).setFill();UIRectFill(bounds)
        let manager=editor.layoutManager,container=editor.textContainer
        let visible=CGRect(x:0,y:max(0,editor.contentOffset.y-editor.textContainerInset.top),width:editor.bounds.width,height:editor.bounds.height)
        let range=manager.glyphRange(forBoundingRect:visible,in:container)
        let font=UIFont.monospacedDigitSystemFont(ofSize:11,weight:.regular)
        let current=editor.sourceLines.line(at:editor.selectedRange.location)
        manager.enumerateLineFragments(forGlyphRange:range){fragment,_,_,glyphs,_ in
            guard glyphs.length>0 else{return}
            let offset=manager.characterIndexForGlyph(at:glyphs.location),line=editor.sourceLines.line(at:offset)
            guard editor.sourceLines.starts[line-1]==offset else{return}
            let label=String(line) as NSString,attrs:[NSAttributedString.Key:Any]=[.font:font,.foregroundColor:line==current ? UIColor.black:UIColor.gray]
            let size=label.size(withAttributes:attrs)
            let y=fragment.minY+editor.textContainerInset.top-editor.contentOffset.y+(fragment.height-size.height)/2
            label.draw(at:CGPoint(x:self.bounds.width-size.width-8,y:y),withAttributes:attrs)
        }
        if editor.sourceLines.starts.last == (editor.text as NSString).length {
            let label=String(editor.sourceLines.count) as NSString,attrs:[NSAttributedString.Key:Any]=[.font:font,.foregroundColor:UIColor.gray]
            let size=label.size(withAttributes:attrs),caret=editor.caretRect(for:editor.endOfDocument)
            label.draw(at:CGPoint(x:bounds.width-size.width-8,y:caret.minY-editor.contentOffset.y+(caret.height-size.height)/2),withAttributes:attrs)
        }
    }
}

// The byte inspector uses the same numbered native editor, with its own page text.
struct NumberedTextEditor:UIViewRepresentable {
    @Binding var text:String
    var editable=true
    func makeCoordinator()->Coordinator{Coordinator(self)}
    func makeUIView(context:Context)->SourceTextView {
        let view=SourceTextView(frame:.zero);view.delegate=context.coordinator
        view.font = .monospacedSystemFont(ofSize:13,weight:.regular);view.textColor = .black
        view.backgroundColor = .white;view.autocorrectionType = .no;view.spellCheckingType = .no
        view.smartQuotesType = .no;view.smartDashesType = .no;view.keyboardDismissMode = .interactive
        return view
    }
    func updateUIView(_ view:SourceTextView,context:Context){context.coordinator.parent=self;view.isEditable=editable;if view.text != text{view.text=text;view.refreshLineNumbers(rebuild:true)}}
    final class Coordinator:NSObject,UITextViewDelegate {
        var parent:NumberedTextEditor;init(_ parent:NumberedTextEditor){self.parent=parent}
        func textViewDidChange(_ view:UITextView){parent.text=view.text;(view as? SourceTextView)?.refreshLineNumbers(rebuild:true)}
        func textViewDidChangeSelection(_ view:UITextView){(view as? SourceTextView)?.refreshLineNumbers()}
    }
}
