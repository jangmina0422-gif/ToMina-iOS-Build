import Foundation

struct SourceLineIndex {
    private(set) var starts=[0]
    mutating func update(_ text:String) {
        let units=Array(text.utf16);var result=[0],i=0
        while i<units.count {
            if units[i]==13 {
                if i+1<units.count,units[i+1]==10{i+=1}
                result.append(i+1)
            } else if units[i]==10 {result.append(i+1)}
            i+=1
        }
        starts=result
    }
    var count:Int{starts.count}
    func line(at offset:Int)->Int {
        var lo=0,hi=starts.count
        while lo<hi {let mid=(lo+hi)/2;if starts[mid]<=max(0,offset){lo=mid+1}else{hi=mid}}
        return max(1,lo)
    }
}
