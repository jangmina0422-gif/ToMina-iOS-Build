import SwiftUI
import UniformTypeIdentifiers

struct SingleGIFToolView: View {
    @ObservedObject var store: SkinStore
    @Binding var transferActive: Bool
    @State private var gifs: [SingleGIFCompiler.GIF] = []
    @State private var selectedGIF = ""
    @State private var targetKey = ""
    @State private var importing = false
    @State private var sizePrompt = false
    @State private var sizeHint = ""
    let applied: () -> Void
    @State private var report = ""
    @State private var working = false
    var body: some View {
        Form {
            SwiftUI.Section {
                Text("选择 GIF 作为当前键盘的动态背景。").font(.footnote)
                Text(targetKey.isEmpty ? "正在读取当前面板…":"当前面板："+targetKey+(targetKey.hasSuffix("/gen") ? ".ini":"")).accessibilityIdentifier("singleGIF.target")
                Text(targetKey.hasSuffix("/gen") ? "应用到"+(targetKey.hasPrefix("land/") ? "横屏":"竖屏")+"全部面板（通用背景）":"仅应用到当前面板").font(.footnote)
                Button("添加 GIF") {
                    do { try store.save();if let root=store.root { sizeHint=try currentSizeHint(root);sizePrompt=true } } catch { report=error.localizedDescription }
                }.accessibilityIdentifier("singleGIF.add").disabled(targetKey.isEmpty)
                if gifs.isEmpty { Text("请先添加 GIF，添加后会自动选中。").font(.footnote) }
                else {
                    Picker("选择 GIF 背景",selection:$selectedGIF) {
                        ForEach(gifs) { gif in Text("\(gif.name) · \(gif.width) × \(gif.height)").tag(gif.name) }
                    }.accessibilityIdentifier("singleGIF.selection")
                }
            }
            SwiftUI.Section {
                Button("应用为背景") { compile() }.disabled(selectedGIF.isEmpty || targetKey.isEmpty).accessibilityIdentifier("singleGIF.compile")
                if working { ProgressView("正在应用背景…") }
                if !report.isEmpty { Text(report).font(.footnote).textSelection(.enabled) }
            }
        }.disabled(working).navigationTitle("GIF 动态背景").navigationBarBackButtonHidden(working)
            .interactiveDismissDisabled(working || importing)
            .onChange(of:importing) { _,_ in transferActive=importing }
            .onDisappear { transferActive=false }
            .task {
                if let root=store.root { do { targetKey=try SingleGIFCompiler.targetKey(project:root,panel:store.currentINIPanel ?? store.bda?.config,nativePanel:store.bda?.panelID ?? "") } catch { report=error.localizedDescription } }
                #if DEBUG
                if ProcessInfo.processInfo.arguments.contains("--single-gif-tool-fixture"),gifs.isEmpty,let data=Data(base64Encoded:"R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"),let gif=try? SingleGIFCompiler.GIF(name:"test.gif",bytes:data) { gifs=[gif];selectedGIF=gif.name }
                #endif
            }
            .alert("GIF 建议尺寸",isPresented:$sizePrompt) {
                Button("继续选择 GIF") { importing=true }
                Button("取消",role:.cancel) {}
            } message: { Text(sizeHint) }
            .sheet(isPresented:$importing) {
                SkinDocumentPicker(contentTypes:[.gif],asCopy:true,title:"选择 GIF") { result in
                    importing=false
                    do {
                        guard let url=try result.get() else { return }
                        let access=url.startAccessingSecurityScopedResource();defer { if access { url.stopAccessingSecurityScopedResource() } }
                        guard (try url.resourceValues(forKeys:[.fileSizeKey]).fileSize ?? Int.max) <= 32*1024*1024 else { throw SkinFailure(message:"GIF 超过 32 MB") }
                        let bytes=try Data(contentsOf:url)
                        guard gifs.reduce(bytes.count,{$0+$1.bytes.count}) <= 128*1024*1024 else { throw SkinFailure(message:"所选 GIF 总量超过 128 MB") }
                        let original=url.deletingPathExtension().lastPathComponent
                        var name=original+".gif", n=2
                        while gifs.contains(where:{$0.name==name}) { name=original+" (\(n)).gif";n+=1 }
                        gifs.append(try SingleGIFCompiler.GIF(name:name,bytes:bytes));selectedGIF=name
                    } catch { report=error.localizedDescription }
                }
            }
    }

    private func currentSizeHint(_ root:URL) throws -> String {
        if store.currentINIPanel == nil,let engine=store.bda,engine.gifBackgroundBounds.width>0,engine.gifBackgroundBounds.height>0 {
            let area=engine.gifBackgroundBounds
            return "当前面板："+targetKey+String(format:"\n建议 GIF 尺寸：%.0f × %.0f px（键盘）",ceil(area.width),ceil(area.height))
        }
        return try SingleGIFCompiler.sizeHint(project:root,panel:store.currentINIPanel ?? store.bda?.config,candidateChoice:store.renderer.candidateChoice)
    }
    private func compile() {
        guard let root=store.root, !working,!targetKey.isEmpty,gifs.contains(where:{$0.name==selectedGIF}) else { return }
        do { guard store.saveAnimationSource() else { return };try store.save() } catch { report=error.localizedDescription;return }
        let assets=gifs, mapping=[targetKey:selectedGIF], name=store.filename, choices=[targetKey:store.renderer.candidateChoice]
        working=true;store.busy=true
        Task {
            defer { working=false;store.busy=false }
            do {
                let result=try await Task.detached(priority:.userInitiated) { let result=try SingleGIFCompiler.compile(project:root,name:name,backgrounds:mapping,gifs:assets,candidateChoices:choices);try SingleGIFCompiler.apply(result,to:root);return result }.value
                report="背景已应用到当前工程。需要导出时，请使用菜单 → 导出。\n\n"+result.report
                store.rescan();applied()
            } catch { report="编译未完成："+error.localizedDescription }
        }
    }
}
