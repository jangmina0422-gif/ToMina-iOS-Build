'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const E=require('./SingleGIF.js'),T=E._test;
let groups=0;const test=(name,fn)=>{fn();groups++;console.log('PASS '+name);};
const input={format:'bds',files:{'port/gen.ini':'[PANEL]\nSIZE=200,100\nBACK_STYLE=1','port/custom.ini':'[PANEL]\n[KEY1]\nCENTER=a\nVIEW_RECT=0,0,100,100\nTOUCH_RECT=1,2,90,90\nFORE_STYLE=2','res/default.css':'[STYLE1]\nNM_COLOR=ffffff\n[STYLE2]\nSHOW=A\nFONT_SIZE=40\nNM_COLOR=000000'},nativeAppearances:{port:T.b64([48,200,1,152,6,42])},nativeLayouts:{},resourcePaths:[],previewBackgrounds:{}};
const clone=x=>JSON.parse(JSON.stringify(x));
const apply=(i,r)=>{i=clone(i);for(const [p,v] of Object.entries(r.writes)){if(p.endsWith('/appearanceConfig'))i.nativeAppearances[p.split('/')[0]]=v;else i.nativeLayouts[p]=v;}return i;};
const field=(b,id)=>T.wire(b).find(f=>f.id===id);
const map=(b,id,key)=>T.mapEntry(T.wire(b).find(f=>f.id===id&&T.mapEntry(f).key===key)).value;
function panel(r){return map(T.un64(r.writes['port/layoutConfig_custom']),1,'custom');}
function key(r,name='KEY_A'){return map(panel(r),2,name);}
test('build layout and styles from edited INI/CSS without selecting a GIF',()=>{
 const r=E.updateHalfBda(input),k=key(r);assert.equal(r.panels,1);assert.deepEqual(Object.keys(r.writes).sort(),['port/appearanceConfig','port/layoutConfig_custom']);
 assert.equal(field(field(field(k,1).data,2).data,1).value,100);
 const style=map(T.un64(r.writes['port/appearanceConfig']),2,'10002');assert.equal(field(style,3).value,40);assert.equal(Buffer.from(field(style,6).data).toString(),'A');
});
test('preserve unknown root bytes and prevent duplicate fields on reapply',()=>{
 const r=E.updateHalfBda(input);assert.equal(field(T.un64(r.writes['port/appearanceConfig']),99).value,42);
 const second=E.updateHalfBda(apply(input,r));assert.deepEqual(second.writes,r.writes);
});
test('geometry, action, inherited defaults and CSS changes reach native messages',()=>{
 const i=clone(input);i.files['port/custom.ini']=i.files['port/custom.ini'].replace('100,100','80,90').replace('CENTER=a','CENTER=b');i.files['res/default.css']=i.files['res/default.css'].replace('FONT_SIZE=40','FONT_SIZE=65');
 const r=E.updateHalfBda(i),k=key(r,'KEY_B');assert.equal(field(field(field(k,1).data,2).data,1).value,80);
 assert.equal(Buffer.from(field(k,8).data).toString(),'b');assert.equal(field(map(T.un64(r.writes['port/appearanceConfig']),2,'10002'),3).value,65);
});
test('retain native GIF bindings and keep GIF panel backgrounds transparent',()=>{
 const i=clone(input);i.previewBackgrounds['port/custom.ini']='mnbg_0123456789abcdef.gif';i.existingAnimations={port:'unchanged-animation'};
 const before=JSON.stringify(i),r=E.updateHalfBda(i);assert.equal(JSON.stringify(i),before);assert.ok(!Object.keys(r.writes).some(p=>p.includes('animation')||p.endsWith('.json')));
 const app=map(T.un64(r.writes['port/appearanceConfig']),4,'custom');assert.equal(field(field(app,7).data,2).value,2147483000);
});
test('use source atlas and TIL to regenerate changed image slices and inner rectangles',()=>{
 const i=clone(input);i.files['res/default.css']=i.files['res/default.css'].replace('SHOW=A\nFONT_SIZE=40\nNM_COLOR=000000','NM_IMG=button,2');i.files['res/button.til']='[IMG2]\nSOURCE_RECT=50,0,50,50\nINNER_RECT=60,10,20,20';i.resourcePaths=['res/button.png'];
 const r=E.updateHalfBda(i);assert.deepEqual(r.imageSlices['port/res/res_button_2.png'],{source:'res/button.png',rect:[50,0,50,50]});
 const image=field(map(T.un64(r.writes['port/appearanceConfig']),1,'10002'),1).data;
 assert.equal(field(field(field(image,2).data,1).data,1).value,10);
});
test('list appearance follows inherited LIST styles and stays stable on reapply',()=>{
 const i=clone(input);i.files['port/gen.ini']+='\n[LIST]\nBACK_STYLE=1\nCELL_STYLE=1\nFORE_STYLE=2';
 const r=E.updateHalfBda(i),app=map(T.un64(r.writes['port/appearanceConfig']),4,'custom'),list=map(app,2,'port');
 assert.equal(field(field(list,3).data,2).value,10002);assert.deepEqual(E.updateHalfBda(apply(i,r)).writes,r.writes);
});
test('refuse malformed binary, absent native appearance and invalid geometry',()=>{
 for(const change of [i=>i.nativeAppearances={},i=>i.nativeAppearances.port=T.b64([10,255]),i=>i.files['port/custom.ini']=i.files['port/custom.ini'].replace('0,0,100,100','0,0,no,100')]){const i=clone(input);change(i);const before=JSON.stringify(i);assert.throws(()=>E.updateHalfBda(i));assert.equal(JSON.stringify(i),before);}
});
test('missing styles and missing atlas definitions fail before writing',()=>{
 const i=clone(input);i.files['res/default.css']='';assert.throws(()=>E.updateHalfBda(i),/STYLE/);
 i.files['res/default.css']=input.files['res/default.css'].replace('SHOW=A','NM_IMG=absent,1');assert.throws(()=>E.updateHalfBda(i),/图片资源/);
});
test('reject unsafe paths and unsupported BDI',()=>{
 const i=clone(input);i.files['../escape.ini']='';assert.throws(()=>E.updateHalfBda(i),/路径/);assert.throws(()=>E.updateHalfBda({...input,format:'bdi'}),/BDS/);
});
if(process.argv[2])test('uploaded 101-panel half-BDA roundtrip, edits and repeatability',()=>{
 const i=JSON.parse(fs.readFileSync(process.argv[2])),before=JSON.stringify(i),r=E.updateHalfBda(i);assert.equal(r.panels,101);assert.equal(Object.keys(r.writes).length,103);assert.equal(Object.keys(r.imageSlices).length,505);assert.equal(before,JSON.stringify(i));
 const second=E.updateHalfBda(apply(i,r));assert.deepEqual(second.writes,r.writes);assert.deepEqual(second.imageSlices,r.imageSlices);
 const edited=clone(i);edited.files['port/py_26.ini']=edited.files['port/py_26.ini'].replace('VIEW_RECT=0,0,116,170','VIEW_RECT=0,0,120,171');
 const next=E.updateHalfBda(edited);assert.notEqual(next.writes['port/layoutConfig_py_26'],r.writes['port/layoutConfig_py_26']);assert.equal(next.writes['land/layoutConfig_py_26'],r.writes['land/layoutConfig_py_26']);
 assert.ok(!Object.keys(r.writes).some(p=>!p.includes('Config')));
});
console.log(groups+' half-BDA update test groups passed');
