'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),crypto=require('node:crypto');
const C=require('./SingleGIF.js'),T=C._test;
const gif=Buffer.from('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7','base64');
const input={format:'bds',files:{
 'Info.txt':'Name=原皮肤\r\nSkinType=1\r\nAuthor=原作者\r\n',
 'port/gen.ini':'[PANEL]\nSIZE=240,120\n[CAND]\nLAYOUT_NAME=我的顶栏.cnd\nVIEW_RECT=0,0,240,40\n',
 'port/我的布局.ini':'[PANEL]\n[KEY1]\nVIEW_RECT=11,17,80,44\nTOUCH_RECT=9,15,84,48\nCENTER=q\nUP=w\nBACK_STYLE=1\nFORE_STYLE=2\n',
 'port/我的顶栏.cnd':'[CAND]\nBACK_STYLE=1\n[ICON1]\nKEY=F1\nVIEW_RECT=190,4,24,24\nFORE_STYLE=2\n',
 'port/res/default.css':'[STYLE1]\nNM_IMG=my-keys.png,1\n[STYLE2]\nFONT_SIZE=20\nNM_COLOR=FF123456\nSHOW=原键字\n',
 'port/res/my-keys.til':'[IMG1]\nSOURCE_RECT=1,0,1,1\n',
 'land/custom.ini':'[PANEL]\nSIZE=400,100\n',
},assetFiles:['port/res/my-keys.png'],backgrounds:{'port/我的布局.ini':'我的背景.gif'},gifs:{'我的背景.gif':{filename:'我的背景.gif',rid:'mnbg_'+crypto.createHash('sha256').update(gif).digest('hex').slice(0,16),width:1,height:1}},templates:{port:Buffer.from('foreign skin').toString('base64'),land:Buffer.from('foreign skin').toString('base64')}};
// Native panel conditions currently accept ASCII panel IDs. Keep the original UTF-8
// layout file in the preservation fixture and select an ASCII companion for playback.
input.files['port/custom.ini']=input.files['port/我的布局.ini'];input.backgrounds={'port/custom.ini':'我的背景.gif'};
const before=JSON.stringify(input),result=C.compile(input),decode=p=>T.un64(result.writes[p]);
const field=(bytes,id)=>T.wire(bytes).find(f=>f.id===id),map=(bytes,id)=>Object.fromEntries(T.wire(bytes).filter(f=>f.id===id).map(f=>{const m=T.mapEntry(f);return[m.key,m.value]}));
const value=(bytes,id)=>field(bytes,id)?.value,data=(bytes,id)=>field(bytes,id)?.data||[];
assert.equal(JSON.stringify(input),before);
assert(!Object.keys(result.writes).some(p=>/\.(ini|css|cnd|til|png|gif)$/i.test(p)));
assert(!Object.keys(result.writes).some(p=>p.startsWith('land/')));
assert.equal(Buffer.from(decode('Info.txt')).toString(),'Name=原皮肤\r\nSkinType=2\r\nAuthor=原作者\r\n');
assert.deepEqual(result.resourcePlans,[{source:'port/res/my-keys.png',path:'port/res/mina_tile_port_my_keys_1.png',rect:[1,0,1,1]}]);
const p=map(decode('port/layoutConfig_custom'),1).custom,key=map(p,2).KEY_Q;
assert.equal(value(data(data(key,1),1),1),11);assert.equal(value(data(data(key,1),1),2),17);
assert.equal(value(data(data(key,2),1),1),9);assert.equal(Buffer.from(data(key,3)).toString(),'w');
const icon=map(data(p,4),5).F1;assert.equal(value(data(icon,4),1),190);assert.equal(value(data(icon,2),1),24);
const appearance=decode('port/appearanceConfig'),panel=map(appearance,4).custom;
assert(map(panel,3).KEY_Q);assert.equal(value(data(map(panel,3).KEY_Q,1),2),10001);
assert.equal(Buffer.from(data(data(data(map(appearance,1)['10001'],1),1),2)).toString(),'mina_tile_port_my_keys_1');
assert.equal(JSON.parse(Buffer.from(decode('bds_compile_backgrounds.json')).toString())['port/custom.ini'],'我的背景.gif');
const second=C.compile({...input,nativeAppearances:{port:result.writes['port/appearanceConfig']},existingAnimations:{port:result.writes['port/animationConfig']}});
assert(!Object.keys(second.writes).some(p=>p.includes('layoutConfig')));assert.deepEqual(second.resourcePlans,[]);
const after=map(T.un64(second.writes['port/appearanceConfig']),4).custom;
assert.deepEqual(data(after,3),data(panel,3));assert.deepEqual(data(after,4),data(panel,4));
assert.throws(()=>C.compile({...input,assetFiles:[]}),/底包缺少/);
console.log('PASS current skin: INI geometry/actions, visible key styles, CND icon geometry, own atlas crop, no template assets, native preservation, original filenames, untouched orientation');
if(process.argv[2])fs.writeFileSync(process.argv[2],JSON.stringify({input,result,gif:gif.toString('base64')},null,2)+'\n');
