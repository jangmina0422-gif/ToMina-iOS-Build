'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const C=require('./SingleGIF.js'),T=C._test;
const v=T.varint,cat=(...a)=>[].concat(...a),msg=(n,b)=>cat(v(n*8+2),v(b.length),b),int=(n,x)=>cat(v(n*8),v(x)),str=(n,s)=>msg(n,Array.from(Buffer.from(s))),map=(n,k,b)=>msg(n,cat(str(1,k),msg(2,b)));
const fields=b=>T.wire(b),data=(b,n)=>fields(b).find(f=>f.id===n)?.data||[],val=(b,n)=>fields(b).find(f=>f.id===n)?.value;
const entries=(b,n)=>Object.fromEntries(fields(b).filter(f=>f.id===n).map(f=>{const m=T.mapEntry(f);return[m.key,m.value]}));
const decode=(r,p)=>T.un64(r.writes[p]),float=(b,n)=>Buffer.from(data(b,n)).readFloatLE();
let checks=0;function check(name,fn){fn();checks++;console.log('PASS '+name);}
const gen='[PANEL]\nSIZE=240,120\n[CAND]\nLAYOUT_NAME=bar.cnd\nVIEW_RECT=0,0,240,40\n';
const ini='[PANEL]\n[KEY1]\nVIEW_RECT=10,10,60,60\nTOUCH_RECT=8,8,64,64\nCENTER=q\nFORE_STYLE=2\n';
const input={files:{'Info.txt':'Name=FullGIF\n','port/gen.ini':gen,'port/py_26.ini':ini,'port/ja.ini':ini,'land/gen.ini':gen.replace('240,120','400,100').replace('240,40','400,20'),'land/py_26.ini':ini,'port/bar.cnd':'[CAND]\nBACK_STYLE=1\nFORE_STYLE=2\n[ICON1]\nKEY=F1\nSIZE=20,20\nPOS=10,0\nFORE_STYLE=2','land/bar.cnd':'[CAND]\nBACK_STYLE=1','res/default.css':'[STYLE1]\nNM_COLOR=FFFF0000\n[STYLE2]\nFONT_SIZE=20\nSHOW=保留文字\n'},templates:{port:'',land:''},backgrounds:{'port/py_26.ini':'a.gif'},gifs:{'a.gif':{rid:'mnbg_0000000000000001',width:240,height:160},'b.gif':{rid:'mnbg_0000000000000002',width:240,height:160}},existingAnimations:{}};
const first=C.compile(input);
function panel(result,ori='port',id='py_26'){return entries(decode(result,ori+'/layoutConfig_'+id),1)[id];}
function bindings(result,ori='port') {const b=entries(decode(result,ori+'/animationConfig'),1).PANEL;return fields(b).filter(f=>f.id===2).map(f=>({key:Buffer.from(data(f.data,3)).toString(),condition:Buffer.from(data(f.data,5)).toString()}));}
check('exported layout includes external top bar without moving keys',()=>{
 const p=panel(first);assert.equal(float(data(p,4),2),40);assert.equal(val(data(p,7),2),120);
 const key=entries(p,2).KEY_Q;assert.equal(val(data(data(key,1),1),2),10);assert.equal(val(data(data(key,2),1),2),8);
 assert.equal(bindings(first).length,1);assert.equal(bindings(first)[0].condition,'curPanelID == py_26');
 assert.deepEqual(Object.keys(entries(decode(first,'port/animationConfig'),8)),['bg_mnbg_0000000000000001']);
});
check('bar background, text and icons stay unchanged in the saved appearance',()=>{
 const appearance=entries(decode(first,'port/appearanceConfig'),4).py_26,cand=data(appearance,4);
 assert.equal(val(data(cand,1),2),10001);
 assert.equal(val(data(cand,4),2),10002);assert(entries(cand,10).CAND_F1);
 assert(!Object.keys(first.writes).some(p=>/\.(ini|css|cnd|gif)$/.test(p)));
});
check('gen assignment covers its orientation automatically',()=>{
 const r=C.compile({...input,backgrounds:{'port/gen':'a.gif'}});
 assert.deepEqual(JSON.parse(Buffer.from(r.writes['bds_compile_backgrounds.json'],'base64')),{'port/ja.ini':'mnbg_0000000000000001.gif','port/py_26.ini':'mnbg_0000000000000001.gif'});
 assert.equal(bindings(r).length,2);assert(!r.writes['land/animationConfig']);
});
check('setting a second panel preserves the first and reapplying has no duplicate playback',()=>{
 const old=JSON.parse(Buffer.from(first.writes['bds_compile_backgrounds.json'],'base64'));
 const second=C.compile({...input,previewBackgrounds:old,existingAnimations:{port:first.writes['port/animationConfig']},backgrounds:{'port/ja.ini':'b.gif'}});
 assert.equal(bindings(second).length,2);
 const selected=JSON.parse(Buffer.from(second.writes['bds_compile_backgrounds.json'],'base64'));assert.equal(selected['port/py_26.ini'],old['port/py_26.ini']);assert.equal(selected['port/ja.ini'],'mnbg_0000000000000002.gif');
 const third=C.compile({...input,previewBackgrounds:selected,existingAnimations:{port:second.writes['port/animationConfig']},backgrounds:{'port/ja.ini':'a.gif'}});
 assert.equal(bindings(third).length,2);assert.equal(bindings(third).find(x=>x.condition.endsWith('ja')).key,'bg_mnbg_0000000000000001');
 assert.equal(fields(decode(third,'port/animationConfig')).filter(f=>f.id===1&&T.mapEntry(f).key==='PANEL').length,1);
});
check('bar height can come from CND SIZE or its background tile',()=>{
 for(const changes of [
  {'port/bar.cnd':'[CAND]\nSIZE=240,60'},
  {'port/bar.cnd':'[CAND]\nBACK_STYLE=1','res/default.css':'[STYLE1]\nNM_IMG=bar.PNG,1','res/bar.til':'[IMG1]\nSOURCE_RECT=0,0,240,60'}
 ]){
  const r=C.compile({...input,files:{...input.files,'port/gen.ini':gen.replace('VIEW_RECT=0,0,240,40\n',''),...changes}});
  assert.equal(float(data(panel(r),4),2),60);
 }
});
check('repeated CAND definitions use the active named bar, not the last definition',()=>{
 const f={...input,files:{...input.files,'port/gen.ini':gen+'[CAND]\nLAYOUT_NAME=second\nVIEW_RECT=0,0,240,64\n','port/second.cnd':'[CAND]\nBACK_STYLE=1'}};
 assert.equal(float(data(panel(C.compile(f)),4),2),40);
 assert.equal(float(data(panel(C.compile({...f,candidateChoices:{'port/py_26.ini':'second.cnd'}})),4),2),64);
 assert.equal(float(data(panel(C.compile({...f,files:{...f.files,'port/py_26.ini':ini+'[CAND]\nLAYOUT_NAME=second\n'}})),4),2),64);
});
check('native BDI clears only selected background layers and preserves unknown fields',()=>{
 const ref=cat(int(1,1),int(2,22)),textRef=cat(int(1,2),int(2,12));
 const cand=cat(msg(1,ref),msg(2,ref),msg(4,textRef),map(10,'CAND_F1',msg(2,textRef)),msg(9,cat(msg(1,ref),msg(3,textRef))),str(88,'unknown-candidate'));
 const original=cat(msg(4,cand),msg(7,ref),msg(10,ref),str(70,'unknown-panel'));
 const app=cat(map(4,'py_26',original),map(4,'other',original),int(6,240));
 const r=C.compile({format:'bdi',files:{},nativeAppearances:{port:T.b64(app)},backgrounds:{'port/py_26':'a.gif'},gifs:input.gifs});
 const p=entries(decode(r,'port/appearanceConfig'),4);assert.deepEqual(p.other,original);
 const actual=data(p.py_26,4);assert.deepEqual(actual,cand);
 assert.deepEqual(data(actual,4),textRef);assert.deepEqual(entries(actual,10),entries(cand,10));assert(Buffer.from(actual).includes(Buffer.from('unknown-candidate')));
 assert.equal(bindings(r).length,1);assert(!Object.keys(r.writes).some(p=>p.includes('layoutConfig')));
});
check('exported binary alone carries the GIF binding, without editor JSON',()=>{
 const binding=bindings(first)[0],definition=entries(decode(first,'port/animationConfig'),8)[binding.key];
 assert.equal(Buffer.from(data(data(definition,3),2)).toString(),'mnbg_0000000000000001');
 assert.equal(val(data(definition,3),1),1);
});
if(process.argv.includes('--export')) {
 const out=path.resolve(__dirname,'../../verification/full-gif-fixture');fs.mkdirSync(out,{recursive:true});
 for(const [p,text]of Object.entries(input.files)){const f=path.join(out,p);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,text);}
 for(const [p,b64]of Object.entries(first.writes)){const f=path.join(out,p);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,Buffer.from(b64,'base64'));}
}
console.log(checks+' keyboard GIF export regression groups passed');
