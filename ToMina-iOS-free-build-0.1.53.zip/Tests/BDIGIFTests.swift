import XCTest
import SwiftUI
import UIKit
@testable import ToMina

final class BDIGIFTests:XCTestCase {
    func fixture() throws -> [String:Any] {
        let file=try XCTUnwrap(Bundle(for:Self.self).url(forResource:"BDIGIFFixtures",withExtension:"json",subdirectory:"Fixtures"))
        return try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:file)) as? [String:Any])
    }
    @MainActor func testNativeBDIWithoutINIAndNoExport() throws {
        let f=try fixture(),input=try XCTUnwrap(f["input"] as? [String:Any]),expected=try XCTUnwrap(f["expected"] as? [String:String])
        XCTAssertEqual(try SingleGIFCompiler.evaluate(input)["writes"] as? [String:String],expected)
        let fm=FileManager.default,project=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString),root=project.appendingPathComponent("skin")
        try fm.createDirectory(at:root.appendingPathComponent("port"),withIntermediateDirectories:true);defer{try? fm.removeItem(at:project)}
        let app=try XCTUnwrap((input["nativeAppearances"] as? [String:String])?["port"])
        try XCTUnwrap(Data(base64Encoded:app)).write(to:root.appendingPathComponent("port/appearanceConfig"))
        let info=Data("SkinType=1\nSupportPlatform=I\n".utf8),token=Data("keep".utf8)
        try info.write(to:root.appendingPathComponent("Info.txt"));try token.write(to:root.appendingPathComponent("Token.txt"))
        XCTAssertEqual(try SingleGIFCompiler.panels(project),["port/ja","port/other"])
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:project,panel:root.appendingPathComponent("port/appearanceConfig")).contains("1080 px"))
        let gif=try SingleGIFCompiler.GIF(name:"a.gif",bytes:Data(base64Encoded:"R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")!)
        let output=try SingleGIFCompiler.compile(project:project,name:"test.bdi",backgrounds:["port/ja":"a.gif"],gifs:[gif])
        defer{try? fm.removeItem(at:output.folder.deletingLastPathComponent())}
        XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("port/appearanceConfig")),Data(base64Encoded:app))
        try SingleGIFCompiler.apply(output,to:project)
        XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("Info.txt")),info)
        XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("Token.txt")),token)
        XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("res/"+gif.name)),gif.bytes)
        XCTAssertFalse(try SingleGIFCompiler.files(project).contains{["bds","bdi"].contains($0.pathExtension)})
    }
    @MainActor func testJapaneseTextIsActuallyDrawnFromINIInBothRenderers() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer{try? fm.removeItem(at:root)}
        func pixels(_ canvas:some View)throws->Data {let output=ImageRenderer(content:canvas.frame(width:100,height:100));output.scale=1;return try XCTUnwrap(output.uiImage?.pngData())}
        for orientation in ["port","land"] {
            let folder=root.appendingPathComponent(orientation),css=folder.appendingPathComponent("res/default.css")
            try fm.createDirectory(at:css.deletingLastPathComponent(),withIntermediateDirectories:true)
            try "[STYLE701]\nSHOW=Q\nFONT_SIZE=40\nNM_COLOR=000000\n".write(to:css,atomically:true,encoding:.utf8)
            for (name,label) in [("ja","た"),("ja_shifts","タ")] {
                let file=folder.appendingPathComponent(name+".ini"),text="[PANEL]\nSIZE=100,100\n[KEY1]\nVIEW_RECT=0,0,100,100\nFORE_STYLE=701\nSHOW=\(label)\nCENTER=q\n"
                try text.write(to:file,atomically:true,encoding:.utf8)
                for native in [false,true] {
                    let app=folder.appendingPathComponent("appearanceConfig")
                    if native {
                        let value:[String:Any]=["textStyles":["701":["contentText":"Q","fontSize":40,"normalColor":4278190080]],"panels":[name:["keys":["KEY_Q":["foreStyles":[["type":2,"key":701]]]]]]]
                        try JSONSerialization.data(withJSONObject:value).write(to:app)
                    }else{try? fm.removeItem(at:app)}
                    let renderer=IniSkinRenderer();renderer.configure(root:root,config:file,files:try SingleGIFCompiler.files(root),text:text)
                    let index=try XCTUnwrap(renderer.effectiveSections.firstIndex{$0.name=="KEY1"})
                    let actual=try pixels(Canvas{context,_ in renderer.key(KeyShape(id:index,name:"KEY1",rect:CGRect(x:0,y:0,width:100,height:100),caption:label),pressed:false,context:&context)})
                    let expected=try pixels(Canvas{context,_ in context.draw(Text(label).font(.system(size:40)).foregroundColor(.black),at:CGPoint(x:50,y:50))})
                    XCTAssertEqual(actual,expected,"\(orientation)/\(name) native=\(native): INI kana not drawn")
                    let attachment=XCTAttachment(data:actual,uniformTypeIdentifier:"public.png");attachment.name="Kana-\(orientation)-\(name)-\(native)";attachment.lifetime = .keepAlways;add(attachment)
                }
                try? fm.removeItem(at:folder.appendingPathComponent("appearanceConfig"))
            }
        }
    }
}
