import XCTest
import ZIPFoundation
import UIKit
@testable import ToMina

final class SingleGIFTests: XCTestCase {
    func testCurrentSkinAtlasAndOriginalNamesSurviveCompileExportAndReimport() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer{try? fm.removeItem(at:root)}
        let res=root.appendingPathComponent("port/res")
        try fm.createDirectory(at:res,withIntermediateDirectories:true)
        let original:[String:String]=[
            "port/custom.ini":"[PANEL]\nSIZE=240,120\n[CAND]\nLAYOUT_NAME=我的顶栏.cnd\nVIEW_RECT=0,0,240,40\n[KEY1]\nVIEW_RECT=11,17,80,44\nTOUCH_RECT=9,15,84,48\nCENTER=q\nUP=w\nBACK_STYLE=1\n",
            "port/我的顶栏.cnd":"[CAND]\nBACK_STYLE=1\n[ICON1]\nKEY=F1\nVIEW_RECT=190,4,24,24\n",
            "port/res/default.css":"[STYLE1]\nNM_IMG=my-keys.png,1\n",
            "port/res/my-keys.til":"[IMG1]\nSOURCE_RECT=1,0,1,1\n",
            "Token.txt":"original-token-placeholder"
        ]
        for (path,text) in original {try Data(text.utf8).write(to:root.appendingPathComponent(path))}
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let atlas=UIGraphicsImageRenderer(size:CGSize(width:2,height:1),format:format).image { ctx in
            UIColor.red.setFill();ctx.fill(CGRect(x:0,y:0,width:1,height:1));UIColor.blue.setFill();ctx.fill(CGRect(x:1,y:0,width:1,height:1))
        }
        let atlasData=try XCTUnwrap(atlas.pngData());try atlasData.write(to:res.appendingPathComponent("my-keys.png"))
        let gif=try SingleGIFCompiler.GIF(name:"我的背景.gif",bytes:pixel)
        let output=try SingleGIFCompiler.compile(project:root,name:"原皮肤.bds",backgrounds:["port/custom.ini":gif.name],gifs:[gif],templates:["port":"invalid-template","resources":["foreign.png":"AA=="]])
        defer{try? fm.removeItem(at:output.folder.deletingLastPathComponent())}
        for (path,text) in original {XCTAssertEqual(try Data(contentsOf:output.folder.appendingPathComponent(path)),Data(text.utf8))}
        XCTAssertEqual(try Data(contentsOf:output.folder.appendingPathComponent("port/res/my-keys.png")),atlasData)
        XCTAssertFalse(fm.fileExists(atPath:output.folder.appendingPathComponent("port/res/foreign.png").path))
        let crop=try XCTUnwrap(atlas.cgImage?.cropping(to:CGRect(x:1,y:0,width:1,height:1)))
        let actualCrop=try XCTUnwrap(UIImage(contentsOfFile:output.folder.appendingPathComponent("port/res/mina_tile_port_my_keys_1.png").path)?.cgImage)
        func rgba(_ image:CGImage)->[UInt8] {
            var bytes=[UInt8](repeating:0,count:4)
            bytes.withUnsafeMutableBytes { pointer in
                let context=CGContext(data:pointer.baseAddress,width:1,height:1,bitsPerComponent:8,bytesPerRow:4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
                context.draw(image,in:CGRect(x:0,y:0,width:1,height:1))
            };return bytes
        }
        XCTAssertEqual(actualCrop.width,1);XCTAssertEqual(actualCrop.height,1);XCTAssertEqual(rgba(actualCrop),rgba(crop))
        XCTAssertEqual(try Data(contentsOf:output.folder.appendingPathComponent("res/我的背景.gif")),pixel)
        try fm.removeItem(at:output.folder.appendingPathComponent("bds_compile_backgrounds.json"))
        XCTAssertEqual(SingleGIFCompiler.background(output.folder.appendingPathComponent("port/custom.ini")),gif.name)
        let exportRoot=root.appendingPathComponent("export");try fm.createDirectory(at:exportRoot,withIntermediateDirectories:true)
        let archive=exportRoot.appendingPathComponent("原皮肤.bds"),reopened=exportRoot.appendingPathComponent("reopened")
        try fm.zipItem(at:output.folder,to:archive,shouldKeepParent:false);try fm.createDirectory(at:reopened,withIntermediateDirectories:true);try fm.unzipItem(at:archive,to:reopened)
        XCTAssertEqual(archive.lastPathComponent,"原皮肤.bds")
        for (path,text) in original {XCTAssertEqual(try Data(contentsOf:reopened.appendingPathComponent(path)),Data(text.utf8))}
        XCTAssertEqual(SingleGIFCompiler.background(reopened.appendingPathComponent("port/custom.ini")),gif.name)
        let conflict=root.appendingPathComponent("conflict.gif");try Data([1,2,3]).write(to:conflict)
        XCTAssertThrowsError(try SingleGIFCompiler.writeNewResource(conflict,bytes:pixel));XCTAssertEqual(try Data(contentsOf:conflict),Data([1,2,3]))
    }
    let pixel = Data(base64Encoded:"R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")!
    func fixture() throws -> [String:Any] {
        let url = try XCTUnwrap(Bundle(for:Self.self).url(forResource:"SingleGIFFixtures",withExtension:"json",subdirectory:"Fixtures"))
        return try XCTUnwrap(JSONSerialization.jsonObject(with:Data(contentsOf:url)) as? [String:Any])
    }
    func testJavaScriptCoreMatchesSharedExportFixtures() throws {
        let cases = try XCTUnwrap(fixture()["cases"] as? [[String:Any]])
        for item in cases {
            let input = try XCTUnwrap(item["input"] as? [String:Any])
            let result = try SingleGIFCompiler.evaluate(input)
            let actual = try XCTUnwrap(result["writes"] as? [String:String])
            let expected = try XCTUnwrap(item["expected"] as? [String:String])
            for (path,value) in expected { XCTAssertEqual(actual[path] ?? (input["existingAnimations"] as? [String:String])?[path.components(separatedBy:"/")[0]],value,"\(item["name"] ?? "") / \(path)") }
        }
    }
    func testGIFValidationPreservesBytesAndRejectsTruncation() throws {
        let gif = try SingleGIFCompiler.GIF(name:"pixel.gif",bytes:pixel)
        XCTAssertEqual(gif.width,1);XCTAssertEqual(gif.height,1);XCTAssertEqual(gif.bytes,pixel)
        XCTAssertEqual(gif.rid.count,21)
        XCTAssertThrowsError(try SingleGIFCompiler.GIF(name:"broken.gif",bytes:pixel.dropLast()))
        XCTAssertThrowsError(try SingleGIFCompiler.GIF(name:"text.gif",bytes:Data("not a gif".utf8)))
        var zero=pixel;zero[6]=0;zero[7]=0
        XCTAssertThrowsError(try SingleGIFCompiler.dimensions(zero))
    }
    func testWrappedCompileKeepsOriginalAndUsesDirectionalStyles() throws {
        let fm=FileManager.default,folder=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? fm.removeItem(at:folder) }
        let root=folder.appendingPathComponent("wrapped"),res=root.appendingPathComponent("port/res")
        try fm.createDirectory(at:res,withIntermediateDirectories:true)
        let ini="[PANEL]\nSIZE=100,100\n[KEY1]\nCENTER=q\nSHOW=た\nFORE_STYLE=701\nVIEW_RECT=0,0,100,100\n"
        let css="[STYLE701]\nSHOW=た\nFONT_SIZE=40\nNM_COLOR=000000\n"
        try ini.write(to:root.appendingPathComponent("port/ja.ini"),atomically:true,encoding:.utf8)
        try css.write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        try Data([1,2,3,4]).write(to:root.appendingPathComponent("scene"))
        let original=try Dictionary(uniqueKeysWithValues:SingleGIFCompiler.files(folder).map { ($0.path,try Data(contentsOf:$0)) })
        let gif=try SingleGIFCompiler.GIF(name:"pixel.gif",bytes:pixel)
        let output=try SingleGIFCompiler.compile(project:folder,name:"kana.bds",backgrounds:["gen":"pixel.gif"],gifs:[gif],templates:["port":"","land":"","resources":["keep.png":Data([9]).base64EncodedString()]])
        defer { try? fm.removeItem(at:output.folder.deletingLastPathComponent()) }
        let compiled=output.folder.appendingPathComponent("wrapped")
        XCTAssertFalse(try SingleGIFCompiler.files(output.folder.deletingLastPathComponent()).contains {$0.pathExtension=="bds"})
        XCTAssertEqual(try Data(contentsOf:compiled.appendingPathComponent("port/ja.ini")),Data(ini.utf8))
        XCTAssertEqual(try Data(contentsOf:compiled.appendingPathComponent("scene")),Data([1,2,3,4]))
        XCTAssertEqual(try Data(contentsOf:compiled.appendingPathComponent("res/"+gif.name)),pixel)
        XCTAssertTrue(try Data(contentsOf:compiled.appendingPathComponent("port/appearanceConfig")).range(of:Data("た".utf8)) != nil)
        XCTAssertTrue(fm.fileExists(atPath:compiled.appendingPathComponent("port/layoutConfig_ja").path))
        for (path,bytes) in original { XCTAssertEqual(try Data(contentsOf:URL(fileURLWithPath:path)),bytes) }
        try SingleGIFCompiler.apply(output,to:folder)
        XCTAssertEqual(try Data(contentsOf:root.appendingPathComponent("res/"+gif.name)),pixel)
        XCTAssertEqual(SingleGIFCompiler.background(root.appendingPathComponent("port/ja.ini")),gif.name)
        XCTAssertFalse(try SingleGIFCompiler.files(folder).contains {$0.pathExtension=="bds"})
        for (path,bytes) in original { XCTAssertEqual(try Data(contentsOf:URL(fileURLWithPath:path)),bytes) }

    }
    @MainActor func testSizeHintUsesCurrentINIIncludingGenAndInheritance() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString),port=root.appendingPathComponent("port")
        try fm.createDirectory(at:port,withIntermediateDirectories:true);defer{try? fm.removeItem(at:root)}
        let gen=port.appendingPathComponent("gen.ini"),ja=port.appendingPathComponent("ja.ini"),other=port.appendingPathComponent("other.ini")
        try "[PANEL]\nSIZE=240,120".write(to:gen,atomically:true,encoding:.utf8)
        try "[PANEL]\nSIZE=400,200".write(to:ja,atomically:true,encoding:.utf8)
        try "[PANEL]\nKEY_NUM=0".write(to:other,atomically:true,encoding:.utf8)
        XCTAssertEqual(try SingleGIFCompiler.sizeHint(project:root,panel:gen),"当前面板：port/gen.ini\n建议 GIF 尺寸：240 × 120 px（键盘）")
        XCTAssertEqual(try SingleGIFCompiler.sizeHint(project:root,panel:ja),"当前面板：port/ja.ini\n建议 GIF 尺寸：400 × 200 px（键盘）")
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:other).contains("240 × 120"))
    }
    func testApplyFailureRestoresCurrentProject() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try fm.createDirectory(at:root,withIntermediateDirectories:true);defer { try? fm.removeItem(at:root) }
        let marker=root.appendingPathComponent("original.txt");try Data("original".utf8).write(to:marker)
        let missing=root.deletingLastPathComponent().appendingPathComponent(UUID().uuidString)
        XCTAssertThrowsError(try SingleGIFCompiler.apply(.init(folder:missing,report:""),to:root))
        XCTAssertEqual(try Data(contentsOf:marker),Data("original".utf8))
    }
    func testMissingGIFFailsWithoutChangingInput() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? fm.removeItem(at:root) }
        try fm.createDirectory(at:root.appendingPathComponent("port"),withIntermediateDirectories:true)
        let file=root.appendingPathComponent("port/ja.ini"),original=Data("[PANEL]\nSIZE=10,10\n[KEY1]\nCENTER=た\nVIEW_RECT=0,0,10,10".utf8)
        try original.write(to:file)
        XCTAssertThrowsError(try SingleGIFCompiler.compile(project:root,name:"bad.bds",backgrounds:["gen":"missing.gif"],gifs:[],templates:["port":"","land":"","resources":[:]]))
        XCTAssertEqual(try SingleGIFCompiler.files(root),[file]);XCTAssertEqual(try Data(contentsOf:file),original)
        XCTAssertThrowsError(try SingleGIFCompiler.safe("../outside",root:root))
    }
    @MainActor func testKanaComesFromPackageShowAndCenterInBothOrientations() async throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? fm.removeItem(at:root) }
        for ori in ["port","land"] {
            let res=root.appendingPathComponent(ori+"/res")
            try fm.createDirectory(at:res,withIntermediateDirectories:true)
            for (name,label) in [("ja","た"),("ja_shifts","タ")] {
                try "[PANEL]\nSIZE=100,100\n[KEY1]\nVIEW_RECT=0,0,100,100\nSHOW=\(label)\nCENTER=q\nFORE_STYLE=701\n".write(to:root.appendingPathComponent(ori+"/"+name+".ini"),atomically:true,encoding:.utf8)
            }
            try "[STYLE701]\nFONT_SIZE=40\nNM_COLOR=000000\n".write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
        }
        let archive=root.deletingLastPathComponent().appendingPathComponent(UUID().uuidString+".bds")
        defer { try? fm.removeItem(at:archive) }
        try fm.zipItem(at:root,to:archive,shouldKeepParent:false)
        let store=SkinStore();await store.openArchive(archive)
        let project=try XCTUnwrap(store.root);defer { try? fm.removeItem(at:project) }
        for ori in ["port","land"] { for (name,label) in [("ja","た"),("ja_shifts","タ")] {
            try store.open(project.appendingPathComponent(ori+"/"+name+".ini"))
            XCTAssertEqual(store.keys.first(where:{$0.name=="KEY1"})?.caption,label)
        } }
        XCTAssertEqual(PreviewLabels.keyCaption(["CENTER":"て"]),"て")
        XCTAssertEqual(PreviewLabels.keyCaption(["CENTER":"q"]),"q")
        XCTAssertEqual(PreviewLabels.keyCaption(["SHOW":"","CENTER":"q"]),"")
        XCTAssertEqual(PreviewLabels.panel("ja_shifts.ini"),"日文 · 片假名")
    }
    @MainActor func testAutomaticScopeAndKeyboardSizeUseTheCurrentINI() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer{try? fm.removeItem(at:root)}
        let port=root.appendingPathComponent("wrapped/port")
        try fm.createDirectory(at:port,withIntermediateDirectories:true)
        let gen=port.appendingPathComponent("gen.ini"),panel=port.appendingPathComponent("py_26.ini"),bar=port.appendingPathComponent("bar.cnd")
        try "[PANEL]\nSIZE=240,120\n[CAND]\nLAYOUT_NAME=bar.cnd\nVIEW_RECT=0,0,240,40\n".write(to:gen,atomically:true,encoding:.utf8)
        try "[PANEL]\n[KEY1]\nVIEW_RECT=0,0,100,100\nCENTER=q\n".write(to:panel,atomically:true,encoding:.utf8)
        try "[CAND]\nBACK_STYLE=1\n".write(to:bar,atomically:true,encoding:.utf8)
        XCTAssertEqual(try SingleGIFCompiler.targetKey(project:root,panel:gen),"port/gen")
        XCTAssertEqual(try SingleGIFCompiler.targetKey(project:root,panel:panel),"port/py_26.ini")
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:gen).contains("240 × 120"))
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:panel).contains("240 × 120"))
        let base=try String(contentsOf:gen,encoding:.utf8)
        try (base+"[CAND]\nLAYOUT_NAME=second\nVIEW_RECT=0,0,240,64\n").write(to:gen,atomically:true,encoding:.utf8)
        try "[CAND]\n".write(to:port.appendingPathComponent("second.cnd"),atomically:true,encoding:.utf8)
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:panel).contains("240 × 120"))
        XCTAssertTrue(try SingleGIFCompiler.sizeHint(project:root,panel:panel,candidateChoice:"second").contains("240 × 120"))

    }

}
