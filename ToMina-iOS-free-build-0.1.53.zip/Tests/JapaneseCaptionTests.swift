import XCTest
import SwiftUI
import UIKit
@testable import ToMina

final class JapaneseCaptionTests:XCTestCase {
    @MainActor func testImageMissingAndLaterTextLayersRenderPackageKana() throws {
        let fm=FileManager.default,root=fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer{try? fm.removeItem(at:root)}
        func pixels(_ view:some View)throws->Data {
            let output=ImageRenderer(content:view.frame(width:100,height:100));output.scale=1
            return try XCTUnwrap(output.uiImage?.pngData())
        }
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let image=UIGraphicsImageRenderer(size:CGSize(width:100,height:100),format:format).image{c in
            UIColor.red.setFill();c.fill(CGRect(x:0,y:0,width:100,height:100))
        }
        let cg=try XCTUnwrap(image.cgImage),png=try XCTUnwrap(image.pngData())
        for orientation in ["port","land"] {for name in ["ja","ja_shifts"] {for native in [false,true] {
            let folder=root.appendingPathComponent(orientation),res=folder.appendingPathComponent("res")
            try fm.createDirectory(at:res,withIntermediateDirectories:true)
            try png.write(to:res.appendingPathComponent("glyph.png"))
            try "[IMG1]\nSOURCE_RECT=0,0,100,100\n".write(to:res.appendingPathComponent("glyph.til"),atomically:true,encoding:.utf8)
            for mode in ["image","missing","none","later","textStyle","function","english"] {
                let label=mode=="function" ? "F38":(name=="ja" ? "た":"タ")
                let panel=mode=="english" ? "en_26":name
                let ids=mode=="missing" ? "999":(mode=="none" ? "":(mode=="later" ? "1,2":"1"))
                let text="[PANEL]\nSIZE=100,100\n[KEY1]\nVIEW_RECT=0,0,100,100\nFORE_STYLE=\(ids)\nSHOW=\(label)\nCENTER=q\n"
                let file=folder.appendingPathComponent(panel+".ini")
                try text.write(to:file,atomically:true,encoding:.utf8)
                let css="[STYLE1]\nNM_IMG=glyph,1\nHL_IMG=glyph,1\nFONT_SIZE=42\nNM_COLOR=000000\nHL_COLOR=000000\n[STYLE2]\nSHOW=Q\nFONT_SIZE=42\nNM_COLOR=000000\nHL_COLOR=000000\n"
                try css.write(to:res.appendingPathComponent("default.css"),atomically:true,encoding:.utf8)
                let appearance=folder.appendingPathComponent("appearanceConfig")
                if native {
                    let refs:[[String:Any]]=ids.isEmpty ? []:ids.components(separatedBy:",").map{["type":$0=="1" ? 0:2,"key":Int($0)!]}
                    var key:[String:Any]=["contentText":"Q","foreStyles":refs]
                    if mode=="textStyle" {key["textStyle"]=["type":2,"key":2]}
                    let value:[String:Any]=["imageStyles":["1":["normalImage":["resource":["resourceID":"glyph.png"]]]],"textStyles":["2":["contentText":"Q","fontSize":42,"normalColor":4278190080,"highlightColor":4278190080]],"panels":[panel:["keys":["KEY_Q":key]]]]
                    try JSONSerialization.data(withJSONObject:value).write(to:appearance)
                } else {try? fm.removeItem(at:appearance)}
                let renderer=IniSkinRenderer();renderer.configure(root:root,config:file,files:try SingleGIFCompiler.files(root),text:text)
                let index=try XCTUnwrap(renderer.effectiveSections.firstIndex{$0.name=="KEY1"})
                let hasImage=mode=="later" || mode=="function" || mode=="english" || (native && mode=="textStyle")
                let hasText=mode != "function" && mode != "english"
                for pressed in [false,true] {
                    let actual=try pixels(Canvas{context,_ in renderer.key(KeyShape(id:index,name:"KEY1",rect:CGRect(x:0,y:0,width:100,height:100),caption:PreviewLabels.caption(label)),pressed:pressed,context:&context)})
                    let expected=try pixels(Canvas{context,_ in
                        if hasImage{context.draw(Image(decorative:cg,scale:1),in:CGRect(x:0,y:0,width:100,height:100))}
                        if hasText{context.draw(Text(label).font(.system(size:42)).foregroundColor(.black),at:CGPoint(x:50,y:50))}
                    })
                    XCTAssertEqual(actual,expected,"\(orientation)/\(panel) native=\(native), mode=\(mode), pressed=\(pressed)")
                    if orientation=="port" && name=="ja" && !pressed {
                        let proof=XCTAttachment(data:actual,uniformTypeIdentifier:"public.png");proof.name="Japanese-\(mode)-native-\(native)";proof.lifetime = .keepAlways;add(proof)
                    }
                }
            }
        }}}
    }
}
