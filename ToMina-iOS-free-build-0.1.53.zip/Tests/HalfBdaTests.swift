import XCTest
@testable import ToMina

final class HalfBdaTests:XCTestCase {
    private func fixture(_ root:URL,invalid:Bool=false) throws {
        let fm=FileManager.default
        try fm.createDirectory(at:root.appendingPathComponent("port"),withIntermediateDirectories:true)
        try fm.createDirectory(at:root.appendingPathComponent("res"),withIntermediateDirectories:true)
        try "[PANEL]\nSIZE=200,100\nBACK_STYLE=1".write(to:root.appendingPathComponent("port/gen.ini"),atomically:true,encoding:.utf8)
        try "[PANEL]\n[KEY1]\nCENTER=a\nVIEW_RECT=0,0,\(invalid ? "bad":"100"),100\nFORE_STYLE=2".write(to:root.appendingPathComponent("port/custom.ini"),atomically:true,encoding:.utf8)
        try "[STYLE1]\nNM_COLOR=ffffff\n[STYLE2]\nSHOW=A\nFONT_SIZE=40\nNM_COLOR=000000".write(to:root.appendingPathComponent("res/default.css"),atomically:true,encoding:.utf8)
        try Data([48,200,1,152,6,42]).write(to:root.appendingPathComponent("port/appearanceConfig"))
    }
    func testRefreshUpdatesNativeFilesAndPreservesOriginalUntilApplied() throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent("half-bda-tests-"+UUID().uuidString)
        defer {try? FileManager.default.removeItem(at:root)}
        try fixture(root)
        let binary=root.appendingPathComponent("port/appearanceConfig"),original=try Data(contentsOf:binary)
        let source=root.appendingPathComponent("port/custom.ini"),sourceData=try Data(contentsOf:source)
        let output=try SingleGIFCompiler.compile(project:root,name:"sample.bds",backgrounds:[:],gifs:[],refreshHalfBda:true)
        XCTAssertEqual(try Data(contentsOf:binary),original)
        XCTAssertTrue(FileManager.default.fileExists(atPath:output.folder.appendingPathComponent("port/layoutConfig_custom").path))
        try SingleGIFCompiler.apply(output,to:root)
        XCTAssertEqual(try Data(contentsOf:source),sourceData)
        var budget=0
        let fields=try BinaryPlaintext.parse(Array(Data(contentsOf:binary)),budget:&budget)
        XCTAssertEqual(fields.first(where:{$0.number==99})?.bits,42)
        let applied=try Data(contentsOf:binary)
        let again=try SingleGIFCompiler.compile(project:root,name:"sample.bds",backgrounds:[:],gifs:[],refreshHalfBda:true)
        XCTAssertEqual(try Data(contentsOf:again.folder.appendingPathComponent("port/appearanceConfig")),applied)
        try? FileManager.default.removeItem(at:again.folder.deletingLastPathComponent())
    }
    func testInvalidLayoutLeavesOriginalProjectUnchanged() throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent("half-bda-tests-"+UUID().uuidString)
        defer {try? FileManager.default.removeItem(at:root)}
        try fixture(root,invalid:true)
        let binary=root.appendingPathComponent("port/appearanceConfig"),original=try Data(contentsOf:binary)
        XCTAssertThrowsError(try SingleGIFCompiler.compile(project:root,name:"sample.bds",backgrounds:[:],gifs:[],refreshHalfBda:true))
        XCTAssertEqual(try Data(contentsOf:binary),original)
        XCTAssertFalse(FileManager.default.fileExists(atPath:root.appendingPathComponent("port/layoutConfig_custom").path))
    }
}
