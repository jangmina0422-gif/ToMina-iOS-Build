import XCTest
import ZIPFoundation
@testable import ToMina

final class HalfBdaUpdateTests: XCTestCase {
    let original=Data([48,184,8,152,6,42])
    let schemas:BdaTextSync.Schemas=["appearance":["6":["name":"designWidth","type":"number"]]]
    func folder() throws -> URL {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true);return root
    }
    @discardableResult func pair(_ root:URL,_ dir:String,_ ext:String="json",_ text:String="{\"designWidth\":1920}") throws -> URL {
        let parent=root.appendingPathComponent(dir)
        try FileManager.default.createDirectory(at:parent,withIntermediateDirectories:true)
        try original.write(to:parent.appendingPathComponent("appearanceConfig"))
        let file=parent.appendingPathComponent("appearanceConfig."+ext)
        try Data(text.utf8).write(to:file);return file
    }
    func update(_ root:URL,drafts:[URL:Data]=[:]) throws -> BdaTextSync.UpdateResult {
        try BdaTextSync.updateHalfBda(root:root,files:SingleGIFCompiler.files(root),drafts:drafts,schemas:schemas)
    }
    func testWholeProjectUpdatesRepeatAndExportRetainsUnknownFields() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"light/port");try pair(root,"dark/land","txt","{\"designWidth\":720}");try pair(root,"same","JSON","{\"designWidth\":1080}")
        let resource=root.appendingPathComponent("Token.txt"),resourceData=Data("unchanged-resource".utf8);try resourceData.write(to:resource)
        let result=try update(root);XCTAssertEqual(result.updated,2);XCTAssertEqual(result.unchanged,1)
        let binary=file.deletingPathExtension(),updated=try Data(contentsOf:binary)
        XCTAssertEqual(updated,Data([48,128,15,152,6,42]))
        let repeated=try update(root);XCTAssertEqual(repeated.updated,0);XCTAssertEqual(repeated.unchanged,3)
        let exportRoot=try folder();defer{try? FileManager.default.removeItem(at:exportRoot)}
        let archive=exportRoot.appendingPathComponent("edited.bda"),reopened=exportRoot.appendingPathComponent("reopened")
        try FileManager.default.zipItem(at:root,to:archive,shouldKeepParent:false)
        try FileManager.default.createDirectory(at:reopened,withIntermediateDirectories:true)
        try FileManager.default.unzipItem(at:archive,to:reopened)
        XCTAssertEqual(try Data(contentsOf:reopened.appendingPathComponent("light/port/appearanceConfig")),updated)
        XCTAssertEqual(try Data(contentsOf:reopened.appendingPathComponent("Token.txt")),resourceData)
    }
    func testInvalidLaterFileDoesNotCommitEarlierBinaryOrDraft() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"a-good","json","{\"designWidth\":1080}");try pair(root,"z-bad","txt","{bad")
        let before=try Data(contentsOf:file)
        XCTAssertThrowsError(try update(root,drafts:[file:Data("{\"designWidth\":1920}".utf8)])) { error in XCTAssertTrue(error.localizedDescription.contains("z-bad")) }
        XCTAssertEqual(try Data(contentsOf:file),before);XCTAssertEqual(try Data(contentsOf:file.deletingPathExtension()),original)
    }
    func testConflictMissingBinaryAndUnknownFieldsLeaveFilesIntact() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"port"),binary=file.deletingPathExtension(),conflict=file.deletingLastPathComponent().appendingPathComponent("APPEARANCECONFIG.TXT")
        try Data("{}".utf8).write(to:conflict)
        XCTAssertThrowsError(try update(root)) { XCTAssertTrue($0.localizedDescription.contains("冲突")) }
        XCTAssertEqual(try Data(contentsOf:binary),original);try FileManager.default.removeItem(at:conflict)
        try Data("{\"unknown\":1}".utf8).write(to:file)
        XCTAssertThrowsError(try update(root)) { XCTAssertTrue($0.localizedDescription.contains("未验证字段")) }
        XCTAssertEqual(try Data(contentsOf:binary),original);try FileManager.default.removeItem(at:binary)
        XCTAssertThrowsError(try update(root)) { XCTAssertTrue($0.localizedDescription.contains("缺少")) }
    }
    func testNoPairsReportsNothingToUpdate() throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        XCTAssertThrowsError(try update(root)) { XCTAssertTrue($0.localizedDescription.contains("未找到半 bda")) }
    }
    @MainActor func testToolCommitsUnsavedEditorDraftAndCanRepeat() async throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"port","json","{\"designWidth\":1080}"),store=SkinStore()
        store.root=root;store.filename="half.bda";store.files=try SingleGIFCompiler.files(root)
        try store.open(file);store.text="{\"designWidth\":1920}"
        XCTAssertTrue(store.canUpdateHalfBda)
        try await store.updateHalfBda(schemas:schemas)
        XCTAssertEqual(try String(contentsOf:file,encoding:.utf8),store.text)
        XCTAssertEqual(try Data(contentsOf:file.deletingPathExtension()),Data([48,128,15,152,6,42]))
        XCTAssertTrue(store.halfBdaReport.contains("已更新 1 个二进制"));XCTAssertFalse(store.busy)
        try await store.updateHalfBda(schemas:schemas)
        XCTAssertTrue(store.halfBdaReport.contains("已更新 0 个二进制，1 个已是最新"))
        store.filename="normal.bds";XCTAssertFalse(store.canUpdateHalfBda)
    }
    @MainActor func testFailedToolKeepsUnsavedDraftAndOldBinary() async throws {
        let root=try folder();defer{try? FileManager.default.removeItem(at:root)}
        let file=try pair(root,"port","json","{\"designWidth\":1080}"),store=SkinStore()
        store.root=root;store.filename="half.bda";store.files=try SingleGIFCompiler.files(root)
        try store.open(file);store.text="{broken"
        do{try await store.updateHalfBda(schemas:schemas);XCTFail("Invalid JSON accepted")}catch{}
        XCTAssertEqual(store.text,"{broken");XCTAssertEqual(try Data(contentsOf:file.deletingPathExtension()),original)
        XCTAssertEqual(try String(contentsOf:file,encoding:.utf8),"{\"designWidth\":1080}")
        XCTAssertTrue(store.halfBdaReport.contains("更新未完成"));XCTAssertFalse(store.busy)
    }
}
