#if DEBUG
import Foundation
enum PreviewTestFixtures {
    static func archive(_ name: String) throws -> URL {
        throw SkinFailure(message: "Private skin samples are available only in the local delivery package")
    }
}
#endif
