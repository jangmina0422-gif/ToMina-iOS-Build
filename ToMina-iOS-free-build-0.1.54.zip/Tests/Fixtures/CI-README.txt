Editor tests use generated geometry and solid-colour images. Private sample archives and artwork are excluded.
