import SwiftUI
import UniformTypeIdentifiers

struct SingleGIFToolView: View {
    @ObservedObject var store: SkinStore
    @Binding var transferActive: Bool
    @State private var gifs: [SingleGIFCompiler.GIF] = []
    @State private var backgrounds: [String:String] = [:]
    @State private var panels: [String] = []
    @State private var importing = false
    @State private var sizePrompt = false
    @State private var sizeHint = ""
    let applied: () -> Void
    @State private var report = ""
    @State private var working = false
    var body: some View {
        Form {
            SwiftUI.Section {
                Text("为安卓百度 BDS 面板设置完整 GIF 背景，保留图片原尺寸。应用后回到预览；需要导出时使用菜单。").font(.footnote)
                Button("添加 GIF") {
                    do { try store.save();if let root=store.root { sizeHint=try SingleGIFCompiler.sizeHint(project:root,panel:store.currentINIPanel);sizePrompt=true } } catch { report=error.localizedDescription }
                }.accessibilityIdentifier("singleGIF.add")
                Text("已添加 \(gifs.count) 张 GIF").font(.footnote)
                selector("通用背景", "gen")
                selector("竖屏默认背景", "port/gen")
                selector("横屏默认背景", "land/gen")
            }
            SwiftUI.Section {
                DisclosureGroup("按面板设置（\(panels.count)）") {
                    ForEach(panels,id:\.self) { panel in selector(panel,panel) }
                }
            }
            SwiftUI.Section {
                Button("应用为背景") { compile() }.disabled(backgrounds.isEmpty || panels.isEmpty).accessibilityIdentifier("singleGIF.compile")
                if working { ProgressView("正在编译…") }
                if !report.isEmpty { Text(report).font(.footnote).textSelection(.enabled) }
            }
        }.disabled(working).navigationTitle("单 GIF 动态背景").navigationBarBackButtonHidden(working)
            .interactiveDismissDisabled(working || importing)
            .onChange(of:importing) { _,_ in transferActive=importing }
            .onDisappear { transferActive=false }
            .task {
                if let root=store.root { do { panels=try SingleGIFCompiler.panels(root) } catch { report=error.localizedDescription } }
                #if DEBUG
                if ProcessInfo.processInfo.arguments.contains("--single-gif-tool-fixture"),gifs.isEmpty,let data=Data(base64Encoded:"R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"),let gif=try? SingleGIFCompiler.GIF(name:"test.gif",bytes:data) { gifs=[gif];backgrounds=["gen":"test.gif"] }
                #endif
            }
            .alert("GIF 建议尺寸",isPresented:$sizePrompt) {
                Button("继续选择 GIF") { importing=true }
                Button("取消",role:.cancel) {}
            } message: { Text(sizeHint) }
            .sheet(isPresented:$importing) {
                SkinDocumentPicker(contentTypes:[.gif],asCopy:true,title:"选择 GIF") { result in
                    importing=false
                    do {
                        guard let url=try result.get() else { return }
                        let access=url.startAccessingSecurityScopedResource();defer { if access { url.stopAccessingSecurityScopedResource() } }
                        guard (try url.resourceValues(forKeys:[.fileSizeKey]).fileSize ?? Int.max) <= 32*1024*1024 else { throw SkinFailure(message:"GIF 超过 32 MB") }
                        let bytes=try Data(contentsOf:url)
                        guard gifs.reduce(bytes.count,{$0+$1.bytes.count}) <= 128*1024*1024 else { throw SkinFailure(message:"所选 GIF 总量超过 128 MB") }
                        let original=url.deletingPathExtension().lastPathComponent
                        var name=original+".gif", n=2
                        while gifs.contains(where:{$0.name==name}) { name=original+" (\(n)).gif";n+=1 }
                        gifs.append(try SingleGIFCompiler.GIF(name:name,bytes:bytes))
                    } catch { report=error.localizedDescription }
                }
            }
    }

    private func selector(_ title:String,_ key:String) -> some View {
        Picker(title,selection:Binding(get:{backgrounds[key] ?? ""},set:{if $0.isEmpty { backgrounds.removeValue(forKey:key) } else { backgrounds[key]=$0 }})) {
            Text(key=="gen" ? "不设置":"继承通用 / 方向背景").tag("")
            ForEach(gifs) { gif in Text(gif.name).tag(gif.name) }
        }
    }
    private func compile() {
        guard let root=store.root, !working else { return }
        do { guard store.saveAnimationSource() else { return };try store.save() } catch { report=error.localizedDescription;return }
        let assets=gifs, mapping=backgrounds, name=store.filename
        working=true;store.busy=true
        Task {
            defer { working=false;store.busy=false }
            do {
                let result=try await Task.detached(priority:.userInitiated) { let result=try SingleGIFCompiler.compile(project:root,name:name,backgrounds:mapping,gifs:assets);try SingleGIFCompiler.apply(result,to:root);return result }.value
                report="背景已应用到当前工程。需要导出时，请使用菜单 → 导出。\n\n"+result.report
                store.rescan();applied()
            } catch { report="编译未完成："+error.localizedDescription }
        }
    }
}
