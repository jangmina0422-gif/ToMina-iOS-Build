import SwiftUI
import UniformTypeIdentifiers

struct SingleGIFToolView: View {
    @ObservedObject var store: SkinStore
    @Binding var transferActive: Bool
    @State private var gifs: [SingleGIFCompiler.GIF] = []
    @State private var backgrounds: [String:String] = [:]
    @State private var panels: [String] = []
    @State private var importing = false
    @State private var exporting = false
    @State private var output: SingleGIFCompiler.Output?
    @State private var report = ""
    @State private var working = false
    var body: some View {
        Form {
            SwiftUI.Section {
                Text("为每个面板绑定一张完整 GIF，生成安卓百度 BDS。图片保持原尺寸；导出新的编译副本。").font(.footnote)
                Button("添加 GIF") { importing = true }.accessibilityIdentifier("singleGIF.add")
                Text("已添加 \(gifs.count) 张 GIF").font(.footnote)
                selector("通用背景", "gen")
                selector("竖屏默认背景", "port/gen")
                selector("横屏默认背景", "land/gen")
            }
            SwiftUI.Section {
                DisclosureGroup("按面板设置（\(panels.count)）") {
                    ForEach(panels,id:\.self) { panel in selector(panel,panel) }
                }
            }
            SwiftUI.Section {
                Button("编译并导出 BDS") { compile() }.disabled(backgrounds.isEmpty || panels.isEmpty).accessibilityIdentifier("singleGIF.compile")
                if working { ProgressView("正在编译…") }
                if output != nil { Button("再次导出") { exporting = true } }
                if !report.isEmpty { Text(report).font(.footnote).textSelection(.enabled) }
            }
        }.disabled(working).navigationTitle("单 GIF 动态背景").navigationBarBackButtonHidden(working)
            .interactiveDismissDisabled(working || importing || exporting)
            .onChange(of:importing) { _,_ in transferActive=importing || exporting }
            .onChange(of:exporting) { _,_ in transferActive=importing || exporting }
            .onDisappear { transferActive=false }
            .task { if let root=store.root { do { panels=try SingleGIFCompiler.panels(root) } catch { report=error.localizedDescription } } }
            .sheet(isPresented:$importing) {
                SkinDocumentPicker(contentTypes:[.gif],asCopy:true,title:"选择 GIF") { result in
                    importing=false
                    do {
                        guard let url=try result.get() else { return }
                        let access=url.startAccessingSecurityScopedResource();defer { if access { url.stopAccessingSecurityScopedResource() } }
                        guard (try url.resourceValues(forKeys:[.fileSizeKey]).fileSize ?? Int.max) <= 32*1024*1024 else { throw SkinFailure(message:"GIF 超过 32 MB") }
                        let bytes=try Data(contentsOf:url)
                        guard gifs.reduce(bytes.count,{$0+$1.bytes.count}) <= 128*1024*1024 else { throw SkinFailure(message:"所选 GIF 总量超过 128 MB") }
                        let original=url.deletingPathExtension().lastPathComponent
                        var name=original+".gif", n=2
                        while gifs.contains(where:{$0.name==name}) { name=original+" (\(n)).gif";n+=1 }
                        gifs.append(try SingleGIFCompiler.GIF(name:name,bytes:bytes))
                    } catch { report=error.localizedDescription }
                }
            }
            .sheet(isPresented:$exporting) {
                if let output { SkinDocumentPicker(contentTypes:[.item],asCopy:true,exporting:output.file,title:"保存编译 BDS") { result in
                    exporting=false
                    do { if try result.get() != nil { report=output.report+"\n\nBDS 已导出。" } } catch { report=error.localizedDescription }
                } }
            }
    }
    private func selector(_ title:String,_ key:String) -> some View {
        Picker(title,selection:Binding(get:{backgrounds[key] ?? ""},set:{if $0.isEmpty { backgrounds.removeValue(forKey:key) } else { backgrounds[key]=$0 }})) {
            Text(key=="gen" ? "不设置":"继承通用 / 方向背景").tag("")
            ForEach(gifs) { gif in Text(gif.name).tag(gif.name) }
        }
    }
    private func compile() {
        guard let root=store.root, !working else { return }
        do { guard store.saveAnimationSource() else { return };try store.save() } catch { report=error.localizedDescription;return }
        let assets=gifs, mapping=backgrounds, name=store.filename
        working=true;store.busy=true
        Task {
            defer { working=false;store.busy=false }
            do {
                let result=try await Task.detached(priority:.userInitiated) { try SingleGIFCompiler.compile(project:root,name:name,backgrounds:mapping,gifs:assets) }.value
                if let previous=output { try? FileManager.default.removeItem(at:previous.file.deletingLastPathComponent()) }
                output=result;report=result.report;exporting=true
            } catch { report="编译未完成："+error.localizedDescription }
        }
    }
}
