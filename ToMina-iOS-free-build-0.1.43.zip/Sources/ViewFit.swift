import Foundation
import JavaScriptCore

/// The engine is the same file shipped in Android assets. Native code owns all IO.
enum GlobalViewFit {
    struct TextFile {
        let original: Data
        let text: String
        let encoding: String.Encoding
        let bom: Data
        func encoded(_ value: String) throws -> Data {
            guard let bytes = value.data(using: encoding, allowLossyConversion: false) else {
                throw SkinFailure(message: "原文件编码不能保存贴合结果")
            }
            return bom + bytes
        }
    }
    struct Result {
        let report: String
        let changedFiles: Int
        let changedPaths: [String]
    }
    static func decode(_ data: Data) throws -> TextFile {
        let bom: Data, encoding: String.Encoding, body: Data
        if data.starts(with: [0xff, 0xfe]) { bom=Data([0xff,0xfe]); encoding = .utf16LittleEndian; body=data.dropFirst(2) }
        else if data.starts(with: [0xfe, 0xff]) { bom=Data([0xfe,0xff]); encoding = .utf16BigEndian; body=data.dropFirst(2) }
        else if data.starts(with: [0xef,0xbb,0xbf]) { bom=Data([0xef,0xbb,0xbf]); encoding = .utf8; body=data.dropFirst(3) }
        else { bom=Data(); body=data; encoding=String(data:data,encoding:.utf8) != nil ? .utf8 : SkinConfiguration.gb }
        guard let text=String(data:body,encoding:encoding), text.data(using:encoding,allowLossyConversion:false)==body else {
            throw SkinFailure(message: "编码无法无损往返，已保留原文件")
        }
        return TextFile(original:data,text:text,encoding:encoding,bom:bom)
    }
    static func child(_ path: String, root: URL) throws -> URL {
        let parts=path.replacingOccurrences(of:"\\",with:"/").components(separatedBy:"/")
        guard !path.hasPrefix("/"), !path.contains(":"), !path.contains("\0"), !parts.contains("..") else {
            throw SkinFailure(message:"贴合结果包含不安全路径")
        }
        let url=root.appendingPathComponent(path).resolvingSymlinksInPath()
        guard url.pathComponents.starts(with:root.resolvingSymlinksInPath().pathComponents), url != root else {
            throw SkinFailure(message:"贴合结果超出当前项目")
        }
        return url
    }
    static func evaluate(_ input: [String:Any], script: String? = nil) throws -> [String:Any] {
        let engine: String
        if let script { engine=script }
        else {
            guard let file=Bundle.main.url(forResource:"ViewFit",withExtension:"js") else { throw SkinFailure(message:"贴合组件缺失") }
            engine=try String(contentsOf:file,encoding:.utf8)
        }
        guard let context=JSContext() else { throw SkinFailure(message:"无法启动贴合组件") }
        context.evaluateScript(engine)
        guard context.exception == nil else { throw SkinFailure(message:"贴合组件加载失败") }
        let data=try JSONSerialization.data(withJSONObject:input,options:[.sortedKeys])
        context.setObject(String(decoding:data,as:UTF8.self),forKeyedSubscript:"viewFitInput" as NSString)
        let value=context.evaluateScript("JSON.stringify(ViewFit.run(JSON.parse(viewFitInput)))")
        guard context.exception == nil, let json=value?.toString(), let bytes=json.data(using:.utf8),
              let result=try JSONSerialization.jsonObject(with:bytes) as? [String:Any] else {
            throw SkinFailure(message:context.exception?.toString() ?? "贴合结果无效")
        }
        return result
    }
    static func report(_ result: [String:Any], proof: [[String:Any]]) -> String {
        let summary=result["summary"] as? [String:Int] ?? [:]
        var lines=["已处理 \(summary["processed",default:0]) · 无需处理 \(summary["unchanged",default:0]) · 无法确定 \(summary["uncertain",default:0])", "已写入并重新读取校验 \(proof.count) 个包内文件。", "编辑源代码、预览和导出均从这些文件加载。"]
        let reports=result["reports"] as? [[String:Any]] ?? []
        for (status,title) in [("processed","已处理"),("unchanged","无需处理"),("uncertain","无法确定 · 保留原文件")] {
            lines.append("\n"+title)
            for item in reports where item["status"] as? String == status {
                lines.append((item["path"] as? String ?? "")+"\n"+(item["reason"] as? String ?? ""))
                if let verified=proof.first(where:{$0["path"] as? String == item["path"] as? String}), let changes=verified["changes"] as? [String] {lines.append(contentsOf:changes.prefix(3))}
                if let notes=item["notes"] as? [String] { lines.append(contentsOf:notes) }
                lines.append("")
            }
        }
        return lines.joined(separator:"\n")
    }
    static func sourceChanges(_ before: String, _ after: String) -> [String] {
        let old=SkinConfiguration.parse(before), next=SkinConfiguration.parse(after)
        var lines:[String]=[]
        for (a,b) in zip(old,next) where a.name == b.name {
            for field in ["VIEW_RECT","POS_TYPE"] where a.values[field] != b.values[field] {
                lines.append("[\(b.name)] \(field)：\(a.values[field] ?? "未填写") → \(b.values[field] ?? "未填写")")
            }
        }
        return lines
    }
    @discardableResult static func apply(_ edits: [[String:Any]], root: URL, snapshot: [String:TextFile], write: (Data,URL) throws -> Void = {try $0.write(to:$1,options:.atomic)}) throws -> [[String:Any]] {
        var pending:[URL:Data]=[:], old:[URL:Data]=[:], written:[URL]=[]
        for (path,saved) in snapshot {
            guard try Data(contentsOf:child(path,root:root)) == saved.original else {throw SkinFailure(message:"检查期间文件发生变化，请重新执行："+path)}
        }
        for edit in edits {
            guard let path=edit["path"] as? String,let text=edit["text"] as? String,let saved=snapshot[path] else { throw SkinFailure(message:"贴合结果引用了未检查的文件") }
            let url=try child(path,root:root)
            guard try Data(contentsOf:url)==saved.original else { throw SkinFailure(message:"检查期间文件发生变化，请重新执行贴合") }
            guard pending[url]==nil else { throw SkinFailure(message:"贴合结果包含重复文件") }
            let bytes=try saved.encoded(text)
            guard bytes != saved.original else {throw SkinFailure(message:"结果没有实际源码修改："+path)}
            guard bytes.count<=2*1024*1024 else {throw SkinFailure(message:"贴合后单个配置超过 2 MB，未修改任何文件")}
            pending[url]=bytes; old[url]=saved.original
        }
        var proof:[[String:Any]]=[]
        do {
            for url in pending.keys.sorted(by:{$0.path<$1.path}) {
                // Record before the write so even a partially failed write is restored.
                written.append(url);try write(pending[url]!,url)
            }
            for edit in edits {
                let path=edit["path"] as! String,url=try child(path,root:root),actual=try Data(contentsOf:url)
                guard actual == pending[url] else {throw SkinFailure(message:"写入后源码校验失败："+path)}
                let readBack=try decode(actual)
                guard readBack.text == edit["text"] as? String else {throw SkinFailure(message:"重新读取的源码与修改结果不一致："+path)}
                proof.append(["path":path,"changes":sourceChanges(snapshot[path]!.text,readBack.text)])
            }
        } catch {
            var failed:[String]=[]
            for url in written.reversed() { do {try old[url]!.write(to:url,options:.atomic);guard try Data(contentsOf:url)==old[url] else {throw SkinFailure(message:"回退校验失败")}} catch {failed.append(url.lastPathComponent)} }
            if !failed.isEmpty { throw SkinFailure(message:"写入及回滚失败："+failed.joined(separator:", ")+"；请重新导入原包") }
            throw error
        }
        return proof
    }
    static func run(root: URL, operation: String = "fit") throws -> Result {
        let manager=FileManager.default
        guard let iterator=manager.enumerator(at:root,includingPropertiesForKeys:[.isRegularFileKey,.isSymbolicLinkKey]) else { throw SkinFailure(message:"当前项目不可读") }
        var snapshots:[String:TextFile]=[:], texts:[String:String]=[:], unreadable:[[String:String]]=[]
        var total=0, inventory:[String]=[]
        for case let file as URL in iterator {
            let info=try file.resourceValues(forKeys:[.isRegularFileKey,.isSymbolicLinkKey])
            let path=SkinConfiguration.relative(file,root:root), ext=file.pathExtension.lowercased()
            if info.isSymbolicLink == true { iterator.skipDescendants();unreadable.append(["path":path,"reason":"符号链接不属于可修改的包内文件"]);continue }
            guard info.isRegularFile == true else {continue}
            inventory.append(path)
            if (operation == "zeroPositionTypes" ? ["ini","cnd","pop","css","til"] : ["ini","cnd","pop"]).contains(ext) {
                do {
                    let data=try Data(contentsOf:file)
                    guard data.count<=2*1024*1024 else {throw SkinFailure(message:"配置超过 2 MB，保留原文件")}
                    total+=data.count
                    guard total<=24*1024*1024 else {throw SkinFailure(message:"配置总量超过 24 MB，请拆分项目后处理")}
                    let saved=try decode(data);snapshots[path]=saved;texts[path]=saved.text
                } catch { unreadable.append(["path":path,"reason":error.localizedDescription]) }
            }
        }
        guard total<=24*1024*1024 else {throw SkinFailure(message:"配置总量超过 24 MB，未修改任何文件")}
        let result=try evaluate(["files":texts,"unreadable":unreadable,"inventory":inventory,"operation":operation])
        let edits=result["edits"] as? [[String:Any]] ?? []
        let summary=result["summary"] as? [String:Int] ?? [:]
        guard summary["files"] == edits.count else {throw SkinFailure(message:"修改数量与结果不一致，未写入任何文件")}
        let proof=try apply(edits,root:root,snapshot:snapshots)
        return Result(report:report(result,proof:proof),changedFiles:proof.count,changedPaths:proof.compactMap{$0["path"] as? String})
    }
}
