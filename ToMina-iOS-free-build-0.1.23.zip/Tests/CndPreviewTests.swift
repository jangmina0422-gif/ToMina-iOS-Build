import XCTest
import SwiftUI
import UIKit
import ZIPFoundation
@testable import ToMina

final class CndPreviewTests: XCTestCase {
    @MainActor private func fixture(_ directory: URL) throws -> URL {
        let root = directory.appendingPathComponent("source"), port = root.appendingPathComponent("port"), res = port.appendingPathComponent("res")
        try FileManager.default.createDirectory(at: res, withIntermediateDirectories: true)
        try "[PANEL]\nSIZE=320,160\n[CAND]\nLAYOUT_NAME=all\nVIEW_RECT=0,0,320,80\n".write(to: port.appendingPathComponent("gen.ini"), atomically: true, encoding: .utf8)
        try "[PANEL]\n[KEY1]\nVIEW_RECT=10,10,32,32\nCENTER=q\n".write(to: port.appendingPathComponent("py_26.ini"), atomically: true, encoding: .utf8)
        var cnd = "[CAND]\nBACK_STYLE=3\nICON_NUM=4\n"
        for (index, persist, x, style) in [(1,1,10,1), (2,2,50,2), (3,0,90,1), (4,3,10,2)] {
            cnd += "[ICON\(index)]\nSIZE=32,32\nPOS=\(x),10\nANCHOR_TYPE=1\nPERSIST=\(persist)\nFORE_STYLE=\(style)\nKEY=F8\n"
        }
        try cnd.write(to: port.appendingPathComponent("all.cnd"), atomically: true, encoding: .utf8)
        try "[STYLE1]\nNM_IMG=atlas,1\n[STYLE2]\nNM_IMG=atlas,2\n[STYLE3]\nNM_COLOR=FFF0F0F0\n".write(to: res.appendingPathComponent("default.css"), atomically: true, encoding: .utf8)
        try "[IMG1]\nSOURCE_RECT=0,0,32,32\n[IMG2]\nSOURCE_RECT=32,0,32,32\n".write(to: res.appendingPathComponent("atlas.til"), atomically: true, encoding: .utf8)
        let format = UIGraphicsImageRendererFormat(); format.scale = 1
        let atlas = UIGraphicsImageRenderer(size: CGSize(width: 64, height: 32), format: format).image { canvas in
            UIColor.red.setFill(); canvas.fill(CGRect(x: 0, y: 0, width: 32, height: 32))
            UIColor.blue.setFill(); canvas.fill(CGRect(x: 32, y: 0, width: 32, height: 32))
        }
        try XCTUnwrap(atlas.pngData()).write(to: res.appendingPathComponent("atlas.png"))
        let archive = directory.appendingPathComponent("icons.bds")
        try FileManager.default.zipItem(at: root, to: archive, shouldKeepParent: false)
        return archive
    }
    @MainActor private func render(_ store: SkinStore) throws -> UIImage {
        let canvas = Canvas(rendersAsynchronously: false) { context, _ in
            context.fill(Path(CGRect(origin: .zero, size: store.panel)), with: .color(.white))
            store.renderer.background(size: store.panel, context: &context)
            for key in store.keys { store.renderer.key(key, pressed: false, context: &context) }
        }.frame(width: store.panel.width, height: store.panel.height)
        let renderer = ImageRenderer(content: canvas); renderer.scale = 1
        return try XCTUnwrap(renderer.uiImage)
    }
    private func rgb(_ image: UIImage, x: Int, y: Int) throws -> [UInt8] {
        let crop = try XCTUnwrap(image.cgImage?.cropping(to: CGRect(x: x, y: y, width: 1, height: 1)))
        var bytes = [UInt8](repeating: 0, count: 4)
        try bytes.withUnsafeMutableBytes { buffer in
            let context = try XCTUnwrap(CGContext(data: buffer.baseAddress, width: 1, height: 1, bitsPerComponent: 8, bytesPerRow: 4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue))
            context.draw(crop, in: CGRect(x: 0, y: 0, width: 1, height: 1))
        }
        return Array(bytes.prefix(3))
    }
    @MainActor func testAllCndIconsAndIndividualOverlappingTilesRender() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = SkinStore(); store.openArchive(try fixture(directory)); XCTAssertNil(store.error)
        let root = try XCTUnwrap(store.root)
        defer { try? FileManager.default.removeItem(at: root) }
        try store.open(root.appendingPathComponent("port/all.cnd"))
        XCTAssertEqual(store.panel, CGSize(width: 320, height: 80))
        XCTAssertEqual(store.renderer.cndIconNames, ["ICON1", "ICON2", "ICON3", "ICON4"])
        for candidates in [false, true] {
            store.renderer.hasCandidates = candidates; store.refresh()
            XCTAssertEqual(store.keys.map { $0.name }, ["ICON1", "ICON2", "ICON3", "ICON4"])
        }
        XCTAssertEqual(try rgb(render(store), x: 106, y: 26), [255,0,0], "PERSIST=0 icon was hidden")
        for (name, expected) in [("ICON1", [UInt8(255),0,0]), ("ICON4", [UInt8(0),0,255])] {
            store.renderer.cndIconChoice = name; store.refresh()
            XCTAssertEqual(store.keys.map { $0.name }, [name])
            XCTAssertEqual(store.keys.first?.rect, CGRect(x: 10, y: 10, width: 32, height: 32))
            let image = try render(store)
            XCTAssertEqual(try rgb(image, x: 26, y: 26), expected, "Overlapping icon cannot be inspected")
            let attachment = XCTAttachment(image: image); attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
        }
        store.renderer.cndIconChoice = ""; store.refresh()
        XCTAssertEqual(store.keys.count, 4)
    }
    @MainActor func testKeyboardCandidateConditionsAndLiveCndEdits() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = SkinStore(); store.openArchive(try fixture(directory)); XCTAssertNil(store.error)
        let root = try XCTUnwrap(store.root)
        defer { try? FileManager.default.removeItem(at: root) }
        let cnd = root.appendingPathComponent("port/all.cnd")
        let sections = SkinStore.parse(try String(contentsOf: cnd, encoding: .utf8))
        XCTAssertFalse(store.renderer.isCnd)
        XCTAssertEqual(sections.filter { CndPreview.isIcon($0) && store.renderer.visible($0) }.map { $0.name }, ["ICON1", "ICON4"])
        store.renderer.hasCandidates = true; store.refresh()
        XCTAssertEqual(sections.filter { CndPreview.isIcon($0) && store.renderer.visible($0) }.map { $0.name }, ["ICON2", "ICON4"])
        try store.open(cnd)
        store.renderer.cndIconChoice = "ICON3"; store.refresh()
        store.setParameter(section: "ICON3", key: "POS", value: "120,20")
        XCTAssertEqual(store.keys.first?.rect, CGRect(x: 120, y: 20, width: 32, height: 32))
        store.change("[CAND]\nICON_NUM=0\n")
        XCTAssertTrue(store.renderer.cndIconNames.isEmpty); XCTAssertTrue(store.keys.isEmpty)
        XCTAssertEqual(store.renderer.cndIconChoice, "")
        try store.open(root.appendingPathComponent("port/py_26.ini"))
        XCTAssertFalse(store.renderer.isCnd); XCTAssertFalse(store.keys.isEmpty)
    }
}
