import SwiftUI
import CryptoKit
import UniformTypeIdentifiers

@main struct ToMinaApp: App {
    var body: some Scene { WindowGroup { RootView().preferredColorScheme(.light) } }
}
enum MinaTheme {
    static let background = Color(red: 245/255, green: 245/255, blue: 243/255)
    static let ink = Color(red: 30/255, green: 30/255, blue: 30/255)
    static let muted = Color(red: 110/255, green: 110/255, blue: 110/255)
    static let button = Color(red: 233/255, green: 233/255, blue: 230/255)
}
struct MinaButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.system(size: 13)).foregroundStyle(MinaTheme.ink)
            .padding(.horizontal, 8).padding(.vertical, 5)
            .background(MinaTheme.button.opacity(configuration.isPressed ? 0.65 : 1))
            .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
struct MinaMenuLabel: View {
    let title: String
    var body: some View {
        Text(title).font(.system(size: 13)).foregroundStyle(Color.black)
            .padding(.horizontal, 8).padding(.vertical, 5)
            .background(MinaTheme.button)
            .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
struct MinaFlow:Layout {
    var spacing:CGFloat=6
    private func positions(_ subviews:Subviews,_ width:CGFloat)->([CGPoint],CGSize){
        var points:[CGPoint]=[],x:CGFloat=0,y:CGFloat=0,line:CGFloat=0,used:CGFloat=0
        for view in subviews{let size=view.sizeThatFits(.unspecified);if x>0 && x+size.width>width{y+=line+spacing;x=0;line=0};points.append(CGPoint(x:x,y:y));x+=size.width+spacing;used=max(used,x-spacing);line=max(line,size.height)}
        return(points,CGSize(width:min(width,used),height:y+line))
    }
    func sizeThatFits(proposal:ProposedViewSize,subviews:Subviews,cache:inout ())->CGSize{positions(subviews,proposal.width ?? 10000).1}
    func placeSubviews(in bounds:CGRect,proposal:ProposedViewSize,subviews:Subviews,cache:inout ()){let points=positions(subviews,bounds.width).0;for i in subviews.indices{subviews[i].place(at:CGPoint(x:bounds.minX+points[i].x,y:bounds.minY+points[i].y),proposal:.unspecified)}}
}
struct RootView: View {
    @Environment(\.scenePhase) private var phase
    @StateObject private var store = SkinStore()
    @State private var restoredOnce = false
    @State private var saveMessage = ""
    @State private var authenticated = false
    @State private var account = ""
    @State private var password = ""
    @AppStorage("rememberPassword") private var rememberPassword = false
    @State private var importing = false
    @State private var fileList = false
    @State private var fileSearch = ""
    @State private var selected = ""
    @State private var zoom: CGFloat = 1
    @State private var zoomBase: CGFloat = 1
    @State private var pan: CGSize = .zero
    @State private var panBase: CGSize = .zero
    @State private var sharing: ShareFile?
    @State private var editing = false
    @State private var parameter = "VIEW_RECT"
    @State private var deleteConfirmation = false
    @State private var pressedPreview = false
    @State private var showingTools = false
    @State private var colorInput = "#FF222222"
    @State private var colorResult = ""
    @State private var landscapeWidth = "1920"
    @State private var multi = false
    @State private var selection: [String] = []
    @State private var touchOverlay = false
    @State private var viewOverlay = false
    @State private var scaleDialog = false
    @State private var scaleFactor = "1.5"
    @State private var layoutDebug=false
    @State private var bdaPlaying=true
    @State private var bdaEpoch=Date()
    @State private var effectMode=""
    @State private var inspecting:ShareFile?
    @State private var resourceImport=false
    var body: some View {
        Group {
            if authenticated { editor }
            else {
                VStack(spacing: 16) {
                    Text("To.Mina").font(.system(size: 28, weight: .bold)).foregroundStyle(.black)
                    TextField("", text: $account, prompt: Text("账号").foregroundColor(.black)).keyboardType(.numberPad).textContentType(.username)
                        .foregroundStyle(.black).padding(14).background(MinaTheme.button).clipShape(RoundedRectangle(cornerRadius: 12))
                    SecureField("", text: $password, prompt: Text("密码").foregroundColor(.black)).textContentType(.password)
                        .foregroundStyle(.black).padding(14).background(MinaTheme.button).clipShape(RoundedRectangle(cornerRadius: 12))
                    Toggle("记住密码", isOn: $rememberPassword).foregroundStyle(.black)
                        .onChange(of: rememberPassword) { _, enabled in if !enabled { RememberedLogin.clear() } }
                    Button {
                        if Credentials.matches(account, password) {
                            if rememberPassword && !RememberedLogin.save(account: account, password: password) {
                                store.error = "密码未能保存，请重试"; return
                            }
                            if !rememberPassword { RememberedLogin.clear() }
                            password = ""; authenticated = true
                            if !restoredOnce {
                                restoredOnce = true
                                Task { do { if let state = try await store.restoreSession() { applySession(state) } } catch { store.error = "无法恢复原文件：" + error.localizedDescription } }
                            }
                        }
                        else { store.error = "账号或密码错误" }
                    } label: { Text("登录").font(.system(size: 16)).foregroundStyle(.black).frame(maxWidth: .infinity).padding(.vertical, 14).background(MinaTheme.button).clipShape(RoundedRectangle(cornerRadius: 12)) }.buttonStyle(.plain)
                }.textFieldStyle(.plain).font(.system(size: 16)).padding(28).frame(maxWidth: 420)
                    .onAppear {
                        if rememberPassword, let login = RememberedLogin.load() {
                            account = login["account"] ?? ""; password = login["password"] ?? ""
                        }
                    }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(MinaTheme.background.ignoresSafeArea()).foregroundStyle(MinaTheme.ink).tint(MinaTheme.ink)
        .preferredColorScheme(.light)
        .alert("提示", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button("确定") { store.error = nil }
        } message: { Text(store.error ?? "") }
        .onChange(of: phase) { _, new in
            if new == .background && !importing && !resourceImport {
                store.soundPreview.clear()
                store.saveAnimationSource()
                do { try store.save() } catch { store.error = error.localizedDescription }
                authenticated = false; password = ""
            }
        }
        .onChange(of:store.documentRevision){_, revision in
            if revision == store.resumeRevision, let state = store.restoredView { applySession(state); return }
            selected="";selection=[];effectMode="";pressedPreview=false;multi=false
            zoom=1;zoomBase=1;pan = .zero;panBase = .zero
        }
    }
    private var editor: some View {
        GeometryReader { available in
        VStack(spacing: 0) {
            HStack {
                Text("To.Mina").font(.system(size: 23, weight: .bold))
                Spacer()
                Menu {
                    Button("导入") { resourceImport = false; importing = true }
                    Button("导出") {
                        do { sharing = ShareFile(url: try store.export()) } catch { store.error = error.localizedDescription }
                    }.disabled(store.root == nil)
                    Button("工具箱") { showingTools = true }
                    Button("生成明文副本") { store.generatePlaintext() }.disabled(store.root == nil)
                    Text("版本 \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "未知") · 构建 \(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "未知")")
                } label: { MinaMenuLabel(title: "⋮") }.buttonStyle(.plain)
            }.padding(.horizontal, 14).padding(.top, 10).padding(.bottom, 8)
            HStack {
                Button(store.filename) { if store.root == nil { importing = true } else { fileList = true } }.font(.system(size: 14)).buttonStyle(.plain).lineLimit(1).padding(8)
                Spacer(minLength: 4)
                Text("\(PanelMetrics.dimension(store.panel.width)) × \(PanelMetrics.dimension(store.panel.height))").font(.system(size: 12)).foregroundStyle(MinaTheme.muted)
                Button("适配") { zoom = 1; zoomBase = 1; pan = .zero; panBase = .zero }.buttonStyle(MinaButtonStyle())
                Button("保存") { saveOriginal() }.buttonStyle(MinaButtonStyle()).disabled(store.root == nil || store.busy)
            }.padding(.horizontal, 14).padding(.bottom, 6)
            preview.frame(height: min(UIDevice.current.userInterfaceIdiom == .pad ? 320 : 264, max(64, available.size.height - 220))).clipped().background(Color(white: 0.90))
            VStack(alignment: .leading, spacing: 8) {
            HStack { Text(saveMessage.isEmpty ? store.previewNote : saveMessage).font(.system(size: 12)).foregroundStyle(MinaTheme.muted); Spacer() }
            if store.bda != nil { bdaControls }
            if let current = store.current {
                Text(store.relative(current)).font(.system(size: 12)).foregroundStyle(MinaTheme.muted).lineLimit(1)
                MinaFlow { editControls }
                if !selected.isEmpty { Text("[" + selected + "]").font(.caption).frame(maxWidth: .infinity, alignment: .leading)
                    if let section=store.renderer.effectiveSections.first(where:{$0.name==selected}),let action=section.values["CENTER"] ?? section.values["KEY"],PreviewLabels.function(action){Text("功能："+PreviewLabels.caption(action)+"（"+action+"）").font(.caption).foregroundStyle(MinaTheme.muted)}
                }
                if !effectMode.isEmpty {
                    AnimationControls(store:store,key:selected,floating:effectMode=="floating")
                    if store.animationText.isEmpty {Text("当前没有绑定的动画，请选择按键后绑定或添加动效。").font(.caption)}
                    TextEditor(text:$store.animationText).font(.system(size:14)).foregroundStyle(.black).padding(8).scrollContentBackground(.hidden).background(.white).clipShape(RoundedRectangle(cornerRadius:12))
                } else if editing {
                    TextEditor(text: Binding(get: { store.text }, set: { store.change($0) })).font(.system(size: 14)).foregroundStyle(MinaTheme.ink).padding(8).scrollContentBackground(.hidden).background(.white).clipShape(RoundedRectangle(cornerRadius: 12))
                    Button("保存") { saveOriginal() }.buttonStyle(MinaButtonStyle()).disabled(store.busy)
                } else {
                    if let section = SkinStore.parse(store.text).first(where: { $0.name == selected }) {
                        Menu {
                            ForEach(Array(Set(["VIEW_RECT", "TOUCH_RECT", "CENTER", "BACK_STYLE", "FORE_STYLE"] + Array(section.values.keys))).sorted(), id: \.self) { field in
                                Button(field) { parameter = field }
                            }
                        } label: { MinaMenuLabel(title: parameter + " ▾") }.buttonStyle(.plain)
                        TextField("参数值", text: Binding(get: {
                            SkinStore.parse(store.text).first(where: { $0.name == selected })?.values[parameter] ?? ""
                        }, set: { store.setParameter(section: selected, key: parameter, value: $0) }))
                        .textFieldStyle(.plain).foregroundStyle(.black).padding(12).background(MinaTheme.button).clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    Spacer()
                }
            } else { Spacer() }
            }.padding(.horizontal, 14).padding(.top, 4).padding(.bottom, 6).frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        }
        .disabled(store.busy)
        .overlay { if store.busy { ProgressView("正在处理原文件…").padding(20).background(MinaTheme.background).clipShape(RoundedRectangle(cornerRadius:12)) } }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.data, .item]) { result in
            if resourceImport {
                resourceImport=false
                do{try store.importResource(result.get())}catch{store.error=error.localizedDescription};return
            }
            switch result { case .success(let url): store.openArchive(url); case .failure(let e): store.error = e.localizedDescription }
        }
        .sheet(isPresented: $fileList) {
            NavigationStack {
                List(store.files.filter { fileSearch.isEmpty || store.relative($0).localizedCaseInsensitiveContains(fileSearch) }, id: \.self) { url in
                    Button(store.relative(url)) {
                        if !["ini","css","txt","json","til","cnd","pop","anim","ani"].contains(url.pathExtension.lowercased()){inspecting=ShareFile(url:url);return}
                        do { try store.open(url); fileList = false; editing = true } catch { store.error = error.localizedDescription; fileList = false }
                    }
                }.searchable(text:$fileSearch,prompt:"搜索文件").navigationTitle("文件").toolbar {
                    ToolbarItemGroup(placement:.topBarTrailing){
                    Button("添加资源"){fileList=false;resourceImport=true;importing=true}.disabled(store.bda != nil)
                    Button("关闭") { fileList = false }
                    }
                }
            }.preferredColorScheme(.light)
            .sheet(item:$inspecting){item in FileInspector(file:item.url,editable:store.bda==nil){store.rescan()}}
        }
        .sheet(item: $sharing) { ShareSheet(url: $0.url) }
        .sheet(isPresented: $showingTools) {
            NavigationStack {
                ScrollView {
                    VStack(alignment:.leading,spacing:16) {
                        Button("导出当前 VIEW 区域辅助线") {
                            do {let file=try PreviewGuides.export(store);showingTools=false;DispatchQueue.main.asyncAfter(deadline:.now()+0.3){sharing=ShareFile(url:file)}}catch{store.error=error.localizedDescription}
                        }.buttonStyle(MinaButtonStyle()).disabled(store.root==nil)
                        Text("颜色换算").font(.headline)
                        TextField("颜色",text:$colorInput).textFieldStyle(.plain).foregroundStyle(.black).padding(12).background(MinaTheme.button).clipShape(RoundedRectangle(cornerRadius:12))
                        Button("换算颜色") { do { colorResult = try SkinTools.color(colorInput) } catch { colorResult = error.localizedDescription } }.buttonStyle(MinaButtonStyle())
                        if !colorResult.isEmpty { Text(colorResult).foregroundStyle(.black).textSelection(.enabled) }
                        TextField("横屏宽度",text:$landscapeWidth).keyboardType(.numberPad).textFieldStyle(.plain).foregroundStyle(.black).padding(12).background(MinaTheme.button).clipShape(RoundedRectangle(cornerRadius:12))
                        Button { showingTools = false; store.convertLandscape(width:Int(landscapeWidth) ?? 0) } label: { Text("转横屏").frame(maxWidth:.infinity) }.buttonStyle(MinaButtonStyle()).disabled(!store.canConvert)
                        Button {
                            showingTools = false
                            do { sharing = ShareFile(url:try store.convertSystem()) } catch { store.error = error.localizedDescription }
                        } label: { Text("转系统").frame(maxWidth:.infinity) }.buttonStyle(MinaButtonStyle()).disabled(!store.canConvert)
                    }.padding(20)
                }.background(MinaTheme.background).navigationTitle("工具箱")
                    .toolbar { Button("关闭") { showingTools = false } }
            }.preferredColorScheme(.light).tint(.black)
        }
    }
    @ViewBuilder private var bdaControls: some View {
        MinaFlow { modeButtons }
        MinaFlow {
            Menu { ForEach(store.bda?.panels.keys.sorted() ?? [],id:\.self) { id in
                Button(id) { store.bda?.panelID=id;store.syncBda();selected="";zoom=1;zoomBase=1;pan = .zero;panBase = .zero }
            }} label:{MinaMenuLabel(title:store.bda?.panelID ?? "布局")}.buttonStyle(.plain)
            Button(bdaPlaying ? "暂停动画":"播放动画") { bdaPlaying.toggle();bdaEpoch=Date() }.buttonStyle(MinaButtonStyle())
            Menu {
                Button("自动"){store.bda?.animationChoice="";store.syncBda();bdaEpoch=Date()}
                ForEach(store.bda?.animations.indices.map{$0} ?? [],id:\.self){index in
                    Button((store.bda?.animations[index].id ?? "")+((store.bda?.animations[index].frames.isEmpty ?? true) ? " · 未支持播放":"")){store.bda?.animationChoice=store.bda?.animations[index].id ?? "";store.syncBda();bdaEpoch=Date()}
                }
            }label:{MinaMenuLabel(title:"动画")}.buttonStyle(.plain)
            Button("布局调试") { layoutDebug.toggle() }.buttonStyle(MinaButtonStyle())
            Button("解析日志") { store.error=store.bda?.log() }.buttonStyle(MinaButtonStyle())
        }
        if let item=store.bda?.panel?.items.first(where:{$0.id==selected}) {
            Text("\(item.id) · \(item.source) · \(String(format:"%.1f",item.confidence))").font(.caption).foregroundStyle(.black)
        }
    }
    private func finishEffects()->Bool {
        guard store.saveAnimationSource() else{return false}
        effectMode="";store.renderer.animationEnabled=false
        return true
    }
    @ViewBuilder private var modeButtons: some View {
        ForEach([("light","浅色"),("dark","深色")],id:\.0) { mode in
            Button(mode.1+(store.bdaColor==mode.0 ? " ✓":"")) { store.bdaColor=mode.0;store.reloadBda() }.buttonStyle(MinaButtonStyle())
        }
        ForEach([("port","竖屏"),("land","横屏")],id:\.0) { mode in
            Button(mode.1+(store.bdaOrientation==mode.0 ? " ✓":"")) { store.bdaOrientation=mode.0;store.reloadBda();zoom=1;zoomBase=1;pan = .zero;panBase = .zero }.buttonStyle(MinaButtonStyle())
        }
    }
    @ViewBuilder private var editControls: some View {
        if store.renderer.isCnd {
            Menu {
                Button("全部 ICON（\(store.renderer.cndIconNames.count)）") {
                    if finishEffects() { store.renderer.cndIconChoice = ""; store.refresh(); selected = "" }
                }
                ForEach(store.renderer.cndIconNames, id: \.self) { name in
                    Button(name) {
                        if finishEffects() { store.renderer.cndIconChoice = name; store.refresh(); selected = name }
                    }
                }
            } label: { MinaMenuLabel(title: store.renderer.cndIconChoice.isEmpty ? "全部 ICON（\(store.renderer.cndIconNames.count)）" : store.renderer.cndIconChoice) }.buttonStyle(.plain)
        }
        if store.bda == nil { Menu {
            ForEach(store.panelFiles,id:\.self) {file in Button(PreviewLabels.panel(file.lastPathComponent)+" · "+store.relative(file)) {if finishEffects(){do{try store.open(file);editing=false}catch{store.error=error.localizedDescription}}}}
        } label:{MinaMenuLabel(title:"面板")}.buttonStyle(.plain) }

        Button(editing ? "切换到画布" : "编辑源代码") { if store.saveAnimationSource(){effectMode="";store.renderer.animationEnabled=false;editing.toggle()} }.buttonStyle(MinaButtonStyle())
        Button(effectMode=="key" ? "退出动效":"动效预览") {
            if store.saveAnimationSource(){effectMode=effectMode=="key" ? "":"key";store.renderer.animationEnabled = !effectMode.isEmpty;store.loadAnimationSource(selected);store.renderer.trigger(selected)}
        }.buttonStyle(MinaButtonStyle()).disabled(store.bda != nil)
        Button(effectMode=="floating" ? "退出漂浮":"漂浮预览") {
            if store.saveAnimationSource(){effectMode=effectMode=="floating" ? "":"floating";store.renderer.animationEnabled=false;store.loadAnimationSource(selected,floating:true);store.renderer.restartFloating()}
        }.buttonStyle(MinaButtonStyle()).disabled(store.bda != nil)
        Menu {
            Toggle("音效",isOn:$store.soundEnabled)
            Button("撤销") { if finishEffects(){store.history(redo: false)} }.disabled(!store.canUndo)
            Button("重做") { if finishEffects(){store.history(redo: true)} }.disabled(!store.canRedo)
            Button(pressedPreview ? "显示普通态" : "显示按下态") { pressedPreview.toggle() }
            Button("检查当前文件") { store.error = store.checkLayout() }
            Menu("候选栏") {
                ForEach(store.renderer.candidateNames,id:\.self){name in Button(name){store.renderer.candidateChoice=name;store.refresh()}}
                Button(store.renderer.hasCandidates ? "无候选状态":"有候选状态"){store.renderer.hasCandidates.toggle();store.refresh()}
            }
            Button(touchOverlay ? "隐藏触控框":"显示触控框") { touchOverlay.toggle() }
            Button(viewOverlay ? "隐藏 VIEW 区域":"显示 VIEW 区域") { viewOverlay.toggle() }
            Button(multi ? "结束多选":"多选按键") { multi.toggle();selection=[] }
            Menu("批量 / 对齐") {
                Button("对齐所选按键左边缘") { if finishEffects(){store.batch(selection,operation:"left")} }
                Button("对齐所选按键上边缘") { if finishEffects(){store.batch(selection,operation:"top")} }
                Button("交换两个按键的位置") { if finishEffects(){store.batch(selection,operation:"swap")} }
                Button("当前布局等比缩放") { scaleDialog=true }
                Button("同步本文件数量声明") { if finishEffects(){store.change(SkinStore.updateCounts(store.text))} }
            }
            Button("添加按键") { if finishEffects(),let name = store.addKey() { selected = name; editing = false } }
            Button("复制按键") { if finishEffects(),let name = store.addKey(copy: selected) { selected = name; editing = false } }.disabled(!selected.hasPrefix("KEY"))
            Button("删除按键", role: .destructive) { deleteConfirmation = true }.disabled(!selected.hasPrefix("KEY"))
        } label: { MinaMenuLabel(title: "编辑操作") }.buttonStyle(.plain)
        .confirmationDialog("删除 [" + selected + "]？", isPresented: $deleteConfirmation, titleVisibility: .visible) {
            Button("删除", role: .destructive) { if finishEffects(){store.deleteKey(selected); selected = ""} }
        }
        .alert("缩放当前布局",isPresented:$scaleDialog) {
            TextField("倍数 0.1～5",text:$scaleFactor).keyboardType(.decimalPad)
            Button("缩放") { if finishEffects(){store.batch([],operation:"scale",factor:Double(scaleFactor) ?? 0)} }
            Button("取消",role:.cancel) {}
        }
    }
    private func sessionState() -> EditorViewState {
        var state = EditorViewState()
        state.selected = selected; state.selection = selection; state.editing = editing; state.multi = multi
        state.touch = touchOverlay; state.view = viewOverlay; state.pressed = pressedPreview; state.parameter = parameter
        state.effect = effectMode; state.event = store.renderer.animationEvent
        state.zoom = Double(zoom); state.panX = Double(pan.width); state.panY = Double(pan.height)
        state.color = store.bdaColor; state.orientation = store.bdaOrientation; state.panel = store.bda?.panelID ?? store.previewPanelName
        state.animation = store.bda?.animationChoice ?? ""; state.playing = bdaPlaying; state.debug = layoutDebug
        state.hasCandidates = store.renderer.hasCandidates; state.candidate = store.renderer.candidateChoice
        state.floating = store.renderer.floatingChoice; state.floatingPaused = store.renderer.floatingPausedAt != nil
        return state
    }
    private func applySession(_ state: EditorViewState) {
        selected = state.selected; selection = state.selection; editing = state.editing; multi = state.multi
        touchOverlay = state.touch; viewOverlay = state.view; pressedPreview = state.pressed; parameter = state.parameter; effectMode = state.effect
        zoom = CGFloat(min(8, max(0.25, state.zoom))); zoomBase = zoom
        pan = CGSize(width: state.panX, height: state.panY); panBase = pan
        bdaPlaying = state.playing; layoutDebug = state.debug; bdaEpoch = Date()
    }
    private func saveOriginal() {
        let state = sessionState()
        Task {
            do {
                try await store.saveSession(state); saveMessage = "已覆盖原文件"
                try? await Task.sleep(for: .seconds(3)); saveMessage = ""
            } catch { store.error = error.localizedDescription }
        }
    }
    private var preview: some View {
        TimelineView(.animation(minimumInterval:1.0/30,paused:(store.bda == nil || !bdaPlaying) && effectMode.isEmpty)) { timeline in
        GeometryReader { geometry in
            let minY=min(store.bda?.minY ?? (store.renderer.candidateFile == nil ? 0:-store.renderer.candidateSize.height),store.keys.map{$0.rect.minY}.min() ?? 0)
            let minX=min(0,store.keys.map{$0.rect.minX}.min() ?? 0)
            let width = max(store.panel.width, store.keys.map { $0.rect.maxX }.max() ?? 1)-minX
            let height = max(store.panel.height, store.keys.map { $0.rect.maxY }.max() ?? 1)-minY
            let fit = max(0.000001,min(max(1,geometry.size.width-16)/max(width,1), max(1,geometry.size.height-16)/max(height,1)))
            let scale = fit * zoom
            let origin = CGPoint(x: (geometry.size.width-width*scale)/2 + pan.width, y: (geometry.size.height-height*scale)/2 + pan.height)
            Canvas { context, _ in
                guard !store.blankPreview else { return }
                context.translateBy(x: origin.x, y: origin.y); context.scaleBy(x: scale, y: scale)
                context.translateBy(x:-minX,y:-minY)
                context.fill(Path(CGRect(origin: .zero, size: store.panel)), with: .color(.white))
                if let bda=store.bda {
                    bda.draw(context:&context,time:bdaPlaying ? timeline.date.timeIntervalSince(bdaEpoch):0,pressed:pressedPreview,debug:layoutDebug,scale:scale,playing:bdaPlaying)
                } else {
                store.renderer.background(size: store.panel, context: &context)
                store.renderer.candidate(context:&context)
                if effectMode=="floating" && store.renderer.floatingLevel<=0{store.renderer.floating(size:store.panel,ios:store.filename.lowercased().hasSuffix(".bdi"),context:&context)}
                for key in store.keys {
                    if store.renderer.hasStyles { store.renderer.key(key, pressed: pressedPreview, context: &context) } else {
                    context.stroke(Path(roundedRect: key.rect, cornerRadius: 5), with: .color(.gray), lineWidth: 1/max(scale,0.01))
                    context.draw(Text(key.caption).font(.system(size: min(36,key.rect.height*0.3))).foregroundColor(.black), at: CGPoint(x: key.rect.midX, y: key.rect.midY))
                    }
                    if touchOverlay, let section=SkinStore.parse(store.text).first(where:{$0.name==key.name}) {
                        let r=SkinStore.numbers(section.values["TOUCH_RECT"])
                        if r.count==4 { context.stroke(Path(CGRect(x:r[0],y:r[1],width:r[2],height:r[3])),with:.color(.gray),style:StrokeStyle(lineWidth:1/max(scale,0.01),dash:[5,3])) }
                    }
                    if selection.contains(key.name) || (!multi && selected==key.name) {
                        context.stroke(Path(key.rect),with:.color(.black),lineWidth:2/max(scale,0.01))
                    }
                }
                if effectMode=="floating" && store.renderer.floatingLevel>0{store.renderer.floating(size:store.panel,ios:store.filename.lowercased().hasSuffix(".bdi"),context:&context)}
                }
                if viewOverlay {PreviewGuides.draw(PreviewGuides.regions(store),scale:scale,context:&context)}
            }
            .contentShape(Rectangle())
            .gesture(MagnificationGesture().onChanged { zoom = min(8,max(0.25,zoomBase*$0)) }.onEnded { _ in zoomBase = zoom })
            .simultaneousGesture(DragGesture(minimumDistance: 6).onChanged { pan = CGSize(width: panBase.width+$0.translation.width, height: panBase.height+$0.translation.height) }.onEnded { _ in panBase = pan })
            .simultaneousGesture(SpatialTapGesture().onEnded { event in
                guard !store.blankPreview && !store.busy else { return }
                let p = CGPoint(x: (event.location.x-origin.x)/scale+minX, y: (event.location.y-origin.y)/scale+minY)
                if store.bda==nil,p.y<0,p.y >= -store.renderer.candidateSize.height,let file=store.renderer.candidateFile {
                    do{try store.open(file);editing=true}catch{store.error=error.localizedDescription};return
                }
                if let key = store.keys.reversed().first(where: { $0.rect.contains(p) }) {
                    store.pressSound(key.name)
                    if !effectMode.isEmpty {
                        guard store.saveAnimationSource() else{return}
                        store.loadAnimationSource(key.name,floating:effectMode=="floating");store.renderer.trigger(key.name)
                        if effectMode=="floating"{store.renderer.restartFloating()}
                    }
                    if let bda=store.bda { bda.triggerKey(key.name);bdaPlaying=true }
                    selected = key.name
                    if multi { if let i=selection.firstIndex(of:key.name) { selection.remove(at:i) } else { selection.append(key.name) } }
                }
            })
        }
        }
    }
}
struct ShareFile: Identifiable { let id = UUID(); let url: URL }
struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: [url], applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
